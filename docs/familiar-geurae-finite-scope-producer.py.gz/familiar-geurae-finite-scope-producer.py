"""Preserve completed independent audits and add one explicitly partial disposition."""
import gzip
import json
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
ROOT = BASE / 'familiar-geurae-prototype'
PREP = BASE / 'familiar-geurae-prepared'
DOCS = ROOT / 'docs'
for stem, count in [('source', 19), ('streams', 18), ('cohorts', 5), ('broad', 17), ('corpora', 10), ('browser', 19), ('historical-ledger', 73)]:
    name = stem + '-controls' + ('-retry1' if stem in ['broad', 'historical-ledger'] else '') + '.log'
    log = (PREP / name).read_text()
    assert f'Ran {count} tests' in log and log.rstrip().endswith('OK'), name
for name in ['source-audit.log', 'source-controls.log', 'streams-audit.log', 'streams-controls.log',
             'cohorts-audit.log', 'cohorts-controls.log', 'broad-audit.log', 'broad-controls-retry1.log',
             'corpora-audit.log', 'corpora-controls.log', 'browser-audit.log', 'browser-controls.log',
             'historical-ledger-controls-retry1.log', 'expanded-focused.log', 'expanded-clippy.log',
             'shared-ledger-tests-retry1.log', 'shared-ledger-append.log', 'focused-tests.log',
             'focused-tests-retry1.log', 'affected-tests.log', 'label-tests.log', 'frontend-build.log',
             'runtime-build.log', 'independent-authoring.log', 'full-native-preparation.log', 'source-preparation.log',
             'source-streams.log', 'native-closure.log', 'cohorts.log', 'corpora.log', 'broad.log']:
    (DOCS / ('familiar-geurae-' + name + '.gz')).write_bytes(gzip.compress((PREP / name).read_bytes(), mtime=0))
for name in ['prepare_sources.py', 'prepare_full_native.py', 'author_cases.py', 'capture_source_streams.py',
             'capture_native_closure.py', 'capture_cohorts.py', 'capture_corpora.py', 'capture_broad.py',
             'prepare_stream_audit.py', 'prepare_corpus_audits.py', 'prepare_browser_audit.py', 'restore_and_append_ledger.py']:
    (DOCS / ('familiar-geurae-' + name + '.gz')).write_bytes(gzip.compress((PREP / name).read_bytes(), mtime=0))
paragraph = ('One finite source-backed particle scope (83913) preserves every original note and all four '
             'complete example groups, including the full two-line group. Twenty-seven independently '
             'authored cases (19 required, eight forbidden) cover the original examples, explicit '
             'attachment boundaries and separately licensed written variants. Initial literal 구만 '
             'and the failed redundant-alias implementation are retained; the corrected implementation '
             'reuses existing ending.exclamation_variant without altering any linguistic target. '
             'Four Rust regressions check all 152 observed Source paths against 50 complete original '
             'Native owners and preserve every pre-change path/order. Six grammar-label tests and '
             'focused Clippy with warnings denied pass. Complete independent Source/stream/cohort/'
             'broad/gold/browser audits pass 19/18/5/17/10/19 corruption controls. All 53,502 cohort '
             'words and 66,570 original annotated rows remain exact; original gold outcomes and '
             'candidate statistics are independently rederived. Of 1,128,312 broad frames, all six '
             'nonspacing streams are byte-exact. The two spacing modes have 398 individually tracked '
             'internal probe-count changes on 12 surfaces; every candidate, assessment, display and '
             'spacing alternative remains exact. Browser proof passes 114 decisions/114 diagrams/six '
             'exact exports/50 full Native endpoints, with owned server stopped. The shared ledger '
             'retains its exact 35,457-case prefix and appends only the 27 authored cases: 35,484 total, '
             '31,263 required and 4,237 forbidden. Four ledger tests and 73 historical corruption '
             'controls pass. No observed alternative or diagnostic is promoted to contextual gold. '
             'Full Rust/Nix/installed/main integration, quiet timing and wider/contextual/independent '
             'linguistic review remain open.')
(DOCS / 'familiar-geurae-draft.md').write_text('# Familiar 그래 particle\n\nStatus: isolated source-backed prototype; main integration pending.\n\n' + paragraph + '\n\nThe particle uses the bare catalog key 그래 with source 83913 and remains separate from standalone interjection 27656 and 품사 없음 60238. Bare nouns, nominalized/connective/quoted bases and the distinct 그려 followers cannot borrow this finite particle license. Unknown alternatives remain visible.\n')
p = DOCS / 'coverage-checklist.md'
text = p.read_text()
assert 'COV-017cu —' not in text
marker = '- [ ] **COV-018 —'
assert text.count(marker) == 1
text = text.replace(marker, '- [ ] **COV-017cu — Familiar final particle 그래 and existing 구만 variants.**\n  **Partial: isolated source-backed prototype; main integration pending.**\n  ' + paragraph + '\n  [Finite scope and retained evidence](familiar-geurae-draft.md).\n\n' + marker)
p.write_text(text)
p = DOCS / 'inventory-reviews.json'
reviews = json.loads(p.read_text())
queue = json.loads((DOCS / 'inventory-review-queue.json').read_text())
source = next(row for row in queue['entries'] if row['source']['id'] == 'krdict:83913')
assert source['review']['status'] == 'unreviewed' and not any(e['id'] == 'krdict:83913' for e in reviews['entries'])
suite = json.loads((ROOT / 'tests/fixtures/familiar-geurae-validity.json').read_text())
evidence = [{'path': 'docs/familiar-geurae-draft.md'}, {'path': 'tests/familiar_geurae.rs'},
            {'path': 'tests/fixtures/familiar-geurae-validity.json'}, {'path': 'tests/fixtures/familiar-geurae-additional-native.json'},
            {'path': 'docs/familiar-geurae-source-preparation.json.gz'}, {'path': 'docs/familiar-geurae-full-native-preparation.json.gz'},
            {'path': 'docs/familiar-geurae-original-source-proposals.json.gz'}, {'path': 'docs/familiar-geurae-canonical-guman-decision.json.gz'},
            {'path': 'docs/familiar-geurae-existing-variant-rule-correction.json.gz'}, {'path': 'docs/familiar-geurae-source-streams.json.gz'},
            {'path': 'docs/familiar-geurae-native-closure.json.gz'}, {'path': 'docs/familiar-geurae-cohorts.json.gz'},
            {'path': 'docs/familiar-geurae-corpora.json.gz'}, {'path': 'docs/familiar-geurae-broad.json.gz'},
            {'path': 'docs/familiar-geurae-spacing-probe-diagnostics.json.gz'}, {'path': 'docs/familiar-geurae-closure-browser.json.gz'},
            {'path': 'docs/familiar-geurae-shared-ledger-append.json.gz'}]
for family in ['source', 'streams', 'cohort', 'broad', 'corpora', 'browser']:
    evidence.extend({'path': f'tools/{prefix}familiar_geurae_{family}_audit.py'} for prefix in ['', 'test_'])
assert all((ROOT / item['path']).exists() for item in evidence)
judgments = [{'case': case['id'], 'judgment': j['id']} for case in suite['cases'] for j in case['judgments'] if j['source'] == 'particle']
assert len(judgments) == 22
reviews['entries'].append({'id': 'krdict:83913', 'source_sha256': source['source_sha256'], 'status': 'scoped',
                          'checklist': ['COV-017cu'], 'scope': paragraph,
                          'remaining': 'Full Rust/Nix/installed/main integration; quiet novel timing; wider attachment licenses, contextual homonym selection and independent linguistic review.',
                          'evidence': evidence, 'judgments': judgments})
p.write_text(json.dumps(reviews, ensure_ascii=False, indent=2) + '\n')
p = ROOT / 'flake.nix'
text = p.read_text()
files = ''.join(f'                ./tools/{prefix}familiar_geurae_{family}_audit.py\n' for family in ['source', 'streams', 'cohort', 'broad', 'corpora', 'browser'] for prefix in ['', 'test_'])
commands = ''.join(f"            python tools/familiar_geurae_{family}_audit.py\n            python -m unittest discover -s tools -p 'test_familiar_geurae_{family}_audit.py'\n" for family in ['source', 'streams', 'cohort', 'broad', 'corpora', 'browser'])
file_marker = '                ./tools/test_explanatory_se_installed_audit.py\n'
command_marker = "            python -m unittest discover -s tools -p 'test_explanatory_se_installed_audit.py'\n"
assert text.count(file_marker) == text.count(command_marker) == 1 and 'familiar_geurae_source_audit.py' not in text
p.write_text(text.replace(file_marker, file_marker + files).replace(command_marker, command_marker + commands))
(DOCS / 'familiar-geurae-finite-scope-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('Added one explicitly partial source disposition and six Nix audit families; regenerate queue last', flush=True)
