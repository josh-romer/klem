"""Run the complete new integration suite with its source and artifacts frozen."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-gentle-command')
OUT = PREP / 'gentle-command-merged-full-rust.json'
LOG = PREP / 'gentle-command-merged-full-rust.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [WORK / name for name in subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=WORK).decode().split('\0')[:-1]]
files.append(Path(__file__))
frozen = {str(path): sha(path) for path in sorted(set(files))}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
index = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest()
command = ['cargo', 'test', '--locked', '--offline', '--features', 'web']
env = dict(os.environ, CARGO_TARGET_DIR='/home/josh/projects/klem/.direnv/gentle-command-target',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2')
r = {'state': 'running', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': os.getpid(),
     'head': head, 'index_sha256': index, 'frozen_inputs': frozen, 'command': command,
     'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
     'scope': 'Actual complete merged gentle-command/willingness interaction Rust suite at its committed captured HEAD. Exact35681active cases and515reviews plus23privategentle-command cases, all original Native/source/baseline histories retained. Merged72auditcontrols/35affectedRust, formatting and focused Clippy passed. All tracked source/proof/frontend/examples/license bytes plus HEAD/index stay frozen throughout. New full Nix/installed browser/source-distribution/main/quiet timing/contextual and independent Korean review remain separate.'}
OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
with LOG.open('xb') as stream:
    job = subprocess.run(command, cwd=WORK, env=env, stdout=stream, stderr=subprocess.STDOUT)
batches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', LOG.read_text())
totals = {key: sum(int(batch[i + 1]) for batch in batches) for i, key in enumerate(['passed', 'failed', 'ignored'])}
unchanged = all(sha(Path(path)) == digest for path, digest in frozen.items())
head_same = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == head
index_same = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest() == index
complete = bool(batches) and len(batches) == 253 and totals == {'passed': 1182, 'failed': 0, 'ignored': 1} and all(batch[0] == 'ok' for batch in batches)
r.update(state='passed' if job.returncode == 0 and complete and unchanged and head_same and index_same else 'failed',
         exit_code=job.returncode, inputs_unchanged=unchanged, head_unchanged=head_same, index_unchanged=index_same,
         totals=totals, batches=len(batches), log_sha256=sha(LOG), finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
print(r['state'], totals, len(batches), 'batches; Sourcefiles', len(frozen), 'unchanged', unchanged, flush=True)
raise SystemExit(0 if r['state'] == 'passed' else 1)
