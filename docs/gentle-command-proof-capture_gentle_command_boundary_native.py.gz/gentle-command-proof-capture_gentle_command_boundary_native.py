"""Capture all additional lexical owners used by the preauthored boundary cases."""
import gzip,hashlib,json,sqlite3,sys
from pathlib import Path
prep=Path(__file__).resolve().parent;root=Path('/home/josh/projects/klem');work=Path('/tmp/klem-gentle-command');out=prep/'gentle-command-boundary-native-closure.json.gz';assert not out.exists()
sys.path.insert(0,str(root/'tools'));from native_lmf import entry,feature
old=json.loads((prep/'gentle-command-native-entries.json').read_bytes());suite=json.loads((work/'tests/fixtures/gentle-command-validity.json').read_bytes())
heads=sorted({lemma for case in suite['cases'] for j in case['judgments'] for lemma in j['lemmas']} - {e['headword'] for e in old.values()});assert heads==['돕다','듣다','먹다','살다']
expected={}
with sqlite3.connect((root/'.direnv/dictionary-restoration/krdict.db').resolve().as_uri()+'?mode=ro',uri=True) as db:
 for head in heads:
  rows=list(db.execute('SELECT data FROM entries WHERE headword=?',(head,)));assert rows,head
  for (raw,) in rows:
   e=json.loads(raw)
   if e['lexical_unit']=='단어':expected[e['id']]=e
assert not (old.keys() & expected.keys())
originals={};exports={};sha=lambda raw:hashlib.sha256(raw).hexdigest()
for source in sorted((root/'.direnv/dictionary-restoration/2026-09').glob('*.json')):
 raw=source.read_bytes();ids=[]
 for value in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
  ident='krdict:'+value['val']
  if ident not in expected or feature(value,'lexicalUnit') in {'관용구','속담'}:continue
  assert ident not in originals and entry(value)==expected[ident];originals[ident]=value;ids.append(ident)
 exports[source.name]={'bytes':len(raw),'sha256':sha(raw),'ids':ids}
assert set(originals)==set(expected) and len(exports)==11
for name,value in [('gentle-command-boundary-native.json',{'LexicalResource':{'Lexicon':{'LexicalEntry':list(originals.values())}}}),('gentle-command-boundary-native-entries.json',expected)]:
 p=prep/name;assert not p.exists();p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');q=work/'tests/fixtures'/name;assert not q.exists();q.write_bytes(p.read_bytes())
r=dict(state='complete-original-boundary-lexical-owners-preserved',heads=heads,owners=len(expected),original_native_entries=originals,complete_imported_entries=expected,original_exports=exports,original40owners_unchanged=True,independently_authored_fixture_sha256=sha((work/'tests/fixtures/gentle-command-validity.json').read_bytes()),producer={'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},new_runtime_observed=False)
out.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print(len(expected),'additional complete Native owners;',len(old)+len(expected),'total; four preauthored boundary heads')
