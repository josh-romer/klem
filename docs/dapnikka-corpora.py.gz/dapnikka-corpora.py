"""Replay every original annotated row using the actual final Nix adapter."""
import gzip,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');SOURCE=ROOT/'docs/literary-question-geona-prototype-corpora.json.gz';OUT=Path('/tmp/klem-dapnikka-corpora.json.gz');assert not OUT.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
adapter=Path('/home/josh/projects/klem/.direnv/dapnikka-target/debug/examples/evaluate')
baseline_path=Path('/tmp/klem-self-question-corpora.json.gz');baseline=json.loads(gzip.decompress(baseline_path.read_bytes()));reference=json.loads(gzip.decompress(SOURCE.read_bytes()));frozen={str(p):sha(p) for p in [SOURCE,baseline_path,adapter,Path(__file__)]};runs=[];changes=[]
for partition in reference['corpora']:
 source=ROOT/partition['source'];assert sha(source)==partition['source_sha256'];frozen[str(source)]=sha(source)
 command=[str(adapter),partition['corpus'],partition['source']];job=subprocess.run(command,cwd=ROOT,capture_output=True,check=True);assert not job.stderr
 rows=[json.loads(line) for line in job.stdout.splitlines()];previous=next(run for run in baseline['runs'] if (run['corpus'],run['partition'])==(partition['corpus'],partition['partition']));expected=[json.loads(line) for line in previous['jsonl'].splitlines()]
 assert len(rows)==len(expected)==partition['report_lines']
 for key in ['schema_version','input_sha256','corpus','input','rows','excluded_rows','malformed_rows','converted_rows','unsupported','gold_lemmas','transformed_rows','adapter_coverage']:
  assert rows[0][key]==expected[0][key],key
 for before,after in zip(expected[1:],rows[1:],strict=True):
  assert {k:before[k] for k in ['id','surface','expected']}=={k:after[k] for k in ['id','surface','expected']}
  assert not before['matched'] or after['matched']
  assert before['recovered']<=after['recovered'] and all(s in after['recovered_sets'] for s in before['recovered_sets'])
  if before!=after:changes.append({'id':after['id'],'corpus':partition['corpus'],'partition':partition['partition'],'before':before,'after':after,'contextual_verdict':'unjudged'})
 for key in ['grouped_matches','recovered_gold_lemmas','transformed_matches','grouped_lemma_recall','lemma_recall','transformed_grouped_recall']:
  assert rows[0][key]>=expected[0][key],key
 summary_changes={k:{'before':expected[0][k],'after':v} for k,v in rows[0].items() if expected[0].get(k)!=v}
 assert rows[0]['input_sha256']==partition['source_sha256']
 assert [{k:row[k] for k in ['id','surface','expected']} for row in rows[1:]]==[{k:row[k] for k in ['id','surface','expected']} for row in partition['original_converted_rows']]
 runs.append({'corpus':partition['corpus'],'partition':partition['partition'],'source':partition['source'],'source_sha256':sha(source),'command':command,'exit_code':0,'rows':len(rows)-1,'summary_changes':summary_changes,'jsonl':job.stdout.decode(),'stdout_sha256':hashlib.sha256(job.stdout).hexdigest()})
 print(partition['corpus'],partition['partition'],len(rows)-1,'original gold rows preserved;',len(summary_changes),'summary changes',flush=True)
assert sum(run['rows'] for run in runs)==66570 and all(sha(p)==h for p,h in frozen.items())
report={'state':'passed','adapter':str(adapter),'runs':runs,'individual_changed_rows':changes,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Actual dapnikka prototype adapter against all66,570 original rows/four unchanged gold partitions. All original IDs, surfaces, expected lemmas, earlier matches and recovered sets preserved; complete summary changes and changed rows retained individually. Candidate cohorts/broad and contextual/independent review remain separate.'}
OUT.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
