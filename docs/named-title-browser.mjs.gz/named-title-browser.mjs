import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
const root='/tmp/klem-named-title-prototype',db='/home/josh/projects/klem/data/dictionaries/krdict/krdict.db';
const cli=process.env.KLEM_BIN,url=process.env.KLEM_WEB_URL;
const cases=JSON.parse(await readFile(root+'/tests/fixtures/named-title-spacing-cases.json','utf8')).cases;
const source=JSON.parse(await readFile(root+'/src/dictionary/proper_names.json','utf8'));
const {chromium}=createRequire('/home/josh/projects/klem/web/package.json')('playwright');
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH,args:['--no-sandbox']});
const errors=[],diagrams=[],exports=[];
try {
 const page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});
 page.on('pageerror',e=>errors.push(String(e)));await page.goto(url);
 await page.getByLabel('Suggest missing spaces').check();
 for(const encoding of ['NFC','NFD']) {
  const text=cases.map(c=>c.surface.normalize(encoding)).join(' ');
  await page.getByLabel('Your sentence',{exact:true}).fill(text);
  const waiting=page.waitForResponse(r=>r.url().endsWith('/api/analyze')&&r.request().postDataJSON()?.text===text);
  await page.getByRole('button',{name:'Analyze sentence',exact:true}).click();
  const api=await(await waiting).json();assert.ok(api.records);
  await page.waitForFunction(t=>document.querySelector('.sentence')?.textContent===t,text);
  for(const [mode,flag] of [['raw',[]],['headword',['--dict-only']],['compatible',['--dict-compatible']]]) {
   if(mode==='raw') await page.getByLabel('Dictionary matches only').uncheck();
   else {await page.getByLabel('Dictionary matches only').check();if(mode==='compatible')await page.getByLabel('Exclude known grammar conflicts').check();else await page.getByLabel('Exclude known grammar conflicts').uncheck();}
   for(const c of cases.filter(c=>c.required_spacing)) {
    const spaced=c.required_spacing.normalize(encoding);
    const region=page.getByRole('region',{name:'Spacing breakdown for '+spaced,exact:true});
    await region.scrollIntoViewIfNeeded();
    const name=region.locator('.breakdown-word').first();
    assert.equal(await name.locator('.part-form').first().textContent(),'박');
    assert.equal(await name.locator('.part-gloss').first().textContent(),'Proper name');
    const button=name.locator('.breakdown-part').first();
    assert.match(await button.getAttribute('title'),/Corpus proper-name evidence/);
    diagrams.push({case_id:c.id,encoding,mode,forms:await region.locator('.part-form').allTextContents(),name_label:await name.locator('.part-gloss').first().textContent()});
   }
   const expected=execFileSync(cli,['text','-','--dictionary',db,'--proper-names','--suggest-spacing',...flag],{input:text,encoding:'utf8',maxBuffer:16*1024*1024}).trim().split('\n').map(JSON.parse);
   const waiting=page.waitForEvent('download');await page.getByRole('button',{name:'Export JSON',exact:true}).click();
   const value=JSON.parse(await readFile(await(await waiting).path(),'utf8'));assert.deepEqual(value.records,expected);exports.push({encoding,mode,records:expected});
  }
 }
 await page.getByLabel('Your sentence',{exact:true}).fill('박선생님께서');
 const waiting=page.waitForResponse(r=>r.url().endsWith('/api/analyze')&&r.request().postDataJSON()?.text==='박선생님께서');await page.getByRole('button',{name:'Analyze sentence',exact:true}).click();await waiting;
 const region=page.getByRole('region',{name:'Spacing breakdown for 박 선생님께서',exact:true});await region.scrollIntoViewIfNeeded();
 await region.locator('.breakdown-word').first().locator('.breakdown-part').first().click();
 await page.waitForSelector('.entry-content');
 const endpoint=(await(await page.request.post(url+'/api/entry',{data:{id:'ud-ko-kaist:proper-name:park'}})).json()).entry;
 assert.equal(endpoint.summary,undefined);assert.equal(endpoint.pos,'PROPN');assert.equal(endpoint.senses.length,5);
 assert.deepEqual(endpoint.origins,[]);assert.ok(endpoint.notes.includes('Original XPOS: nq'));
 const canonical=value=>Array.isArray(value)?value.map(canonical):value&&typeof value==='object'?Object.fromEntries(Object.entries(value).sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>[k,canonical(v)])):value;
 const projectionSha=createHash('sha256').update(JSON.stringify(canonical([endpoint]))).digest('hex');
 const status=await(await page.request.get(url+'/api/status')).json();
 assert.equal(status.dictionary.metadata.supplements[0].projection_sha256,projectionSha);
 for(const [i,sense] of endpoint.senses.entries())assert.equal(sense.examples[0][0],source.names[0].observations[i].complete_original_sentence);
 assert.equal(await page.locator('.entry-content .ko-definition').count(),5);
 assert.equal(await page.locator('.source-tag').textContent(),'UD Korean Kaist');
 await page.getByRole('link',{name:'Open original corpus source ↗',exact:true}).waitFor();
 assert.ok((await page.locator('.entry-content').textContent()).includes('CC BY-SA 4.0'));
 assert.ok((await page.locator('footer').textContent()).includes('CC BY-SA 4.0'));
 assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:'/tmp/klem-named-title-browser-desktop.png'});
 await page.setViewportSize({width:390,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:'/tmp/klem-named-title-browser-mobile.png'});
 assert.deepEqual(errors,[]);
 await writeFile('/tmp/klem-named-title-browser.json',JSON.stringify({state:'isolated-browser-passed',diagrams,exports,complete_corpus_entry:endpoint,errors,scope:'Debug prototype and locally built frontend; installed Nix and Main checks pending.'},null,2)+'\n');
 console.log('Passed',diagrams.length,'diagrams,',exports.length,'exact exports, complete five-context corpus entry and desktop/mobile geometry.');
}finally{await browser.close();}
