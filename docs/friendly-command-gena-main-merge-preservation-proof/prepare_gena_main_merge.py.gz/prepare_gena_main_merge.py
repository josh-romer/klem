"""Retain original main and Gena ledger/review bytes before main integration."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path
P = Path(__file__).resolve().parent
ROOT = P.parents[1]
W = ROOT / '.direnv/friendly-command-gena'
OUT = P / 'friendly-command-gena-main-before-merge.json'
assert not OUT.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda root, *a: subprocess.check_output(['git', *a], cwd=root)
assert not git(ROOT, 'status', '--porcelain') and not git(W, 'status', '--porcelain')
main = json.loads((ROOT / 'tests/fixtures/validity.json').read_bytes())
gena = json.loads((W / 'tests/fixtures/validity.json').read_bytes())
reviews = json.loads((ROOT / 'docs/inventory-reviews.json').read_bytes())
new_reviews = json.loads((W / 'docs/inventory-reviews.json').read_bytes())
assert len(main['cases']) == 35740 and len(gena['cases']) == 35764 and gena['cases'][:35740] == main['cases']
assert len(reviews['entries']) == 519 and len(new_reviews['entries']) == 520 and new_reviews['entries'][:519] == reviews['entries']
files = {}
for label, tree in [('main', ROOT), ('gena', W)]:
    for name in ['tests/fixtures/validity.json', 'tests/validity.rs', 'docs/inventory-reviews.json',
                 'docs/inventory-review-queue.json', 'docs/coverage-checklist.md', 'flake.nix']:
        raw = (tree / name).read_bytes(); packed = gzip.compress(raw, mtime=0)
        path = P / ('friendly-command-gena-main-before-merge-' + label + '-' + name.replace('/', '-') + '.gz')
        path.write_bytes(packed)
        files[label + ':' + name] = dict(path=str(path), source_sha256=sha(raw), archive_sha256=sha(packed), bytes=len(raw))
OUT.write_text(json.dumps(dict(state='complete-original-main-and-gena-inputs-preserved', files=files,
                              main_head=git(ROOT, 'rev-parse', 'HEAD').decode().strip(),
                              gena_head=git(W, 'rev-parse', 'HEAD').decode().strip(),
                              main_index_sha256=sha(git(ROOT, 'ls-files', '--stage', '-z')),
                              gena_index_sha256=sha(git(W, 'ls-files', '--stage', '-z')),
                              exact_35740_case_and519_review_prefixes=True,
                              producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes()))), indent=2) + '\n')
print('Preserved12 whole main/Gena inputs;35740 cases and519 reviews retained exactly.')
