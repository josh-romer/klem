"""Bind actual current main test-built CLI/server binaries to all frozen source inputs."""
import hashlib,json,shutil
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');TARGET=Path('/tmp/klem-additive-ppundeoreo-prototype-target-no-debug/debug')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads(Path('/tmp/klem-additive-ppundeoreo-main-rust.json').read_bytes());snapshot=run['snapshot_files'];assert run['cwd']==str(ROOT) and len(snapshot)==964
assert all(sha((ROOT/n).read_bytes())==v['sha256'] for n,v in snapshot.items())
binaries={}
for name,exe in [('cli','klem'),('server','klem-web')]:
 source=TARGET/exe;dest=Path('/tmp/klem-additive-ppundeoreo-main-'+name);assert source.exists() and not dest.exists()
 before=sha(source.read_bytes());shutil.copy2(source,dest);assert sha(source.read_bytes())==sha(dest.read_bytes())==before
 binaries[name]={'path':str(dest),'sha256':before,'built_path':str(source)}
r={'state':'actual-main-binaries-captured-full-suite-pending','snapshot_files':snapshot,'binaries':binaries,'command':run['command'],'cwd':run['cwd'],'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'scope':'Actual all-targets cargo test from main finished building the binaries and is running integration tests. All964compile/frontend inputs remain frozen. No full-suite/package completion claim.'}
Path('/tmp/klem-additive-ppundeoreo-main-binaries.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print('Copied actual main CLI/server; all964inputs match running full-suite snapshot.',flush=True)
# Fresh actual CLI original and boundary observations.
for stem in ['source-replay','boundary-replay']:
 s=Path('/tmp/klem-additive-ppundeoreo-'+stem+'.py').read_text().replace("CLI=Path('/tmp/klem-additive-ppundeoreo-cli')", "CLI=Path('/tmp/klem-additive-ppundeoreo-main-cli')")
 s=s.replace('klem-additive-ppundeoreo-source-replay.json.gz','klem-additive-ppundeoreo-main-source-replay.json.gz') if stem=='source-replay' else s.replace('klem-additive-ppundeoreo-boundary-preflight.json.gz','klem-additive-ppundeoreo-main-boundary-preflight.json.gz')
 s=s.replace("'isolated_proposal_only':True","'isolated_proposal_only':False").replace("'preparation_only':True","'preparation_only':False")
 s=s.replace('Root and its combined Nix gate are unchanged.','Actual current-main runtime; full-suite/package and broader review remain separate.').replace('Actual isolated observations','Actual current-main observations')
 Path('/tmp/klem-additive-ppundeoreo-main-'+stem+'.py').write_text(s)
