"""Run the complete new integration suite with its source and artifacts frozen."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/home/josh/projects/klem/.direnv/gentle-command-long')
OUT = PREP / 'gentle-command-long-full-rust.json'
LOG = PREP / 'gentle-command-long-full-rust.log'
assert not OUT.exists() and not LOG.exists()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK), 'complete validation requires a clean committed source tree'
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [WORK / name for name in subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=WORK).decode().split('\0')[:-1]]
files.append(Path(__file__))
frozen = {str(path): sha(path) for path in sorted(set(files))}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
index = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest()
command = ['cargo', 'test', '--locked', '--offline', '--features', 'web']
env = dict(os.environ, CARGO_TARGET_DIR='/home/josh/projects/klem/.direnv/gentle-command-target',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2')
r = {'state': 'running', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': os.getpid(),
     'head': head, 'index_sha256': index, 'frozen_inputs': frozen, 'command': command,
     'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
     'scope': 'Actual whole Rust suite at the committed longer-command prototype, expecting1189passed/0failed/1ignored254batches. All35704activecases/517reviews unchanged,25preauthoredprivate long cases and43fullNativeowners included, all original baselines preserved. Earlier36focusedRust/40controls/format/Clippy pass; original first harness failure preserved. All trackedSource/docs/head/index remain frozen until terminal. Current-production binding,53502cohort/history path attribution,66570gold/1128312broad outputs,installed/browser/currentNix/main/quiet/context/independent review remain separate; historical gentle runtime proof still binds its exact original production, not this new revision.'}
OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
with LOG.open('xb') as stream:
    job = subprocess.run(command, cwd=WORK, env=env, stdout=stream, stderr=subprocess.STDOUT)
batches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', LOG.read_text())
totals = {key: sum(int(batch[i + 1]) for batch in batches) for i, key in enumerate(['passed', 'failed', 'ignored'])}
unchanged = all(sha(Path(path)) == digest for path, digest in frozen.items())
head_same = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == head
index_same = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest() == index
complete = bool(batches) and len(batches) == 254 and totals == {'passed': 1189, 'failed': 0, 'ignored': 1} and all(batch[0] == 'ok' for batch in batches)
r.update(state='passed' if job.returncode == 0 and complete and unchanged and head_same and index_same else 'failed',
         exit_code=job.returncode, inputs_unchanged=unchanged, head_unchanged=head_same, index_unchanged=index_same,
         totals=totals, batches=len(batches), log_sha256=sha(LOG), finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
print(r['state'], totals, len(batches), 'batches; Sourcefiles', len(frozen), 'unchanged', unchanged, flush=True)
raise SystemExit(0 if r['state'] == 'passed' else 1)
