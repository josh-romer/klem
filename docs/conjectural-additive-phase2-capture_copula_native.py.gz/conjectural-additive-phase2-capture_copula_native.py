"""Retain original Native nouns/copula/endings for the observed omitted copula."""
import gzip
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = PREP.parents[1]
PROTO = PREP.parent / 'conjectural-additive-copula-prototype'
OUT = PREP / 'copula-native-closure.json.gz'
assert not OUT.exists()
sys.path.insert(0, str(ROOT / 'tools'))
from native_lmf import entry, feature

DB = ROOT / '.direnv/dictionary-restoration/krdict.db'
expected = {}
with sqlite3.connect(DB.resolve().as_uri() + '?mode=ro', uri=True) as db:
    for row in db.execute('SELECT data FROM entries WHERE headword IN (?,?,?,?,?,?)', ('장래', '학교', '학생', '이다', '-려니와', '-으려니와')):
        owner = json.loads(row[0])
        if owner['lexical_unit'] == '단어':
            expected[owner['id']] = owner
sha = lambda raw: hashlib.sha256(raw).hexdigest()
originals = {}
exports = {}
for source in sorted((ROOT / '.direnv/dictionary-restoration/2026-09').glob('*.json')):
    raw = source.read_bytes()
    ids = []
    for value in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
        ident = 'krdict:' + value['val']
        if ident not in expected or feature(value, 'lexicalUnit') in {'관용구', '속담'}:
            continue
        assert ident not in originals and entry(value) == expected[ident]
        originals[ident] = value
        ids.append(ident)
    exports[source.name] = {'bytes': len(raw), 'sha256': sha(raw), 'ids': ids}
assert len(exports) == 11 and set(originals) == set(expected)
for name, value in [('conjectural-additive-copula-native.json', {'LexicalResource': {'Lexicon': {'LexicalEntry': list(originals.values())}}}),
                    ('conjectural-additive-copula-native-entries.json', expected)]:
    path = PROTO / 'tests/fixtures' / name
    assert not path.exists()
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
report = {'state': 'complete-original-copula-native-closure-preserved', 'owners': len(originals),
          'original_native_entries': originals, 'complete_imported_entries': expected,
          'original_exports': exports, 'original_database_sha256': sha(DB.read_bytes()),
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())},
          'scope': 'Every original word homonym of the three independently selected nouns, copula and both ending owners, without inventing POS/notes/senses or borrowing idiom/proverb base IDs. All eleven exports hashed and every Python Native projection equals the pinned dictionary. Rust importer/compatible paths/CLI and full viewer/contextual validation remain separate.'}
OUT.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
print('Retained', len(originals), 'original Native noun/copula/ending owners', flush=True)
