import hashlib,json,re,subprocess,time
from pathlib import Path
root=Path('/home/josh/projects/klem/.direnv/gentle-command-long')
out=Path('/home/josh/projects/klem/.direnv/willingness-question-prepared')
receipt=out/'gentle-command-long-runtime-audits.json'
log=out/'gentle-command-long-runtime-audits.log'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root).decode().strip()
files=[root/n for n in git('ls-files','--cached','--others','--exclude-standard').splitlines()]
files.append(Path(__file__))
frozen={str(p):sha(p.read_bytes()) for p in files}
head=git('rev-parse','HEAD');index=Path(git('rev-parse','--git-path','index'))
index_digest=sha(index.read_bytes())
producer=Path(__file__).read_text()
report=dict(state='running',head=head,index_sha256=index_digest,frozen_inputs=frozen,producer=dict(text=producer,sha256=sha(producer.encode())),results=[],started_at=time.time())
def save():receipt.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
save()
patterns=['test_gentle_command_long_runtime_audit.py','test_gentle_command_runtime_audit.py','test_gentle_command_installed_audit.py']
commands=[['python3','-m','unittest','discover','-s','tools','-p',p] for p in patterns]+[['git','diff','--check']]
with log.open('w') as stream:
 for command in commands:
  job=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  stream.write('COMMAND '+json.dumps(command)+'\n'+job.stdout);stream.flush()
  count=re.search(r'Ran (\d+) tests',job.stdout)
  report['results'].append(dict(command=command,exit_code=job.returncode,output=job.stdout,controls=int(count.group(1)) if count else 0));save()
  if job.returncode:break
report.update(inputs_unchanged=all(p.exists() and sha(p.read_bytes())==frozen[str(p)] for p in files),head_unchanged=git('rev-parse','HEAD')==head,index_unchanged=sha(index.read_bytes())==index_digest,controls=sum(s['controls'] for s in report['results']),log_sha256=sha(log.read_bytes()),finished_at=time.time())
report['state']='passed' if len(report['results'])==len(commands) and all(s['exit_code']==0 for s in report['results']) and all(report[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged']) else 'failed'
save();print(json.dumps({k:report[k] for k in ['state','controls','inputs_unchanged','head_unchanged','index_unchanged']}),flush=True)
raise SystemExit(0 if report['state']=='passed' else 1)
