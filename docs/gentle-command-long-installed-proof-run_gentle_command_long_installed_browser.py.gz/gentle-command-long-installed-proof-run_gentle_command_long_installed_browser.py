"""Check the actual current Nix launcher, assets and every private UI judgment."""
import gzip
import hashlib
import json
import os
import re
import signal
import subprocess
import urllib.request
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/home/josh/projects/klem/.direnv/gentle-command-long')
BINDING = PREP/'gentle-command-long-installed-runtime.json.gz'
OUT = PREP/'gentle-command-long-installed-browser-runtime.json'
LOG = PREP/'gentle-command-long-installed-browser-runtime.log'
PREFIX = PREP/'gentle-command-long-installed'
DRIVER = PREP/'gentle-command-long-installed-browser.mjs'
DB = PREP.parents[1]/'.direnv/dictionary-restoration/krdict.db'
CHROMIUM = Path('/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium')
assert not OUT.exists() and not LOG.exists() and not Path(str(PREFIX)+'-browser.json').exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
binding = json.loads(gzip.decompress(BINDING.read_bytes()))
package = json.loads((PREP/'gentle-command-long-nix-packages-retry2.json').read_bytes())
assert binding['state'] == 'passed' and all(binding[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip() == binding['captured_head']
assert all(hashlib.sha256((WORK/n).read_bytes()).hexdigest() == digest for n,digest in package['frozen_inputs'].items())
files = [BINDING, DRIVER, DB, CHROMIUM, Path(__file__), WORK/'web/src/grammar-labels.json']
files += [Path(b['path']) for b in binding['binaries'].values()]
files += [WORK/'tests/fixtures'/n for n in ['gentle-command-long-validity.json','gentle-command-long-novel-validity.json','gentle-command-class-interaction-validity.json','gentle-command-validity.json','willingness-question-interaction-validity.json','gentle-command-long-native-entries.json','gentle-command-long-boundary-native-entries.json','gentle-command-long-novel-native-entries.json','gentle-command-native-entries.json','gentle-command-boundary-native-entries.json']]
assets = Path(binding['packages']['klem-web-assets'])/'share/klem-web'
files += [p for p in assets.rglob('*') if p.is_file()]
frozen = {str(p):sha(p) for p in files}
assert {str(p.relative_to(assets)):sha(p) for p in assets.rglob('*') if p.is_file()} == binding['assets']
command = [binding['binaries']['launcher']['path'],'--port','0','--dictionary',str(DB)]
r = dict(state='running',command=command,captured_head=binding['captured_head'],
         frozen_inputs=frozen, producer=dict(text=Path(__file__).read_text(),sha256=sha(__file__)),
         driver=dict(text=DRIVER.read_text(),sha256=sha(DRIVER)),
         scope='Actual currentlong installed Nix launcher/server/CLI/immutableSolidJS assets. Original67cases/44required23forbidden; all402Unicode/filter decisions, six exactCLIexports and62completeNativeentries. Original25 andold23 judgments unchanged; novel8 proposals after-runtime, other11raw novel hypotheses unjudged; main/inventory/quiet/contextindependent review separate.')
save = lambda: OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
job = subprocess.Popen(command,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
try:
    line = job.stderr.readline();match = re.search(r'http://127\.0\.0\.1:\d+',line);assert match,line
    url = match.group();r['url'] = url;r['owned_server_pid'] = job.pid
    with urllib.request.urlopen(url+'/api/status',timeout=10) as response: r['status'] = json.load(response)
    with urllib.request.urlopen(url,timeout=10) as response: html = response.read();assert html == (assets/'index.html').read_bytes()
    r['served_assets'] = []
    for path in re.findall(r'(?:src|href)="(/assets/[^"?#]+\.(?:js|css))"',html.decode()):
        with urllib.request.urlopen(url+path,timeout=10) as response:
            raw = response.read();assert raw == (assets/path.lstrip('/')).read_bytes()
        r['served_assets'].append(dict(path=path,sha256=hashlib.sha256(raw).hexdigest()))
    env = dict(os.environ,KLEM_WEB_URL=url,KLEM_BIN=binding['binaries']['klem']['path'],KLEM_CAPTURE_PREFIX=str(PREFIX),CHROMIUM_PATH=str(CHROMIUM))
    with LOG.open('xb') as stream: run = subprocess.run(['node',str(DRIVER)],env=env,stdout=stream,stderr=subprocess.STDOUT)
    r.update(exit_code=run.returncode,log_sha256=sha(LOG))
    assert run.returncode == 0
    result = json.loads(Path(str(PREFIX)+'-browser.json').read_bytes())
    assert result['state'] == 'source-bound-gentle-command-long-installed-browser-passed' and not result['errors']
    assert len(result['policyDecisions']) == 402 and len(result['exports']) == 6 and len(result['nativeEntries']) == 62
    assert sum(d.get('verdict') == 'forbidden' for d in result['policyDecisions']) == 138
    assert len(result['diagrams']) == sum(bool(d.get('allowed')) for d in result['policyDecisions'])
    r.update(state='passed',decisions=402,diagrams=len(result['diagrams']),exports=6,native_entries=62,
             result_sha256=sha(Path(str(PREFIX)+'-browser.json')))
except Exception as error:
    r.update(state='failed',error=str(error));raise
finally:
    if job.poll() is None: job.send_signal(signal.SIGINT)
    r.update(server_exit_code=job.wait(timeout=20),server_stopped=True,
             inputs_unchanged=all(sha(p) == digest for p,digest in frozen.items()),
             source_unchanged=all(hashlib.sha256((WORK/n).read_bytes()).hexdigest() == digest for n,digest in package['frozen_inputs'].items()),
             index_unchanged=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK)).hexdigest() == package['index_sha256'],
             head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip() == binding['captured_head'])
    save()
assert r['state'] == 'passed' and all(r[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged']) and r['server_exit_code'] in [0,-signal.SIGINT]
print('Passed installed Solid67case/402policy/sixexport/62Native proof; owned server stopped.',flush=True)
