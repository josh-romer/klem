"""Capture every original corpus/history word against the immutable prior Nix CLI."""
import gzip,hashlib,json,subprocess,sys,datetime,os
from pathlib import Path
prep=Path(__file__).resolve().parent;work=Path('/tmp/klem-gentle-command');root=Path('/home/josh/projects/klem');out=prep/'gentle-command-cohorts.json.gz';progress=prep/'gentle-command-cohorts-progress.json';assert not out.exists() and not progress.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest();digest=lambda raw:hashlib.sha256(raw).hexdigest()
source=work/'docs/willingness-question-distribution-proof-willingness-cohorts.json.gz';reference=json.loads(gzip.decompress(source.read_bytes()));assert reference['inputs_unchanged']
old_binding_path=prep/'willingness-installed-source-binding-retry1.json';old=json.loads(old_binding_path.read_bytes());assert old['state']=='passed';before=Path(old['profiles']['klem']['package'])/'bin/klem'
new_binding_path=prep/'gentle-command-debug-binding.json';new=json.loads(new_binding_path.read_bytes());assert new['state']=='passed';after=Path(new['binaries']['klem']['path']);assert sha(after)==new['binaries']['klem']['sha256']
sys.path.insert(0,str(work/'tools'));from doeda_native_corpora import words_from_cli
frozen={str(p):sha(p) for p in [source,old_binding_path,new_binding_path,before,after,Path(__file__),work/'tools/doeda_native_corpora.py']}
r=dict(state='running',pid=os.getpid(),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),frozen_inputs=frozen,runs=[],individual_changed_words=[],producer={'text':Path(__file__).read_text(),'sha256':sha(__file__)})
save=lambda:progress.write_text(json.dumps({**r,'completed_runs':len(r['runs'])},ensure_ascii=False,indent=2)+'\n');save()
try:
 for cohort in reference['runs']:
  expected=cohort['captures'][1]['words'];assert words_from_cli(before,sorted(expected))==expected,'every original parent Nix word and path'
  actual=words_from_cli(after,sorted(expected));assert set(actual)==set(expected);changed=[]
  for surface,prior in expected.items():
   current=actual[surface];assert {k:v for k,v in prior.items() if k!='analyses'}=={k:v for k,v in current.items() if k!='analyses'},surface
   assert [a for a in current['analyses'] if a in prior['analyses']]==prior['analyses'],('original path/order loss',surface)
   additions=[a for a in current['analyses'] if a not in prior['analyses']]
   assert all('ending.gentle_command' in a['rules'] for a in additions),('unrelated addition',surface)
   if current!=prior:
    changed.append(surface);r['individual_changed_words'].append(dict(id='gentle-command-cohort-'+cohort['family']+'-'+str(len(changed)),family=cohort['family'],surface=surface,before=prior,after=current,new_paths=additions,contextual_verdict='unjudged',independent_review='pending'))
  r['runs'].append(dict(family=cohort['family'],surfaces=len(expected),captures=[{'binary':str(before),'words':expected},{'binary':str(after),'words':actual}],changed_words=changed));save();print(cohort['family'],len(expected),'completewords;',len(changed),'changed',flush=True)
 assert sum(run['surfaces'] for run in r['runs'])==53502
 r.update(state='complete-original-corpus-history-comparison-passed',inputs_unchanged=all(sha(p)==h for p,h in frozen.items()),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Every original53502corpus/history word and prior ordered path retained. Only new gentle-command paths recorded with full before/after and stable IDs. Candidate additions are contextually unjudged; no source/baseline/gold refreshed. Full Rust failure, broad/annotated/Native/browser/Nix/main/timing and independent review remain separate.');assert r['inputs_unchanged'];out.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));save()
except Exception as error:
 r.update(state='failed',error=str(error));save();raise
