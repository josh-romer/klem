"""Verify the exact parent guard from committed Git-selected Nix source."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
OUT = P / 'friendly-hortative-sena-gena-parent-selected-source-retry5.json'
LOG = P / 'friendly-hortative-sena-gena-parent-selected-source-retry5.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=W)
assert not git('status', '--porcelain')
source = {name: sha((W / name).read_bytes()) for name in git('ls-files', '-z').decode().split('\0')[:-1]}
head = git('rev-parse', 'HEAD').decode().strip()
index = sha(git('ls-files', '--stage', '-z'))
prior_path = P / 'friendly-hortative-sena-gena-parent-controls-retry1.json'
prior = json.loads(prior_path.read_bytes())
assert prior['state'] == 'passed' and prior['controls'] == 351
rust_path = P / 'friendly-hortative-sena-gena-parent-full-rust.json'
rust = json.loads(rust_path.read_bytes())
assert rust['state'] == 'passed' and rust['rust_totals'] == dict(passed=1212, failed=0, ignored=1)
protected = prior['protected_binaries']
assert all(sha(Path(path).read_bytes()) == digest for path, digest in protected.items())
old_profiles = json.loads((P / 'friendly-hortative-sena-wide-selected-source.json').read_bytes())['profiles']
temporary = Path('/var/tmp/klem-sena-gena-parent-selected-source')
temporary.mkdir(exist_ok=True)
env = dict(os.environ, TMPDIR=str(temporary), PYTHONDONTWRITEBYTECODE='1', KLEM_SENA_BINARY_EVIDENCE='captured')
flake = 'git+file://' + str(W) + '?rev=' + head
r = dict(state='running', head=head, index_sha256=index, source_inputs=source,
         protected_binaries=protected, results=[], prerequisite_sha256=sha(prior_path.read_bytes()),
         rust_prerequisite_sha256=sha(rust_path.read_bytes()),
         producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Actual Git-selected31+14+46+46 controls and715 queue; complete1158/1158/18 profiles bind the passed parent Rust and unchanged frontend. No new full Nix build, installed replay, shared promotion or main claim.')
def save():
    OUT.write_text(json.dumps(r, indent=2) + '\n')
save()
try:
    with LOG.open('xb') as log:
        def selected(attr, prefix=''):
            command = ['nix', 'eval', '--option', 'auto-optimise-store', 'true', '--offline', '--raw', flake + '#' + attr]
            job = subprocess.run(command, cwd=W, env=env, capture_output=True)
            r['results'].append(dict(command=command, exit_code=job.returncode,
                                     stdout=job.stdout.decode(), stderr=job.stderr.decode()))
            log.write(('COMMAND ' + json.dumps(command) + '\n').encode() + job.stdout + job.stderr)
            log.flush(); save(); assert job.returncode == 0
            root = Path(job.stdout.decode().strip()); files = {}
            for path in root.rglob('*'):
                assert not path.is_symlink()
                if path.is_file():
                    name = str(path.relative_to(root)); digest = sha(path.read_bytes())
                    assert source[prefix + name] == digest, 'all actual Git-selected source bytes'
                    files[name] = digest
            return root, files
        root, files = selected('checks.x86_64-linux.inventory-review.src')
        r.update(selected_source=str(root), selected_files=files)
        for name in ('tools/friendly_hortative_sena_gena_parent_audit.py',
                     'tools/test_friendly_hortative_sena_gena_parent_audit.py',
                     'docs/friendly-hortative-sena-gena-parent-validation-proof-archive.json',
                     'docs/friendly-hortative-sena-gena-parent-controls-proof-archive.json'):
            assert files[name] == source[name], 'all current exact parent guards and complete proof selected'
        r['profiles'] = {}
        for attr, prefix in [('klem', ''), ('corpus-adapter', ''), ('web-assets', 'web/')]:
            selected_root, current = selected('packages.x86_64-linux.' + attr + '.src', prefix)
            old = old_profiles[attr]['files']
            assert len(current) == (18 if attr == 'web-assets' else 1158)
            assert set(current) == set(old), 'whole original compile profile membership'
            changed = {name for name in current if current[name] != old[name]}
            assert changed == (set() if attr == 'web-assets' else {'tests/fixtures/validity.json', 'tests/validity.rs'}), 'only exact two tested parent inputs'
            assert all(rust['frozen_inputs'][prefix + name] == digest for name, digest in current.items()), 'every selected compile byte belongs to actual passed parent Rust'
            r['profiles'][attr] = dict(source=str(selected_root), files=current)
        save()
        for name, count in [('test_friendly_hortative_sena_revision.py', 31),
                            ('test_friendly_hortative_sena_gena_parent_audit.py', 14),
                            ('test_friendly_hortative_sena_installed_audit.py', 46),
                            ('test_friendly_command_gena_promoted_installed_audit.py', 46),
                            (None, None)]:
            command = (['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', name]
                       if name else ['python3', 'tools/review_inventory.py', '--verify'])
            log.write(('COMMAND ' + json.dumps(command) + '\n').encode()); log.flush()
            job = subprocess.run(command, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            log.write(job.stdout); log.flush()
            r['results'].append(dict(command=command, exit_code=job.returncode, stdout=job.stdout.decode())); save()
            assert job.returncode == 0
            if count:
                assert re.search(rb'Ran ' + str(count).encode() + rb' tests? in ', job.stdout)
                assert job.stdout.rstrip().endswith(b'OK')
        r.update(state='passed', controls=137, executable_replays=0, full_build_replays=0)
except BaseException as error:
    r.update(state='failed', error=repr(error)); raise
finally:
    r.update(source_unchanged=all(sha((W / name).read_bytes()) == digest for name, digest in source.items()),
             head_unchanged=git('rev-parse', 'HEAD').decode().strip() == head,
             index_unchanged=sha(git('ls-files', '--stage', '-z')) == index,
             protected_binaries_unchanged=all(sha(Path(path).read_bytes()) == digest for path, digest in protected.items()),
             log_sha256=sha(LOG.read_bytes()) if LOG.exists() else None,
             completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[key] for key in ('source_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged')):
        r['state'] = 'failed'
    save()
assert r['state'] == 'passed'
print('Actual Git-selected Sena parent137 controls and715 queue passed; every1158/1158/18 compiled input bound.', flush=True)
