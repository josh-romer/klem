"""Author -세나 proposals before targeted current runtime; retain historical discovery."""
import datetime,gzip,hashlib,json,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');PREP=Path(__file__).resolve().parent
OUT=PREP/'friendly-hortative-sena-source-authoring.json'
CLOSURE=PREP/'friendly-hortative-sena-original-native-closure.json.gz'
SUITE=PREP/'friendly-hortative-sena-validity.json'
assert not OUT.exists() and not CLOSURE.exists() and not SUITE.exists()
WORK=ROOT/'.direnv/friendly-command-gena'
sys.path.insert(0,str(WORK/'tools'))
from native_lmf import array,features,entry
from review_inventory import source_entry,digest
sha=lambda raw:hashlib.sha256(raw).hexdigest()
original_path=ROOT/'docs/unreviewed-inventory-source-closure.json.gz'
original=json.loads(gzip.decompress(original_path.read_bytes()));owner=original['complete_native_entries']['krdict:78469'];assert owner['headword']=='-세나' and len(owner['senses'])==1 and len(owner['senses'][0]['examples'])==5
queue=json.loads((ROOT/'docs/inventory-review-queue.json').read_bytes());row=next(r for r in queue['entries'] if r['source']['id']=='krdict:78469');assert source_entry(owner)==row['source'] and digest(row['source'])==row['source_sha256']
heads={'-세나','-세','-으세','하다','지켜보다','그만두다','살다','일하다','가다','보다','먹다','듣다','돕다','짓다','낫다','푸다','예쁘다','학생','이다','-답다','공부하다','공부','사다'}
raws={};entries={};exports={}
for path in sorted((ROOT/'.direnv/dictionary-restoration/2026-09').glob('*.json')):
 raw=path.read_bytes();exports[path.name]=dict(sha256=sha(raw),bytes=len(raw));lex=json.loads(raw)['LexicalResource']['Lexicon'];assert not isinstance(lex,list)
 for item in array(lex['LexicalEntry']):
  found={h for lemma in array(item['Lemma']) for h in features(lemma,'writtenForm')}
  if not found & heads:continue
  value=entry(item);assert value['id'] not in raws;raws[value['id']]=item;entries[value['id']]=value
assert len(exports)==11 and entries['krdict:78469']==owner and raws['krdict:78469']==original['original_lmf']['krdict:78469']
assert {e['headword'] for e in entries.values()}==heads,'All selected lexical/boundary heads must exist; do not invent missing dictionary entries'
closure=dict(state='complete-original-gena-owner-lexical-boundary-closure',original_lmf=raws,complete_native_entries=entries,source_exports=exports,selected_heads=sorted(heads),scope='All same-head owners for original five targets and declared synthetic lexical/known-class boundaries; complete original multilingual senses, forms, example types, dialogue, annotations, relationships and whitespace retained. No runtime observation, gold annotation or review promotion.')
packed=gzip.compress((json.dumps(closure,ensure_ascii=False)+'\n').encode(),mtime=0);CLOSURE.write_bytes(packed)
source='friendly-hortative-sena-78469';cases=[];items=[]
def case(ident,surface,lemmas,kinds,morphemes,morph_kinds,verdict,reason):
 c=dict(id=ident,surface=surface,judgments=[dict(id='structural-path',lemmas=lemmas,lemma_kinds=kinds,morphemes=morphemes,morpheme_kinds=morph_kinds,verdict=verdict,source=source,reason=reason)]);cases.append(c);return c
for ordinal,(group,(surface,lemma)) in enumerate(zip(owner['senses'][0]['examples'],[('하세나','하다'),('지켜보세나','지켜보다'),('그만두세나','그만두다'),('사세나','살다'),('일하세나','일하다')],strict=True),1):
 raw='\n'.join(group).encode();needle=surface.encode();assert raw.count(needle)==1;start=raw.index(needle);c=case('friendly-hortative-sena-78469-sense-1-group-'+str(ordinal),surface,[lemma],['predicate'],['세나'],['ending'],'required','Independent finite lexical/canonical ending target from this complete original source group. No contextual homonym or sense selection, social-register verdict or rejection of other paths is assigned. The original 사세나 occurrence retains the proposed 살다 path.');items.append(dict(id=c['id'],entry_id=owner['id'],sense_id='1',example_group=ordinal,complete_original_group=group,surface=surface,local_span=dict(start=start,end=start+len(needle)),typed_target=c['judgments'][0],contextual_verdict='unjudged',independent_korean_review='pending'))
for ordinal,(surface,lemma) in enumerate([('가세나','가다'),('보세나','보다'),('먹세나','먹다'),('듣세나','듣다'),('돕세나','돕다'),('짓세나','짓다'),('낫세나','낫다'),('푸세나','푸다'),('공부하세나','공부하다'),('사세나','사다')],1):
 case('friendly-hortative-sena-regular-boundary-'+str(ordinal),surface,[lemma],['predicate'],['세나'],['ending'],'required','Declared synthetic structural proposal for consonant-initial 세나. This is not a quoted source example. The separate 사다 proposal on 사세나 preserves lexical ambiguity with the source-target 살다 path; other homonyms remain unjudged.')
for ordinal,(surface,lemma) in enumerate([('먹으시세나','먹다'),('사시세나','살다'),('도우시세나','돕다')],1):
 case('friendly-hortative-sena-honorific-'+str(ordinal),surface,[lemma],['predicate'],['시','세나'],['prefinal','ending'],'required','Declared synthetic verbal-honorific proposal from the explicit -으시- note. Adjective/copula honorific constructions and register are unjudged.')
for ordinal,(surface,lemma) in enumerate([('들세나','듣다'),('도우세나','돕다'),('지으세나','짓다'),('퍼세나','푸다')],1):
 case('friendly-hortative-sena-invalid-stem-boundary-'+str(ordinal),surface,[lemma],['predicate'],['세나'],['ending'],'forbidden','Declared synthetic proposal rejecting this exact vowel-triggered irregular restoration immediately before consonant-initial 세나. Other lexical readings are unjudged; the source-backed ㄹ-deleted 살다 path on 사세나 is explicitly separate.')
case('friendly-hortative-sena-bare-copula','학생이세나',['학생','이다'],['nominal','copula'],['세나'],['ending'],'forbidden','The source bare attachment note names verbs. This exact bare copula path is a negative structural proposal; honorific copulas and other raw hypotheses remain unjudged.')
case('friendly-hortative-sena-derived-adjective','학생답세나',['학생'],['nominal'],['답다','세나'],['suffix','ending'],'forbidden','This known nominal-plus-답다 adjective retains its actual suffix representation and must not borrow a bare verb hortative license. Unknown lexical and honorific constructions remain unjudged.')
case('friendly-hortative-sena-attached-auxiliary','먹어보세나',['먹다','보다'],['predicate','auxiliary'],['어','세나'],['ending','ending'],'required','Declared synthetic attached verbal auxiliary alternative. Other lexical compound and standalone paths remain unjudged.')
assert len(cases)==25 and sum(j['verdict']=='required' for c in cases for j in c['judgments'])==19 and sum(j['verdict']=='forbidden' for c in cases for j in c['judgments'])==6
suite=dict(schema_version=1,review_status='finite structural proposals authored before targeted current runtime; earlier whole-inventory discovery exists; contextual and Korean review pending',sources={source:owner['url']},cases=cases)
SUITE.write_text(json.dumps(suite,ensure_ascii=False,indent=2)+'\n')
record=dict(state='sena-original-source-and-targets-authored-before-targeted-current-runtime',authored_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),owner_ids=[owner['id']],owners={owner['id']:owner},related_owners={ident:entries[ident] for ident in ['krdict:78404','krdict:78434']},original_lmf={owner['id']:raws[owner['id']]},items=items,original_inventory_source=row['source'],original_inventory_sha256=row['source_sha256'],native_closure_sha256=sha(packed),suite_sha256=sha(SUITE.read_bytes()),source_archive_sha256=sha(original_path.read_bytes()),producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),candidate_runtime_observed=False,shared_cases_reviews_changed=False,bare_lexical_adjective_dictionary_targets=[dict(surface='예쁘세나',lemma='예쁘다',expected_own_pos='형용사',hortative_compatibility='incompatible on this known bare adjective owner; raw lexical hypotheses unjudged')],honorific_adjective_copula_scope='unjudged: do not infer or forbid their licenses from the bare-verb note; preserve explicit honorific note',historical_whole_inventory_discovery_already_exists=True,prior_discovery_outputs_used_for_target_selection=False,required_rule_ids_assigned=False,scope='Complete original single-owner/five source groups and all lexical/boundary homonyms; finite synthetic morphology proposals clearly separate from original examples. Canonical 세나 is separate from 세 + 나 and from the related 세/으세 family. The source 사세나→살다 target differs from ㄹ-preserving 게나. Future rule IDs are not required; baseline matching must check the typed path independently of provenance. Explicit verb honorifics, known bare copula/답다 and auxiliary paths are tracked. Raw candidate preservation, every fullsource mode, actualNative import/filter/UI, corpus/history/gold/novel/runtime/installed/Nix/main/performance/context/register/independent review required; no contextual precision or all-Korean completion claim.')
OUT.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print('Authored sena before targeted current runtime:',len(items),'original groups;',len(cases),'typed proposals;',len(entries),'complete Native owners; no shared changes',flush=True)
