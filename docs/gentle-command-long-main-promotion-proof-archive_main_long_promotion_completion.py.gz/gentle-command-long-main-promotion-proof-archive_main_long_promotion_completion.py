"""Preserve the passed promotion Nix gate and actual local main merge evidence."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = Path('/home/josh/projects/klem')
D = W / 'docs'
sha = lambda b: hashlib.sha256(b).hexdigest()
gate = json.loads((P / 'gentle-command-long-promoted-complete-nix-gate-retry2.json').read_bytes())
current = json.loads((P / 'main-long-promotion-merge-validation.json').read_bytes())
assert gate['state'] == current['state'] == 'passed' and gate['exit_code'] == 0
assert all(gate[k] and current[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged'])
assert current['controls'] == 133 and [v['controls'] for v in current['results']] == [101, 32, 0, 0]
assert all(v['exit_code'] == 0 for v in current['results'])
assert all(sha((W / name).read_bytes()) == digest for name, digest in current['frozen_inputs'].items())
for attr, prefix in [('klem', ''), ('klem-corpus-adapter', ''), ('klem-web-assets', 'web/')]:
    assert all(sha((W / (prefix + name)).read_bytes()) == digest
               for name, digest in gate['compiled_source_profiles'][attr]['files'].items()), 'all1137/1137/18 actual compile inputs'
for report, name in [(gate, 'gentle-command-long-promoted-complete-nix-gate-retry2.log'),
                     (current, 'main-long-promotion-merge-validation.log')]:
    assert sha((P / name).read_bytes()) == report['log_sha256']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=W)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD^1'], cwd=W, text=True).strip() == current['head']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD^2'], cwd=W, text=True).strip() == gate['head']
files = {}
for name in ['run_complete_gentle_command_long_promoted_nix_gate.py',
             'run_complete_gentle_command_long_promoted_nix_gate_retry1.py',
             'run_complete_gentle_command_long_promoted_nix_gate_retry2.py',
             'gentle-command-long-promoted-nix-fetch-failure.json',
             'gentle-command-long-promoted-nix-reference-failure.json',
             'gentle-command-long-promoted-complete-nix-gate-retry2.json',
             'gentle-command-long-promoted-complete-nix-gate-retry2.log',
             'main-long-promotion-merge-parent.json.gz', 'validate_main_long_promotion_merge.py',
             'main-long-promotion-merge-validation.json', 'main-long-promotion-merge-validation.log',
             Path(__file__).name]:
    raw = (P / name).read_bytes()
    output = D / ('gentle-command-long-main-promotion-proof-' + name + '.gz')
    assert not output.exists()
    packed = gzip.compress(raw, mtime=0)
    output.write_bytes(packed)
    files[name] = dict(path=output.name, source_sha256=sha(raw), archive_sha256=sha(packed))
output = D / 'gentle-command-long-main-promotion-proof-archive.json'
assert not output.exists()
output.write_text(json.dumps(dict(
    state='actual-long-promotion-four-Nix-checks-and-main133controls-passed', files=files,
    promotion_nix_head=gate['head'], main_merge_head=head, main_parent_head=current['head'],
    promotion_frozen_source_files=len(gate['frozen_inputs']),
    promotion_selected_source_files=gate['inventory_source_files'],
    main_frozen_source_files=len(current['frozen_inputs']),
    all_actual_compiled_inputs_match_main=True,
    compiled_profiles={k: len(v['files']) for k, v in gate['compiled_source_profiles'].items()},
    original35704cases_declarations_metadata_and517reviews_retained=True,
    exact_appended_cases=36, exact_appended_scoped_reviews=2, shared_cases=35740,
    required_judgments=31452, forbidden_judgments=4305, scoped_reviews=519, unreviewed_entries=196,
    all715original_source_fields_retained=True, Main_original_failure_archives_and_single_COV017cw_retained=True,
    actual_main_controls=133, actual_historical_controls=101, actual_long_ledger_controls=32,
    original_validation_scope_text_expected29_but_actual_results_record32=True,
    original_fetch_reference_failures_retained=True, original_failed_Main_Long_gates_remain_failed=True,
    fresh_main_full_Nix_quiet_context_register_independent_review='pending', full_coverage_complete=False), indent=2) + '\n')
print('Archived12 complete originals:actual promotion allfourNix checks;currentmain133controls;all1137/1137/18compileinputs match;oldfailures retained.', flush=True)
