"""Capture independently authored interactions without changing any expectation."""
import gzip
import hashlib
import json
import subprocess
import sys
import unicodedata
from pathlib import Path

prep = Path(__file__).resolve().parent
work = Path('/tmp/klem-willingness-question-prototype')
sys.path.insert(0, str(work / 'tools'))
from conjectural_additive_novel_audit import matches

sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
digest = lambda raw: hashlib.sha256(raw).hexdigest()
packet_path = prep / 'willingness-interaction-authored.json'
binding_path = prep / 'prototype-binaries-retry2.json'
out = prep / 'willingness-interaction-preflight.json.gz'
assert not out.exists()
packet = json.loads(packet_path.read_text())
assert packet['state'] == 'authored-before-interaction-probes'
binding = json.loads(binding_path.read_text())
assert binding['state'] == 'passed' and binding['inputs_unchanged']
cli = Path(binding['binaries']['klem']['path'])
assert sha(cli) == binding['binaries']['klem']['sha256']
for path, h in binding['frozen_inputs'].items():
    if path.startswith(str(work / 'src') + '/') or path in [str(work / 'Cargo.toml'), str(work / 'Cargo.lock')]:
        assert sha(path) == h, ('actual prototype runtime source unchanged', path)
db = Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db')
frozen = {str(p): sha(p) for p in [packet_path, binding_path, cli, db, Path(__file__)]}
for name, h in packet['source_inputs'].items():
    assert sha(work / name) == h
    frozen[str(work / name)] = h
items = [dict(c, target=c['judgments'][0]) for c in packet['cases']] + packet['policy_proposals']
r = {'state': 'running', 'binding_sha256': sha(binding_path), 'packet_sha256': sha(packet_path),
     'frozen_inputs': frozen, 'runs': [], 'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)},
     'scope': 'Current source-bound prototype interaction discovery, not a pre-implementation baseline. Preserve every independently authored target, raw/Native/policy distinction and original field. Failures and unjudged paths remain visible; shared ledger, regression implementation, installed/browser and independent contextual review remain pending.'}
for encoding in ['NFC', 'NFD']:
    raw = unicodedata.normalize(encoding, ' '.join(c['surface'] for c in items)).encode()
    for mode in ['raw', 'headword', 'compatible']:
        for cache in [0, 4096]:
            flags = {'raw': [], 'headword': ['--dict-only'], 'compatible': ['--dict-compatible']}[mode]
            command = [str(cli), 'text', '-', '--dictionary', str(db), *flags, '--cache-bytes', str(cache)]
            job = subprocess.run(command, input=raw, capture_output=True)
            assert job.returncode == 0 and not job.stderr
            rows = [json.loads(line) for line in job.stdout.splitlines()]
            assert ''.join(row['surface'] for row in rows).encode() == raw
            words = [(i, row) for i, row in enumerate(rows) if row['kind'] == 'word']
            assert len(words) == len(items)
            observations = []
            for item, (index, row) in zip(items, words, strict=True):
                assert row['surface'] == unicodedata.normalize(encoding, item['surface'])
                paths = (row.get('analysis') or {}).get('analyses', [])
                indices = [i for i, path in enumerate(paths) if matches(path, item['target'])]
                observed = {'id': item['id'], 'record_index': index, 'typed_path_indices': indices}
                if 'judgments' in item:
                    observed.update(authored_verdict=item['target']['verdict'], named_structural_judgment_satisfied=bool(indices) if item['target']['verdict'] == 'required' else not indices)
                else:
                    statuses = [row['dictionary']['readings'][i]['status'] for i in indices]
                    observed.update(morphological_verdict='unjudged', authored_status_if_present=item['dictionary_status_if_present'], actual_statuses=statuses,
                                    conditional_dictionary_policy_satisfied=all(status == item['dictionary_status_if_present'] for status in statuses))
                observations.append(observed)
            r['runs'].append({'encoding': encoding, 'mode': mode, 'cache_bytes': cache, 'command': command,
                              'exit_code': 0, 'input_sha256': digest(raw), 'records': len(rows),
                              'jsonl': job.stdout.decode(), 'jsonl_sha256': digest(job.stdout), 'observations': observations})
assert all(r['runs'][i]['jsonl'] == r['runs'][i + 1]['jsonl'] for i in range(0, len(r['runs']), 2))
r.update(state='complete-interaction-preflight-captured', inputs_unchanged=all(sha(p) == h for p, h in frozen.items()))
assert r['inputs_unchanged']
out.write_bytes(gzip.compress((json.dumps(r, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
raw_run = next(run for run in r['runs'] if run['encoding'] == 'NFC' and run['mode'] == 'raw')
for observed in raw_run['observations']:
    print(observed)
