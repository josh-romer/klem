"""Promote only the independent source/structural proposals into private regression fixtures."""
import gzip,hashlib,json,shutil
from pathlib import Path
prep=Path(__file__).resolve().parent;work=Path('/tmp/klem-gentle-command');fixtures=work/'tests/fixtures'
source=json.loads((prep/'gentle-command-original-source.json').read_bytes());assert not source['observed_runtime'] and not source['linguistic_judgments_promoted']
for name,target in [('gentle-command-original-source.json','gentle-command-source.json'),('gentle-command-native.json','gentle-command-native.json'),('gentle-command-native-entries.json','gentle-command-native-entries.json')]:
 p=fixtures/target;assert not p.exists();shutil.copyfile(prep/name,p)
sources={'gentle-command-'+ident.split(':')[1]:owner['url'] for ident,owner in source['owners'].items()}
cases=[]
for item in source['items']:
 j=dict(item['independent_typed_proposal'],id='lexical-path',verdict='required',required_rules=['ending.gentle_command'],source='gentle-command-'+item['entry_id'].split(':')[1],reason='Independently proposed lexical head and canonical ending from the complete original dictionary example; exact contextual sense and exclusion of other paths remain unjudged.')
 cases.append(dict(id=item['id'],surface=item['surface'],judgments=[j]))
# These structural boundaries are authored before any new runtime probe.
boundaries=[('오렴','오다',True),('살렴','살다',True),('먹으렴','먹다',True),('들으렴','듣다',True),('도우렴','돕다',True),('지으렴','짓다',True),('오으렴','오다',False),('살으렴','살다',False),('먹렴','먹다',False),('들렴','듣다',False),('도렴','돕다',False),('지렴','짓다',False)]
for n,(surface,lemma,allowed) in enumerate(boundaries,1):
 cases.append(dict(id='gentle-command-boundary-'+str(n),surface=surface,judgments=[dict(id='exact-stem-path',verdict='required' if allowed else 'forbidden',lemmas=[lemma],lemma_kinds=['predicate'],morphemes=['으렴'],morpheme_kinds=['ending'],required_rules=['ending.gentle_command'],source='gentle-command-79343',reason='Original ending notes require vowel-or-ㄹ short versus other-coda full attachment, including licensed irregular recovery; target only this exact path and keep all other candidates unjudged.')]))
for ident,surface,lemmas,kinds,morphs,morph_kinds in [('copula','학생이렴',['학생','이다'],['nominal','copula'],['으렴'],['ending']),('derived-adjective','학생답렴',['학생'],['nominal'],['답다','으렴'],['suffix','ending'])]:
 cases.append(dict(id='gentle-command-'+ident,surface=surface,judgments=[dict(id='bare-class-exclusion',verdict='forbidden',lemmas=lemmas,lemma_kinds=kinds,morphemes=morphs,morpheme_kinds=morph_kinds,required_rules=['ending.gentle_command'],source='gentle-command-79343',reason='The original ending notes select bare verbs; this exact known copular/adjectival derivation cannot borrow the ending. Other surface hypotheses remain unjudged.')]))
cases.append(dict(id='gentle-command-source-auxiliary',surface='물어보렴',judgments=[dict(id='separate-auxiliary-path',verdict='required',lemmas=['묻다','보다'],lemma_kinds=['predicate','auxiliary'],morphemes=['어','으렴'],morpheme_kinds=['ending','ending'],required_rules=['ending.gentle_command'],source='gentle-command-79340',reason='Independently proposed morphological alternative: existing -어 보다 auxiliary connection plus verb-attached gentle command, alongside the source lexical compound 물어보다; no contextual sense choice is assigned.')]))
suite=dict(schema_version=1,review_status='Source-based structural candidate judgments; independent Korean-language and contextual/register review pending. Original proposals authored before new runtime output.',sources=sources,cases=cases)
p=fixtures/'gentle-command-validity.json';assert not p.exists();p.write_text(json.dumps(suite,ensure_ascii=False,indent=2)+'\n')
label=work/'web/src/grammar-labels.json';raw=label.read_text();assert '"-으렴"' not in raw
anchor='  "-으련": {';assert raw.count(anchor)==1
entry={'kind':'ending','label':'Gentle command / permission','sources':[{'id':79340,'headword':'-렴','pos':'어미'},{'id':79343,'headword':'-으렴','pos':'어미'}],'note':'Canonical -(으)렴 follows verbs to express gentle permission or a softened command, in the source-listed very informal speech level. Context and social/register appropriateness are not selected.'}
encoded='  "-으렴": '+json.dumps(entry,ensure_ascii=False,indent=2).replace('\n','\n  ')+',\n';label.write_text(raw.replace(anchor,encoded+anchor))
base=json.loads(gzip.decompress((prep/'gentle-command-installed-baseline.json.gz').read_bytes()))
observations=[dict(surface=o['actual_record']['surface'],actual_record=o['actual_record']) for o in next(r for r in base['runs'] if r['family']=='individual-targets' and r['encoding']=='NFC' and r['mode']=='raw' and r['cache_bytes']==0)['observations']]
p=fixtures/'gentle-command-prior-paths.json';assert not p.exists();p.write_text(json.dumps(observations,ensure_ascii=False,indent=2)+'\n')
r=dict(state='independent-private-gentle-command-fixtures-authored',source_cases=8,stem_boundaries=12,bare_class_exclusions=2,auxiliary_cases=1,total_cases=len(cases),required=sum(j['verdict']=='required' for c in cases for j in c['judgments']),forbidden=sum(j['verdict']=='forbidden' for c in cases for j in c['judgments']),shared_ledger_unchanged=True,producer={'text':Path(__file__).read_text(),'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},private_fixture_sha256=hashlib.sha256((fixtures/'gentle-command-validity.json').read_bytes()).hexdigest(),new_runtime_observed=False)
out=prep/'gentle-command-prototype-preparation.json';assert not out.exists();out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print('Authored',len(cases),'private cases:',r['required'],'required/',r['forbidden'],'forbidden; no active ledger or review change')
