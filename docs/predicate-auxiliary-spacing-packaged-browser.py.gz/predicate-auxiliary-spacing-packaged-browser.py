"""Run the actual installed Nix SolidJS frontend against its compiled CLI/server and original dictionary."""
import datetime,hashlib,json,os,re,signal,socket,subprocess,time,urllib.request
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');P=ROOT
ASSETS=Path('/nix/store/pzcmhjvgc3z8qj0qj62ka0k1pdpyzfp3-klem-web-assets-0.1.0/share/klem-web');PREFIX=Path('/tmp/klem-predicate-auxiliary-spacing-packaged')
OUT=Path(str(PREFIX)+'-browser-runtime.json');assert not OUT.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
built_path=Path('/tmp/klem-predicate-auxiliary-spacing-packaged-binaries.json')
frontend_path=Path('/tmp/klem-predicate-auxiliary-spacing-main-frontend-build.json')
built=json.loads(built_path.read_bytes());frontend=json.loads(frontend_path.read_bytes())
snapshot=built['snapshot_files'];cli=Path(built['binaries']['cli']['path']);server=Path(built['binaries']['server']['path'])
driver=P/'web/tests/predicate-auxiliary-spacing.mjs';DB=ROOT/'data/dictionaries/krdict/krdict.db'
assert all(sha((P/n).read_bytes())==v['sha256'] for n,v in snapshot.items())
assert all(sha((P/n).read_bytes())==v['sha256'] for n,v in frontend['source_inputs'].items())
assert all(sha((ASSETS/n).read_bytes())==v['sha256'] for n,v in frontend['assets'].items())
source=Path('/tmp/klem-additive-ppundeoreo-source-discovery.json.gz')
replay=Path('/tmp/klem-additive-ppundeoreo-main-source-replay.json.gz');owners=Path('/tmp/klem-predicate-auxiliary-spacing-owner-native-closure.json.gz')
frozen={str(p):sha(p.read_bytes()) for p in [cli,server,driver,DB,source,replay,owners,Path(__file__),built_path,frontend_path]}
with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
url=f'http://127.0.0.1:{port}';command=[str(server),'--port',str(port),'--assets',str(ASSETS),'--dictionary',str(DB)]
report={'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'url':url,
        'snapshot_files':snapshot,'frontend_inputs':frontend['source_inputs'],'assets':frontend['assets'],'frozen_inputs':frozen,
        'scope':'Actual installed Nix predicate-auxiliary spacing CLI/server and built SolidJS assets. Twenty source-licensed spacing cases and joined-context diagrams; distinct spans remain separate, source panes/Native entries and exact Unicode/filter CLI exports. Full Rust, packaged runtime/performance and broader context/independent review remain separate.'}
def save():OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
save();job=None;serverlog=Path(str(PREFIX)+'-browser-server.log');browserlog=Path(str(PREFIX)+'-browser-driver.log')
try:
    with serverlog.open('xb') as stream:
        job=subprocess.Popen(command,cwd=P,stdout=stream,stderr=subprocess.STDOUT);report['server_pid']=job.pid;save()
        deadline=time.monotonic()+30
        while True:
            assert job.poll() is None,'Owned server exited during startup'
            try:
                with urllib.request.urlopen(url,timeout=2) as response:html=response.read()
                break
            except OSError:assert time.monotonic()<deadline;time.sleep(.1)
        assert html==(ASSETS/'index.html').read_bytes();checks=[]
        for path in re.findall(r'(?:src|href)="(/assets/[^"?#]+\.(?:js|css))"',html.decode()):
            with urllib.request.urlopen(url+path,timeout=20) as response:raw=response.read()
            assert raw==(ASSETS/path.lstrip('/')).read_bytes();checks.append({'path':path,'sha256':sha(raw),'bytes':len(raw)})
        assert len(checks)==2;report['served_asset_checks']=checks
        env=dict(os.environ,KLEM_ROOT=str(P),KLEM_DEPENDENCY_ROOT=str(ROOT),KLEM_WEB_URL=url,KLEM_BIN=str(cli),
                 KLEM_DICTIONARY=str(DB),KLEM_CAPTURE_PREFIX=str(PREFIX),KLEM_PPUN_SOURCE=str(source),KLEM_PPUN_REPLAY=str(replay),
                 KLEM_PPUN_OWNERS=str(owners),CHROMIUM_PATH='/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium')
        report['browser_command']=['node',str(driver)];save()
        with browserlog.open('xb') as stream:completed=subprocess.run(report['browser_command'],cwd=P,env=env,stdout=stream,stderr=subprocess.STDOUT)
        assert completed.returncode==0,f'Browser exit {completed.returncode}; see {browserlog}'
        report.update(state='passed',exit_code=0,browser_sha256=sha(Path(str(PREFIX)+'-browser.json').read_bytes()))
except BaseException as error:report.update(state='failed',exit_code=1,error=repr(error));raise
finally:
    if job is not None:
        if job.poll() is None:job.send_signal(signal.SIGINT)
        report.update(server_exit_code=job.wait(timeout=20),server_stopped=True)
    report['inputs_unchanged']=(all(sha(Path(p).read_bytes())==h for p,h in frozen.items())
        and all(sha((P/n).read_bytes())==v['sha256'] for n,v in snapshot.items())
        and all(sha((P/n).read_bytes())==v['sha256'] for n,v in frontend['source_inputs'].items())
        and all(sha((ASSETS/n).read_bytes())==v['sha256'] for n,v in frontend['assets'].items()))
    report['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    report['server_log_sha256']=sha(serverlog.read_bytes());report['driver_log_sha256']=sha(browserlog.read_bytes()) if browserlog.exists() else None;save()
assert report['inputs_unchanged'] and report['server_stopped'] and report['server_exit_code'] in [-2,130]
print('Actual installed Nix predicate-auxiliary spacing SolidJS browser, exact CLI/Native endpoints and served assets passed; owned server stopped.',flush=True)
