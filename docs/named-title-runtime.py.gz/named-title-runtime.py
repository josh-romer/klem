"""Track every named-title case and preserve prior candidates and spacing hypotheses."""
import hashlib,json,subprocess,unicodedata
from pathlib import Path
ROOT=Path('/tmp/klem-named-title-prototype');OUT=Path('/tmp/klem-named-title-runtime.json');assert not OUT.exists()
BEFORE=Path('/home/josh/projects/klem/.direnv/surname-runtime-target/debug/klem');AFTER=Path('/home/josh/projects/klem/.direnv/named-title-target/debug/klem');DB=Path('/home/josh/projects/klem/data/dictionaries/krdict/krdict.db');CASES=ROOT/'tests/fixtures/named-title-spacing-cases.json';RULE='spacing.proper_name_title'
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest();inputs={str(p):sha(p) for p in [BEFORE,AFTER,DB,CASES,Path(__file__)]};cases=json.loads(CASES.read_text())['cases'];runs=[];observations=[]
key=lambda h:(h.get('rule'),h['spaced'],tuple(h['inserted_at']))
for encoding in ['NFC','NFD']:
 text='前🙂「'+' '.join(unicodedata.normalize(encoding,c['surface']) for c in cases)+'」'
 for cache in [0,4096]:
  for mode,flag in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
   common=['text','-','--dictionary',str(DB),'--proper-names','--suggest-spacing','--cache-bytes',str(cache),*flag];captures=[]
   for binary in [BEFORE,AFTER]:
    job=subprocess.run([str(binary),*common],input=text.encode(),capture_output=True,check=True);assert not job.stderr;captures.append([json.loads(line) for line in job.stdout.splitlines()])
   before,after=captures;assert len(before)==len(after)
   for old,new in zip(before,after,strict=True):
    assert {k:v for k,v in old.items() if k!='spacing'}=={k:v for k,v in new.items() if k!='spacing'}
    if old.get('spacing'):
     oldkeys=[key(h) for h in old['spacing']['alternatives']]
     assert [key(h) for h in new['spacing']['alternatives'] if key(h) in oldkeys]==oldkeys
     for h in old['spacing']['alternatives']:assert h in new['spacing']['alternatives']
   words=[r for r in after if r['kind']=='word' and r['surface']!='前'];assert len(words)==len(cases)
   for c,record in zip(cases,words,strict=True):
    selected=[h for h in record['spacing']['alternatives'] if h.get('rule')==RULE]
    if 'required_spacing' in c:
     h=next(h for h in selected if unicodedata.normalize('NFC',h['spaced'])==c['required_spacing'])
     assert len(h['records'])==2 and h['records'][0]['entry_witnesses']==['ud-ko-kaist:proper-name:park'] and h['records'][1]['entry_witnesses']==['krdict:62818']
     for segment in h['records']:assert text.encode()[segment['span']['start']:segment['span']['end']].decode()==segment['surface']
    else:assert not selected,c['id']
    observations.append({'case_id':c['id'],'encoding':encoding,'mode':mode,'cache_bytes':cache,'record':record,'contextual_verdict':'unjudged'})
   runs.append({'encoding':encoding,'mode':mode,'cache_bytes':cache,'text':text,'before':before,'after':after})
assert all(sha(p)==digest for p,digest in inputs.items())
r={'state':'named-title-current-runtime-passed','runs':runs,'observations':observations,'frozen_inputs':inputs,'inputs_unchanged':True,'scope':'All108case observations retain every earlier word/candidate/dictionary/spacing alternative and exact UTF8 slices. New nominal title particles are structural hypotheses; copular/other formations, contextual review, broad and installed checks remain open.'};OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print('Passed',len(observations),'individual observations and all prior hypotheses')
