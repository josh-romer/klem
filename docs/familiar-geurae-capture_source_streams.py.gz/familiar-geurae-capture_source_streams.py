"""Replay complete original source text in every Unicode/filter/cache mode."""
import gzip,hashlib,json,subprocess,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PREP=OUT/'full-native-preparation.json.gz';prepared=json.loads(gzip.decompress(PREP.read_bytes()))
BEFORE=ROOT/'.direnv/explanatory-se-target/debug/klem';AFTER=ROOT/'.direnv/familiar-geurae-target/debug/klem';DB=(ROOT/'data/dictionaries/krdict/krdict.db').resolve()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
frozen={str(p):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in [BEFORE,AFTER,DB,PREP,Path(__file__)]}
runs=[];observations=[];cache_parity={}
for encoding in ['NFC','NFD']:
 text=unicodedata.normalize(encoding,prepared['complete_source_text']);original=text.encode()
 for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
  for cache in [0,8388608]:
   captures=[]
   for cli in [BEFORE,AFTER]:
    command=[str(cli),'text','-','--dictionary',str(DB),'--cache-bytes',str(cache),*flags]
    job=subprocess.run(command,input=original,capture_output=True,check=True);assert not job.stderr
    rows=[json.loads(line) for line in job.stdout.splitlines()];cursor=0
    for r in rows:
     assert r['span']['start']==cursor and original[cursor:r['span']['end']].decode()==r['surface'];cursor=r['span']['end']
    assert cursor==len(original)
    captures.append({'command':command,'exit_code':0,'stdout_sha256':sha(job.stdout),'jsonl':job.stdout.decode(),'records':rows})
   old,new=[c['records'] for c in captures];assert len(old)==len(new)
   additions=[]
   for ordinal,(a,b) in enumerate(zip(old,new,strict=True),1):
    assert {k:v for k,v in a.items() if k not in ['analysis','dictionary']}=={k:v for k,v in b.items() if k not in ['analysis','dictionary']}
    if a.get('analysis') is None:assert a==b;continue
    before,after=a['analysis']['analyses'],b['analysis']['analyses']
    assert [p for p in after if p in before]==before,(encoding,mode,cache,ordinal,'old path order')
    assert all(m in b['dictionary']['lemmas'] for m in a['dictionary']['lemmas'])
    for path in before:assert a['dictionary']['readings'][before.index(path)]==b['dictionary']['readings'][after.index(path)]
    for path in after:
     if path in before:continue
     assert any(r in path['rules'] for r in ['particle.familiar_geurae'])
     span=b['span'];left=original.rfind(b'\n',0,span['start'])+1;right=original.find(b'\n',span['end']);line=original[left:right if right>=0 else len(original)].decode()
     value={'encoding':encoding,'mode':mode,'cache_bytes':cache,'record':ordinal,'surface':b['surface'],'span':span,'complete_original_line':line,'analysis':path,'dictionary_assessment':b['dictionary']['readings'][after.index(path)],'contextual_verdict':'unjudged','independent_review':'pending'}
     ident=sha(json.dumps(value,ensure_ascii=False,sort_keys=True).encode())[:24]
     additions.append({'id':'familiar-geurae-source-stream-'+ident,**value})
   if cache==0:cache_parity[(encoding,mode)]=[c['stdout_sha256'] for c in captures]
   else:assert cache_parity[(encoding,mode)]==[c['stdout_sha256'] for c in captures]
   observations.extend(additions)
   runs.append({'encoding':encoding,'mode':mode,'cache_bytes':cache,'input_text':text,'input_sha256':sha(original),'captures':captures,'individual_additions':additions})
   print(encoding,mode,cache,len(new),'complete frames;',len(additions),'new paths',flush=True)
assert len(runs)==12 and all(hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()==v for p,v in frozen.items())
report={'state':'passed','complete_original_groups':prepared['complete_groups'],'complete_source_text':prepared['complete_source_text'],'runs':runs,'individual_additions':observations,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':frozen[str(Path(__file__))]},'scope':'Actual complete4original-group source replay across all12NFC/NFD/raw/headword/compatible/cache choices. Original bytes, paths/order/Native assessments conserved, each addition gets stable ID and complete original line. Contextual and independent review pending; full corpus/history/broad distributions separate.'}
(OUT/'source-streams.json.gz').write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('All12complete-source streams preserved',flush=True)
