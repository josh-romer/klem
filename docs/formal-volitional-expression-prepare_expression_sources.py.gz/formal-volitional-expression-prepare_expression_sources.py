"""Preserve separate expression homonyms and author their targets before probing them."""
import gzip
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
PREP = ROOT / '.direnv/formal-volitional-expression-prepared'
PREP.mkdir(exist_ok=True)
assert not (PREP / 'source-preparation.json.gz').exists()
sys.path.insert(0, str(ROOT / 'tools'))
from native_lmf import entry, feature

sha = lambda raw: hashlib.sha256(raw).hexdigest()
db = sqlite3.connect((ROOT / '.direnv/dictionary-restoration/krdict.db').resolve().as_uri() + '?mode=ro', uri=True)
ids = ['krdict:89455', 'krdict:89456']
owners = {ident: json.loads(db.execute('select data from entries where id=?', (ident,)).fetchone()[0]) for ident in ids}
groups = []
for ident, owner in owners.items():
    assert owner['id'] == ident and owner['homonym'] == '2'
    assert owner['pos'] == '품사 없음' and owner['lexical_unit'] == '문법‧표현'
    for sense in owner['senses']:
        for ordinal, lines in enumerate(sense['examples']):
            groups.append({'id': f'formal-volitional-expression-{ident.split(":")[1]}-sense-{sense["id"]}-group-{ordinal+1}',
                           'source_entry_id': ident, 'source_headword': owner['headword'],
                           'sense_id': sense['id'], 'group_ordinal': ordinal,
                           'complete_original_group': lines, 'source_notes': owner['notes'],
                           'sense_notes': sense['notes'], 'definition': sense['definition']})
targets = [('가시렵니까', '가다', ['시']), ('배우렵니까', '배우다', []),
           ('빌리렵니까', '빌리다', []), ('가시렵니까', '가다', ['시']),
           ('모으렵니까', '모으다', []), ('참으렵니까', '참다', []),
           ('숨으렵니까', '숨다', []), ('먹으렵니까', '먹다', [])]
assert len(groups) == len(targets) == 8
proposals = []
cases = []
for group, (surface, lemma, prefinals) in zip(groups, targets, strict=True):
    raw = '\n'.join(group['complete_original_group']).encode()
    assert raw.count(surface.encode()) == 1
    judgment = {'id': 'path', 'lemmas': [lemma], 'lemma_kinds': ['predicate'],
                'morphemes': [*prefinals, '으렵니까'],
                'morpheme_kinds': ['prefinal'] * len(prefinals) + ['ending'],
                'required_rules': ['ending.formal_volitional'], 'verdict': 'required',
                'source': group['source_entry_id'],
                'reason': 'Independently selected lexical path in the complete original expression example. Canonical 으렵니까 represents the existing short/full question pair. Expression homonym2 and its contraction note remain separate from ending owners and do not establish a contextual sense or an alternative multi-predicate decomposition.'}
    cases.append({'id': group['id'], 'surface': surface, 'judgments': [judgment]})
    proposals.append({**group, 'surface': surface, 'surface_byte_offset': raw.index(surface.encode()),
                      'judgment': judgment})
needed = set(ids) | {'krdict:86548', 'krdict:86549', 'krdict:86604', 'krdict:86605'}
for headword in {lemma for _, lemma, _ in targets}:
    for ident, raw in db.execute('select id,data from entries where headword=?', (headword,)):
        if json.loads(raw)['lexical_unit'] == '단어':
            needed.add(ident)
expected = {ident: json.loads(db.execute('select data from entries where id=?', (ident,)).fetchone()[0]) for ident in sorted(needed)}
originals, exports = {}, {}
for path in sorted((ROOT / '.direnv/dictionary-restoration/2026-09').glob('*.json')):
    raw = path.read_bytes()
    selected = []
    for value in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
        ident = 'krdict:' + value['val']
        if ident not in needed:
            continue
        assert ident not in originals and entry(value) == expected[ident], ident
        originals[ident] = value
        selected.append(ident)
    if selected:
        exports[path.name] = {'bytes': len(raw), 'sha256': sha(raw), 'ids': selected}
assert set(originals) == needed and {ident: entry(value) for ident, value in originals.items()} == expected
queue = json.loads((ROOT / 'docs/inventory-review-queue.json').read_bytes())
assert not set(ids) & {row['source']['id'] for row in queue['entries']}
tension = {'id': 'formal-volitional-expression-89456-vowel-stem-example',
           'source_entry_id': 'krdict:89456', 'surface': '모으렵니까', 'lexical_target': '모으다',
           'complete_original_group': groups[4]['complete_original_group'],
           'note': 'The full-form entry note names non-ㄹ consonantal stems; its original 모으렵니까 example has vowel-final 모으다 and uses short 렵니까 after that lexical stem. Preserve both source fields without silently changing the note, stem or source identity. No verdict for other lexical hypotheses.'}
producer = {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())}
packet = {'state': 'complete-original-expression-sources-and-independent-targets-before-probe',
          'expression_entries': owners, 'complete_groups': groups,
          'complete_source_text': '\n'.join(line for group in groups for line in group['complete_original_group']),
          'complete_imported_entries': expected, 'original_native_entries': originals,
          'original_exports': exports, 'dictionary_metadata': dict(db.execute('select key,value from metadata')),
          'independent_proposals': proposals, 'source_tensions': [tension], 'producer': producer,
          'scope': 'Two separately attributed homonym2/POS품사없음 expression owners outside715inventory, eight complete groups and eight independently authored lexical paths. Their contraction notes remain attributed notes rather than an automatic lemma expansion. Four ending owners and every lexical homonym are retained independently. No engine output was read. Runtime/library/CLI/browser/corpus/timing and independent contextual review remain separate.'}
(PREP / 'source-preparation.json.gz').write_bytes(gzip.compress((json.dumps(packet, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
suite = {'schema_version': 1, 'review_status': 'Eight original expression-example targets independently authored before their runtime probe; no original59 ending judgment is changed.',
         'sources': {ident: owner['url'] for ident, owner in owners.items()}, 'cases': cases}
(PREP / 'formal-volitional-expression-validity.json').write_text(json.dumps(suite, ensure_ascii=False, indent=2) + '\n')
print('Prepared two separate expression owners, eight complete groups and eight targets with', len(originals), 'original Native identities', flush=True)
