"""Bind installed interaction display to the complete new compiled Rust source snapshot."""
import gzip,hashlib,json,re,subprocess
from pathlib import Path
prep=Path(__file__).resolve().parent;work=Path('/tmp/klem-willingness-interactions');out=prep/'willingness-interaction-browser-source-binding-controls-retry1.json';assert not out.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
paths=[work/p for p in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=work).decode().split('\0')[:-1]]+[Path(__file__)]
frozen={str(p):sha(p) for p in paths};r=dict(state='running',frozen_inputs=frozen,runs=[],producer={'text':Path(__file__).read_text(),'sha256':sha(__file__)})
out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
for i,command in enumerate([['python3','tools/willingness_question_interaction_browser_audit.py'],['python3','-m','unittest','discover','-s','tools','-p','test_willingness_question_interaction_browser_audit.py']]):
 log=prep/('willingness-interaction-browser-source-binding-controls-retry1-'+str(i)+'.log');assert not log.exists()
 with log.open('xb') as stream:result=subprocess.run(command,cwd=work,stdout=stream,stderr=subprocess.STDOUT)
 r['runs'].append(dict(command=command,exit_code=result.returncode,log_sha256=sha(log)));out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');assert result.returncode==0
 if i==1:assert re.search(rb'Ran 17 tests in ',log.read_bytes()) and log.read_bytes().rstrip().endswith(b'OK')
changed=[p for p,h in frozen.items() if sha(p)!=h];r.update(state='passed' if not changed else 'failed',controls=17,inputs_unchanged=not changed,changed_inputs=changed);out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');assert r['inputs_unchanged']
p=work/'docs/willingness-question-interaction-preflight.json';d=json.loads(p.read_bytes());sha_raw=lambda raw:hashlib.sha256(raw).hexdigest()
for name in ['validate_interaction_browser_source_binding.py','willingness-interaction-browser-source-binding-initial-failure.json','willingness-interaction-browser-source-binding-controls-0.log','willingness-interaction-browser-source-binding-controls-1.log',Path(__file__).name,out.name,'willingness-interaction-browser-source-binding-controls-retry1-0.log','willingness-interaction-browser-source-binding-controls-retry1-1.log']:
 raw=(prep/name).read_bytes();target=work/'docs'/('willingness-question-interaction-browser-proof-'+name+'.gz');assert not target.exists();target.write_bytes(gzip.compress(raw,mtime=0));d['archives'][name]={'path':target.name,'sha256':sha(target),'original_sha256':sha_raw(raw)}
d['interaction_installed_browser'].update(complete_source_binding_controls=17,current_production_matches_parent_from_full_rust_snapshot=True,compiled_test_profile_differences=['tests/fixtures/validity.json','tests/validity.rs','tests/willingness_question.rs'],new_fixture_outside_inherited_profile='tests/fixtures/willingness-question-interaction-validity.json')
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print('Independent browser17controls and actual1176Rust source equivalence passed with all captured files unchanged')
