"""Run current installed corruption controls only after actual complete captures exist."""
import datetime
import gzip
import hashlib
import json
import os
import re
import subprocess
import sys
import unittest
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-command-gena'
OUT = P / 'friendly-command-gena-promoted-installed-audits.json'
LOG = P / 'friendly-command-gena-promoted-installed-audits.log'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=W)


def main():
    assert not OUT.exists() and not LOG.exists()
    def read(name):
        raw = (P / name).read_bytes()
        return json.loads(gzip.decompress(raw) if name.endswith('.gz') else raw)
    package = read('friendly-command-gena-promoted-nix-packages.json')
    installed = read('friendly-command-gena-promoted-installed-runtime.json.gz')
    browser = read('friendly-command-gena-promoted-installed-browser-runtime.json')
    gate = read('friendly-command-gena-promoted-complete-nix-gate-retry2.json')
    assert all(r['state'] == 'passed' for r in [gate, package, installed, browser])
    assert all(r['head_unchanged'] and r['index_unchanged'] and r['inputs_unchanged'] for r in [gate, package, installed, browser])
    assert installed['source_unchanged'] and browser['source_unchanged']
    source = package['frozen_inputs']
    assert not git('status', '--porcelain')
    assert git('rev-parse', 'HEAD').decode().strip() == package['head']
    assert sha(git('ls-files', '--stage', '-z')) == package['index_sha256']
    assert all(sha((W / name).read_bytes()) == digest for name, digest in source.items())
    frozen = dict(installed['frozen_inputs'])
    for path, digest in browser['frozen_inputs'].items():
        assert path not in frozen or frozen[path] == digest
        frozen[path] = digest
    paths = [
        'friendly_command_gena_promoted_installed_audit_retry2.py',
        'test_friendly_command_gena_promoted_installed_audit_retry2.py', Path(__file__).name,
        'friendly-command-gena-promoted-complete-nix-gate-retry2.json', 'friendly-command-gena-promoted-complete-nix-gate-retry2.log',
        'friendly-command-gena-promoted-nix-packages.json', 'friendly-command-gena-promoted-nix-packages.log',
        'friendly-command-gena-promoted-release-rust.log',
        'friendly-command-gena-promoted-installed-runtime.json.gz',
        'friendly-command-gena-promoted-installed-browser-runtime.json',
        'friendly-command-gena-promoted-installed-browser-runtime.log',
        'friendly-command-gena-promoted-installed-browser.json',
        'run_friendly_command_gena_promoted_nix_gate_retry2.py',
        'build_friendly_command_gena_promoted_nix_packages_retry2.py',
        'capture_friendly_command_gena_promoted_installed_runtime_retry2.py',
        'run_friendly_command_gena_promoted_installed_browser_retry2.py', 'friendly-command-gena-browser.mjs',
    ]
    for name in paths:
        path = P / name; frozen[str(path)] = sha(path.read_bytes())
    sys.path.insert(0, str(P))
    sys.path.insert(0, str(W / 'tools'))
    import friendly_command_gena_promoted_installed_audit_retry2 as audit
    import test_friendly_command_gena_promoted_installed_audit_retry2 as controls
    assert Path(audit.__file__).resolve() == P / 'friendly_command_gena_promoted_installed_audit_retry2.py'
    assert Path(audit.original.__file__).resolve() == W / 'tools/friendly_command_gena_installed_audit.py'
    assert Path(audit.revision.__file__).resolve() == W / 'tools/friendly_command_gena_revision.py'
    suite = unittest.defaultTestLoader.loadTestsFromModule(controls)
    assert suite.countTestCases() == 33
    r = dict(state='running', head=package['head'], index_sha256=package['index_sha256'], source_inputs=source,
             frozen_inputs=frozen, protected_binaries=package['protected_binaries'],
             producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
             module_origins=dict(audit=str(Path(audit.__file__).resolve()), historical=str(Path(audit.original.__file__).resolve()), revision=str(Path(audit.revision.__file__).resolve())),
             started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             scope='Actual33 independent current promoted installed controls after complete Nix/packages/full replay/browser. Full actual capture streams and original candidate/Native/annotation/browser assertions retained. Current source, all evidence inputs, HEAD/index and six protected binaries frozen. No main/quiet/context/register/independent Korean review or full checklist completion claim.')
    def save(): OUT.write_text(json.dumps(r, indent=2) + '\n')
    save()
    try:
        with LOG.open('x') as log:
            result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
            log.flush()
        r.update(controls=result.testsRun, failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped))
        assert result.wasSuccessful() and result.testsRun == 33 and not result.skipped
        r['summary'] = controls.Controls.summary
        r['state'] = 'passed'
    except BaseException as error:
        r.update(state='failed', error=repr(error)); raise
    finally:
        r.update(inputs_unchanged=all(sha(Path(name).read_bytes()) == digest for name, digest in frozen.items()),
                 source_unchanged=all(sha((W / name).read_bytes()) == digest for name, digest in source.items()),
                 head_unchanged=git('rev-parse', 'HEAD').decode().strip() == package['head'],
                 index_unchanged=sha(git('ls-files', '--stage', '-z')) == package['index_sha256'],
                 protected_binaries_unchanged=all(sha(Path(name).read_bytes()) == digest for name, digest in package['protected_binaries'].items()),
                 log_sha256=sha(LOG.read_bytes()) if LOG.exists() else None,
                 finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
        if not all(r[k] for k in ['inputs_unchanged', 'source_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged']): r['state'] = 'failed'
        save()
    assert r['state'] == 'passed'
    print('Actual33 promoted installed controls passed; all captured source/evidence/HEAD/index/protected binaries unchanged.', flush=True)


if __name__ == '__main__': main()
