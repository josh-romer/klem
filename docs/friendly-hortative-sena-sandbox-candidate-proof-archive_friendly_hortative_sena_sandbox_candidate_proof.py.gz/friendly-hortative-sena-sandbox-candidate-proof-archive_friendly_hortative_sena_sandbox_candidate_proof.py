"""Archive actual live/captured evidence-mode validation with every old control retained."""
import gzip
import hashlib
import json
from pathlib import Path

P=Path(__file__).resolve().parent
W=P.parent/'friendly-hortative-sena'
D=W/'docs'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
r=json.loads((P/'friendly-hortative-sena-sandbox-candidate.json').read_bytes())
assert r['state']=='passed' and r['controls']==123 and len(r['results'])==7
assert all(row['exit_code']==0 for row in r['results'])
assert all(r[k] for k in ['inputs_unchanged','external_inputs_unchanged','protected_binaries_unchanged','head_unchanged','index_unchanged'])
assert all(sha((W/n).read_bytes())==d for n,d in r['frozen_inputs'].items())
assert all(sha(Path(p).read_bytes())==d for p,d in r['external_inputs'].items())
assert sha((P/'friendly-hortative-sena-sandbox-candidate.log').read_bytes())==r['log_sha256']
assert r['old41_and34_test_source_bytes_exact']
files={}
for path in [P/'validate_friendly_hortative_sena_sandbox_candidate.py',
             P/'friendly-hortative-sena-sandbox-candidate.json',P/'friendly-hortative-sena-sandbox-candidate.log',
             *sorted((P/'sandbox-candidate').glob('*.py')),Path(__file__)]:
    raw=path.read_bytes();name='friendly-hortative-sena-sandbox-candidate-proof-'+path.name+'.gz'
    output=D/name;assert not output.exists();packed=gzip.compress(raw,mtime=0);output.write_bytes(packed)
    files[path.name]=dict(path=name,source_sha256=sha(raw),archive_sha256=sha(packed))
out=D/'friendly-hortative-sena-sandbox-candidate-proof-archive.json';assert not out.exists()
out.write_text(json.dumps(dict(state='actual-external-live-and-captured-Sena-evidence-modes123controls-passed',files=files,
    controls=123,old_runtime_controls_live=41,old_runtime_controls_captured=41,new_binary_evidence_controls=7,old_wide_controls_captured=34,
    every_old41_and34_test_source_byte_exact=True,live_mode_verifies_all_six_actual_executable_files=True,
    captured_mode_explicitly_does_not_claim_live_executable_verification=True,
    captured_mode_checks_current44_production_and18_frontend_inputs_and_full_immutable_runtime_evidence=True,
    executable_file_read_denial_control_passed=True,source_head_index_and_protected_binaries_unchanged=True,
    scope='External candidate validated before worktree integration. Explicit immutable artifact replay enables future Nix sandbox checks; no actual sandboxed/fullNix execution claimed.',
    actual_Nix_sandbox_execution='pending',full_coverage_complete=False),indent=2)+'\n')
print('Archived',len(files),'full originals for actual123live/captured controls.',flush=True)
