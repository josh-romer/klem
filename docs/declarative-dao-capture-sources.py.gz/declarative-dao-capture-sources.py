"""Bind installed package sources and exact draft changes to the current committed baseline."""
import gzip,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from reported_deoni_complete_sources import source_store_path
RECEIPT=Path('/tmp/klem-declarative-dao-nix-retry1.json');OUT=Path('/tmp/klem-declarative-dao-installed-sources.json.gz');assert not OUT.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
receipt=json.loads(RECEIPT.read_bytes());assert receipt['state']=='passed' and receipt['exit_code']==0 and receipt['snapshot_unchanged']
prior_path=ROOT/'docs/possessive-bound-noun-installed-sources.json.gz';prior=json.loads(gzip.decompress(prior_path.read_bytes()))
expected={n:v for n,v in receipt['snapshot_files'].items() if n not in ['flake.nix','flake.lock']}
assert len(expected)==985 and set(prior['snapshot_files'])<=set(expected)
base_texts={}
for label in ['klem','web-assets']:
 profile=prior['profiles'][label]
 for name,record in profile['files'].items():
  raw=(Path(profile['source'])/name).read_bytes();assert {'bytes':len(raw),'sha256':sha(raw)}==prior['snapshot_files'][record['snapshot_path']]
  base_texts[record['snapshot_path']]=raw.decode()
assert len(base_texts)==977
profiles={};snapshot={};texts={}
for label,suffix in [('klem','-klem-0.1.0'),('web-assets','-klem-web-assets-0.1.0'),('corpus-adapter','-klem-corpus-adapter-0.1.0')]:
 output=next(o for o in receipt['outputs'] if o.endswith(suffix));drv=subprocess.check_output(['nix-store','--query','--deriver',output],text=True).strip();drv_text=subprocess.check_output(['nix','derivation','show',drv],text=True);d=json.loads(drv_text)
 assert len(d)==1 and d[drv]['outputs']['out']['path']==output
 source=d[drv]['env']['src'];files={};directories=[]
 for p in Path(source).rglob('*'):
  assert not p.is_symlink();relative=str(p.relative_to(source))
  if p.is_dir():directories.append(relative);continue
  name='web/'+relative if label=='web-assets' else relative;raw=p.read_bytes();record={'bytes':len(raw),'sha256':sha(raw)}
  assert record==expected[name],name
  if name in snapshot:assert snapshot[name]==record and texts[name]==raw.decode()
  snapshot[name]=record;texts[name]=raw.decode();files[relative]={**record,'snapshot_path':name,'executable':bool(p.stat().st_mode&0o111)}
 job=subprocess.Popen(['nix-store','--dump',source],stdout=subprocess.PIPE,stderr=subprocess.PIPE);h=hashlib.sha256();count=0
 while chunk:=job.stdout.read(1048576):h.update(chunk);count+=len(chunk)
 error=job.stderr.read();assert job.wait()==0,error;assert source_store_path(h.hexdigest())==source
 profiles[label]={'source':source,'package':output,'derivation':drv,'derivation_json_text':drv_text,'derivation_json_sha256':sha(drv_text.encode()),'files':files,'directories':sorted(directories),'nar_sha256':h.hexdigest(),'nar_bytes':count,'nar_command':['nix-store','--dump',source],'actual_dump_verified':True}
 print(label,len(files),'actual source files and source NAR verified',flush=True)
assert snapshot==expected and len(snapshot)==985
updates={n:{'before_sha256':sha(base_texts[n].encode()) if n in base_texts else None,'after_sha256':sha(value.encode()),'after_text':value} for n,value in texts.items() if n not in base_texts or value!=base_texts[n]}
assert len(updates)==19 and sum(u['before_sha256'] is None for u in updates.values())==8
assert profiles['klem']['source']==profiles['corpus-adapter']['source'] and profiles['klem']['files']==profiles['corpus-adapter']['files']
r={'schema_version':1,'state':'passed','receipt_sha256':sha(RECEIPT.read_bytes()),'baseline':{'proof':'docs/possessive-bound-noun-installed-sources.json.gz','proof_sha256':sha(prior_path.read_bytes())},'snapshot_files':snapshot,'updates':updates,'profiles':profiles,'actual_source_profiles_verified':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'scope':'Actual isolated installed dao union of985inputs,11updates/8newfiles from the977input current committed package. Every source byte and complete source NAR/derivation is retained; installed runtime and Root integration remain separate.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
