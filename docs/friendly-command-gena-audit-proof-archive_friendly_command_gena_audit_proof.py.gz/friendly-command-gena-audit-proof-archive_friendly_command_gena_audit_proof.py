import gzip,hashlib,json,re
from pathlib import Path
P=Path(__file__).resolve().parent;W=Path('/home/josh/projects/klem/.direnv/friendly-command-gena');D=W/'docs'
sha=lambda b:hashlib.sha256(b).hexdigest()
runtime=json.loads((P/'friendly-command-gena-runtime-audit-controls.json').read_bytes());browser=json.loads((P/'friendly-command-gena-browser-audit-controls-retry4.json').read_bytes())
assert runtime['state']==browser['state']=='passed' and runtime['exit_code']==browser['exit_code']==0
for r,n,count in [(runtime,'friendly-command-gena-runtime-audit-controls.log',40),(browser,'friendly-command-gena-browser-audit-controls-retry4.log',18)]:
 raw=(P/n).read_bytes();assert sha(raw)==r['log_sha256'] and ('Ran '+str(count)+' tests in ').encode() in raw and raw.rstrip().endswith(b'OK') and r['inputs_unchanged']
files={}
names=sorted(path.name for path in P.glob('*friendly*gena*audit*') if path.is_file())
inputs={n:P/n for n in names}
inputs.update({n:W/'tools'/n for n in ['friendly_command_gena_revision.py','friendly_command_gena_runtime_audit.py','test_friendly_command_gena_runtime_audit.py','friendly_command_gena_browser_audit.py','test_friendly_command_gena_browser_audit.py']})
for n,path in inputs.items():
 raw=path.read_bytes();archive=D/('friendly-command-gena-audit-proof-'+n+'.gz');assert not archive.exists();packed=gzip.compress(raw,mtime=0);archive.write_bytes(packed);files[n]=dict(path=archive.name,source_sha256=sha(raw),archive_sha256=sha(packed))
manifest=D/'friendly-command-gena-audit-proof-archive.json';assert not manifest.exists();manifest.write_text(json.dumps(dict(state='independent-current-gena-runtime-and-browser-audits-passed',files=files,runtime_controls=40,browser_controls=18,original_development_failures_retained=True,cli_runs=36,cli_frames=1488,old_cli_paths=3644,required_checks=264,forbidden_checks=108,cohort_words=53502,unjudged_history_paths=11,annotated_rows=66570,changed_gold_rows=0,broad_frames=1128312,unjudged_broad_paths=18,complete_extra_native_owners=42,browser_choices=144,required_diagrams=102,forbidden_exclusions=42,exact_exports=6,complete_primary_native_entries=31,declared_frontend_build_inputs=14,complete_browser_frontend_inputs=18,current_initial_production_inputs=44,shared_judgments_reviews_changed=False,old_historical_source_adapters_and_selected_nix_installed_main_quiet_context_register_independent_review='pending',full_coverage_complete=False),ensure_ascii=False,indent=2)+'\n');print('Archived',len(files),'full original audit artifacts; 40 runtime and 18 browser controls passed',flush=True)
