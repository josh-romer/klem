"""Exercise the built SolidJS app with bound executables and complete source freeze."""
import datetime
import hashlib
import json
import os
import re
import signal
import subprocess
import urllib.request
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
TARGET = P.parent / 'friendly-hortative-sena-target'
OUT = P / 'friendly-hortative-sena-browser-runtime-retry1.json'
LOG = P / 'friendly-hortative-sena-browser-runtime-retry1.log'
PREFIX = P / 'friendly-hortative-sena'
DRIVER = P / 'friendly-hortative-sena-browser.mjs'
DB = P.parent / 'dictionary-restoration/krdict.db'
CHROMIUM = Path('/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium')
RESULT = Path(str(PREFIX) + '-browser.json')
assert not OUT.exists() and not LOG.exists() and not RESULT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
raw_sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=W)
assert not git('status', '--porcelain')
build = json.loads((P / 'friendly-hortative-sena-frontend-build.json').read_bytes())
binding = json.loads((P / 'friendly-hortative-sena-complete-runtime-binding.json').read_bytes())
assert build['state'] == binding['state'] == 'passed'
source = {n: sha(W / n) for n in git('ls-files', '-z').decode().split('\0')[:-1]}
assert source == build['frozen_inputs']
assert all(source[n] == digest for n, digest in binding['production_inputs'].items())
assert {n: source['web/' + n] for n in build['frontend_inputs']} == build['frontend_inputs']
head = git('rev-parse', 'HEAD').decode().strip()
index = raw_sha(git('ls-files', '--stage', '-z'))
assert head == build['head'] and index == build['index_sha256']
assets = W / 'web/dist'
assert {str(p.relative_to(assets)): sha(p) for p in assets.rglob('*') if p.is_file()} == build['assets']
binary_paths = {v['path']: v['sha256'] for v in binding['binaries'].values()}
binary_paths.update(binding['protected_parent_binaries'])
assert len(binary_paths) == 6 and all(sha(path) == digest for path, digest in binary_paths.items())
assert sha(DB) == '23d993696c55d0e54660e4a2b23dac7d68525fecb1fdc44341e1f2b3f75dead5'
files = [DB, CHROMIUM, DRIVER, Path(__file__), P / 'friendly-hortative-sena-frontend-build.json',
         P / 'friendly-hortative-sena-complete-runtime-binding.json']
files += [p for p in assets.rglob('*') if p.is_file()]
frozen = {str(p): sha(p) for p in files}
frozen.update(binary_paths)
command = [str(TARGET / 'debug/klem-web'), '--port', '0', '--assets', str(assets), '--dictionary', str(DB)]
temp = P.parent / 'sc'
temp.mkdir(exist_ok=True)
r = dict(state='running', command=command, head=head, index_sha256=index, source_inputs=source,
         frozen_inputs=frozen, frontend_inputs=build['frontend_inputs'], assets=build['assets'],
         production_inputs=binding['production_inputs'],
         producer=dict(text=Path(__file__).read_text(), sha256=sha(__file__)),
         driver=dict(text=DRIVER.read_text(), sha256=sha(DRIVER)),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Actual current 18-input SolidJS assets, bound CLI/server and unchanged full imported dictionary. All 25 preauthored structural cases, 150 Unicode/filter decisions, 114 required diagrams, 36 forbidden exclusions, six original-corpus decisions, twelve complete CLI exports, and 37 complete Native API records. This does not judge the corpus hypothesis in context or establish installed Nix/full inventory/shared promotion/main/performance/register/independent review completion.')
def save():
    OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
save()
job = None
try:
    job = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
    line = job.stderr.readline()
    match = re.search(r'http://127\.0\.0\.1:\d+', line)
    assert match, line
    url = match.group()
    r.update(url=url, owned_server_pid=job.pid, server_startup=line)
    with urllib.request.urlopen(url + '/api/status', timeout=10) as response:
        r['status'] = json.load(response)
    with urllib.request.urlopen(url, timeout=10) as response:
        html = response.read()
    assert html == (assets / 'index.html').read_bytes()
    r['served_assets'] = []
    for path in re.findall(r'(?:src|href)="(/assets/[^"?#]+\.(?:js|css))"', html.decode()):
        with urllib.request.urlopen(url + path, timeout=10) as response:
            raw = response.read()
        assert raw == (assets / path.lstrip('/')).read_bytes()
        r['served_assets'].append(dict(path=path, sha256=raw_sha(raw)))
    assert {v['path'].rsplit('.', 1)[-1] for v in r['served_assets']} == {'js', 'css'}
    save()
    env = dict(os.environ, KLEM_WEB_URL=url, KLEM_BIN=str(TARGET / 'debug/klem'),
               KLEM_CAPTURE_PREFIX=str(PREFIX), CHROMIUM_PATH=str(CHROMIUM), TMPDIR=str(temp))
    with LOG.open('xb') as stream:
        run = subprocess.run(['node', str(DRIVER)], env=env, stdout=stream, stderr=subprocess.STDOUT)
    r['exit_code'] = run.returncode
    assert run.returncode == 0
    result = json.loads(RESULT.read_bytes())
    assert result['state'] == 'source-bound-friendly-hortative-sena-browser-passed' and not result['errors']
    assert len(result['policyDecisions']) == 150 and len(result['diagrams']) == 114
    assert sum(d.get('verdict') == 'forbidden' for d in result['policyDecisions']) == 36
    assert len(result['corpusDecisions']) == 6 and len(result['exports']) == 12 and len(result['nativeEntries']) == 37
    r.update(state='passed', decisions=150, diagrams=114, forbidden=36, corpus_decisions=6,
             exports=12, native_entries=37, result_sha256=sha(RESULT))
    r['screenshots'] = {str(p): sha(p) for p in [Path(str(PREFIX) + '-browser-desktop.png'), Path(str(PREFIX) + '-browser-mobile.png')]}
except BaseException as error:
    r.update(state='failed', error=repr(error))
    raise
finally:
    if job is not None:
        if job.poll() is None:
            job.send_signal(signal.SIGINT)
        r.update(server_exit_code=job.wait(timeout=20), server_stopped=True)
    r.update(inputs_unchanged=all(Path(p).is_file() and sha(p) == d for p, d in frozen.items()),
             source_unchanged=all(sha(W / n) == d for n, d in source.items()),
             head_unchanged=git('rev-parse', 'HEAD').decode().strip() == head,
             index_unchanged=raw_sha(git('ls-files', '--stage', '-z')) == index,
             log_sha256=sha(LOG) if LOG.exists() else None,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['inputs_unchanged', 'source_unchanged', 'head_unchanged', 'index_unchanged']):
        r['state'] = 'failed'
    if r.get('server_exit_code') not in [0, -signal.SIGINT]:
        r['state'] = 'failed'
    save()
assert r['state'] == 'passed'
print('Passed actual browser: 150 policies, 114 diagrams, 6 corpus decisions, 12 exports, 37 Native entries; owned server stopped.', flush=True)
