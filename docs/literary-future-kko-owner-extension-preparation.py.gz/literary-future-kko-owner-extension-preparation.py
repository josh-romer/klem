"""Propose nineteen source structures with actual earlier question parents and complete native owners."""
import copy
import gzip
import hashlib
import json
import sqlite3
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
sys.path.insert(0, str(ROOT/'tools'))
from native_lmf import array, entry, verify_native_lmf

sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(gzip.decompress(p.read_bytes()) if p.suffix == '.gz' else p.read_bytes())
source_path = Path('/tmp/klem-literary-future-kko-source-discovery.json.gz')
output = Path('/tmp/klem-literary-future-kko-owner-extension-preparation.json.gz')
assert not output.exists()
source = read(source_path)
cli = next(p for p in source['frozen_inputs'] if p.endswith('/bin/klem'))
dictionary = ROOT/'data/dictionaries/krdict/krdict.db'
spec = {
    '갔을꼬': (['가다'], ['었']),
    '돌아오셨을꼬': (['돌아오다'], ['시', '었']),
    '많을꼬': (['많다'], []),
    '놀랐을꼬': (['놀라다'], ['었']),
    '알았을꼬': (['알다'], ['었']),
    '먹을꼬': (['먹다'], []),
    '심을꼬': (['심다'], []),
    '좋을꼬': (['좋다'], []),
    '있을꼬': (['있다'], []),
    '뜰꼬': (['뜨다'], []),
    '조용할꼬': (['조용하다'], []),
    '살꼬': (['살다'], []),
    '누구일꼬': (['누구', '이다'], []),
    '할꼬': (['하다'], []),
    '더울꼬': (['덥다'], []),
    '볼꼬': (['보다'], []),
    '쓸꼬': (['쓰다'], []),
    '나갈꼬': (['나가다'], []),
}
assert set(spec) == {t['surface'] for t in source['targets']} and len(spec) == 18
text = ' '.join(word[:-1]+'까' for word in spec)
command = [cli, 'text', '-', '--dictionary', str(dictionary)]
result = subprocess.run(command, input=text.encode(), capture_output=True, check=True)
parents = {r['surface']: r for r in map(json.loads, result.stdout.splitlines()) if r.get('analysis')}
assert len(parents) == 18
baseline = next(r for r in source['runs'] if r['encoding'] == 'NFC' and r['mode'] == 'raw')
original_rows = list(map(json.loads, baseline['jsonl'].splitlines()))
cases = []
owner_ids = set()
for target in source['targets']:
    word = target['surface']
    heads, prefinals = spec[word]
    parent = parents[word[:-1]+'까']
    hits = [i for i, a in enumerate(parent['analysis']['analyses'])
            if [l['text'] for l in a['lemmas']] == heads
            and [m['form'] for m in a['morphemes']] == prefinals+['을까']]
    assert len(hits) == 1
    i = hits[0]
    path = parent['analysis']['analyses'][i]
    assessment = parent['dictionary']['readings'][i]
    owner_ids.update(e['id'] for slot in assessment['lemmas'] for e in slot['entries'])
    span = {k: len(source['input'][:v].encode()) for k, v in target['char_span'].items()}
    row = next(r for r in original_rows if r['span'] == span)
    expected = {'lemmas': heads, 'lemma_kinds': [l['kind'] for l in path['lemmas']],
                'morphemes': prefinals+['을꼬'], 'morpheme_kinds': [m['kind'] for m in path['morphemes']],
                'required_rules': ['ending.literary_future_question_kko']}
    cases.append({'id': f"literary-future-kko-original-{target['source'].split(':')[1]}-{target['sense']}-{target['group_index']}",
                  'surface': word, 'source_occurrence': target, 'expected': expected,
                  'before': row['analysis'], 'earlier_parent': {'surface': parent['surface'],
                  'analysis': path, 'assessment': assessment}, 'structural_verdict': 'proposed-required',
                  'contextual_verdict': 'unjudged', 'independent_review': 'pending'})
assert len(cases) == 19 and len({c['id'] for c in cases}) == 19
replay_path = Path('/tmp/klem-literary-future-kko-prototype-source-replay.json.gz')
replay = read(replay_path)
owner_ids.update(replay['matched_native_owner_ids'])
boundary_path = Path('/tmp/klem-literary-future-kko-boundary-preflight.json.gz')
boundary = read(boundary_path)
extension_path=Path('/tmp/klem-literary-future-kko-owner-extension-preflight.json.gz')
extension=read(extension_path)
assert extension['state']=='passed'
prior=read(Path('/tmp/klem-literary-future-kko-boundary-owner-preparation.json.gz'))
boundary_owners = set()
for run in boundary['runs']+extension['runs']:
    for row in map(json.loads, run['jsonl'].splitlines()):
        if not row.get('analysis'): continue
        for assessment in row['dictionary']['readings']:
            boundary_owners.update(e['id'] for slot in assessment['lemmas'] for e in slot['entries'])
owner_ids.update(boundary_owners)
heads = {h for names, _ in spec.values() for h in names} | {'-ㄹ꼬', '-을꼬', '-ㄹ까', '-을까', '-으시-', '-시-', '-었-', '-겠-', '-더-'}
heads.update(prior['named_headwords'])
heads.update({'-답다','-하다','-되다','-어','-게','-지','-고'})
with sqlite3.connect(dictionary.resolve().as_uri()+'?mode=ro', uri=True) as db:
    for ident in owner_ids:
        owner_row = db.execute('SELECT headword FROM entries WHERE id=?', (ident,)).fetchone()
        assert owner_row
        heads.add(owner_row[0])
    expected_entries = {ident: json.loads(raw) for ident, head, raw in db.execute('SELECT id,headword,data FROM entries') if head in heads}
assert owner_ids <= expected_entries.keys()
pinned = read(ROOT/'docs/reported-dana-source-preparation.json.gz')['source_hashes']
native, original, source_hashes = {}, {}, {}
for path in sorted((ROOT/'data/dictionaries/krdict/json').glob('*.json')):
    name = str(path.relative_to(ROOT)); raw_bytes = path.read_bytes()
    source_hashes[name] = sha(raw_bytes); assert source_hashes[name] == pinned[name]
    document = json.loads(raw_bytes)
    for raw in array(document['LexicalResource']['Lexicon']['LexicalEntry']):
        base = 'krdict:'+raw['val']
        if base not in expected_entries and not any(key.startswith(base+':') for key in expected_entries): continue
        value = entry(raw); ident = value['id']
        if ident not in expected_entries: continue
        assert ident not in native and value == expected_entries[ident]
        native[ident] = value; original[ident] = raw
    del document, raw_bytes
assert native == expected_entries
assert all(native[k]==v for k,v in prior['complete_native_entries'].items())
assert all(native[key] == value for key, value in source['sqlite_entries'].items())
projection = {'LexicalResource': {'Lexicon': {'LexicalEntry': []}}}
for ident in sorted(native):
    raw = copy.deepcopy(original[ident])
    for sense in array(raw.get('Sense')):
        sense['Equivalent'] = [t for t in array(sense.get('Equivalent'))
                              if any(f.get('att') == 'language' and f.get('val') == '영어' for f in array(t.get('feat')))]
    projection['LexicalResource']['Lexicon']['LexicalEntry'].append(raw)
verify_native_lmf(projection, native)
assert all(sha(Path(p).read_bytes()) == expected for p, expected in source['frozen_inputs'].items())
producer = Path(__file__)
report = {'schema_version': 1, 'preparation_only': True,
          'source_capture_sha256': sha(source_path.read_bytes()), 'original_cases': cases,
          'prototype_replay_sha256': sha(replay_path.read_bytes()),
          'matched_native_owner_ids': replay['matched_native_owner_ids'],
          'boundary_preflight_sha256': sha(boundary_path.read_bytes()),
          'owner_extension_preflight_sha256':sha(extension_path.read_bytes()),
          'prior_boundary_preparation_sha256':sha(Path('/tmp/klem-literary-future-kko-boundary-owner-preparation.json.gz').read_bytes()),
          'boundary_matched_owner_ids': sorted(boundary_owners),
          'parent_capture': {'command': command, 'input': text, 'input_sha256': sha(text.encode()),
                             'jsonl': result.stdout.decode(), 'sha256': sha(result.stdout), 'exit_code': 0},
          'primary_entry_ids': list(source['sqlite_entries']), 'matched_parent_owner_ids': sorted(owner_ids),
          'named_headwords': sorted(heads), 'complete_native_entries': native,
          'original_lmf': original, 'english_projection': projection, 'source_hashes': source_hashes,
          'producer': {'text': producer.read_text(), 'sha256': sha(producer.read_bytes())},
          'scope': 'Nineteen individual proposed structures from all original source occurrences, each with its selected exact earlier -(으)ㄹ까 path and actual Native assessment. Complete original LMF/SQLite equality and English projection retain every named-head homonym and matched selected-parent owner. All matched new source-replay owners and every named-head homonym are now retained as complete Native entries. All actual boundary and authored derivation/auxiliary extension-matched owners and their headword homonyms are separately preserved; contextual sense/register and precision remain unreviewed. No production integration or global-ledger judgment yet.'}
output.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2)+'\n').encode(), mtime=0))
print('Prepared nineteen original source structures, eighteen exact earlier question parents and',len(native),'complete Native entries.',flush=True)
