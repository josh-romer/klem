"""Check independent novel targets in complete contexts and exact Native fixtures."""
import argparse
import datetime
import gzip
import hashlib
import json
import subprocess
import unicodedata
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--cli', type=Path, required=True)
parser.add_argument('--prefix', type=Path, required=True)
args = parser.parse_args()
PREP = Path(__file__).resolve().parent
ROOT = PREP.parents[1]
AUTHOR = PREP / 'novel-context-authoring.json'
FIXTURE = PREP / 'novel-context-validity-authored.json'
NATIVE = PREP / 'novel-context-native.json'
OWNERS = PREP / 'novel-context-native-entries.json'
CLOSURE = PREP / 'novel-context-native-closure.json.gz'
OUT = Path(str(args.prefix) + '.json.gz')
DB = Path('/tmp') / (args.prefix.name + '-native.db')
assert not OUT.exists() and not DB.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
frozen = {str(p): sha(p) for p in [AUTHOR, FIXTURE, NATIVE, OWNERS, CLOSURE, args.cli, Path(__file__)]}
author = json.loads(AUTHOR.read_text())
suite = json.loads(FIXTURE.read_text())
assert sha(FIXTURE) == author['fixture_sha256']
native = json.loads(OWNERS.read_text())
commands = []

def execute(command, original=None):
    job = subprocess.run(command, input=original, capture_output=True, cwd=ROOT)
    commands.append({'command': command, 'exit_code': job.returncode,
                     'stdout_sha256': hashlib.sha256(job.stdout).hexdigest(),
                     'stderr': job.stderr.decode()})
    assert job.returncode == 0 and not job.stderr, commands[-1]
    return job.stdout

execute([str(args.cli), 'dict', 'import-krdict', str(NATIVE), str(DB), '--snapshot', 'independent-novel-context-native'])
for ident, expected in native.items():
    actual = json.loads(execute([str(args.cli), 'dict', 'entry', str(DB), ident]))
    assert actual['entry'] == expected, ('original Native importer field mismatch', ident)
frozen[str(DB)] = sha(DB)

def matches(path, target):
    return ([lemma['text'] for lemma in path['lemmas']] == target['lemmas']
            and [lemma['kind'] for lemma in path['lemmas']] == target['lemma_kinds']
            and [morph['form'] for morph in path['morphemes']] == target['morphemes']
            and [morph['kind'] for morph in path['morphemes']] == target['morpheme_kinds']
            and set(target['required_rules']) <= set(path['rules']))

runs = []
missing = []
for family in ['complete-original-novel-lines', 'standalone-novel-targets']:
    for encoding in ['NFC', 'NFD']:
        groups = [unicodedata.normalize(encoding, item['complete_original_line'] if family.startswith('complete') else item['surface']) for item in author['items']]
        original = '\n'.join(groups).encode()
        positions = []
        offset = 0
        for group, item in zip(groups, author['items'], strict=True):
            raw = group.encode()
            target = unicodedata.normalize(encoding, item['surface']).encode()
            assert raw.count(target) == 1
            positions.append(offset + raw.index(target))
            offset += len(raw) + 1
        for mode, flags in [('raw', []), ('headword', ['--dict-only']), ('compatible', ['--dict-compatible'])]:
            uncached = None
            for cache in [0, 4096]:
                command = [str(args.cli), 'text', '-', '--dictionary', str(DB), *flags, '--cache-bytes', str(cache)]
                output = execute(command, original)
                rows = [json.loads(line) for line in output.splitlines()]
                cursor = 0
                for row in rows:
                    assert row['span']['start'] == cursor
                    cursor = row['span']['end']
                    assert original[row['span']['start']:cursor].decode() == row['surface']
                assert cursor == len(original)
                observations = []
                for position, case in zip(positions, suite['cases'], strict=True):
                    index, row = next((i, row) for i, row in enumerate(rows) if row['span']['start'] == position)
                    assert row['surface'] == unicodedata.normalize(encoding, case['surface'])
                    observed = []
                    for target in case['judgments']:
                        indices = [i for i, path in enumerate(row['analysis']['analyses']) if matches(path, target)]
                        observed.append({'judgment_id': target['id'], 'typed_path_indices': indices})
                        if not indices:
                            missing.append({'family': family, 'encoding': encoding, 'mode': mode, 'cache_bytes': cache,
                                            'case_id': case['id'], 'target': target, 'actual_complete_frame': row})
                    observations.append({'id': case['id'], 'record_index': index, 'judgments': observed})
                if uncached is None:
                    uncached = output
                else:
                    assert uncached == output, 'cache changes complete ordered output'
                runs.append({'family': family, 'encoding': encoding, 'mode': mode, 'cache_bytes': cache,
                             'command': command, 'exit_code': 0, 'records': len(rows),
                             'input': original.decode(), 'input_sha256': hashlib.sha256(original).hexdigest(),
                             'jsonl': output.decode(), 'jsonl_sha256': hashlib.sha256(output).hexdigest(),
                             'observations': observations, 'original_bytes_conserved': True})
                print(family, encoding, mode, cache, len(rows), 'frames', flush=True)
unchanged = all(sha(path) == digest for path, digest in frozen.items())
assert unchanged and len(runs) == 24
report = {'state': 'passed' if not missing else 'failed-independent-targets',
          'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'runs': runs, 'missing': missing, 'native_owners': len(native),
          'native_import_exact_fields': True, 'commands': commands, 'frozen_inputs': frozen,
          'inputs_unchanged': unchanged,
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
          'scope': 'Actual CLI, exact original Native importer fields, complete original novel lines, every original byte, all 15 independently authored occurrences and 16 typed local requirements tested across 24 Unicode/filter/cache streams. Missing targets and all actual outputs remain preserved. No alternative is forbidden or contextual sense selected. Library/browser/spacing, ledger, installed/main validation and independent Korean review remain separate.'}
OUT.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
print(report['state'], len(runs), 'streams', len(missing), 'missing requirements', flush=True)
raise SystemExit(0 if not missing else 1)
