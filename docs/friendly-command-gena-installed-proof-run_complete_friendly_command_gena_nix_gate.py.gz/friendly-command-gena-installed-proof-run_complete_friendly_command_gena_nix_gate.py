"""Run the entire current Git-backed four-check Nix gate without changing baselines."""
import datetime,gzip,hashlib,json,os,subprocess
from pathlib import Path
PREP=Path(__file__).resolve().parent
WORK=Path('/home/josh/projects/klem/.direnv/friendly-command-gena')
OUT=PREP/'friendly-command-gena-complete-nix-gate.json'
LOG=PREP/'friendly-command-gena-complete-nix-gate.log'
BUILD=Path('/var/tmp/klem-friendly-command-gena-nix-packages-build')
assert not OUT.exists() and not LOG.exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
BUILD.mkdir(exist_ok=True); BUILD.chmod(0o1777)
assert BUILD.stat().st_mode & 0o7777 == 0o1777
os.environ['TMPDIR']=str(BUILD)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
paths=subprocess.check_output(['git','ls-files','-z'],cwd=WORK).decode().split('\0')[:-1]
frozen={n:sha((WORK/n).read_bytes()) for n in paths}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK))
flake='git+file://'+str(WORK)
source=subprocess.check_output(['nix','eval','--offline','--raw',flake+'#checks.x86_64-linux.inventory-review.src'],cwd=WORK,text=True).strip()
selected={}
for p in Path(source).rglob('*'):
 if not p.is_file():continue
 name=str(p.relative_to(source));digest=sha(p.read_bytes());assert frozen[name]==digest;selected[name]=digest
for name in ['tools/friendly_command_gena_revision.py','tools/friendly_command_gena_source_audit.py','tools/friendly_command_gena_runtime_audit.py','tools/test_friendly_command_gena_runtime_audit.py','tools/friendly_command_gena_browser_audit.py','tools/test_friendly_command_gena_browser_audit.py','docs/friendly-command-gena-audit-proof-archive.json','tests/fixtures/friendly-command-gena-history.json']:
 assert name in selected,('new audit must be selected',name)
reference_path=PREP/'gentle-command-long-installed-runtime.json.gz'
reference=json.loads(gzip.decompress(reference_path.read_bytes()));assert reference['state']=='passed'
profiles={}
for name,attr,prefix in [('klem','klem',''),('klem-corpus-adapter','corpus-adapter',''),('klem-web-assets','web-assets','web/')]:
 profile_source=Path(subprocess.check_output(['nix','eval','--offline','--raw',flake+'#packages.x86_64-linux.'+attr+'.src'],cwd=WORK,text=True).strip());files={}
 for p in profile_source.rglob('*'):
  if not p.is_file():continue
  name_in_source=str(p.relative_to(profile_source));digest=sha(p.read_bytes());assert frozen[prefix+name_in_source]==digest;files[name_in_source]=digest
 prior=reference['profiles'][name]['files']
 differences={key:{'before':prior.get(key),'after':files.get(key)} for key in set(prior)|set(files) if prior.get(key)!=files.get(key)}
 profiles[name]=dict(source=str(profile_source),files=files,individual_installed_source_differences=differences,all_original_installed_source_bytes_match=not differences)
 if name=='klem-web-assets':
  assert len(files)==18 and set(differences)=={'src/grammar-labels.json'},'Only the independently bound Gena label changes the original18frontend profile'
 else:
  binding=json.loads((PREP/'friendly-command-gena-complete-runtime-binding.json').read_bytes());assert all(files[n]==digest for n,digest in binding['production_inputs'].items()),'All44independently bound Gena compiled production inputs'
command=['nix','build','--offline','--option','auto-optimise-store','true','--option','build-dir',str(BUILD),'--cores','4','--max-jobs','1','--no-link','--print-out-paths','-L']+[flake+'#checks.x86_64-linux.'+n for n in ['klem','web-assets','corpus-adapter','inventory-review']]
r=dict(state='running',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,index_sha256=index,frozen_inputs=frozen,inventory_source=source,inventory_source_files=selected,compiled_source_profiles=profiles,installed_reference_sha256=sha(reference_path.read_bytes()),command=command,producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),scope='Actual entire isolated Gena four-check Nix gate, including all selected independent historical/source/history/gold/broad/Native/browser auditors and the strictly named Source44/frontend18 adapters. Alloriginaldatasets/judgments/35740cases519reviews unchanged. Gena24cases remainprivate. Currentinstalled packages/runtime/browser, mainintegration,quietperformance/contextregisterindependent review andsharedpromotion remainseparate.')
def save():OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
modules=['test_expression_conjectural_ledger_audit.py','test_gentle_command_ledger_audit.py','test_gentle_command_long_installed_audit.py','test_gentle_command_long_ledger_audit.py','test_literary_question_geona_runtime.py','test_gentle_command_long_source_audit.py','test_friendly_command_gena_source_audit.py','test_friendly_command_gena_runtime_audit.py','test_friendly_command_gena_browser_audit.py']
r['selected_preflight']=[]
with LOG.open('xb') as stream:
 for module in modules:
  selected_command=['python3','-m','unittest','discover','-s','tools','-p',module]
  stream.write(('SELECTED SOURCE COMMAND '+json.dumps(selected_command)+'\n').encode());stream.flush()
  step=subprocess.run(selected_command,cwd=source,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=stream,stderr=subprocess.STDOUT)
  r['selected_preflight'].append(dict(command=selected_command,exit_code=step.returncode));save()
  if step.returncode:break
 if len(r['selected_preflight'])==len(modules) and all(x['exit_code']==0 for x in r['selected_preflight']):
  r['selected_preflight_passed']=True;save()
  stream.write(('COMPLETE NIX COMMAND '+json.dumps(command)+'\n').encode());stream.flush()
  job=subprocess.run(command,cwd=WORK,env=dict(os.environ,TMPDIR=str(BUILD)),stdout=stream,stderr=subprocess.STDOUT)
 else:
  r['selected_preflight_passed']=False
  job=step

r.update(exit_code=job.returncode,inputs_unchanged=all(sha((WORK/n).read_bytes())==digest for n,digest in frozen.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK))==index,outputs=[line for line in LOG.read_text().splitlines() if line.startswith('/nix/store/')],log_sha256=sha(LOG.read_bytes()),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
r['state']='passed' if job.returncode==0 and len(r['outputs'])==4 and all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged']) else 'failed'
save();print(r['state'],'actual current Gena four-check Nix gate;',len(selected),'selected source files',flush=True)
raise SystemExit(0 if r['state']=='passed' else 1)
