"""Independently derive every original/boundary geona observation and full Native closure."""
import gzip,hashlib,json,sys,unicodedata
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from literary_future_kko_audit import matches
from native_lmf import entry,verify_native_lmf
sha=lambda raw:hashlib.sha256(raw).hexdigest();read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes())

def rows(run):
 assert run['exit_code']==0 and sha(run['jsonl'].encode())==run['sha256']
 return list(map(json.loads,run['jsonl'].splitlines()))

def conserve(before,after):
 assert len(before)==len(after)
 for a,b in zip(before,after,strict=True):
  for k in ['surface','span','kind']:assert a[k]==b[k]
  if not a.get('analysis'):assert a==b;continue
  assert a['analysis']['normalized']==b['analysis']['normalized']
  old,new=a['analysis']['analyses'],b['analysis']['analyses'];assert [p for p in new if p in old]==old
  for path,assessment in zip(old,a['dictionary']['readings'],strict=True):assert b['dictionary']['readings'][new.index(path)]==assessment

def inspect(source,prepared,replay,boundary,owners):
 for capture in [source,prepared,replay,owners]:
  assert sha(capture['producer']['text'].encode())==capture['producer']['sha256']
 assert replay['state']==boundary['state']==owners['state']=='passed'
 assert replay['inputs_unchanged'] and owners['inputs_unchanged'] and replay['root_parent_inputs_unchanged']
 assert len(replay['snapshot_files'])==65 and len(replay['parent_snapshot_files'])==947
 assert set(replay['changes'])=={'src/engine.rs','src/grammar.rs','src/dictionary/attachment.rs','web/src/grammar-labels.json'}
 for n,c in replay['changes'].items():
  assert sha(c['before_text'].encode())==c['before_sha256']==replay['parent_snapshot_files'][n]['sha256']
  assert sha(c['after_text'].encode())==c['after_sha256']==replay['snapshot_files'][n]['sha256']
 expected_groups=[{'source':ident,'sense':s['id'],'index':i,'original':group} for ident,value in sorted(source['sqlite_entries'].items()) for s in value['senses'] for i,group in enumerate(s['examples'])]
 assert source['all_original_groups']==expected_groups and len(expected_groups)==8
 assert source['input']=='\n'.join(line for g in expected_groups for line in g['original'])+'\n'
 assert len(source['targets'])==len(prepared['original_cases'])==8
 assert replay['source_capture_sha256']==sha((ROOT/'docs/literary-question-geona-source-discovery.json.gz').read_bytes())
 assert replay['preparation_sha256']==sha((ROOT/'docs/literary-question-geona-original-preparation.json.gz').read_bytes())
 native=owners['complete_native_entries'];assert len(native)==97 and all(native[i]==e for i,e in prepared['complete_native_entries'].items())
 assert all(source['sqlite_entries'][i]==native[i] for i in source['sqlite_entries'])
 assert {i:entry(raw) for i,raw in owners['original_lmf'].items()}==native
 verify_native_lmf(owners['english_projection'],native)
 assert set(replay['matched_new_owner_ids'])|set(boundary['matched_new_owner_ids'])==set(owners['matched_owner_ids']) and len(owners['matched_owner_ids'])==89
 keys=[(e,m) for e in ['NFC','NFD'] for m in ['raw','headword','compatible']]
 assert [(r['encoding'],r['mode']) for r in replay['runs']]==keys
 parent_rows=rows(prepared['parent_capture'])
 derived=[]
 for run in replay['runs']:
  actual=rows(run);baseline=next(r for r in source['runs'] if (r['encoding'],r['mode'])==(run['encoding'],run['mode']));conserve(rows(baseline),actual);assert len(actual)==116
  for case,target in zip(prepared['original_cases'],source['targets'],strict=True):
   assert case['source_occurrence']==target
   span=target['char_span'];assert source['input'][span['start']:span['end']]==case['surface']==target['surface']
   parent=case['earlier_parent']['analysis'];parent_row=next(r for r in parent_rows if r['surface']==case['earlier_parent']['surface']);assert parent in parent_row['analysis']['analyses'];assert parent_row['dictionary']['readings'][parent_row['analysis']['analyses'].index(parent)]==case['earlier_parent']['assessment'];assert [l['text'] for l in parent['lemmas']]==case['expected']['lemmas'] and [m['form'] for m in parent['morphemes']]==['을까']
   row=next(r for r in actual if r.get('analysis') and r['analysis']['normalized']==case['surface']);hits=[(i,a) for i,a in enumerate(row['analysis']['analyses']) if matches(a,case['expected'])];assert len(hits)==1;i,path=hits[0];assessment=row['dictionary']['readings'][i]
   assert assessment['status']==('unknown' if case['surface']=='좋을거나' else 'compatible')
   assert path.get('spelling_paths')==parent.get('spelling_paths')
   derived.append({'encoding':run['encoding'],'mode':run['mode'],'case_id':case['id'],'surface':case['surface'],'analysis':path,'assessment':assessment,'source_occurrence':target,'contextual_verdict':'unjudged'})
 assert derived==replay['original_observations'] and len(derived)==48
 assert len(boundary['cases'])==47 and len(boundary['observations'])==282
 assert len(boundary['initial_mismatches_retained'])==12 and len(boundary['explicit_draft_corrections'])==2 and boundary['proposal_mismatches']==[]
 correction=boundary['correction_producer'];assert sha(correction['text'].encode())==correction['sha256']
 assert [(r['encoding'],r['mode']) for r in boundary['runs']]==keys
 assert {v:sum(c['proposal']==v for c in boundary['cases']) for v in ['required','conditional','forbidden','native-policy-only']}=={'required':27,'conditional':11,'forbidden':5,'native-policy-only':4}
 derived=[]
 for run in boundary['runs']:
  before,after=rows(run['before']),rows(run['after']);conserve(before,after);assert len(after)==93
  for c in boundary['cases']:
   row=next(r for r in after if r.get('analysis') and r['analysis']['normalized']==c['surface']);paths=[(i,a) for i,a in enumerate(row['analysis']['analyses']) if matches(a,c)];assessments=[row['dictionary']['readings'][i] for i,_ in paths];assert bool(paths)==c['expected_presence'][run['mode']]
   assert all(a['status']!='incompatible' if c['expected_status']=='not-incompatible' else a['status']==c['expected_status'] for a in assessments)
   record={'encoding':run['encoding'],'mode':run['mode'],'case_id':c['id'],'proposal':c['proposal'],'present':bool(paths),'expected_present':c['expected_presence'][run['mode']],'paths':[p for _,p in paths],'assessments':assessments,'expected_status':c['expected_status'],'matches_proposed_presence':True,'matches_proposed_status':True,'contextual_verdict':'unjudged','independent_review':'pending'}
   if assessments and 'expected_entry_statuses' in c:
    entries={e['id']:e['status'] for a in assessments for l in a['lemmas'] for e in l['entries']};assert all(entries[i]==s for i,s in c['expected_entry_statuses'].items());record['specific_owner_statuses']=c['expected_entry_statuses']
   derived.append(record)
 assert derived==boundary['observations']
 return {'original_observations':48,'boundary_observations':282,'source_frames':696,'matched_owners':89,'complete_native_entries':97,'conditional_cases_not_promoted':11,'raw_exclusions_separate_from_native_spelling':True,'full_main_and_linguistic_review':'pending'}

def inputs():return [read(p) for p in [ROOT/'docs/literary-question-geona-source-discovery.json.gz',ROOT/'docs/literary-question-geona-original-preparation.json.gz',Path('/tmp/klem-literary-question-geona-prototype-source-replay.json.gz'),Path('/tmp/klem-literary-question-geona-boundary-corrected.json.gz'),Path('/tmp/klem-literary-question-geona-matched-owner-preparation.json.gz')]]
if __name__=='__main__':print(inspect(*inputs()))
