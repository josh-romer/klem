import json,os,re,signal,subprocess,time,urllib.request,hashlib
from pathlib import Path
prefix=Path('/tmp/klem-declarative-dao-browser-runtime-revision2');out=Path(str(prefix)+'.json');assert not out.exists()
assets=Path('/tmp/klem-declarative-dao-web-build/web/dist');server=Path('/tmp/klem-declarative-dao-server');driver=Path('/tmp/klem-declarative-dao-browser-revision2.mjs');db=Path('/home/josh/projects/klem/data/dictionaries/krdict/krdict.db')
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
frozen={str(p):sha(p) for p in [server,driver,db,Path(__file__),*assets.rglob('*')] if p.is_file()}
command=[str(server),'--port','0','--assets',str(assets),'--dictionary',str(db)]
r={'state':'running','command':command,'frozen_inputs':frozen};out.write_text(json.dumps(r,indent=2)+'\n')
job=subprocess.Popen(command,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
try:
 line=job.stderr.readline();match=re.search(r'http://127\.0\.0\.1:\d+',line);assert match,line
 url=match.group();r['url']=url;r['server_pid']=job.pid
 with urllib.request.urlopen(url,timeout=10) as response:assert response.read()==(assets/'index.html').read_bytes()
 env=dict(os.environ,KLEM_WEB_URL=url,CHROMIUM_PATH='/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium')
 with Path(str(prefix)+'.log').open('xb') as output:completed=subprocess.run(['node',str(driver)],env=env,stdout=output,stderr=subprocess.STDOUT)
 r.update(state='passed' if completed.returncode==0 else 'failed',exit_code=completed.returncode)
finally:
 if job.poll() is None:job.send_signal(signal.SIGINT)
 r['server_exit_code']=job.wait(timeout=20);r['server_stopped']=True;r['inputs_unchanged']=all(sha(p)==h for p,h in frozen.items());out.write_text(json.dumps(r,indent=2)+'\n')
assert r['state']=='passed',r
assert r['inputs_unchanged']
print('Draft browser passed; owned server stopped.')
