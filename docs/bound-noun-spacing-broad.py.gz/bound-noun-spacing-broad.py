"""Compare all eight complete streams and retain every added split with original context."""
import gzip,hashlib,itertools,json,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');OLD=Path('/tmp/klem-predicate-auxiliary-spacing-main-cli');NEW=Path('/tmp/klem-bound-noun-spacing-cli');DB=ROOT/'data/dictionaries/krdict/krdict.db';PRIOR=ROOT/'docs/predicate-auxiliary-spacing-main-broad.json.gz';OUT=Path('/tmp/klem-bound-noun-spacing-broad.json.gz');assert not OUT.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prior=json.loads(gzip.decompress(PRIOR.read_bytes()));frozen={str(p):sha(p) for p in [OLD,NEW,DB,PRIOR]};comparisons=[];observations=[];unique_words=set();metadata=[]
for previous in prior['comparisons']:
 path=Path(previous['source']);original=path.read_bytes();assert sha(path)==previous['source_sha256'];frozen[str(path)]=sha(path);mode=previous['mode'];flags=['--dict-compatible'] if 'compatible' in mode else ['--dict-only'] if 'headword' in mode else []
 commands=[[str(cli),'text',str(path),'--dictionary',str(DB),*flags,*(['--suggest-spacing'] if 'spacing' in mode else [])] for cli in [OLD,NEW]]
 jobs=[subprocess.Popen(c,stdout=subprocess.PIPE,cwd=ROOT) for c in commands];hashes=[hashlib.sha256(),hashlib.sha256()];count=0;cursor=0;changed=0;added_count=0;meta_changed=0
 try:
  for pair in itertools.zip_longest(*(p.stdout for p in jobs)):
   assert all(l is not None for l in pair);count+=1
   for h,line in zip(hashes,pair,strict=True):h.update(line)
   after=json.loads(pair[1]);span=after['span'];assert span['start']==cursor and original[span['start']:span['end']].decode()==after['surface'];cursor=span['end']
   if pair[0]==pair[1]:continue
   before=json.loads(pair[0]);changed+=1
   assert {k:v for k,v in before.items() if k!='spacing'}=={k:v for k,v in after.items() if k!='spacing'},(mode,count,'word candidates/dictionary/token changed')
   old,new=before['spacing'],after['spacing'];assert old['rule']==new['rule'] and old['limits']==new['limits']
   assert [a for a in new['alternatives'] if a in old['alternatives']]==old['alternatives'],(mode,count,'prior spacing loss/reorder')
   assert old['segment_probes']<=new['segment_probes']<=new['limits']['segment_probes']
   if not old['complete']:assert new==old
   added=[a for a in new['alternatives'] if a not in old['alternatives']]
   metadata.append({'source_sha256':previous['source_sha256'],'mode':mode,'record':count,'span':span,'surface':after['surface'],'before':{k:v for k,v in old.items() if k!='alternatives'},'after':{k:v for k,v in new.items() if k!='alternatives'},'added_options':len(added)})
   if not added:meta_changed+=1
   for hypothesis in added:
    assert hypothesis['rule']=='spacing.modifier_bound_noun'
    contexts=hypothesis.get('joined_contexts',[])
    context_spans=set()
    for context in contexts:
     context_span=context['span'];assert span['start']<=context_span['start']<context_span['end']<span['end']
     assert original[context_span['start']:context_span['end']].decode()==context['surface']
     assert (context_span['start'],context_span['end']) not in context_spans;context_spans.add((context_span['start'],context_span['end']))
     assert context['analysis']['analyses'] and all(any(l['kind']=='auxiliary' for l in a['lemmas']) for a in context['analysis']['analyses'])
     assert all(r['status']!='incompatible' for r in context['dictionary']['readings'])
     unique_words.add(context['surface'])
    records=hypothesis['records'];assert len(records)>=2 and ''.join(r['surface'] for r in records)==after['surface']
    assert hypothesis['spaced']==' '.join(r['surface'] for r in records)
    assert hypothesis['inserted_at']==[r['span']['start'] for r in records[1:]]
    end=span['start']
    for segment in records:
     assert segment['span']['start']==end;end=segment['span']['end']
     assert original[segment['span']['start']:segment['span']['end']].decode()==segment['surface']
     assert segment['analysis']['analyses'] and all(order is not None for order in segment['breakdowns'])
     assert all(r['status']!='incompatible' for r in segment['dictionary']['readings'])
     unique_words.add(segment['surface'])
    assert end==span['end']
    left=original.rfind(b'\n',0,span['start'])+1;right=original.find(b'\n',span['end']);right=len(original) if right<0 else right
    ident=hashlib.sha256(json.dumps([previous['source_sha256'],mode,count,hypothesis],ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:24]
    observations.append({'id':'bound-noun-spacing-'+ident,'source':str(path),'source_sha256':previous['source_sha256'],'mode':mode,'record':count,'surface':after['surface'],'span':span,'complete_original_line':original[left:right].decode(),'hypothesis':hypothesis,'earlier_alternatives':old['alternatives'],'structural_verdict':'finite source-profile modifier/noun boundary; independent segment replay pending','contextual_verdict':'unjudged','independent_review':'pending'})
    added_count+=1
  codes=[p.wait() for p in jobs];assert codes==[0,0] and hashes[0].hexdigest()==previous['after_jsonl_sha256'] and count==previous['records'] and cursor==len(original)
 finally:
  for p in jobs:
   if p.poll() is None:p.terminate();p.wait()
 comparisons.append({'source':str(path),'source_sha256':sha(path),'mode':mode,'commands':commands,'exit_codes':codes,'records':count,'before_jsonl_sha256':hashes[0].hexdigest(),'after_jsonl_sha256':hashes[1].hexdigest(),'baseline_matches_previous_capture':True,'changed_frames':changed,'metadata_only_changed_frames':meta_changed,'new_spacing_options':added_count,'word_candidates_dictionary_bytes_conserved':True,'all_previous_spacing_options_and_order_conserved':True})
 print(mode,count,'complete paired frames',changed,'changed',added_count,'new options',flush=True)
# Every piece and joined witness is independently replayed through the original
# CLI once. Its exact raw path, Native reading and breakdown identity is retained.
words=sorted(unique_words);batch=Path('/tmp/klem-bound-noun-spacing-broad-independent-input.txt');batch.write_text('\n'.join(words)+'\n');frozen[str(batch)]=sha(batch)
command=[str(OLD),'text',str(batch),'--dictionary',str(DB),'--dict-compatible'];job=subprocess.run(command,capture_output=True,text=True,cwd=ROOT);assert job.returncode==0,job.stderr
independent={r['surface']:r for r in map(json.loads,job.stdout.splitlines()) if r['kind']=='word'};assert set(independent)==set(words)
for observation in observations:
 for segment in [*observation['hypothesis']['records'],*observation['hypothesis'].get('joined_contexts',[])]:
  raw=independent[segment['surface']];analyses=raw['analysis']['analyses']
  for i,analysis in enumerate(segment['analysis']['analyses']):
   assert analysis in analyses, (observation["surface"],segment["surface"],analysis,analyses)
   assert segment['dictionary']['readings'][i]==raw['dictionary']['readings'][analyses.index(analysis)]
  assert all(m in raw['dictionary']['lemmas'] for m in segment['dictionary']['lemmas'])
 observation['structural_verdict']='finite source-profile modifier/noun boundary and every independent raw segment/Native assessment verified; intended spacing unjudged'
assert len(comparisons)==8 and sum(c['records'] for c in comparisons)==1128312 and all(sha(p)==h for p,h in frozen.items())
assert len(observations)==len({o['id'] for o in observations})
r={'schema_version':1,'state':'isolated-complete-broad-preservation-passed','comparisons':comparisons,'individual_spacing_additions':observations,'work_metadata_changes':metadata,'independent_replay':{'command':command,'input_sha256':sha(batch),'words':independent,'stdout_sha256':hashlib.sha256(job.stdout.encode()).hexdigest(),'exit_code':job.returncode},'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'historical_auxiliary_context_merge_failure':{'producer':'/tmp/klem-predicate-auxiliary-spacing-broad-retry1.py','log':'/tmp/klem-predicate-auxiliary-spacing-broad-retry1.log','reason':'Actual 달아나왔습니다 equal-space alternatives mixed full-word and suffix joined witnesses under one span. Distinct witness spans are now retained; constructed ambiguity regression passes and this replay checks every real novel witness.'},'historical_auxiliary_filter_replay_failure':{'producer':'/tmp/klem-predicate-auxiliary-spacing-broad.py','log':'/tmp/klem-predicate-auxiliary-spacing-broad.log','reason':'Independent comparison used unfiltered raw records, but existing Compatible filtering may narrow spelling-path alternatives. Retry compares exact actual previous-CLI compatible results; all word-level raw outputs remain exact.'},'scope':'All eight complete actual CLI streams; every word candidate, dictionary assessment and prior spacing option/order unchanged. Every new spacing option has exact source bytes, complete original line and independent old-CLI Compatible segment/context replay (including existing spelling-path narrowing). Every work-only metadata change is retained individually. Structural witnesses do not choose intended spaces/contextual senses or certify independent Korean review. Prototype only: Root integration, Nix runtime, performance and independent language review remain pending.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Passed',1128312,'frames;',len(observations),'individual new options;',len(independent),'independent words.',flush=True)
