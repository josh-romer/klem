"""Record an observed missing family without treating authored targets as passing tests."""
import gzip
import json
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
PREP = ROOT / '.direnv/fear-lsera-prepared'
DOCS = ROOT / 'docs'
baseline = json.loads(gzip.decompress((PREP / 'baseline-gap.json.gz').read_bytes()))
assert baseline['inputs_unchanged'] and len(baseline['runs']) == 150
assert all(r['lexical_target_matches'] == r['structural_target_matches'] == 0 for r in baseline['runs'])
authored = json.loads((PREP / 'independent-authoring.json').read_text())
assert (authored['cases'], authored['required'], authored['forbidden'], authored['native_owners']) == (46, 37, 9, 69)
for name in ['source-preparation.json.gz', 'independent-source-proposals.json', 'baseline-gap.json.gz',
             'baseline-gap.log', 'fear-lsera-validity.json', 'authored-native-closure.json.gz',
             'independent-authoring.json', 'independent-authoring.log', 'source-preparation.log',
             'prepare_original_sources.py', 'capture_baseline_gaps.py', 'author_boundary_cases.py']:
    raw = (PREP / name).read_bytes()
    target = 'fear-lsera-' + name + ('' if name.endswith('.gz') else '.gz')
    assert not (DOCS / target).exists()
    (DOCS / target).write_bytes(raw if name.endswith('.gz') else gzip.compress(raw, mtime=0))
p = DOCS / 'coverage-checklist.md'
text = p.read_text()
assert 'COV-017cv —' not in text
marker = '- [ ] **COV-018 —'
assert text.count(marker) == 1
addition = '''- [ ] **COV-017cv — Apprehensive and exclamatory -ㄹ세라/-을세라.**
  **Missing: complete original source preparation and independent targets;
  implementation pending.** Original entries 86497 and 86619 preserve all
  three senses, separate short/full attachment notes and all 25 complete
  groups, including their multi-line contexts. Fifty initial and 69 complete
  authored Native owners retain every lexical homonym and original field.
  [Independent source proposals](fear-lsera-independent-source-proposals.json.gz)
  were preserved before probing the immutable installed baseline. All 150
  NFC/NFD/raw/headword/Compatible probes miss their intended lexical and
  canonical structural targets; actual commands and unchanged input hashes
  are retained in the [baseline capture](fear-lsera-baseline-gap.json.gz).
  [Forty-six authored cases](fear-lsera-fear-lsera-validity.json.gz) propose
  37 required and nine forbidden named paths, covering original examples,
  immediate allomorphs, prefinals, explicit copulas and irregular recovery.
  These are proposed targets, not passing tests or candidate-authored gold.
  Remaining: implementation, independent source/Native/distribution audits,
  shared-ledger regressions, library/CLI/browser parity, full Rust and actual
  Nix/installed validation, quiet performance, integration and broader review.

'''
text = text.replace(marker, addition + marker)
text = text.replace('Last reviewed: 2026-10-08.', 'Last reviewed: 2026-10-09.')
p.write_text(text)
(DOCS / 'fear-lsera-preflight-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('Recorded missing25-group/46-target family; no inventory disposition or executable gold changed', flush=True)
