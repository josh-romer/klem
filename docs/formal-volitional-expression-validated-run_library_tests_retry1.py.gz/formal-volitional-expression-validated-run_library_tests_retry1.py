"""Run focused expression/library/shared-ledger tests with source inputs frozen."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

BASE = Path('/home/josh/projects/klem')
PREP = Path(__file__).resolve().parent
ROOT = BASE / '.direnv/formal-volitional-expression-integration'
OUT = PREP / 'library-tests-retry1.json'
LOG = PREP / 'library-tests-retry1.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
files = [ROOT / 'Cargo.toml', ROOT / 'Cargo.lock', ROOT / 'web/src/grammar-labels.json']
files += [p for folder in ['src', 'tests', 'tools', 'examples'] for p in (ROOT / folder).rglob('*')
          if p.is_file() and '__pycache__' not in p.parts]
frozen = {str(p.relative_to(ROOT)): sha(p) for p in files}
commands = [
    ['cargo', 'test', '--locked', '--offline', '--features', 'web', '--test', 'formal_volitional_expression', '--test', 'validity'],
    ['cargo', 'clippy', '--locked', '--offline', '--features', 'web', '--test', 'formal_volitional_expression', '--', '-D', 'warnings'],
]
env = {**os.environ, 'CARGO_TARGET_DIR': '/tmp/klem-formal-expression-target', 'CARGO_BUILD_JOBS': '4',
       'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_INCREMENTAL': '0'}
report = {'state': 'running', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'commands': commands, 'frozen_source_files': frozen,
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
          'scope': 'Three independently authored expression/native/CLI-library regressions plus four complete35595case shared-ledger tests. Original16Native owners/eightsourcejudgments and35587prefix preserved. Unicode/raw/headword/Compatible/cache andordered-breakdown coverage; warnings-denied focusedClippy. Dedicated/tmp target; no old prototype binary or frozen Nix-gate worktree rebuilt. FullRust/Nix/browser/installed/main/wider review remain separate.'}
def save():
    OUT.write_text(json.dumps(report, indent=2) + '\n')
save()
results = []
with LOG.open('xb') as output:
    for command in commands:
        job = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT)
        results.append({'command': command, 'exit_code': job.returncode})
        if job.returncode:
            break
batches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', LOG.read_text())
totals = {label: sum(int(row[index]) for row in batches) for label, index in [('passed', 1), ('failed', 2), ('ignored', 3)]}
report.update(state='passed' if len(results) == 2 and all(r['exit_code'] == 0 for r in results) else 'failed',
              results=results, totals=totals, inputs_unchanged=all(sha(ROOT / path) == digest for path, digest in frozen.items()),
              finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), log_sha256=sha(LOG))
save()
print(report['state'], totals, 'inputs unchanged', report['inputs_unchanged'], flush=True)
assert report['inputs_unchanged']
if report['state'] == 'passed':
    assert totals == {'passed': 7, 'failed': 0, 'ignored': 0}
else:
    raise SystemExit(1)
