"""Build the frozen final draft using the repository's unchanged Nix package definitions."""
import datetime,hashlib,json,os,subprocess
from pathlib import Path
ROOT=Path('/tmp/klem-declarative-dao-prototype');PREFIX=Path('/tmp/klem-declarative-dao-nix');OUT=Path(str(PREFIX)+'.json');LOG=Path(str(PREFIX)+'.log');assert not OUT.exists() and not LOG.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
inputs={str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in ROOT.rglob('*') if p.is_file()}
assert sha(ROOT/'flake.nix')==sha('/home/josh/projects/klem/flake.nix')
assert sha(ROOT/'flake.lock')==sha('/home/josh/projects/klem/flake.lock')
build=Path('/tmp/klem-declarative-dao-nix-build');build.mkdir(exist_ok=True)
command=['nix','build','--offline','--option','build-dir',str(build),'--cores','4','--max-jobs','1','--no-link','--print-out-paths','-L',str(ROOT)+'#klem',str(ROOT)+'#web-assets',str(ROOT)+'#corpus-adapter',str(ROOT)+'#web']
r={'schema_version':1,'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'snapshot_files':inputs,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Final isolated dao source, identical normal flake package definitions, full Rust release tests, actual CLI/server, adapter, SolidJS assets and web launcher. Root integration, installed/runtime/corpus/novel comparison, performance and contextual review remain separate.'}
def save():OUT.write_text(json.dumps(r,indent=2)+'\n')
save();env=dict(os.environ,TMPDIR=str(build))
with LOG.open('xb') as output:job=subprocess.run(command,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT)
r.update(state='passed' if job.returncode==0 else 'failed',exit_code=job.returncode,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),snapshot_unchanged=all(sha(ROOT/p)==v['sha256'] for p,v in inputs.items()),outputs=[line for line in LOG.read_text().splitlines() if line.startswith('/nix/store/')],log_sha256=sha(LOG));save()
assert r['snapshot_unchanged']
if job.returncode==0:assert len(r['outputs'])==4
print('Final draft Nix:',r['state'],'source frozen:',r['snapshot_unchanged'],flush=True)
raise SystemExit(job.returncode)
