"""Replay every word in both preserved corpus/history cohorts against the current release."""
import gzip,json,hashlib,subprocess,copy
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');SOURCE=ROOT/'docs/additive-ppundeoreo-main-corpus-history.json.gz';OUT=Path('/tmp/klem-declarative-dao-cohorts.json.gz');assert not OUT.exists()
BEFORE=Path('/nix/store/mfd8vyfqgmcbz0ns6jg05vglkzz7ldi4-klem-0.1.0/bin/klem');AFTER=Path('/tmp/klem-declarative-dao-cli')
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
frozen={str(p):sha(p) for p in [BEFORE,AFTER,SOURCE,Path(__file__)]}
cohorts=json.loads(gzip.decompress(SOURCE.read_bytes()))['cohorts'];runs=[];additions=[];parents=set()
for cohort in cohorts:
 text='\n'.join(sorted(cohort['after_words']))+'\n';captures=[]
 for binary in [BEFORE,AFTER]:
  command=[str(binary),'text','-'];job=subprocess.run(command,input=text.encode(),capture_output=True,check=True);assert not job.stderr
  records=[json.loads(line) for line in job.stdout.splitlines()]
  words={r['surface']:r['analysis'] for r in records if r.get('analysis')};assert len(words)==len(cohort['after_words'])
  captures.append({'command':command,'stdout_sha256':hashlib.sha256(job.stdout).hexdigest(),'words':words})
 assert captures[0]['words']==cohort['after_words']
 changes={}
 for surface,old in captures[0]['words'].items():
  now=captures[1]['words'][surface];assert now['normalized']==old['normalized']
  assert [p for p in now['analyses'] if p in old['analyses']]==old['analyses']
  if old==now:continue
  changes[surface]={'before':old,'after':now}
  for p in now['analyses']:
   if p in old['analyses']:continue
   assert 'ending.declarative_dao' in p['rules']
   inverse=copy.deepcopy(p);inverse['rules'].remove('ending.declarative_dao');m=inverse['morphemes'][-1];m['form']={'다오':'다고','는다오':'는다고'}[m['form']]
   assert surface.endswith('다오');parent=surface[:-1]+'고';parents.add(parent)
   ident=hashlib.sha256(json.dumps([cohort['family'],surface,p],sort_keys=True,ensure_ascii=False).encode()).hexdigest()[:24]
   additions.append({'id':'declarative-dao-cohort-'+ident,'family':cohort['family'],'surface':surface,'analysis':p,'parent_surface':parent,'exact_parent':inverse,'contextual_verdict':'unjudged','independent_review':'pending'})
 runs.append({'family':cohort['family'],'surfaces':len(cohort['after_words']),'captures':captures,'changed_words':changes})
 print(cohort['family'],len(cohort['after_words']),len(changes),'changed',flush=True)
job=subprocess.run([str(BEFORE),'text','-'],input=('\n'.join(sorted(parents))+'\n').encode(),capture_output=True,check=True);assert not job.stderr
companions={r['surface']:r['analysis'] for r in map(json.loads,job.stdout.splitlines()) if r.get('analysis')}
assert set(companions)==parents
for row in additions:assert row['exact_parent'] in companions[row['parent_surface']]['analyses']
assert all(sha(p)==digest for p,digest in frozen.items())
r={'state':'complete-corpus-history-cohorts-passed','cohorts':runs,'individual_additions':additions,'actual_prior_companions':companions,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'All original corpus/history word analyses, prior candidates/order preserved; exact individual dao additions and actual earlier companions retained. This does not substitute for annotated-row adapter execution or contextual judgment.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
