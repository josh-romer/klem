"""Replay every original annotated row using the actual final Nix adapter."""
import gzip,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');RECEIPT=Path('/tmp/klem-declarative-dao-nix-retry1.json');SOURCE=ROOT/'docs/literary-question-geona-prototype-corpora.json.gz';OUT=Path('/tmp/klem-declarative-dao-installed-adapter-retry1.json.gz');assert not OUT.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
r=json.loads(RECEIPT.read_bytes());assert r['state']=='passed' and r['exit_code']==0 and r['snapshot_unchanged']
adapter=Path(next(p for p in r['outputs'] if p.endswith('-klem-corpus-adapter-0.1.0')))/'bin/klem-corpus-adapter'
baseline_path=ROOT/'docs/possessive-bound-noun-installed-adapter.json.gz';baseline=json.loads(gzip.decompress(baseline_path.read_bytes()));reference=json.loads(gzip.decompress(SOURCE.read_bytes()));frozen={str(p):sha(p) for p in [RECEIPT,SOURCE,baseline_path,adapter,Path(__file__)]};runs=[]
for partition in reference['corpora']:
 source=ROOT/partition['source'];assert sha(source)==partition['source_sha256'];frozen[str(source)]=sha(source)
 command=[str(adapter),partition['corpus'],partition['source']];job=subprocess.run(command,cwd=ROOT,capture_output=True,check=True);assert not job.stderr
 rows=[json.loads(line) for line in job.stdout.splitlines()];previous=next(run for run in baseline['runs'] if (run['corpus'],run['partition'])==(partition['corpus'],partition['partition']));expected=[json.loads(line) for line in previous['jsonl'].splitlines()]
 assert rows==expected and len(rows)==partition['report_lines']
 assert rows[0]['input_sha256']==partition['source_sha256']
 assert [{k:row[k] for k in ['id','surface','expected']} for row in rows[1:]]==[{k:row[k] for k in ['id','surface','expected']} for row in partition['original_converted_rows']]
 runs.append({'corpus':partition['corpus'],'partition':partition['partition'],'source':partition['source'],'source_sha256':sha(source),'command':command,'exit_code':0,'rows':len(rows)-1,'jsonl':job.stdout.decode(),'stdout_sha256':hashlib.sha256(job.stdout).hexdigest()})
 print(partition['corpus'],partition['partition'],len(rows)-1,'exact actual adapter rows',flush=True)
assert sum(run['rows'] for run in runs)==66570 and all(sha(p)==h for p,h in frozen.items())
report={'state':'passed','adapter':str(adapter),'runs':runs,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Actual final installed adapter against all66,570 original rows/four unchanged gold partitions, with complete candidate-count summaries and no rewritten baseline. Independent/contextual precision is not established.'}
OUT.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
