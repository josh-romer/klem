"""Check authored split hypotheses while retaining complete before/after spacing outputs."""
import datetime,gzip,hashlib,json,subprocess,unicodedata
from pathlib import Path
ROOT=Path('/home/josh/projects/klem')
OLD=Path('/nix/store/jmk0c772h8z0frp6f0x14v6siz0w8zhl-klem-0.1.0/bin/klem')
NEW=Path('/tmp/klem-literary-question-geona-cli');DB=ROOT/'data/dictionaries/krdict/krdict.db'
OUT=Path('/tmp/klem-literary-question-geona-spacing-preflight.json.gz');assert not OUT.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
cases=[{'id':'literary-question-geona-spacing-'+name,'surface':word,'left':left,'right':right,'right_head':head,'structural_verdict':'authored split hypothesis','contextual_verdict':'unjudged','independent_review':'pending'} for name,word,left,right,head in [('return','돌아갈거나','돌아','갈거나','가다'),('live','살아갈거나','살아','갈거나','가다'),('benefactive','먹어줄거나','먹어','줄거나','주다'),('try','읽어볼거나','읽어','볼거나','보다')]]
for c in cases:
 c['expected_split_present']=c['id'].endswith(('return','live'))
 c['scope']='Existing nominal-case spacing template; general predicate/auxiliary spacing remains unimplemented.'
frozen={str(p):sha(p.read_bytes()) for p in [OLD,NEW,DB,Path(__file__)]};runs=[];observations=[]
for encoding in ['NFC','NFD']:
 text=unicodedata.normalize(encoding,' '.join(c['surface'] for c in cases));raw=text.encode()
 for mode,flag in [('headword','--dict-only'),('compatible','--dict-compatible')]:
  pair=[]
  for cli in [OLD,NEW]:
   command=[str(cli),'text','-','--dictionary',str(DB),flag,'--suggest-spacing'];result=subprocess.run(command,input=raw,capture_output=True,check=True)
   pair.append({'command':command,'exit_code':0,'jsonl':result.stdout.decode(),'sha256':sha(result.stdout)})
  before,after=[list(map(json.loads,p['jsonl'].splitlines())) for p in pair];assert len(before)==len(after)==7
  for b,a in zip(before,after,strict=True):
   assert {k:v for k,v in b.items() if k not in ['analysis','dictionary','spacing']}=={k:v for k,v in a.items() if k not in ['analysis','dictionary','spacing']}
   if not a.get('analysis'):assert a==b;continue
   assert [p for p in a['analysis']['analyses'] if p in b['analysis']['analyses']]==b['analysis']['analyses']
   for p,assessment in zip(b['analysis']['analyses'],b['dictionary']['readings'],strict=True):assert a['dictionary']['readings'][a['analysis']['analyses'].index(p)]==assessment
   for old in b['spacing']['alternatives']:
    new=next((h for h in a['spacing']['alternatives'] if h['inserted_at']==old['inserted_at'] and h.get('rule')==old.get('rule')),None);assert new is not None
    assert {k:v for k,v in old.items() if k!='records'}=={k:v for k,v in new.items() if k!='records'}
    for os,ns in zip(old['records'],new['records'],strict=True):
     assert {k:v for k,v in os.items() if k not in ['analysis','dictionary','breakdowns']}=={k:v for k,v in ns.items() if k not in ['analysis','dictionary','breakdowns']}
     op,np=os['analysis']['analyses'],ns['analysis']['analyses'];assert [p for p in np if p in op]==op
     for i,p in enumerate(op):
      j=np.index(p);assert os['dictionary']['readings'][i]==ns['dictionary']['readings'][j];assert os['breakdowns'][i]==ns['breakdowns'][j]
  for case in cases:
   row=next(r for r in after if r.get('analysis') and r['analysis']['normalized']==case['surface']);lhs=unicodedata.normalize(encoding,case['left']);rhs=unicodedata.normalize(encoding,case['right'])
   h=next((h for h in row['spacing']['alternatives'] if h['spaced']==lhs+' '+rhs),None);assert (h is not None)==case['expected_split_present'],case['id']
   if h is None:
    observations.append({'case_id':case['id'],'encoding':encoding,'mode':mode,'original_span':row['span'],'hypothesis':None,'right_paths':[],'contextual_verdict':'unjudged','independent_review':'pending'})
    continue
   assert h['inserted_at']==[row['span']['start']+len(lhs.encode())]
   assert h['records'][0]['surface']==lhs and h['records'][1]['surface']==rhs
   assert h['records'][0]['span']=={'start':row['span']['start'],'end':row['span']['start']+len(lhs.encode())}
   assert h['records'][1]['span']=={'start':row['span']['start']+len(lhs.encode()),'end':row['span']['end']}
   right=h['records'][1];paths=[p for p in right['analysis']['analyses'] if p['lemmas'][0]['text']==case['right_head'] and 'ending.literary_question_geona' in p['rules']];assert paths
   observations.append({'case_id':case['id'],'encoding':encoding,'mode':mode,'original_span':row['span'],'hypothesis':h,'right_paths':paths,'contextual_verdict':'unjudged','independent_review':'pending'})
  runs.append({'encoding':encoding,'mode':mode,'input':text,'input_sha256':sha(raw),'before':pair[0],'after':pair[1]})
assert all(sha(Path(p).read_bytes())==h for p,h in frozen.items())
r={'schema_version':1,'state':'passed','cases':cases,'runs':runs,'observations':observations,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Two authored nominal-case split hypotheses and two explicit exclusions from the current nominal-case spacing template, in both Unicode encodings and both dictionary filters. The excluded predicate/auxiliary splits can be legitimate Korean spacing; their absence records the unimplemented broader template, not linguistic incorrectness. All actual complete input frames, previous candidate paths/assessments and old spacing segments are retained. Byte offsets refer to the original unsplit text. Hypotheses are not asserted to be preferred spacing or contextual readings.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Four spacing template cases:16 observations; previous paths and original byte boundaries conserved.',flush=True)
