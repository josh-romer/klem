"""Replay all complete source groups through the actual CLI and verify Native importer closure."""
import gzip,hashlib,json,subprocess,unicodedata
from pathlib import Path
ROOT=Path('/tmp/klem-self-question-prototype');DB=Path('/home/josh/projects/klem/data/dictionaries/krdict/krdict.db');CLI=Path('/home/josh/projects/klem/.direnv/self-question-target/debug/klem');OLD=Path('/nix/store/j4in370si6hf8dv52x2vsxj95grmsnvi-klem-0.1.0/bin/klem');SOURCE=Path('/tmp/klem-self-question-source-preparation-retry1.json.gz');CLOSURE=Path('/tmp/klem-self-question-native-closure-retry2.json.gz');OUT=Path('/tmp/klem-self-question-runtime.json.gz');assert not OUT.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
source=json.loads(gzip.decompress(SOURCE.read_bytes()));closure=json.loads(gzip.decompress(CLOSURE.read_bytes()));frozen={str(p):sha(p) for p in [CLI,OLD,DB,SOURCE,CLOSURE,Path(__file__),ROOT/'tests/fixtures/self-question-native.json',ROOT/'tests/fixtures/self-question-validity.json']};runs=[]
for encoding in ['NFC','NFD']:
 text=unicodedata.normalize(encoding,source['complete_source_text'])
 for cache in [0,4096]:
  for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
   common=['text','-','--dictionary',str(DB),'--cache-bytes',str(cache),*flags];commands=[[str(OLD),*common],[str(CLI),*common]];jobs=[subprocess.run(c,input=text.encode(),capture_output=True,check=True) for c in commands];assert all(not j.stderr for j in jobs);records=[[json.loads(line) for line in j.stdout.splitlines()] for j in jobs];assert len(records[0])==len(records[1]);observations=[]
   for ordinal,(before,after) in enumerate(zip(*records,strict=True)):
    assert before['span']==after['span'] and before['surface']==after['surface'] and before['kind']==after['kind'];assert text.encode()[after['span']['start']:after['span']['end']].decode()==after['surface']
    if after['kind']!='word':assert before==after;continue
    assert before['analysis']['normalized']==after['analysis']['normalized'];prior=before['analysis']['analyses'];now=after['analysis']['analyses'];assert [a for a in now if a in prior]==prior
    olddict,newdict=before['dictionary'],after['dictionary'];assert olddict['source']==newdict['source'] and olddict['fingerprint']==newdict['fingerprint']
    for oldslot in olddict['lemmas']:assert oldslot in newdict['lemmas']
    for i,a in enumerate(prior):assert olddict['readings'][i]==newdict['readings'][now.index(a)]
    added=[a for a in now if a not in prior]
    if added:
     assert all('ending.self_question' in a['rules'] for a in added)
     ident=hashlib.sha256(json.dumps([encoding,cache,mode,ordinal,after],ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:24]
     observations.append({'id':'self-question-runtime-'+ident,'record':ordinal,'surface':after['surface'],'before':before,'after':after,'contextual_verdict':'unjudged'})
   runs.append({'encoding':encoding,'mode':mode,'cache_bytes':cache,'commands':commands,'records':records,'new_observations':observations,'stdout_sha256':[hashlib.sha256(j.stdout).hexdigest() for j in jobs],'exit_codes':[j.returncode for j in jobs]})
fixture=ROOT/'tests/fixtures/self-question-native.json';temp=Path('/tmp/klem-self-question-native-import-validation.db');assert not temp.exists();command=[str(CLI),'dict','import-krdict',str(fixture),str(temp),'--snapshot','self-question-original-source'];job=subprocess.run(command,capture_output=True,check=True)
entries={}
try:
 for ident,expected in closure['entries'].items():
  actual=json.loads(subprocess.check_output([str(CLI),'dict','entry',str(temp),ident]));assert actual==expected,ident;entries[ident]=actual
finally:temp.unlink(missing_ok=True)
r={'state':'source-runtime-and-complete-importer-passed','runs':runs,'import_command':command,'import_stdout':job.stdout.decode(),'import_stderr':job.stderr.decode(),'complete_native_entries':entries,'frozen_inputs':frozen,'inputs_unchanged':all(sha(p)==h for p,h in frozen.items()),'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'All complete original source text in twelve Unicode/cache/filter modes, prior words/candidates/native entries/assessments retained and new candidates tracked individually. All51Native importer entries equal the pinned dictionary. Authored hypotheses are not annotation gold; contextual/independent review and installed/main validation remain pending.'};assert r['inputs_unchanged'];OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Passed',len(runs),'complete source streams and',len(entries),'exact Native entries')
