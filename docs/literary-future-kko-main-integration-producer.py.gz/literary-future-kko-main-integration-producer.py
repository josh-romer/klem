"""Apply only byte-guarded candidate files and an append-only finite regression proposal."""
import collections,datetime,gzip,hashlib,json
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');PROTO=Path('/tmp/klem-literary-future-kko-prototype')
OUT=Path('/tmp/klem-literary-future-kko-main-integration.json');assert not OUT.exists()
read=lambda p:json.loads(gzip.decompress(Path(p).read_bytes()) if str(p).endswith('.gz') else Path(p).read_bytes())
sha=lambda raw:hashlib.sha256(raw).hexdigest()
full=read('/tmp/klem-literary-future-kko-full-rust.json')
assert full['state']=='failed' and full['inputs_unchanged'] and len(full['batches'])==225
assert [(b['target']['name'],b['tests']['failed']) for b in full['batches'] if b['exit_code']]==[('klem-web',1)]
proposal=read(ROOT/'docs/literary-future-kko-current-integration-proposal.json.gz')
baseline=read(ROOT/'docs/literary-question-go-package-nix.json')['snapshot']['files'];assert len(baseline)==939
assert all(sha((ROOT/n).read_bytes())==r['sha256'] for n,r in baseline.items())
changes=dict(proposal['changes'])
prepared=read(ROOT/'docs/literary-future-kko-original-preparation.json.gz')
entries=[v for v in prepared['english_projection']['LexicalResource']['Lexicon']['LexicalEntry'] if 'krdict:'+v['val'] in ['krdict:81026','krdict:81032']];assert len(entries)==2
label_path='tests/fixtures/krdict-literary-future-kko-labels.json'
label_raw=(json.dumps({'LexicalResource':{'Lexicon':{'LexicalEntry':entries}}},ensure_ascii=False,indent=2)+'\n').encode()
changes[label_path]={'before_sha256':None,'after_sha256':sha(label_raw),'after_text':label_raw.decode()}
name='src/bin/klem-web/grammar_labels.rs';raw=(ROOT/name).read_bytes();text=raw.decode();needle='                PathBuf::from("tests/fixtures/krdict-literary-question-go-labels.json"),\n';assert text.count(needle)==1
text=text.replace(needle,needle+'                PathBuf::from("tests/fixtures/krdict-literary-future-kko-labels.json"),\n');changes[name]={'before_sha256':sha(raw),'after_sha256':sha(text.encode()),'after_text':text}
ledger=read(ROOT/'docs/literary-future-kko-append-only-ledger-proposal.json.gz');name='tests/fixtures/validity.json';raw=(ROOT/name).read_bytes();assert sha(raw)==ledger['before_sha256'] and raw.decode()==ledger['before_text']
value=json.loads(raw);assert len(value['cases'])==34843
value['cases'].extend(ledger['added_cases']);value['sources'].update(ledger['added_sources']);assert len(value['cases'])==34920
counts=collections.Counter(j['verdict'] for c in value['cases'] for j in c['judgments']);assert counts=={'required':30808,'forbidden':4128}
text=json.dumps(value,ensure_ascii=False,indent=2)+'\n';changes[name]={'before_sha256':sha(raw),'after_sha256':sha(text.encode()),'after_text':text}
name='tests/validity.rs';raw=(ROOT/name).read_bytes();text=raw.decode();assert text.count('30742')==text.count('4117')==1;text=text.replace('30742','30808').replace('4117','4128');changes[name]={'before_sha256':sha(raw),'after_sha256':sha(text.encode()),'after_text':text}
name='tests/fixtures/literary-future-kko-validity.json';text=json.dumps(ledger['finite_suite'],ensure_ascii=False,indent=2)+'\n';changes[name]={'before_sha256':None,'after_sha256':sha(text.encode()),'after_text':text}
for n,c in changes.items():
 p=ROOT/n
 if c['before_sha256'] is None:assert not p.exists(),n
 else:assert sha(p.read_bytes())==c['before_sha256'],n
 assert sha(c['after_text'].encode())==c['after_sha256']
for n,c in changes.items():
 p=ROOT/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(c['after_text'])
for n,c in changes.items():assert sha((ROOT/n).read_bytes())==c['after_sha256']
names=set(baseline)|set(changes);assert len(names)==947
snapshot={n:{'sha256':sha((ROOT/n).read_bytes()),'bytes':(ROOT/n).stat().st_size} for n in sorted(names)}
r={'schema_version':1,'state':'guarded-main-integration-applied','finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'preceding_full_rust':full['tests'],'preceding_full_rust_sha256':sha(Path('/tmp/klem-literary-future-kko-full-rust.json').read_bytes()),'baseline_package_sha256':sha((ROOT/'docs/literary-question-go-package-nix.json').read_bytes()),'baseline_inputs_preserved_until_integration':939,'snapshot_files':snapshot,'changes':{n:{k:v for k,v in c.items() if k!='after_text'} for n,c in changes.items()},'global_ledger_cases_before':34843,'global_ledger_cases_after':34920,'global_required':30808,'global_forbidden':4128,'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'scope':'Production candidate support and77append-only structural regression cases applied with all old939inputs and all changed/new paths checked before any mutation. The preceding complete945input Rust run found only the independently diagnosed missing-label-source fixture. Two complete primary-entry English projections now supplement the existing source-import test; no test is skipped or weakened. Actual main Rust/CLI/package/cache/performance/adapter/browser validation remains pending; broader coverage and contextual/independent Korean review remain open.'}
OUT.write_text(json.dumps(r,indent=2)+'\n');print('Applied',len(changes),'guarded changes;947inputs and77append-only cases. Main validation pending.',flush=True)
