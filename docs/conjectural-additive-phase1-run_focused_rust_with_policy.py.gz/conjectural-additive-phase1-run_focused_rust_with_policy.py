"""Run the isolated typed-source/Native/CLI regression suite with frozen inputs."""
import datetime
import hashlib
import json
import os
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
PROTO = PREP.parent / 'conjectural-additive-prototype'
OUT = PREP / 'focused-rust-with-policy.json'
LOG = PREP / 'focused-rust-with-policy.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
frozen = {str(p.relative_to(PROTO)): sha(p) for p in PROTO.rglob('*') if p.is_file()}
command = ['cargo', 'test', '--locked', '--offline', '--test', 'conjectural_additive']
env = {**os.environ, 'CARGO_TARGET_DIR': '/tmp/klem-conjectural-additive-target',
       'CARGO_BUILD_JOBS': '4', 'CARGO_PROFILE_DEV_DEBUG': '0',
       'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_INCREMENTAL': '0'}
receipt = {'state': 'running', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'command': command, 'frozen_files': frozen,
           'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
           'scope': 'Isolated six-test typed35/28required/7forbidden original16 Native34 NFC/NFD full-source/target three-filter zero/4096cache CLI/library suite plus six independently authored immediate-owner attachment policy paths. Main and all complete-gate source trees are unchanged. Full ledger/corpus/browser/inventory/Nix/main/linguistic review remain required.'}
OUT.write_text(json.dumps(receipt, indent=2) + '\n')
with LOG.open('xb') as stream:
    job = subprocess.run(command, cwd=PROTO, env=env, stdout=stream, stderr=subprocess.STDOUT)
unchanged = all(sha(PROTO / name) == digest for name, digest in frozen.items())
receipt.update(state='passed' if job.returncode == 0 and unchanged else 'failed',
               exit_code=job.returncode, inputs_unchanged=unchanged,
               finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
OUT.write_text(json.dumps(receipt, indent=2) + '\n')
print(receipt['state'], job.returncode, len(frozen), 'inputs unchanged', unchanged, flush=True)
raise SystemExit(0 if receipt['state'] == 'passed' else 1)
