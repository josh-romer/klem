"""Run the complete current Rust suite in a fresh target with frozen Source and binaries."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = P.parents[1]
W = P.parent / 'friendly-hortative-sena'
O = P / 'friendly-hortative-sena-full-rust.json'
L = P / 'friendly-hortative-sena-full-rust.log'
TARGET = ROOT / '.direnv/friendly-hortative-sena-full-target'
assert not O.exists() and not L.exists() and not TARGET.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=W)
assert not git('status', '--porcelain')
frozen = {n:sha((W/n).read_bytes()) for n in git('ls-files','-z').decode().split('\0')[:-1]}
head, index = git('rev-parse','HEAD').decode().strip(), sha(git('ls-files','--stage','-z'))
binding_path = P / 'friendly-hortative-sena-complete-runtime-binding.json'
binding = json.loads(binding_path.read_bytes())
assert binding['state']=='passed' and all(frozen[n]==d for n,d in binding['production_inputs'].items())
protected = {b['path']:b['sha256'] for b in binding['binaries'].values()}
protected.update(binding['protected_parent_binaries'])
assert all(sha(Path(p).read_bytes())==d for p,d in protected.items())
temp = P / 'rust-temp';temp.mkdir(exist_ok=True)
overrides = dict(CARGO_TARGET_DIR=str(TARGET), CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2',
                 CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', TMPDIR=str(temp),
                 PYTHONDONTWRITEBYTECODE='1')
r = dict(state='running', head=head,index_sha256=index,frozen_inputs=frozen,
         protected_binaries=protected,production_inputs=binding['production_inputs'],
         runtime_binding_sha256=sha(binding_path.read_bytes()),environment_overrides=overrides,results=[],
         producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Complete all-targets Rust/CLI/library tests and warning-denied Clippy for exact current Sena Source, plus formatting, preserved715-source queue and diff. Fresh target, all prior CLI/server/adapter binaries protected. Private25 and stable original corpus case remain separate from shared35740cases519reviews. No fullNix/installed/browser/performance/contextual-review claim.')
def save():
    O.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
    with L.open('xb') as log:
        commands=[['cargo','fmt','--all','--','--check'],
                  ['cargo','test','--locked','--offline','--all-targets','--features','web'],
                  ['cargo','clippy','--locked','--offline','--all-targets','--features','web','--','-D','warnings'],
                  ['python3','tools/review_inventory.py','--verify'],['git','diff','--check']]
        for command in commands:
            log.write(('COMMAND '+json.dumps(command)+'\n').encode());log.flush()
            job=subprocess.run(command,cwd=W,env=dict(os.environ,**overrides),stdout=log,stderr=subprocess.STDOUT)
            r['results'].append(dict(command=command,exit_code=job.returncode));save()
            print(command[0:2],'exit',job.returncode,flush=True)
            assert job.returncode==0,'Actual full Rust gate failed; full original producer/receipt/log preserved.'
    r['state']='passed'
except BaseException as error:
    r.update(state='failed',error=repr(error));raise
finally:
    text=L.read_text() if L.exists() else ''
    totals=dict(passed=0,failed=0,ignored=0)
    batches=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    for batch in batches:
        for key,n in zip(totals,batch,strict=True):totals[key]+=int(n)
    r.update(rust_totals=totals,rust_batches=len(batches),
             inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),
             protected_binaries_unchanged=all(sha(Path(p).read_bytes())==d for p,d in protected.items()),
             head_unchanged=git('rev-parse','HEAD').decode().strip()==head,
             index_unchanged=sha(git('ls-files','--stage','-z'))==index,
             log_sha256=sha(L.read_bytes()) if L.exists() else None,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['inputs_unchanged','protected_binaries_unchanged','head_unchanged','index_unchanged']):r['state']='failed'
    save()
assert r['state']=='passed'
print('Actual full Rust passed:',r['rust_totals'],'batches',r['rust_batches'],'allSource/HEAD/index/protected binaries unchanged.',flush=True)
