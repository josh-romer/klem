"""Run archive-aware installed, timing and draft checks on frozen Gena source."""
import ast
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent/'friendly-command-gena'
OUT = P/'friendly-command-gena-completed-evidence-validation.json'
LOG = P/'friendly-command-gena-completed-evidence-validation.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
raw_sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git',*args],cwd=W)
names = git('ls-files','--cached','--others','--exclude-standard','-z').decode().split('\0')[:-1]
assert len(names) == len(set(names))
source = {n:sha(W/n) for n in names}
head = git('rev-parse','HEAD').decode().strip()
index = raw_sha(git('ls-files','--stage','-z'))
assert head == '6cf27565c7891005de12651abcb7f18911495adf'
test_names = ['test_friendly_command_gena_installed_audit.py','test_friendly_command_gena_ledger_audit.py']
for name in test_names:
    assert (W/'tools'/name).read_bytes() == (P/name).read_bytes()
before = ast.parse((P/'test_friendly_command_gena_performance_audit.py').read_text())
after = ast.parse((W/'tools/test_friendly_command_gena_performance_audit.py').read_text())
old = {n.name:ast.dump(n) for n in ast.walk(before) if isinstance(n,ast.FunctionDef)}
new = {n.name:ast.dump(n) for n in ast.walk(after) if isinstance(n,ast.FunctionDef)}
assert all(new[k] == v for k,v in old.items())
frozen = {str(P/n):sha(P/n) for n in [*test_names,'test_friendly_command_gena_performance_audit.py',Path(__file__).name]}
binding = json.loads((P/'friendly-command-gena-complete-runtime-binding.json').read_bytes())
protected = {row['path']:row['sha256'] for row in binding['binaries'].values()}
assert all(sha(p) == d for p,d in protected.items())
frozen.update(protected)
r = dict(state='running',head=head,index_sha256=index,source_inputs=source,frozen_inputs=frozen,
         original_installed28_and_draft24_test_bytes_preserved=True,
         original_performance23_test_bodies_preserved=True,new_archive_controls=6,
         results=[],producer=dict(text=Path(__file__).read_text(),sha256=sha(__file__)),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Actual current Gena source with all new archive-aware modules and full proof originals frozen; installed28/timing29/draft24 controls, queue and diff checks. Historical installed executables are captured evidence. Shared35740 cases and519 reviews remain unchanged; no main/shared promotion or full checklist claim.')
def save():
    OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
env = dict(os.environ,PYTHONDONTWRITEBYTECODE='1',KLEM_GENA_PROMOTION_DRAFT='1')
commands = []
for kind in ['installed','performance','ledger']:
    command = ['python3','tools/friendly_command_gena_'+kind+'_audit.py']
    if kind == 'ledger': command.append('--draft')
    commands.append(command)
    commands.append(['python3','-m','unittest','discover','-s','tools','-p','test_friendly_command_gena_'+kind+'_audit.py','-v'])
commands += [['python3','tools/review_inventory.py','--verify'],['git','diff','--check']]
try:
    with LOG.open('xb') as log:
        for command in commands:
            log.write(('COMMAND '+json.dumps(command)+'\n').encode());log.flush()
            job = subprocess.run(command,cwd=W,env=env,capture_output=True)
            raw = job.stdout+job.stderr
            log.write(raw);log.flush()
            count = re.search(rb'Ran (\d+) tests',raw)
            r['results'].append(dict(command=command,exit_code=job.returncode,controls=int(count.group(1)) if count else 0))
            save()
            assert job.returncode == 0
    assert len(r['results']) == 8 and sum(row['controls'] for row in r['results']) == 81
    r.update(state='passed',controls=81)
except BaseException as error:
    r.update(state='failed',error=repr(error))
    raise
finally:
    r.update(inputs_unchanged=all(sha(p) == d for p,d in frozen.items()),
             source_unchanged=all(sha(W/p) == d for p,d in source.items()),
             head_unchanged=git('rev-parse','HEAD').decode().strip() == head,
             index_unchanged=raw_sha(git('ls-files','--stage','-z')) == index,
             log_sha256=sha(LOG) if LOG.exists() else None,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged']):
        r['state'] = 'failed'
    save()
assert r['state'] == 'passed'
print('Passed actual81 installed/timing/draft archive controls,715 queue and diff checks; all frozen source/HEAD/index/debug executables unchanged.',flush=True)
