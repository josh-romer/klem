"""Validate explicit evidence modes without changing the live frozen worktree."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
C = P / 'sandbox-candidate'
O = P / 'friendly-hortative-sena-sandbox-candidate.json'
L = P / 'friendly-hortative-sena-sandbox-candidate.log'
assert not O.exists() and not L.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=W)
assert not git('status', '--porcelain')
frozen = {n:sha((W/n).read_bytes()) for n in git('ls-files','-z').decode().split('\0')[:-1]}
head,index=git('rev-parse','HEAD').decode().strip(),sha(git('ls-files','--stage','-z'))
external={str(p):sha(p.read_bytes()) for p in [Path(__file__),*sorted(C.glob('*.py'))]}
for name in ['test_friendly_hortative_sena_runtime_audit.py','test_friendly_hortative_sena_wide_audit.py']:
    assert (C/name).read_bytes()==(W/'tools'/name).read_bytes(), 'all original41/34 test assertions unchanged'
binding=json.loads((P/'friendly-hortative-sena-complete-runtime-binding.json').read_bytes())
protected={row['path']:row['sha256'] for row in binding['binaries'].values()}
protected.update(binding['protected_parent_binaries'])
assert all(sha(Path(p).read_bytes())==d for p,d in protected.items())
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,external_inputs=external,
       protected_binaries=protected,old41_and34_test_source_bytes_exact=True,results=[],
       producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
       started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
       scope='External proposed auditor only: actual live six executable fingerprints; explicit captured mode replays immutable whole original artifacts/current44Source/18frontend without claiming live executable verification. Old41runtime and34wide tests byte exact; seven new mode controls include denying all executable file reads. No Source edit, actual sandboxed Nix execution or full currentNix claim.')
def save():
    O.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
    with L.open('xb') as log:
        unit=lambda pattern:['python3','-m','unittest','discover','-s',str(C),'-p',pattern]
        commands=[('live',['python3',str(C/'friendly_hortative_sena_runtime_audit.py')]),
                  ('live',unit('test_friendly_hortative_sena_runtime_audit.py')),
                  ('captured',['python3',str(C/'friendly_hortative_sena_runtime_audit.py')]),
                  ('captured',unit('test_friendly_hortative_sena_runtime_audit.py')),
                  ('captured',unit('test_friendly_hortative_sena_binary_evidence.py')),
                  ('captured',['python3',str(C/'friendly_hortative_sena_wide_audit.py')]),
                  ('captured',unit('test_friendly_hortative_sena_wide_audit.py'))]
        for mode,command in commands:
            env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(C)+os.pathsep+str(W/'tools'),KLEM_SENA_BINARY_EVIDENCE=mode)
            log.write(('MODE '+mode+' COMMAND '+json.dumps(command)+'\n').encode());log.flush()
            job=subprocess.run(command,cwd=W,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            log.write(job.stdout);log.flush()
            match=re.search(rb'Ran (\d+) tests',job.stdout)
            row=dict(mode=mode,command=command,exit_code=job.returncode,controls=int(match[1]) if match else 0)
            if command[-1].endswith('_audit.py') and '-m' not in command:
                expected=("'mode': '"+mode+"', 'live_executable_files_verified': "+('True' if mode=='live' else 'False')).encode()
                row['explicit_scope_reported']=expected in job.stdout
                assert row['explicit_scope_reported'],'Proposed auditor must explicitly distinguish captured replay from live executable verification.'
            r['results'].append(row);save()
            print(mode,command[-1],job.returncode,row['controls'],flush=True)
            assert job.returncode==0,'Actual external candidate failed; complete original producer/receipt/log retained.'
    r['state']='passed'
except BaseException as error:
    r.update(state='failed',error=repr(error));raise
finally:
    r.update(inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),
             external_inputs_unchanged=all(sha(Path(p).read_bytes())==d for p,d in external.items()),
             protected_binaries_unchanged=all(sha(Path(p).read_bytes())==d for p,d in protected.items()),
             head_unchanged=git('rev-parse','HEAD').decode().strip()==head,
             index_unchanged=sha(git('ls-files','--stage','-z'))==index,
             log_sha256=sha(L.read_bytes()) if L.exists() else None,
             controls=sum(x['controls'] for x in r['results']),
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['inputs_unchanged','external_inputs_unchanged','protected_binaries_unchanged','head_unchanged','index_unchanged']):r['state']='failed'
    save()
assert r['state']=='passed'
print('Passed external live/captured candidate:',r['controls'],'controls;all original Source and actual protected binaries unchanged.',flush=True)
