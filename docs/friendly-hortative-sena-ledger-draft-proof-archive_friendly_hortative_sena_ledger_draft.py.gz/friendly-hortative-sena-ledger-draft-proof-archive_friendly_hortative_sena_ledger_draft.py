"""Preserve the complete validated draft before any eventual shared promotion."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = P.parents[1]
DRAFT = P / 'friendly-hortative-sena-promotion-draft'
OUT = P / 'friendly-hortative-sena-ledger-draft-proof-archive.json'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    assert not OUT.exists()
    metadata = json.loads((DRAFT / 'draft.json').read_bytes())
    controls = json.loads((P / 'friendly-hortative-sena-ledger-draft-controls.json').read_bytes())
    assert controls['state'] == 'actual-draft-controls-passed-not-promoted' and controls['controls'] == 12
    assert controls['actual_terminal_tool_result']['exit_code'] == 0
    assert 'Ran 12 tests' in controls['actual_terminal_tool_result']['output']
    assert not controls['shared_cases_reviews_changed'] and not controls['full_coverage_complete']
    for name, state in metadata['reference_parent_states'].items():
        work = ROOT / '.direnv' / ('friendly-command-gena' if name == 'gena' else 'friendly-hortative-sena')
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip() == state['head']
        assert sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=work)) == state['index_sha256']
        assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=work)
    for name, item in metadata['files'].items():
        path = DRAFT / (name + '.gz' if 'archive_sha256' in item else name)
        raw = path.read_bytes()
        if 'archive_sha256' in item:
            assert sha(raw) == item['archive_sha256']
            assert sha(gzip.decompress(raw)) == item['source_sha256']
            assert Path(item['original_path']).read_bytes() == gzip.decompress(raw)
        else:
            assert sha(raw) == item['source_sha256']
    paths = sorted(DRAFT.iterdir()) + [P / name for name in [
        'prepare_friendly_hortative_sena_ledger_draft.py',
        'friendly_hortative_sena_ledger_draft_audit.py',
        'test_friendly_hortative_sena_ledger_draft_audit.py',
        'friendly-hortative-sena-ledger-draft-controls.json', Path(__file__).name]]
    files = {}
    for path in paths:
        label = ('draft-' if path.parent == DRAFT else '') + path.name
        destination = P / ('friendly-hortative-sena-ledger-draft-proof-' + label + '.gz')
        assert not destination.exists() and label not in files
        raw = path.read_bytes()
        packed = gzip.compress(raw, mtime=0)
        destination.write_bytes(packed)
        assert gzip.decompress(destination.read_bytes()) == raw
        files[label] = dict(original_path=str(path), path=destination.name,
                            source_sha256=sha(raw), archive_sha256=sha(packed), source_bytes=len(raw))
    manifest = dict(state='complete-original-Sena-ledger-draft-archived', files=files,
                    parent_cases=35764, proposed_cases=35789, added_cases=25,
                    added_required=19, added_forbidden=6, parent_reviews=520, proposed_reviews=521,
                    actual_controls=12, actual_shared_promotion=False, full_coverage_complete=False,
                    scope='Complete original parent ledger/reviews/715-source queue, original25-case suite/corrected authoring/source manifest, full proposed ledger/reviews, bounded proposal, actual tool result observations and all producers retained. Original candidate/gold/context judgments remain unchanged. Current installed prerequisites and shared/main promotion remain open.')
    OUT.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print('Archived all', len(files), 'full original Sena draft artifacts; actual12controls passed; promotion pending.', flush=True)


if __name__ == '__main__':
    main()
