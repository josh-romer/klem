import hashlib,json,os,re,signal,subprocess,urllib.request
from pathlib import Path
ROOT=Path('/tmp/klem-named-title-prototype');PREFIX=Path('/tmp/klem-named-title-browser-runtime');OUT=Path(str(PREFIX)+'.json');assert not OUT.exists()
BIN=Path('/home/josh/projects/klem/.direnv/named-title-target/debug');ASSETS=Path('/tmp/klem-surname-prototype/web/dist');DB=Path('/home/josh/projects/klem/data/dictionaries/krdict/krdict.db');DRIVER=Path('/tmp/klem-named-title-browser.mjs')
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
inputs={str(p):sha(p) for p in [BIN/'klem',BIN/'klem-web',DB,DRIVER,Path(__file__),ROOT/'src/dictionary/proper_names.json',*[p for p in ASSETS.rglob('*') if p.is_file()]]}
command=[str(BIN/'klem-web'),'--port','0','--assets',str(ASSETS),'--dictionary',str(DB),'--proper-names']
r={'state':'running','command':command,'frozen_inputs':inputs};OUT.write_text(json.dumps(r,indent=2)+'\n');job=subprocess.Popen(command,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
try:
 line=job.stderr.readline();match=re.search(r'http://127\.0\.0\.1:\d+',line);assert match,line;url=match.group();r['url']=url
 with urllib.request.urlopen(url+'/api/status',timeout=10) as response:status=json.load(response)
 assert status['dictionary']['metadata']['supplements'][0]['sha256']==sha(ROOT/'src/dictionary/proper_names.json')
 r['status']=status
 with urllib.request.urlopen(url,timeout=10) as response:html=response.read();assert html==(ASSETS/'index.html').read_bytes()
 for path in re.findall(r'(?:src|href)="(/assets/[^"?#]+\.(?:js|css))"',html.decode()):
  with urllib.request.urlopen(url+path,timeout=10) as response:assert response.read()==(ASSETS/path.lstrip('/')).read_bytes()
 env=dict(os.environ,KLEM_WEB_URL=url,KLEM_BIN=str(BIN/'klem'),CHROMIUM_PATH='/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium')
 with Path(str(PREFIX)+'.log').open('xb') as log:completed=subprocess.run(['node',str(DRIVER)],env=env,stdout=log,stderr=subprocess.STDOUT)
 r.update(state='passed' if completed.returncode==0 else 'failed',exit_code=completed.returncode)
finally:
 if job.poll() is None:job.send_signal(signal.SIGINT)
 r['server_exit_code']=job.wait(timeout=20);r['server_stopped']=True;r['inputs_unchanged']=all(sha(p)==d for p,d in inputs.items());OUT.write_text(json.dumps(r,indent=2)+'\n')
assert r['state']=='passed';assert r['inputs_unchanged'];print('Prototype browser capture passed; owned server stopped.')
