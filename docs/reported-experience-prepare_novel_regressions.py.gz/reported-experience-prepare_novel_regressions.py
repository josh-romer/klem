"""Bind later novel paths to complete original broad and Native evidence."""
import gzip,json,hashlib,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];PROTO=ROOT/'.direnv/reported-experience-prototype';PREP=Path(__file__).resolve().parent
sys.path.insert(0,str(PROTO/'tools'))
from native_lmf import entry
report=json.loads(gzip.decompress((PREP/'broad.json.gz').read_bytes()))
raw=next(r for r in report['comparisons'] if r['mode']=='novel-raw')
assert len(raw['changed_frames'])==2 and len(report['individual_additions'])==16 and not report['individual_spacing_additions']
entries=report['complete_native_entries'];assert set(entries)=={'krdict:59096','krdict:15078'}
source=json.loads((PROTO/'tests/fixtures/reported-experience-native.json').read_text())
selected=[v for v in source['LexicalResource']['Lexicon']['LexicalEntry'] if entry(v)['id'] in entries]
assert {entry(v)['id']:entry(v) for v in selected}==entries
fixture={'state':'complete-reported-experience-novel-path-preservation-passed','source_sha256':raw['source_sha256'],'broad_sha256':hashlib.sha256((PREP/'broad.json.gz').read_bytes()).hexdigest(),'raw_changed_frames':raw['changed_frames'],**{k:report[k] for k in ['individual_additions','individual_spacing_additions','complete_native_entries','independent_spacing_replay']}}
for name,value in [('reported-experience-novel-history.json',fixture),('reported-experience-novel-native.json',{'LexicalResource':{'Lexicon':{'LexicalEntry':selected}}}),('reported-experience-novel-entries.json',entries)]:
 (PROTO/'tests/fixtures'/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
print('Preserved2complete novel frames,16individual observations,8raw additions,2complete Native owners')
