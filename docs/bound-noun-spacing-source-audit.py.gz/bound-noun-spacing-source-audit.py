"""Check unabridged source closure and retained correction independently of runtime success."""
import gzip,hashlib,json,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from native_lmf import array,entry,verify_native_lmf
read=lambda p:json.load(gzip.open(p,'rt'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def verify(r):
 closure=read('/tmp/klem-bound-noun-spacing-native-closure.json.gz')
 assert r['state']=='finite-structural-source-review-retained' and len(r['profiles'])==12
 assert r['bound_noun_closure_sha256']==sha('/tmp/klem-bound-noun-spacing-native-closure.json.gz')
 assert r['dictionary_sha256']==closure['dictionary_sha256'] and r['source_exports']==closure['source_exports']
 entries=r['complete_modifier_native_entries'];original=r['original_modifier_lmf']
 assert len(entries)==15 and set(original)==set(entries)
 assert {e['headword'] for e in entries.values()}==set(r['modifier_heads'])
 for ident,value in original.items():assert entry(value)==entries[ident]
 verify_native_lmf(r['english_modifier_projection'],entries)
 # Retain the competing final/suffix identities; none is relabeled as a noun
 # modifier source simply because its surface matches an adnominal/nominalizer.
 assert entries['krdict:77062']['headword']==entries['krdict:86038']['headword']=='-던'
 assert entries['krdict:73332']['pos']=='접사' and entries['krdict:72222']['pos']=='어미'
 heads=set();ids=set()
 for profile in r['profiles']:
  ident=profile['id'];heads.add(profile['headword']);ids.add(ident)
  assert profile['complete_native_entry']==closure['complete_native_entries'][ident]
  assert profile['original_lmf']==closure['original_lmf'][ident]
  assert profile['complete_native_entry']['pos']=='의존 명사'
  assert profile['canonical_modifier_forms'] and set(profile['canonical_modifier_forms'])<=set(['은','는','을','던','기'])
  assert 'not verbatim dictionary examples or contextual gold' in profile['evidence_class']
 assert len(heads)==len(ids)==12
 original=json.loads((ROOT/'tests/fixtures/predicate-auxiliary-spacing-owner-cases.json').read_bytes())['cases'][9]
 assert r['original_proposal']==original and original['required_space']=='먹어 준것은'
 c=r['correction'];assert c['proper_targets']==['먹어준 것은','먹어 준 것은']
 spaces={h['spaced'] for h in c['actual_compatible_record']['spacing']['alternatives']}
 assert set(c['proper_targets'])<=spaces and original['required_space'] not in spaces
 assert 'independent language review pending' in c['status']
 assert sha(r['producer_path'])==r['producer']['sha256'] if 'producer_path' in r else hashlib.sha256(r['producer']['text'].encode()).hexdigest()==r['producer']['sha256']
 return {'profiles':12,'complete_modifier_homonyms':15,'unchanged_original_requirement':True,'separately_tested_corrected_targets':2,'independent_review':'pending'}
if __name__=='__main__':print(json.dumps(verify(read('/tmp/klem-bound-noun-spacing-source-review.json.gz'))))
