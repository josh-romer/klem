"""Author finite boundary and marker proposals before observing the isolated output."""
import json
from pathlib import Path
OUT=Path('/tmp/klem-additive-ppundeoreo-authored-boundaries.json');assert not OUT.exists()
cases=[]
def add(name,surface,head,morphs=('을뿐더러',),*,present=True,status='compatible',kinds=None,lemma_kinds=None,proposal='required'):
    heads=[head] if isinstance(head,str) else head
    cases.append({'id':'additive-ppundeoreo-'+name,'surface':surface,'lemmas':heads,
                  'lemma_kinds':lemma_kinds or ['predicate']*len(heads),'morphemes':list(morphs),
                  'morpheme_kinds':kinds or ['prefinal']*(len(morphs)-1)+['ending'],
                  'required_rules':['ending.additive_ppundeoreo'],
                  'expected_presence':dict.fromkeys(['raw','headword','compatible'],present),
                  'expected_status':status if present else None,'proposal':proposal if present else 'forbidden',
                  'contextual_verdict':'unjudged','independent_review':'pending'})
for name,surface,head in [
 ('vowel','갈뿐더러','가다'),('consonant','먹을뿐더러','먹다'),('lexical-l','살뿐더러','살다'),
 ('d-irregular','걸을뿐더러','걷다'),('b-irregular-verb','도울뿐더러','돕다'),
 ('b-irregular-adjective','추울뿐더러','춥다'),('s-irregular','나을뿐더러','낫다'),
 ('eu','끌뿐더러','끄다'),('reu-preserved','모를뿐더러','모르다'),
 ('h-irregular','파랄뿐더러','파랗다'),('h-demonstrative','이럴뿐더러','이렇다')]:add(name,surface,head)
for name,surface,head in [
 ('missing-eul','먹뿐더러','먹다'),('extra-eul-vowel','가을뿐더러','가다'),
 ('extra-eul-l','살을뿐더러','살다'),('missing-attached-l','가뿐더러','가다'),
 ('unrecovered-d','걷뿐더러','걷다'),('missing-eul-adjective','좁뿐더러','좁다')]:
    add(name,surface,head,present=False)
for name,surface,head,morphs,status,proposal in [
 ('honorific-verb','먹으실뿐더러','먹다',['시','을뿐더러'],'compatible','required'),
 ('honorific-adjective','좋으실뿐더러','좋다',['시','을뿐더러'],'compatible','required'),
 ('past-verb','먹었을뿐더러','먹다',['었','을뿐더러'],'compatible','required'),
 ('past-adjective','좋았을뿐더러','좋다',['었','을뿐더러'],'compatible','required'),
 ('honorific-past','먹으셨을뿐더러','먹다',['시','었','을뿐더러'],'compatible','conditional'),
 ('double-past','먹었었을뿐더러','먹다',['었','었','을뿐더러'],'compatible','conditional'),
 ('modal','먹겠을뿐더러','먹다',['겠','을뿐더러'],'unknown','conditional'),
 ('retrospective','먹더럴뿐더러','먹다',['더','을뿐더러'],'unknown','conditional'),
 ('formal-honorific','먹사옵실뿐더러','먹다',['사옵시','을뿐더러'],'unknown','conditional')]:
    add(name,surface,head,morphs,status=status,proposal=proposal)
for name,surface,heads,morphs,kinds,lemma_kinds,status,proposal in [
 ('derived-dap','학생다울뿐더러',['학생'],['답다','을뿐더러'],['suffix','ending'],['nominal'],'compatible','conditional'),
 ('derived-hada','공부할뿐더러',['공부'],['하다','을뿐더러'],['suffix','ending'],['nominal'],'compatible','conditional'),
 ('derived-hada-past','공부했을뿐더러',['공부'],['하다','었','을뿐더러'],['suffix','prefinal','ending'],['nominal'],'compatible','conditional'),
 ('auxiliary-ju','먹어줄뿐더러',['먹다','주다'],['어','을뿐더러'],['ending','ending'],['predicate','auxiliary'],'compatible','conditional'),
 ('auxiliary-bo','읽어볼뿐더러',['읽다','보다'],['어','을뿐더러'],['ending','ending'],['predicate','auxiliary'],'compatible','conditional'),
 ('copula-consonant','학생일뿐더러',['학생','이다'],['을뿐더러'],['ending'],['nominal','copula'],'compatible','required'),
 ('copula-vowel','바다일뿐더러',['바다','이다'],['을뿐더러'],['ending'],['nominal','copula'],'compatible','required'),
 ('omitted-copula','바달뿐더러',['바다','이다'],['을뿐더러'],['ending'],['nominal','copula'],'unknown','conditional'),
 ('copula-past','학생이었을뿐더러',['학생','이다'],['었','을뿐더러'],['prefinal','ending'],['nominal','copula'],'compatible','conditional'),
 ('copula-modal','학생이겠을뿐더러',['학생','이다'],['겠','을뿐더러'],['prefinal','ending'],['nominal','copula'],'unknown','conditional')]:
    add(name,surface,heads,morphs,kinds=kinds,lemma_kinds=lemma_kinds,status=status,proposal=proposal)
assert len(cases)==36 and len({c['id'] for c in cases})==36
OUT.write_text(json.dumps({'schema_version':1,'source_ids':['krdict:74341','krdict:74021'],
                          'cases':cases,'scope':'Finite authored structural/Native policy draft, separate from all original examples. Conditional composed/marker/omission cases remain outside required global judgments. Expected shapes/statuses are proposals to be checked, not observed truth.'},ensure_ascii=False,indent=2)+'\n')
print('Authored36 distinct boundary, marker, derivation, auxiliary and copula proposals before execution.')
