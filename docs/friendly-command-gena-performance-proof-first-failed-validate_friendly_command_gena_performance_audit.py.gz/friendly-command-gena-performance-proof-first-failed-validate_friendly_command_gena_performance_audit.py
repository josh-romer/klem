"""Preserve the actual performance audit attempt, including terminal failures."""
import datetime
import hashlib
import json
import subprocess
import sys
import unittest
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent/'friendly-command-gena'
OUT = P/'friendly-command-gena-performance-audit-validation.json'
LOG = P/'friendly-command-gena-performance-audit-validation.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
git = lambda *a: subprocess.check_output(['git',*a],cwd=W)
raw_sha = lambda raw: hashlib.sha256(raw).hexdigest()
source = {p:sha(W/p) for p in git('ls-files','-z').decode().split('\0')[:-1]}
head = git('rev-parse','HEAD').decode().strip()
index = raw_sha(git('ls-files','--stage','-z'))
names = ['friendly-command-gena-performance.json','capture_friendly_command_gena_performance.py',
         'friendly_command_gena_performance_audit.py','test_friendly_command_gena_performance_audit.py',Path(__file__).name]
frozen = {str(P/n):sha(P/n) for n in names}
r = dict(state='running',head=head,index_sha256=index,source_inputs=source,frozen_inputs=frozen,
         producer=dict(text=Path(__file__).read_text(),sha256=sha(__file__)),
         original_auditor=dict(text=(P/names[2]).read_text(),sha256=sha(P/names[2])),
         original_controls=dict(text=(P/names[3]).read_text(),sha256=sha(P/names[3])),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Actual independent verification of already retained timing samples. This does not run new measurements during the Sena build or establish host isolation, statistical equivalence, context/register precision, independent Korean review, main/shared promotion or checklist completion.')
def save():
    OUT.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
    sys.dont_write_bytecode = True
    import test_friendly_command_gena_performance_audit as tests
    suite = unittest.defaultTestLoader.loadTestsFromModule(tests)
    assert suite.countTestCases() == 22
    with LOG.open('x') as stream:
        result = unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    r.update(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped))
    assert result.wasSuccessful() and result.testsRun == 22 and not result.skipped
    r['summary'] = tests.Controls.summary
    r['state'] = 'passed'
except BaseException as error:
    r.update(state='failed',error=repr(error))
    raise
finally:
    r.update(inputs_unchanged=all(sha(p)==d for p,d in frozen.items()),
             source_unchanged=all(sha(W/p)==d for p,d in source.items()),
             head_unchanged=git('rev-parse','HEAD').decode().strip()==head,
             index_unchanged=raw_sha(git('ls-files','--stage','-z'))==index,
             log_sha256=sha(LOG) if LOG.exists() else None,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged']):
        r['state'] = 'failed'
    save()
assert r['state'] == 'passed'
print('Passed actual22 Gena performance controls:80 original samples,6 full179112-frame cache streams.',flush=True)
