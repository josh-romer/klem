"""Bind independent complete cohort and gold audits to the captured family."""
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
PARENT = BASE / 'explanatory-se-integration'
ROOT = BASE / 'familiar-geurae-prototype'
PREP = BASE / 'familiar-geurae-prepared'
for family in ['cohort', 'corpora']:
    for prefix in ['', 'test_']:
        name = prefix + 'giroseo_' + family + '_audit.py'
        text = (PARENT / 'tools' / name).read_text()
        text = text.replace('giroseo', 'familiar_geurae' if prefix else 'familiar-geurae')
        text = text.replace('reported-experience-cohorts', 'explanatory-se-cohorts').replace('reported-experience-corpora', 'explanatory-se-corpora')
        text = text.replace('ending.concessive_familiar-geurae', 'particle.familiar_geurae')
        if not prefix:
            text = text.replace('"familiar-geurae-" + family', '"familiar-geurae-" + family')
            if family == 'cohort':
                marker = '    return {\n'
                assert marker in text
                text = text.replace(marker, '    assert changed_counts == [0, 0] and not additions, "complete unchanged cohort candidates"\n' + marker, 1)
        target = ROOT / 'tools' / (prefix + 'familiar_geurae_' + family + '_audit.py')
        assert not target.exists()
        target.write_text(text)
for name in ['cohorts.json.gz', 'corpora.json.gz']:
    (ROOT / 'docs' / ('familiar-geurae-' + name)).write_bytes((PREP / name).read_bytes())
for name in ['explanatory-se-cohorts.json.gz', 'explanatory-se-corpora.json.gz',
             'literary-question-geona-prototype-corpora.json.gz', 'literary-question-geona-prototype-legacy-history.json.gz']:
    (ROOT / 'docs' / name).write_bytes((PARENT / 'docs' / name).read_bytes())
print('Prepared independent53502word/66570originalgold audits and5/10corruption controls', flush=True)
