"""Check all original Native owner fields through both actual CLI versions."""
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-gentle-command')
OUT = PREP / 'gentle-command-native-cli.json'
assert not OUT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
new_binding_path = PREP / 'gentle-command-current-production-binding.json'
old_binding_path = PREP / 'willingness-installed-source-binding-retry1.json'
new_binding = json.loads(new_binding_path.read_bytes())
old_binding = json.loads(old_binding_path.read_bytes())
assert new_binding['state'] == old_binding['state'] == 'passed'
before = Path(old_binding['profiles']['klem']['package']) / 'bin/klem'
after = Path(new_binding['binaries']['klem']['path'])
assert sha(after) == new_binding['binaries']['klem']['sha256']
db = Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db')
fixture_paths = [WORK / ('tests/fixtures/' + name) for name in
                 ['gentle-command-native-entries.json', 'gentle-command-boundary-native-entries.json']]
expected = {}
for path in fixture_paths:
    entries = json.loads(path.read_bytes())
    assert not set(entries) & set(expected)
    expected.update(entries)
assert len(expected) == 47
frozen = {str(p): sha(p) for p in [before, after, db, new_binding_path, old_binding_path,
                                *fixture_paths, Path(__file__)]}
r = dict(state='running', frozen_inputs=frozen, records=[],
         captured_head=new_binding['captured_head'],
         producer=dict(text=Path(__file__).read_text(), sha256=sha(__file__)))
save = lambda: OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2)+'\n')
save()
try:
    for ident, native in expected.items():
        captures = []
        for cli in [before, after]:
            command = [str(cli), 'dict', 'entry', str(db), ident]
            job = subprocess.run(command, capture_output=True)
            assert job.returncode == 0 and not job.stderr, job.stderr
            response = json.loads(job.stdout)
            assert response['entry'] == native, ('complete original Native fields', ident)
            captures.append(dict(command=command, exit_code=0, json=job.stdout.decode(),
                                 stdout_sha256=hashlib.sha256(job.stdout).hexdigest()))
        assert captures[0]['json'] == captures[1]['json']
        r['records'].append(dict(id=ident, complete_original_entry=native, captures=captures))
    r.update(state='complete-gentle-command-native-cli-passed', entries=len(r['records']),
             inputs_unchanged=all(sha(p) == value for p, value in frozen.items()),
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             scope='All47completeoriginalowners,includingbothendings,allverb/adjectivehomonyms,boundaryheadsand-dapda,retainedbyte-for-bytethroughbothactualCLIversions. This does not certify contextual candidate precision or independent linguistic review.')
    assert r['inputs_unchanged']
    save()
    print('All47 complete Native owners match both actual CLI versions byte-for-byte.', flush=True)
except Exception as error:
    r.update(state='failed', error=str(error))
    save()
    raise
