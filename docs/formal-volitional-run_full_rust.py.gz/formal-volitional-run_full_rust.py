"""Run the complete Rust suite with every selected source file frozen."""
import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
PREP=Path(__file__).resolve().parent;PROTO=PREP.parent/'formal-volitional-prototype'
LOG=PREP/'full-rust.log';OUT=PREP/'full-rust.json';assert not LOG.exists() and not OUT.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
paths=[PROTO/n for n in ['Cargo.toml','Cargo.lock','web/src/grammar-labels.json']]
for folder in ['src','tests','tools','examples']:
 for source in (PROTO/folder).rglob('*.rs'):
  for relative in re.findall(r'include_(?:str|bytes)!\(\s*"([^"]+)"',source.read_text()):
   selected=(source.parent/relative).resolve()
   if selected not in paths:paths.append(selected)
for folder in ['src','tests','tools','examples']:
 paths.extend(p for p in (PROTO/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
frozen={str(p.relative_to(PROTO)):sha(p) for p in paths}
command=['cargo','test','--locked','--offline','--features','web'];env={**os.environ,'CARGO_TARGET_DIR':str(PREP.parent/'formal-volitional-target'),'CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_INCREMENTAL':'0'}
r={'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'frozen_source_files':frozen,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Actual entire formal-volitional private Rust suite after53 original structural and4 independently reviewed novel cases preserve the exact35530-case apprehensive prefix. Original59Source judgments remain immutable, all59 separately dictionary-enforced. Five Source/four novel/four shared-ledger tests andClippy pass;222browser decisions/diagrams/sixexports/69Native endpoints and111family/84historical/10inventory controls passed. Seven formal audit families plus completed historical performance auditing are wired into Nix. Every manifest/source/test/tool/example and all literal include inputs frozen. Full linguistic coverage, actual Nix/installed/main/performance/contextual review remain separate. Original80paired+6cachebenchmark and every formal runtime/browser capture confirmed terminal/passed before starting this complete suite. No formal prototype selected inputs or its runtimes may change until authoritative terminal.'}
OUT.write_text(json.dumps(r,indent=2)+'\n')
with LOG.open('xb') as stream:job=subprocess.run(command,cwd=PROTO,env=env,stdout=stream,stderr=subprocess.STDOUT)
batches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',LOG.read_text());totals={k:sum(int(b[i+1]) for b in batches) for i,k in enumerate(['passed','failed','ignored'])}
unchanged=all(sha(PROTO/name)==value for name,value in frozen.items())
r.update(state='passed' if job.returncode==0 and totals['failed']==0 and unchanged else 'failed',exit_code=job.returncode,totals=totals,batches=len(batches),inputs_unchanged=unchanged,log_sha256=sha(LOG),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
OUT.write_text(json.dumps(r,indent=2)+'\n');print({k:r[k] for k in ['state','exit_code','totals','batches','inputs_unchanged']},flush=True)
assert unchanged;raise SystemExit(job.returncode)
