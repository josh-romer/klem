"""Observe original targets through an installed binary with unchanged production sources."""
import gzip
import hashlib
import json
import subprocess
import unicodedata
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = Path('/home/josh/projects/klem')
WORK = Path('/tmp/klem-expression-conjectural-main')
AUTHOR = PREP / 'independent-source-authoring.json'
BINDING = ROOT / '.direnv/conjectural-additive-prepared/conjectural-integration-installed-source-binding.json'
DB = ROOT / '.direnv/dictionary-restoration/krdict.db'
OUT = PREP / 'original-installed-baseline.json.gz'
assert not OUT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
binding, author = json.loads(BINDING.read_bytes()), json.loads(AUTHOR.read_bytes())
assert binding['state'] == 'passed' and author['state'] == 'original-source-targets-authored-before-runtime-probe'
assert not subprocess.check_output(['git', 'diff', '0f7a599', 'ea34949', '--', 'src', 'web/src'], cwd=ROOT)
CLI = Path(binding['profiles']['klem']['package']) / 'bin/klem'
frozen = {str(p): sha(p) for p in [AUTHOR, BINDING, DB, CLI, Path(__file__)]}
source_profiles = binding['profiles']
for name, profile in source_profiles.items():
    for metadata in profile['files'].values():
        relative = metadata['snapshot_path']
        if relative.startswith('src/') or relative.startswith('web/src/') or relative in ['Cargo.toml', 'Cargo.lock']:
            assert sha(WORK / relative) == metadata['sha256'], 'installed production source differs from combined source'
items = author['items'] + author['separate_expression_groups']
runs = []
for family in ['complete-original-source', 'all-individual-targets']:
    groups = ['\n'.join(i['complete_original_group']) if family == 'complete-original-source' else i['surface'] for i in items]
    text = ('\n' if family == 'complete-original-source' else ' ').join(groups)
    for encoding in ['NFC', 'NFD']:
        original = unicodedata.normalize(encoding, text).encode()
        positions, offset = [], 0
        for group, item in zip(groups, items, strict=True):
            group_bytes = unicodedata.normalize(encoding, group).encode()
            target = unicodedata.normalize(encoding, item['surface']).encode()
            positions.append(offset + group_bytes.index(target))
            offset += len(group_bytes) + 1
        for mode, flags in [('raw', []), ('headword', ['--dict-only']), ('compatible', ['--dict-compatible'])]:
            cached = None
            for cache in [0, 4096]:
                command = [str(CLI), 'text', '-', '--dictionary', str(DB), *flags, '--cache-bytes', str(cache)]
                job = subprocess.run(command, cwd=ROOT, input=original, capture_output=True)
                assert job.returncode == 0 and not job.stderr
                records = [json.loads(line) for line in job.stdout.splitlines()]
                cursor = 0
                for record in records:
                    assert record['span']['start'] == cursor and original[cursor:record['span']['end']].decode() == record['surface']
                    cursor = record['span']['end']
                assert cursor == len(original)
                if cached is None: cached = job.stdout
                else: assert cached == job.stdout
                observations = []
                for item, position in zip(items, positions, strict=True):
                    index, record = next((i, row) for i, row in enumerate(records) if row['span']['start'] == position)
                    assert record['surface'] == unicodedata.normalize(encoding, item['surface'])
                    paths = (record.get('analysis') or {}).get('analyses', [])
                    proposed = item['typed_target']['lemmas'] if 'typed_target' in item else item['independent_lexical_proposal']
                    lexical = [i for i, path in enumerate(paths) if [l['text'] for l in path['lemmas']] == proposed]
                    typed = [i for i, path in enumerate(paths) if 'typed_target' in item and [l['text'] for l in path['lemmas']] == proposed and [l['kind'] for l in path['lemmas']] == item['typed_target']['lemma_kinds'] and [m['form'] for m in path['morphemes']] == item['typed_target']['morphemes'] and [m['kind'] for m in path['morphemes']] == item['typed_target']['morpheme_kinds']]
                    observations.append({'id': item['id'], 'entry_id': item['entry_id'], 'surface': item['surface'], 'record_index': index, 'independent_lexical_proposal': proposed, 'lexical_path_indices': lexical, 'typed_ending_path_indices': typed, 'actual_record': record, 'disposition': 'observation-only; no alternative or contextual verdict'})
                runs.append({'family': family, 'encoding': encoding, 'mode': mode, 'cache_bytes': cache,
                             'command': command, 'exit_code': 0, 'input_sha256': hashlib.sha256(original).hexdigest(),
                             'jsonl': job.stdout.decode(), 'jsonl_sha256': hashlib.sha256(job.stdout).hexdigest(),
                             'records': len(records), 'original_bytes_conserved': True, 'observations': observations})
                print(family, encoding, mode, cache, len(records), 'frames;', sum(bool(o['lexical_path_indices']) for o in observations), '/18lexicaltargets;', sum(bool(o['typed_ending_path_indices']) for o in observations), '/10endingtargets', flush=True)
assert len(runs) == 24 and all(sha(path) == digest for path, digest in frozen.items())
r = {'state': 'complete-original-baseline-observed', 'runs': runs, 'frozen_inputs': frozen, 'inputs_unchanged': True,
     'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
     'installed_package': str(CLI.parent.parent), 'production_source_identity': 'Original a23eb576 actual installed package; all runtime src, web/src, Cargo.toml/Cargo.lock bytes equal the frozen combined ea34949 source. Combined differences are tests, fixtures, tools and documents only.',
     'scope': 'All18 original ending/expression groups preserved in24NFC/NFD/raw/headword/Compatible/cache0/4096 streams. Exact preauthored lexical/ending proposals tracked separately from actual paths. Missing markers alone do not establish missing lemmas. Existing lexical analyses and every source byte/cache result retained. No source, runtime, gold fixture, corpus baseline or manual disposition changed.'}
OUT.write_bytes(gzip.compress((json.dumps(r, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
