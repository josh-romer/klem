"""Preserve complete original familiar 그래 particle and original follower-ending sources before any engine-driven judgments."""
import gzip,hashlib,json,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from native_lmf import entry,feature
sha=lambda raw:hashlib.sha256(raw).hexdigest()
DB=(ROOT/'data/dictionaries/krdict/krdict.db').resolve();ids=['krdict:83913'];lexical_heads=['쉬다','생각','오랜만','쏠쏠하다','이다','그래','-구먼','-군','-지','-는구먼','-더구먼','-로구먼','-는군','-로군','학생','먹다','가다','좋다','넓다','맞다','되다','하다','읽다','알다']
with sqlite3.connect(DB.as_uri()+'?mode=ro',uri=True) as db:
 expressions={ident:json.loads(db.execute('select data from entries where id=?',(ident,)).fetchone()[0]) for ident in ids}
 lexicals={ident:json.loads(raw) for ident,raw in db.execute('select id,data from entries where headword in ('+','.join('?' for _ in lexical_heads)+')',lexical_heads)}
 metadata=dict(db.execute('select key,value from metadata'))
expected={**expressions,**lexicals};native={};exports={}
for p in sorted((ROOT/'.direnv/dictionary-restoration/2026-09').rglob('*.json')):
 raw=p.read_bytes();selected=[]
 for v in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
  ident='krdict:'+str(v.get('val'))
  if ident not in expected or feature(v,'lexicalUnit') in {'관용구','속담'}:continue
  assert ident not in native and entry(v)==expected[ident]
  native[ident]=v;selected.append(ident)
 if selected:exports[p.name]={'sha256':sha(raw),'bytes':len(raw),'ids':selected}
assert set(native)==set(expected)
groups=[]
for ident in ids:
 owner=expressions[ident]
 assert owner['pos']=='조사'
 for sense in owner['senses']:
  for ordinal,group in enumerate(sense['examples']):
   groups.append({'id':f'familiar-geurae-{ident.split(":")[1]}-sense-{sense["id"]}-group-{ordinal+1}','source_entry_id':ident,'source_headword':owner['headword'],'sense_id':sense['id'],'group_ordinal':ordinal,'complete_original_group':group,'source_notes':owner['notes'],'sense_notes':sense['notes'],'definition':sense['definition']})
assert len(groups)==4
report={'state':'complete-original-sources-preserved-no-engine-judgments','expression_entries':expressions,'complete_imported_entries':expected,'original_native_entries':native,'complete_groups':groups,'complete_source_text':'\n'.join(line for group in groups for line in group['complete_original_group']),'original_exports':exports,'dictionary_metadata':metadata,'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'scope':'The unreviewed familiar 그래 particle retains all4 original complete groups, every sense/attachment note/trailing byte and complete manually proposed lexical homonyms. Source-listed ending followers are preserved separately. Original literal 구만 remains pending canonical/allomorph review; no rewritten source or required judgment. Native judgments and contextual review are not inferred from engine output. This preflight authors no candidate judgments and does not certify context or coverage.'}
(OUT/'full-native-preparation.json.gz').write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Preserved1particle original entry,4complete groups,',len(expected),'Native owners;',len(lexicals),'lexical homonyms',flush=True)
