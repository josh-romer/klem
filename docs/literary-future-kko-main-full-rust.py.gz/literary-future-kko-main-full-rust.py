"""Discover and run all Rust targets with bounded, disposable test executables."""
import datetime,gzip,hashlib,json,os,re,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');PROTO=ROOT
OUT=Path('/tmp/klem-literary-future-kko-main-full-rust.json');LOG=OUT.with_suffix('.log')
assert not OUT.exists() and not LOG.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
proposal=json.loads(gzip.decompress((ROOT/'docs/literary-future-kko-main-integration.json.gz').read_bytes()))
snapshot=proposal['snapshot_files'];assert len(snapshot)==947
assert all(sha((PROTO/n).read_bytes())==v['sha256'] for n,v in snapshot.items())
target=ROOT/'web/test-results/literary-question-go-prototype-cargo'
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TARGET_DIR=str(target))
metadata_command=['cargo','metadata','--locked','--offline','--no-deps','--format-version','1','--features','web']
metadata=json.loads(subprocess.check_output(metadata_command,cwd=PROTO,env=env))
ts=metadata['packages'][0]['targets'];assert len(ts)==229
initial={str(p.resolve()) for p in (target/'debug/deps').iterdir() if p.is_file() and p.stat().st_mode&0o111}
commands=[(['cargo','test','--locked','--offline','--features','web','-j2','--message-format=json',{'lib':'--lib','bin':'--bin','test':'--test'}[t['kind'][0]],*([t['name']] if t['kind']!=['lib'] else [])],t) for t in ts if t['test'] and t['kind'][0] in ['lib','bin','test']]
commands += [(['cargo','test','--locked','--offline','--features','web','-j2','--doc'],{'kind':['doctest'],'name':'klem'}), (['cargo','build','--locked','--offline','--features','web','-j2','--examples','--message-format=json'],{'kind':['examples'],'name':'all-six-examples'})]
r={'schema_version':1,'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'worktree':str(PROTO),'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'snapshot_files':snapshot,'metadata':metadata,'metadata_command':metadata_command,'batches':[],'deleted_test_executables':[],'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'scope':'Actual target discovery and sequential execution of every library/bin/integration test, doctests, and compilation of all six default examples. The947 inputs are frozen. Newly rebuilt test-only executables are hashed and removed after their completed batch; initial executables and all libraries/fixtures/stable captured CLIs are retained. No old target is skipped, and all failures remain in the log. No contextual or precision conclusion.'}
def save():OUT.write_text(json.dumps(r,indent=2)+'\n')
save()
with LOG.open('xb') as log:
 for i,(command,t) in enumerate(commands):
  start=log.tell();log.write((json.dumps({'batch':i,'target':t,'command':command})+'\n').encode());log.flush()
  job=subprocess.run(command,cwd=PROTO,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  log.write(job.stdout);log.flush()
  text=job.stdout.decode();counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
  result={'index':i,'target':t,'command':command,'exit_code':job.returncode,'log_start':start,'log_end':log.tell(),'stdout_sha256':sha(job.stdout),'tests':{'passed':sum(int(c[0]) for c in counts),'failed':sum(int(c[1]) for c in counts),'ignored':sum(int(c[2]) for c in counts),'batches':len(counts)}}
  r['batches'].append(result)
  for line in text.splitlines():
   if not line.startswith('{'):continue
   try:m=json.loads(line)
   except json.JSONDecodeError:continue
   executable=m.get('executable')
   if m.get('reason')!='compiler-artifact' or not executable or not m.get('profile',{}).get('test'):continue
   p=Path(executable).resolve()
   assert p.parent==(target/'debug/deps').resolve()
   if str(p) in initial or not p.exists():continue
   receipt={'target':t['name'],'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'completed_batch':i,'exit_code':job.returncode}
   p.unlink();r['deleted_test_executables'].append(receipt)
  save()
  if job.returncode or i%10==0:print(i+1,'/',len(commands),t['name'],'exit',job.returncode,result['tests'],flush=True)
r['tests']={k:sum(b['tests'][k] for b in r['batches']) for k in ['passed','failed','ignored','batches']}
r['commit_unchanged']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==r['commit']
r.update(state='passed' if all(b['exit_code']==0 for b in r['batches']) else 'failed',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),inputs_unchanged=all(sha((PROTO/n).read_bytes())==v['sha256'] for n,v in snapshot.items()),log_sha256=sha(LOG.read_bytes()))
save();print('All actual Rust targets:',r['state'],r['tests'],'inputs unchanged',r['inputs_unchanged'],flush=True)
assert r['inputs_unchanged'] and r['commit_unchanged'];raise SystemExit(0 if r['state']=='passed' else 1)
