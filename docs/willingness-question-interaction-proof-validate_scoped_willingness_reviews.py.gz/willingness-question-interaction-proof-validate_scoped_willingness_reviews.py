"""Validate appended reviews, unchanged histories and archived installed browser evidence."""
import datetime, hashlib, json, os, re, subprocess
from pathlib import Path
work = Path('/tmp/klem-willingness-interactions')
prep = Path(__file__).resolve().parent
out = prep / 'willingness-scoped-review-validation.json'
assert not out.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [work / p for p in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=work).decode().split('\0')[:-1]]
frozen = {str(p):sha(p) for p in files}; frozen[str(Path(__file__))]=sha(__file__)
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
index = hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=work)).hexdigest()
tools = [('expression_conjectural_ledger_audit',29), ('literary_question_geona_runtime',97), ('formal_volitional_expression_ledger_audit',8), ('conjectural_additive_ledger_audit',14), ('willingness_question_source_audit',14), ('willingness_question_interaction_browser_audit',13), ('willingness_question_installed_audit',44)]
r = dict(state='running', started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), pid=os.getpid(), head=head, index_sha256=index, frozen_inputs=frozen, producer={'text':Path(__file__).read_text(),'sha256':sha(__file__)},runs=[],scope='Exact 513 previous review fields and every 35673 earlier case preserved; only two bounded ending reviews and eight unchanged preauthored interactions appended. No independent Korean-language, contextual precision, full Nix or current-main certification.')
save = lambda: out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');save()
try:
 for name,count in tools:
  commands=[(['python3','tools/'+name+'.py']+(['--report','docs/literary-question-geona-packaged-cli-replay.json'] if name=='literary_question_geona_runtime' else []),None),(['python3','-m','unittest','discover','-s','tools','-p','test_'+name+'.py'],count)]
  for command,expected in commands:
   log=prep/('willingness-scoped-review-validation-'+str(len(r['runs']))+'.log');assert not log.exists()
   with log.open('xb') as stream: result=subprocess.run(command,cwd=work,stdout=stream,stderr=subprocess.STDOUT)
   raw=log.read_bytes();actual=None
   if expected is not None and result.returncode==0:
    parsed=re.findall(rb'Ran (\d+) tests? in ',raw); assert len(parsed)==1 and int(parsed[0])==expected and raw.rstrip().endswith(b'OK'), (command,expected,raw[-1200:])
    actual=expected
   r['runs'].append(dict(command=command,exit_code=result.returncode,controls=actual,log_sha256=sha(log)));save()
   assert result.returncode==0,(command,str(log))
   print('passed',name,'controls',actual,flush=True)
 r.update(state='passed',exit_code=0,controls=sum(n for _,n in tools),scoped_reviews=515,prior_reviews_retained=513)
except Exception as error:
 r.update(state='failed',error=str(error));raise
finally:
 r.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),inputs_unchanged=all(sha(p)==h for p,h in frozen.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==head,index_unchanged=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=work)).hexdigest()==index);save()
assert r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged']
print('passed all219 controls with unchanged complete source/proofs/HEAD/index',flush=True)
