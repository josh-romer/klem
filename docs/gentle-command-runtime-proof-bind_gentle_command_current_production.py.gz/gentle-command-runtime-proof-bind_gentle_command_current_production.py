"""Bind the current CLI to unchanged, previously source-frozen production bytes."""
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-gentle-command')
OUT = PREP / 'gentle-command-current-production-binding.json'
assert not OUT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
original_path = PREP / 'gentle-command-debug-binding.json'
full_path = PREP / 'gentle-command-merged-full-rust-retry2.json'
original = json.loads(original_path.read_bytes())
full = json.loads(full_path.read_bytes())
assert original['state'] == 'passed' and original['inputs_unchanged']
assert full['state'] in ['running', 'passed', 'failed']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert head == full['head']
production = {name: digest for name, digest in original['compiled_inputs'].items()
              if Path(name).relative_to(WORK).parts[0] != 'tests'}
assert production and all(sha(name) == digest == full['frozen_inputs'][name]
                          for name, digest in production.items())
assert all(sha(item['path']) == item['sha256'] for item in original['binaries'].values())
report = dict(state='passed', captured_head=head, production_inputs=production,
              binaries=original['binaries'],
              prior_source_frozen_binding_sha256=sha(original_path),
              full_rust_receipt=str(full_path), observed_full_rust_state=full['state'],
              inputs_unchanged=True,
              created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              producer=dict(text=Path(__file__).read_text(), sha256=sha(__file__)),
              scope='Actual CLI/server bytes identical to the original source-frozen compiled prototype. All production Rust/Cargo/example/tool/catalog inputs unchanged at the current clean checkpoint; only historical tests/audits/proofs advanced. Full Rust completion and current Nix/package/main validation remain separate.')
OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
print('Bound unchanged actual CLI/server bytes and', len(production), 'production inputs at', head)
