"""Replay each full novel stream with zero/8MiB caches against captured prototype bytes."""
import datetime,gzip,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');CLI=Path('/tmp/klem-bound-noun-spacing-cli');DB=ROOT/'data/dictionaries/krdict/krdict.db';BOOK=ROOT/'data/books/mujeong.txt';BROAD=Path('/tmp/klem-bound-noun-spacing-broad.json.gz');OUT=Path('/tmp/klem-bound-noun-spacing-cache-parity.json');assert not OUT.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
broad=json.load(gzip.open(BROAD,'rt'));frozen={str(p):sha(p) for p in [CLI,DB,BOOK,BROAD,Path(__file__)]}
r={'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_inputs':frozen,'streams':[],'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Isolated complete novel streams at zero/8MiB word/dictionary caches; output bytes must match full broad prototype capture. These are exact-output checks, not performance measurements or contextual validity judgments.'}
def save():OUT.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible']),('headword-spacing',['--dict-only','--suggest-spacing']),('compatible-spacing',['--dict-compatible','--suggest-spacing'])]:
  expected=next(c for c in broad['comparisons'] if c['mode']=='novel-'+mode)
  for cache in [0,8388608]:
   command=[str(CLI),'text',str(BOOK),'--dictionary',str(DB),*flags,'--cache-bytes',str(cache)];job=subprocess.Popen(command,stdout=subprocess.PIPE);h=hashlib.sha256();count=0
   try:
    for line in job.stdout:h.update(line);count+=1
    code=job.wait();assert code==0 and count==expected['records']==179112 and h.hexdigest()==expected['after_jsonl_sha256']
   finally:
    if job.poll() is None:job.terminate();job.wait()
   r['streams'].append({'mode':mode,'cache_bytes':cache,'command':command,'records':count,'stdout_sha256':h.hexdigest(),'exit_code':code,'matches_captured_prototype':True});save();print(mode,cache,count,'exact frames',flush=True)
 assert len(r['streams'])==10 and all(sha(p)==h for p,h in frozen.items())
 r.update(state='passed',exit_code=0,inputs_unchanged=True)
except BaseException as error:r.update(state='failed',error=repr(error));raise
finally:r['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
