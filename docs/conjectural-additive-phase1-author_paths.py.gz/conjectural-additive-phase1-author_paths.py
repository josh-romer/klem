"""Author typed source and allomorph judgments before implementation/probing."""
import hashlib
import json
from pathlib import Path

PREP = Path(__file__).resolve().parent
PROTO = PREP.parent / 'conjectural-additive-prototype'
SOURCE = PREP / 'complete-source-preparation.json'
OUT = PROTO / 'tests/fixtures/conjectural-additive-validity.json'
assert not OUT.exists()
packet = json.loads(SOURCE.read_text())
sources = {key: value['url'] for key, value in packet['source_entries'].items()}
cases = []

def judgment(lemmas, kinds, forms, verdict, owner, reason):
    return {'id': 'path', 'lemmas': lemmas, 'lemma_kinds': kinds,
            'morphemes': forms,
            'morpheme_kinds': ['ending' if form in ['어', '으려니와'] else 'prefinal' for form in forms],
            'required_rules': ['ending.conjectural_additive'], 'verdict': verdict,
            'source': owner, 'reason': reason}

for proposal in packet['independent_proposals']:
    kinds = ['predicate']
    forms = ['으려니와']
    if proposal['construction'] == 'adjectival-change-auxiliary':
        kinds = ['predicate', 'auxiliary']
        forms = ['어', '으려니와']
    elif proposal['construction'] == 'nominal-copula':
        kinds = ['nominal', 'copula']
    elif proposal['construction'] == 'verb-past-prefinal':
        forms = ['었', '으려니와']
    elif proposal['construction'] == 'verb-modal-prefinal':
        forms = ['겠', '으려니와']
    cases.append({'id': proposal['id'], 'surface': proposal['surface'], 'judgments': [
        judgment(proposal['proposed_lemmas'], kinds, forms, 'required',
                 proposal['source_entry_id'],
                 'Typed path independently authored from the complete original example and its attachment notes. Canonical 으려니와 preserves the two allomorph owners. The original sense/context remains separately identified; this candidate requirement does not adjudicate other analyses or select a dictionary sense.')
    ]})

# These are constructed attachment examples, explicitly separate from the 16
# original groups. The negatives concern the written allomorph of this path;
# another lexical head or hypothetical spelling class stays unjudged.
for number, (surface, head, forms, verdict, reason) in enumerate([
    ('가려니와', '가다', [], 'required', 'Vowel-final verb takes the short form.'),
    ('가으려니와', '가다', [], 'forbidden', 'Full 으 cannot follow this bare vowel-final stem.'),
    ('먹으려니와', '먹다', [], 'required', 'Non-ㄹ consonant stem takes the full form.'),
    ('먹려니와', '먹다', [], 'forbidden', 'Short form cannot follow the unchanged non-ㄹ consonant stem.'),
    ('살려니와', '살다', [], 'required', 'Lexical ㄹ remains before the short form.'),
    ('사려니와', '살다', [], 'forbidden', 'This family does not delete lexical ㄹ.'),
    ('살으려니와', '살다', [], 'forbidden', 'Full form cannot follow lexical ㄹ.'),
    ('들으려니와', '듣다', [], 'required', 'ㄷ-irregular stem is recovered before the full form.'),
    ('도우려니와', '돕다', [], 'required', 'ㅂ-irregular stem is recovered before the short form.'),
    ('아니려니와', '아니다', [], 'required', 'The negative copular adjective retains its vowel stem.'),
    ('가시려니와', '가다', ['시'], 'required', 'Canonical honorific 시 precedes the short form.'),
    ('먹으시려니와', '먹다', ['시'], 'required', 'Honorific 으시 has its own lexical boundary.'),
    ('가셨으려니와', '가다', ['시', '었'], 'required', 'Honorific and past are separately represented; past takes the full form.'),
    ('갔으려니와', '가다', ['었'], 'required', 'Past takes the full form.'),
    ('갔려니와', '가다', ['었'], 'forbidden', 'Past cannot take the short form at its consonantal boundary.'),
    ('가겠으려니와', '가다', ['겠'], 'required', 'Modal 겠 takes the full form.'),
    ('가겠려니와', '가다', ['겠'], 'forbidden', 'Modal 겠 cannot take the short form.'),
    ('가시으려니와', '가다', ['시'], 'forbidden', 'Honorific 시 cannot take the full form at its vowel boundary.'),
    ('좋으려니와', '좋다', [], 'required', 'Adjectives are explicitly licensed; this is not verb-only intention.'),
], 1):
    owner = 'krdict:86084' if '으려니와' in surface else 'krdict:86083'
    cases.append({'id': f'conjectural-additive-boundary-{number:02}', 'surface': surface,
                  'judgments': [judgment([head], ['predicate'], forms + ['으려니와'], verdict, owner, reason)]})

suite = {'schema_version': 1,
         'review_status': '16 original example targets and 19 constructed boundary cases independently typed before implementation. Other paths, contextual sense selection and independent Korean review remain open.',
         'sources': sources, 'cases': cases}
OUT.write_text(json.dumps(suite, ensure_ascii=False, indent=2) + '\n')
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
record = {'state': 'typed-judgments-authored-before-implementation-probe',
          'source_sha256': sha(SOURCE), 'fixture_sha256': sha(OUT),
          'original_cases': 16, 'constructed_cases': 19,
          'required': sum(j['verdict'] == 'required' for c in cases for j in c['judgments']),
          'forbidden': sum(j['verdict'] == 'forbidden' for c in cases for j in c['judgments']),
          'prototype_before': json.loads((PREP / 'prototype-preparation.json').read_text()),
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))}}
(PREP / 'typed-path-preparation.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(record['original_cases'], record['constructed_cases'], record['required'], record['forbidden'])
