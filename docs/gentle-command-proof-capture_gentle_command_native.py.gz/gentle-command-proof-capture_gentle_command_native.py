"""Preserve all original lexical homonyms and both -렴/-으렴 owners."""
import gzip
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

prep = Path(__file__).resolve().parent
root = Path('/home/josh/projects/klem')
packet_path = prep / 'gentle-command-original-source.json'
packet = json.loads(packet_path.read_bytes())
out = prep / 'gentle-command-original-native-closure.json.gz'
assert not out.exists()
sys.path.insert(0, str(root / 'tools'))
from native_lmf import entry, feature

sha = lambda raw: hashlib.sha256(raw).hexdigest()
db_path = root / '.direnv/dictionary-restoration/krdict.db'
heads = sorted({head for item in packet['items'] for head in item['independent_typed_proposal']['lemmas']} | {'묻다', '보다', '예쁘다', '있다', '학생', '이다', '학생답다', '걷다', '짓다'})
expected = dict(packet['owners'])
with sqlite3.connect(db_path.resolve().as_uri() + '?mode=ro', uri=True) as db:
    for head in heads:
        rows = list(db.execute('SELECT data FROM entries WHERE headword = ?', (head,)))
        assert rows, head
        for (raw,) in rows:
            owner = json.loads(raw)
            if owner['lexical_unit'] == '단어':
                expected[owner['id']] = owner
originals, exports = {}, {}
for source in sorted((root / '.direnv/dictionary-restoration/2026-09').glob('*.json')):
    raw = source.read_bytes()
    ids = []
    for value in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
        ident = 'krdict:' + value['val']
        if ident not in expected or feature(value, 'lexicalUnit') in {'관용구', '속담'}:
            continue
        assert ident not in originals and entry(value) == expected[ident], ident
        originals[ident] = value
        ids.append(ident)
    exports[source.name] = {'bytes': len(raw), 'sha256': sha(raw), 'ids': ids}
    print(source.name, len(ids), 'original owners', flush=True)
assert len(exports) == 11 and set(originals) == set(expected)
assert {ident: entry(value) for ident, value in originals.items()} == expected
for name, value in [
    ('gentle-command-native.json', {'LexicalResource': {'Lexicon': {'LexicalEntry': list(originals.values())}}}),
    ('gentle-command-native-entries.json', expected),
]:
    target = prep / name
    assert not target.exists()
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
receipt = {'state': 'complete-original-gentle-command-native-closure-preserved',
           'lexical_heads': heads, 'owners': len(originals),
           'source_authoring_sha256': sha(packet_path.read_bytes()),
           'original_database_sha256': sha(db_path.read_bytes()),
           'original_native_entries': originals, 'complete_imported_entries': expected,
           'original_exports': exports,
           'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())},
           'scope': 'Every word homonym for all independently selected source lexical targets and both gentle-command ending owners and separately named class/auxiliary probe heads. Complete Native fields retained and checked against the pinned dictionary. Reused idiom/proverb IDs are excluded. Rust import, runtime morphology, POS constraints, browser, contextual sense selection and independent Korean review remain separate.'}
out.write_bytes(gzip.compress((json.dumps(receipt, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
print(len(heads), 'lexical heads;', len(originals), 'complete original owners')
