"""Run an owned isolated server/browser and retain exact inputs, assets and shutdown."""
import datetime
import gzip
import hashlib
import json
import os
import signal
import socket
import subprocess
import time
import urllib.request
from pathlib import Path

ROOT=Path('/home/josh/projects/klem');PROTO=ROOT
prefix=Path('/tmp/klem-literary-future-kko-main-web')
output=Path(str(prefix)+'-runtime.json');assert not output.exists()
cli=Path('/tmp/klem-literary-future-kko-main-cli');server=Path('/tmp/klem-literary-future-kko-main-server')
browser=Path('/tmp/klem-literary-future-kko-main-browser.mjs')
chromium=Path('/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium')
database=ROOT/'data/dictionaries/krdict/krdict.db';assets=PROTO/'web/dist'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
proposal_path=ROOT/'docs/literary-future-kko-main-integration.json.gz'
proposal=json.loads(gzip.decompress(proposal_path.read_bytes()))
assert len(proposal['snapshot_files'])==947
assert all(sha(PROTO/name)==r['sha256'] for name,r in proposal['snapshot_files'].items())
frozen={str(p):sha(p) for p in [cli,server,browser,database,Path(__file__),proposal_path,*[ROOT/'docs'/('literary-future-kko-'+n+'.json.gz') for n in ['source-discovery','prototype-source-replay','spacing-owner-preparation']]]}
asset_snapshot={str(p.relative_to(assets)):sha(p) for p in assets.rglob('*') if p.is_file()}
with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
url=f'http://127.0.0.1:{port}'
command=[str(server),'--assets',str(assets),'--port',str(port),'--dictionary',str(database)]
report={'schema_version':1,'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'command':command,'url':url,'frozen_inputs':frozen,'source_snapshot':proposal['snapshot_files'],
        'asset_snapshot':asset_snapshot,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},
        'scope':'Owned actual integrated main server, configured full dictionary and actual SolidJS/Chromium browser. The947 code/frontend inputs are frozen; complete Rust/corpus/broad/history and production/package release validation remain separate pending work.'}
output.write_text(json.dumps(report,indent=2)+'\n')
job=None
try:
    with Path(str(prefix)+'-server.log').open('xb') as stream:
        job=subprocess.Popen(command,cwd=PROTO,stdout=stream,stderr=subprocess.STDOUT)
        report['server_pid']=job.pid
        deadline=time.monotonic()+30
        while True:
            assert job.poll() is None
            try:
                with urllib.request.urlopen(url,timeout=2) as response:html=response.read()
                break
            except OSError:
                assert time.monotonic()<deadline;time.sleep(.1)
        assert hashlib.sha256(html).hexdigest()==asset_snapshot['index.html']
        env=os.environ.copy();env.update(KLEM_WEB_URL=url,KLEM_BIN=str(cli),KLEM_CAPTURE_PREFIX=str(prefix),CHROMIUM_PATH=str(chromium))
        result=subprocess.run(['node',str(browser)],cwd=PROTO,env=env,check=True)
        report.update(state='passed',exit_code=0,browser_sha256=sha(str(prefix)+'-browser.json'))
except BaseException as error:
    report.update(state='failed',error=repr(error));raise
finally:
    if job is not None:
        if job.poll() is None:job.send_signal(signal.SIGINT)
        job.wait(timeout=15)
        report['server_exit_code']=job.returncode;report['server_stopped']=True
    report['inputs_unchanged']=all(sha(p)==expected for p,expected in frozen.items()) and all(sha(PROTO/name)==r['sha256'] for name,r in proposal['snapshot_files'].items())
    report['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    output.write_text(json.dumps(report,indent=2)+'\n')
assert report['inputs_unchanged'] and report['server_stopped'] and report['server_exit_code'] in [-2,130]
print('Actual integrated main browser passed; all947 source inputs unchanged and owned server stopped.',flush=True)
