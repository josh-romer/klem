"""Capture every original source occurrence, preserving the complete before output."""
import gzip
import hashlib
import json
import subprocess
import unicodedata
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = PREP.parents[1]
PROTO = PREP.parent / 'conjectural-additive-copula-prototype'
SOURCE = PREP / 'complete-source-preparation.json'
BEFORE = PREP / 'before-streams.json.gz'
FIXTURE = PROTO / 'tests/fixtures/conjectural-additive-validity.json'
CLI = Path('/tmp/klem-conjectural-additive-copula-target/debug/klem')
DB = ROOT / '.direnv/dictionary-restoration/krdict.db'
RESULT = PREP / 'copula-source-streams.json.gz'
assert not RESULT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
frozen = {str(p): sha(p) for p in [SOURCE, BEFORE, CLI, DB, Path(__file__), FIXTURE,
          PREP / 'typed-path-preparation.json', *[p for p in PROTO.rglob('*') if p.is_file()]]}
packet = json.loads(SOURCE.read_bytes())
suite = json.loads(FIXTURE.read_bytes())
cases = suite['cases'][:16]
baseline = json.loads(gzip.decompress(BEFORE.read_bytes()))
assert len(cases) == 16
assert sha(FIXTURE) == json.loads((PREP / 'typed-path-preparation.json').read_text())['fixture_sha256']
assert [c['id'] for c in cases] == [p['id'] for p in packet['independent_proposals']]
runs = []

def matches(path, judgment):
    return ([l['text'] for l in path['lemmas']] == judgment['lemmas']
            and [l['kind'] for l in path['lemmas']] == judgment['lemma_kinds']
            and [m['form'] for m in path['morphemes']] == judgment['morphemes']
            and [m['kind'] for m in path['morphemes']] == judgment['morpheme_kinds']
            and all(rule in path['rules'] for rule in judgment['required_rules']))

for family in ['complete-original-source', 'all-proposed-targets']:
    groups = ['\n'.join(g['complete_original_group']) for g in packet['complete_groups']] if family == 'complete-original-source' else [c['surface'] for c in cases]
    text = ('\n' if family == 'complete-original-source' else ' ').join(groups)
    for encoding in ['NFC', 'NFD']:
        original = unicodedata.normalize(encoding, text).encode()
        positions = []
        offset = 0
        for group, case in zip(groups, cases, strict=True):
            raw = unicodedata.normalize(encoding, group).encode()
            target = unicodedata.normalize(encoding, case['surface']).encode()
            assert raw.count(target) == 1
            positions.append(offset + raw.index(target))
            offset += len(raw) + 1
        for mode, flags in [('raw', []), ('headword', ['--dict-only']), ('compatible', ['--dict-compatible'])]:
            uncached = None
            for cache in [0, 4096]:
                command = [str(CLI), 'text', '-', '--dictionary', str(DB), *flags, '--cache-bytes', str(cache)]
                job = subprocess.run(command, input=original, capture_output=True, check=True, cwd=PROTO)
                assert not job.stderr
                rows = [json.loads(line) for line in job.stdout.splitlines()]
                old_run = next(r for r in baseline['runs'] if (r['family'], r['encoding'], r['mode'], r['cache_bytes']) == (family, encoding, mode, cache))
                old_rows = [json.loads(line) for line in old_run['jsonl'].splitlines()]
                assert len(rows) == len(old_rows)
                cursor = preserved = additions = 0
                for row, old in zip(rows, old_rows, strict=True):
                    assert all(row[key] == old[key] for key in ['surface', 'span', 'kind'])
                    assert row['span']['start'] == cursor
                    cursor = row['span']['end']
                    assert original[row['span']['start']:cursor].decode() == row['surface']
                    old_paths = (old.get('analysis') or {}).get('analyses', [])
                    new_paths = (row.get('analysis') or {}).get('analyses', [])
                    for path in old_paths:
                        assert path in new_paths, ('lost original path', row['surface'], path)
                        preserved += 1
                    for path in new_paths:
                        if path not in old_paths:
                            assert 'ending.conjectural_additive' in path['rules'], ('unrelated new path', row['surface'], path)
                            additions += 1
                assert cursor == len(original)
                observed = []
                for position, case in zip(positions, cases, strict=True):
                    index, row = next((i, r) for i, r in enumerate(rows) if r['span']['start'] == position)
                    assert row['surface'] == unicodedata.normalize(encoding, case['surface'])
                    paths = row['analysis']['analyses']
                    indices = [i for i, path in enumerate(paths) if matches(path, case['judgments'][0])]
                    assert indices, ('missing independently authored typed path', family, encoding, mode, cache, case['id'])
                    observed.append({'id': case['id'], 'record_index': index, 'typed_path_indices': indices})
                if uncached is None:
                    uncached = job.stdout
                else:
                    assert job.stdout == uncached
                runs.append({'family': family, 'encoding': encoding, 'mode': mode, 'cache_bytes': cache,
                             'command': command, 'exit_code': 0, 'input_sha256': hashlib.sha256(original).hexdigest(),
                             'jsonl': job.stdout.decode(), 'jsonl_sha256': hashlib.sha256(job.stdout).hexdigest(),
                             'records': len(rows), 'observed_typed_paths': observed, 'original_bytes_conserved': True,
                             'original_paths_preserved': preserved, 'new_family_paths': additions})
                print(family, encoding, mode, cache, len(rows), 'frames;', len(observed), 'typed occurrences;', preserved, 'old paths retained', flush=True)
assert len(runs) == 24 and all(sha(path) == digest for path, digest in frozen.items())
report = {'state': 'complete-after-observation-passed', 'runs': runs, 'frozen_inputs': frozen,
          'inputs_unchanged': True, 'typed_fixture': suite,
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
          'scope': 'Every original16target occurrence across24Unicode/filter/cache streams checked against independently authored exact lemma/morpheme kinds, forms and provenance. Complete contexts, original byte spans and every old candidate are preserved. Other candidates remain unjudged. Full distribution/browser/ledger/Nix/main/contextual and independent Korean review remain separate.'}
RESULT.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
