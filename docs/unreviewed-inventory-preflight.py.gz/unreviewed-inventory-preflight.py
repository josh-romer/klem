"""Preserve every unreviewed source group without assigning linguistic verdicts."""
import copy,gzip,hashlib,json,sqlite3,sys,subprocess,time
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from native_lmf import array,entry,feature,verify_native_lmf
from review_inventory import source_entry,digest
QUEUE=ROOT/'docs/inventory-review-queue.json';DB=ROOT/'data/dictionaries/krdict/krdict.db';CLI=Path('/nix/store/qm6ffk87sb4vl5r9zbcj77y3411i0mhj-klem-0.1.0/bin/klem');OUT=Path('/tmp/klem-unreviewed-inventory-preflight.json.gz');assert not OUT.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
queue=json.loads(QUEUE.read_bytes());rows=[r for r in queue['entries'] if r['review']['status']=='unreviewed'];assert len(rows)==237
con=sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True);native={}
for row in rows:
 source=row['source'];value=json.loads(con.execute('select data from entries where id=?',(source['id'],)).fetchone()[0]);assert source_entry(value)==source and digest(source)==row['source_sha256']
 for ident,raw in con.execute('select id,data from entries where headword=?',(source['headword'],)):native[ident]=json.loads(raw)
original={};exports={};numbers={i.split(':')[1] for i in native}
for p in sorted((ROOT/'data/dictionaries/krdict/json').glob('*.json')):
 exports[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
 for value in array(json.loads(p.read_bytes())['LexicalResource']['Lexicon'].get('LexicalEntry')):
  if value.get('val') not in numbers:continue
  projected=entry(value);ident=projected['id']
  if ident not in native:continue
  assert ident not in original and projected==native[ident];original[ident]=value
assert original.keys()==native.keys()
projection=copy.deepcopy(list(original.values()))
for value in projection:
 for sense in array(value.get('Sense')):sense['Equivalent']=[v for v in array(sense.get('Equivalent')) if feature(v,'language')=='영어']
lmf={'LexicalResource':{'Lexicon':{'LexicalEntry':projection}}};verify_native_lmf(lmf,native)
groups=[];text='';cursor=0
for row in rows:
 source=row['source'];value=native[source['id']]
 for sense in value['senses']:
  for ordinal,examples in enumerate(sense['examples'],1):
   complete='\n'.join(examples);start=cursor;text+=complete+'\n';cursor+=len((complete+'\n').encode())
   identity=f"unreviewed-source-{source['id'].split(':')[1]}-{sense['id']}-{ordinal}"
   groups.append({'id':identity,'entry_id':source['id'],'sense_id':sense['id'],'example_group':ordinal,'complete_original_examples':examples,'text':complete,'span':{'start':start,'end':cursor-1},'source_url':source['url'],'linguistic_verdict':'unjudged','attachment_verdict':'unjudged','independent_review':'pending'})
text_path=Path('/tmp/klem-unreviewed-inventory-source-text.txt');assert not text_path.exists();text_path.write_text(text);assert len(text.encode())==cursor
native_path=Path('/tmp/klem-unreviewed-inventory-source-closure.json.gz');assert not native_path.exists();closure={'state':'complete-unreviewed-source-and-same-head-closure','review_entries':rows,'complete_native_entries':native,'original_lmf':original,'english_projection':lmf,'groups':groups,'source_exports':exports,'queue_sha256':sha(QUEUE),'dictionary_sha256':sha(DB),'scope':'All237unreviewed grammar entries and all same-head homonyms; complete original Native and LMF groups, without clipping multiword/dialogue content. This is preparation only, not a manual disposition or correctness judgment.'};native_path.write_bytes(gzip.compress((json.dumps(closure,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
frozen={str(p):sha(p) for p in [QUEUE,DB,CLI,text_path,native_path,Path(__file__)]};captures=[];fingerprints={}
for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
 for cache in [0,4096]:
  command=[str(CLI),'text',str(text_path),'--dictionary',str(DB),*flags,'--cache-bytes',str(cache)];output=Path(f'/tmp/klem-unreviewed-inventory-{mode}-{cache}.jsonl.gz');assert not output.exists();h=hashlib.sha256();cursor=0;count=0;empty=[];ambiguous=0;started=time.time()
  job=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  with gzip.open(output,'wb',compresslevel=6) as stream:
   for line in job.stdout:
    h.update(line);stream.write(line);r=json.loads(line);count+=1;span=r['span'];assert span['start']==cursor and text.encode()[cursor:span['end']].decode()==r['surface'];cursor=span['end']
    if r.get('analysis'):
     analyses=r['analysis']['analyses'];ambiguous+=len(analyses)>1
     if not analyses:empty.append({'record':count,'surface':r['surface'],'span':span,'status':'unjudged-dictionary-filter-empty'})
  error=job.stderr.read().decode();code=job.wait();assert code==0 and not error and cursor==len(text.encode())
  fingerprint=h.hexdigest()
  if mode in fingerprints:assert fingerprints[mode]==fingerprint,'cache changed candidate output'
  else:fingerprints[mode]=fingerprint
  captures.append({'mode':mode,'cache_bytes':cache,'command':command,'exit_code':code,'records':count,'stdout_sha256':fingerprint,'artifact':str(output),'artifact_sha256':sha(output),'empty_filtered_records':empty,'ambiguous_records':ambiguous,'seconds':time.time()-started})
  print(mode,cache,count,'complete original source frames',len(empty),'filtered-empty words',flush=True)
assert all(sha(p)==v for p,v in frozen.items())
r={'state':'complete-unreviewed-source-runtime-preparation-passed','entries':237,'same_head_entries':len(native),'original_groups':len(groups),'captures':captures,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'full_coverage_complete':False,'scope':'All full original source groups and six actual current-installed CLI streams. Cache parity, exact source spans and Native/LMF closure verified. Empty dictionary-filter records and ambiguity are triage observations, never gold missing lemmas or contextual judgments. Root frozen; no inventory dispositions, corpus baselines, runtime code or review queue changed.'};OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Completed preparation:',len(rows),'entries',len(native),'same-head entries',len(groups),'whole original groups',flush=True)
