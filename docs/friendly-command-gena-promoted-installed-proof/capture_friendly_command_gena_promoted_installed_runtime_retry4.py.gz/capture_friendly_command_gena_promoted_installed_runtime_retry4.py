"""Replay complete original captures with the actual promoted Gena packages."""
import datetime,gzip,hashlib,json,os,re,subprocess,sys,threading
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=P.parents[1];W=ROOT/'.direnv/friendly-command-gena';B=Path('/var/tmp/klem-friendly-command-gena-nix-packages-build')
O=P/'friendly-command-gena-promoted-installed-runtime-retry1.json.gz';Q=P/'friendly-command-gena-promoted-installed-runtime-retry1-progress.json';assert not O.exists() and not Q.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(name):
 raw=(P/name).read_bytes();return json.loads(gzip.decompress(raw) if name.endswith('.gz') else raw)
pkg=load('friendly-command-gena-promoted-nix-packages.json');assert pkg['state']=='passed' and all(pkg[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==pkg['head'] and not subprocess.check_output(['git','status','--porcelain'],cwd=W)
gate=load('friendly-command-gena-promoted-completed-nix-output-audit.json');assert gate['state']=='passed' and sha((P/'friendly-command-gena-promoted-completed-nix-output-audit.json').read_bytes())==pkg['complete_gate_sha256']
assert len(json.loads((W/'tests/fixtures/validity.json').read_bytes())['cases'])==35764 and len(json.loads((W/'docs/inventory-reviews.json').read_bytes())['entries'])==520
assert all(sha((W/p).read_bytes())==d for p,d in pkg['frozen_inputs'].items())
paths={}
for output in pkg['outputs']:
 name=next(n for n in ['klem-web-assets','klem-corpus-adapter','klem-web','klem'] if Path(output).name.endswith('-'+n+'-0.1.0') or Path(output).name.endswith('-'+n));assert name not in paths;paths[name]=output
assert set(paths)=={'klem','klem-web-assets','klem-corpus-adapter','klem-web'}
cli=Path(paths['klem'])/'bin/klem';adapter=Path(paths['klem-corpus-adapter'])/'bin/klem-corpus-adapter';server=Path(paths['klem'])/'bin/klem-web';launcher=Path(paths['klem-web'])/'bin/klem-web';assets=Path(paths['klem-web-assets'])/'share/klem-web'
binding=load('friendly-command-gena-complete-runtime-binding.json');assert binding['state']=='passed';DB=ROOT/'.direnv/dictionary-restoration/krdict.db'
assert sha(DB.read_bytes())=='23d993696c55d0e54660e4a2b23dac7d68525fecb1fdc44341e1f2b3f75dead5', 'exact original restored dictionary bytes'
profiles={}
for name,attr,prefix in [('klem','klem',''),('klem-corpus-adapter','corpus-adapter',''),('klem-web-assets','web-assets','web/')]:
 source=Path(subprocess.check_output(['nix','eval','--offline','--raw','git+file://'+str(W)+'#packages.x86_64-linux.'+attr+'.src'],cwd=W,env=dict(os.environ,TMPDIR=str(B)),text=True).strip());files={}
 for p in source.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():
   name_in_source=str(p.relative_to(source));digest=sha(p.read_bytes());assert pkg['frozen_inputs'][prefix+name_in_source]==digest;files[name_in_source]=digest
 if name!='klem-web-assets':assert all(files[p]==d for p,d in binding['production_inputs'].items()),'complete44 currentcompiled inputs'
 profiles[name]=dict(package=paths[name],source=str(source),files=files)
assert len(profiles['klem-web-assets']['files'])==18 and str(server) in launcher.read_text() and str(assets) in launcher.read_text()
log=(P/'friendly-command-gena-promoted-release-rust.log').read_bytes();assert sha(log)==pkg['release_log_sha256'];plain_log=re.sub(rb'\x1b\[[0-?]*[ -/]*[@-~]',b'',log);batches=re.findall(rb'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',plain_log);totals={k:sum(int(x[i+1]) for x in batches) for i,k in enumerate(['passed','failed','ignored'])};assert totals==dict(passed=1200,failed=0,ignored=1) and len(batches)==255 and all(x[0]==b'ok' for x in batches)
names=['friendly-command-gena-promoted-nix-packages.json','friendly-command-gena-promoted-completed-nix-output-audit.json','friendly-command-gena-promoted-release-rust.log','friendly-command-gena-complete-runtime-binding.json','friendly-command-gena-runtime-records.json.gz','friendly-command-gena-cohorts.json.gz','friendly-command-gena-broad.json.gz','friendly-command-gena-corpora.json.gz','friendly-command-gena-extra-native.json.gz']
frozen={str(P/n):sha((P/n).read_bytes()) for n in names};frozen.update({str(p):sha(p.read_bytes()) for p in [cli,adapter,server,launcher,DB,Path(__file__)]});frozen.update({str(p):sha(p.read_bytes()) for p in assets.rglob('*') if p.is_file()})
for binary_path,digest in pkg['protected_binaries'].items():assert sha(Path(binary_path).read_bytes())==digest;frozen[binary_path]=digest
index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W));r=dict(state='running',captured_head=pkg['head'],index_sha256=index,profiles=profiles,packages=paths,binaries={name:dict(path=str(p),sha256=frozen[str(p)]) for name,p in [('klem',cli),('adapter',adapter),('server',server),('launcher',launcher)]},assets={str(p.relative_to(assets)):sha(p.read_bytes()) for p in assets.rglob('*') if p.is_file()},release_rust=dict(totals=totals,batches=len(batches)),frozen_inputs=frozen,source_runs=[],native_records=[],lookup_records=[],corpus_runs=[],broad_runs=[],cohort_runs=[],producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),scope='Actual currentGena4installed packages, complete44compiled/18frontend source profiles,1200releaseRust; all36CLI policies/all44uniquecomplete Native owners/69lookups/53502originalcohortwords/66570goldrows/1128312broadframes exactly match independently audited currentGena outputs. Shared35764cases520reviews exactly match the promoted package source snapshot; alloriginal35740cases519reviews preserved. No newly observed corpus/hypothetical/contextual judgments promoted. Complete currentNix prerequisite and actual shared24promotion already verified; installed browser/main/quiet/contextregister independent review remain separate.')
def save():
 Q.write_text(json.dumps({k:v for k,v in r.items() if k not in ['source_runs','native_records','lookup_records','corpus_runs','broad_runs','cohort_runs']},ensure_ascii=False,indent=2)+'\n');O.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False)+'\n').encode(),mtime=0))
prefix_manifest_path=P/'gena-installed-cohort-recorder-failure-originals.json';prefix_manifest=json.loads(prefix_manifest_path.read_bytes());prefix_row=prefix_manifest['files']['friendly-command-gena-promoted-installed-runtime.json.gz'];seed_packed=Path(prefix_row['path']).read_bytes();assert sha(seed_packed)==prefix_row['archive_sha256'];seed_raw=gzip.decompress(seed_packed);assert sha(seed_raw)==prefix_row['source_sha256'];seed=json.loads(gzip.decompress(seed_raw));assert seed['state']=='failed' and seed['captured_head']==r['captured_head'] and seed['profiles']==r['profiles'] and seed['binaries']==r['binaries'] and seed['packages']==r['packages'] and seed['assets']==r['assets']
assert len(seed['source_runs'])==36 and len(seed['native_records'])==44 and len(seed['lookup_records'])==69 and len(seed['command_attempts'])==149 and seed['cohort_runs']==seed['corpus_runs']==seed['broad_runs']==[]
expected_current=load('friendly-command-gena-runtime-records.json.gz')
for row,expected in zip(seed['source_runs'],expected_current['captures'],strict=True):assert row['original_capture']==expected and row['stdout']==expected['stdout'] and row['stderr']==expected['stderr'] and row['command']==[str(cli),*expected['command'][1:]]
for key in ['native_records','lookup_records']:
 for row in seed[key]:assert row['stdout']==row['original_capture']['stdout'] and row['stderr']==row['original_capture']['stderr'] and row['command']==[str(cli),*row['original_capture']['command'][1:]]
for attempt in seed['command_attempts']:
 assert attempt['exit_code']==0
 for stream in attempt['streams'].values():
  stream_path=Path(stream['path']);body=stream_path.read_bytes();assert sha(body)==stream['archive_sha256'];raw=gzip.decompress(body);assert sha(raw)==stream['source_sha256'] and len(raw)==stream['bytes'];frozen[str(stream_path)]=sha(body)
for key in ['source_runs','native_records','lookup_records','command_attempts']:r[key]=seed[key]
frozen[str(prefix_manifest_path)]=sha(prefix_manifest_path.read_bytes());frozen[str(Path(prefix_row['path']))]=sha(seed_packed)
r['reused_completed_prefix']=dict(failed_original_receipt_sha256=sha(seed_raw),original_archive_sha256=sha(seed_packed),actual_completed_commands=149,whole_streams=298,prefix_commands_replayed=0,failed_cohort_artifacts_retained=True)
save()
def call(command,text=None):
 job=subprocess.run(command,cwd=ROOT,input=text.encode() if text is not None else None,capture_output=True)
 attempts=r.setdefault('command_attempts',[]);number=len(attempts)
 captured={}
 for stream,raw in [('stdout',job.stdout),('stderr',job.stderr)]:
  destination=P/('friendly-command-gena-promoted-installed-command-'+str(number)+'-'+stream+'.gz');assert not destination.exists()
  packed=gzip.compress(raw,mtime=0);destination.write_bytes(packed);assert gzip.decompress(destination.read_bytes())==raw
  frozen[str(destination)]=sha(packed);captured[stream]=dict(path=str(destination),source_sha256=sha(raw),archive_sha256=sha(packed),bytes=len(raw))
 attempts.append(dict(command=command,exit_code=job.returncode,input=text,streams=captured));save()
 if job.returncode:
  r['failed_actual_command']=dict(command=command,exit_code=job.returncode,input=text,stdout=job.stdout.decode(),stderr=job.stderr.decode());save()
 assert job.returncode==0,(command,job.stderr.decode());return job.stdout.decode(),job.stderr.decode()
try:
 current=load('friendly-command-gena-runtime-records.json.gz')
 for capture in []:
  command=[str(cli),*capture['command'][1:]];out,err=call(command,capture['input']);assert out==capture['stdout'] and err==capture['stderr'];r['source_runs'].append(dict(original_capture=capture,command=command,exit_code=0,stdout=out,stderr=err,stdout_sha256=sha(out.encode())));save();print('CLI',capture['family'],capture['normalization'],capture['mode'],capture['cache_bytes'],flush=True)
 native=dict(current['native_entries']);extra=load('friendly-command-gena-extra-native.json.gz')
 for ident,row in extra['actual_complete_entry_responses'].items():
  if ident in native:assert row['stdout']==native[ident]['stdout'] and row['response']==native[ident]['response']
  else:native[ident]=row
 assert len(native)==44
 for ident,row in []:
  command=[str(cli),*row['command'][1:]];out,err=call(command);assert out==row['stdout'] and err==row['stderr'];r['native_records'].append(dict(id=ident,original_capture=row,command=command,exit_code=0,stdout=out,stderr=err,stdout_sha256=sha(out.encode())))
 for head,row in []:
  command=[str(cli),*row['command'][1:]];out,err=call(command);assert out==row['stdout'] and err==row['stderr'];r['lookup_records'].append(dict(headword=head,original_capture=row,command=command,exit_code=0,stdout=out,stderr=err,stdout_sha256=sha(out.encode())))
 save();print('Native',len(native),'completeowners;',len(r['lookup_records']),'actualheadqueries',flush=True)
 sys.path.insert(0,str(W/'tools'));from doeda_native_corpora import words_from_cli
 original_run=subprocess.run;cohort_lock=threading.RLock()
 def recorded_cohort(*args,**kwargs):
  with cohort_lock:
   command=[str(x) for x in (args[0] if args else kwargs['args'])];job=original_run(*args,**kwargs)
   assert command[0]==str(cli);attempts=r.setdefault('cohort_command_attempts',[]);number=len(attempts);supplied=kwargs.get('input');raw_input=supplied.encode() if isinstance(supplied,str) else supplied
   row=dict(command=command,exit_code=job.returncode,input=None if raw_input is None else raw_input.decode(),input_sha256=None if raw_input is None else sha(raw_input),streams={})
   for kind in ['stdout','stderr']:
    value=getattr(job,kind);assert value is not None;raw=value.encode() if isinstance(value,str) else value;dest=P/('friendly-command-gena-promoted-installed-cohort-retry1-command-'+str(number).zfill(4)+'-'+kind+'.gz');assert not dest.exists();packed=gzip.compress(raw,mtime=0);dest.write_bytes(packed);frozen[str(dest)]=sha(packed);row['streams'][kind]=dict(path=str(dest),source_sha256=sha(raw),archive_sha256=sha(packed),bytes=len(raw))
   attempts.append(row);save();return job
 for run in load('friendly-command-gena-cohorts.json.gz')['runs']:
  expected=run['captures'][1]['words'];subprocess.run=recorded_cohort
  try:actual=words_from_cli(cli,sorted(expected))
  finally:subprocess.run=original_run
  r['last_actual_cohort_words']=actual;assert actual==expected;r.pop('last_actual_cohort_words');r['cohort_runs'].append(dict(family=run['family'],surfaces=run['surfaces'],words=actual));save();print('Cohort',run['family'],run['surfaces'],flush=True)
 for run in load('friendly-command-gena-corpora.json.gz')['runs']:
  source=ROOT/run['source'];assert sha(source.read_bytes())==run['source_sha256'];frozen[str(source)]=run['source_sha256'];command=[str(adapter),*run['command'][1:]];out,err=call(command);assert out==run['jsonl'] and sha(out.encode())==run['stdout_sha256'];r['corpus_runs'].append(dict(original_capture=run,command=command,exit_code=0,stdout=out,stderr=err,stdout_sha256=sha(out.encode())));save();print('Gold',run['corpus'],run['partition'],run['rows'],flush=True)
 for run in load('friendly-command-gena-broad.json.gz')['runs']:
  source=Path(run['actual_source']);assert sha(source.read_bytes())==run['source_sha256'];frozen[str(source)]=run['source_sha256'];command=[str(cli),*run['commands'][1][1:]];out,err=call(command);assert sha(out.encode())==run['after_jsonl_sha256'];count=len(out.splitlines());assert count==run['records'];r['broad_runs'].append(dict(mode=run['mode'],command=command,exit_code=0,records=count,source_sha256=run['source_sha256'],stdout_sha256=sha(out.encode()),stderr=err,changed_frames=run['changed_frames']));save();print('Broad',run['mode'],count,flush=True)
 r.update(state='passed',inputs_unchanged=all(sha(Path(p).read_bytes())==d for p,d in frozen.items()),source_unchanged=all(sha((W/p).read_bytes())==d for p,d in pkg['frozen_inputs'].items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==pkg['head'],index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))==index,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());assert all(r[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged']);save();print('passed currentinstalled all36policies44Native69heads53502cohorts66570gold1128312broadframes',flush=True)
except Exception as e:r.update(state='failed',error=str(e));save();raise
