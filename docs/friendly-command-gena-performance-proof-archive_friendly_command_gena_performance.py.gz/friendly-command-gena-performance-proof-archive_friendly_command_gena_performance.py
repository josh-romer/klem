"""Archive full original timing prerequisites, the failed audit, and retry."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent/'friendly-command-gena'
DOCS = W/'docs'
OUT = P/'friendly-command-gena-performance-archive.json'
MANIFEST = DOCS/'friendly-command-gena-performance-proof-archive.json'
assert not OUT.exists() and not MANIFEST.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
retry = json.loads((P/'friendly-command-gena-performance-audit-validation-retry1.json').read_bytes())
assert retry['state'] == 'passed' and retry['tests_run'] == 23 and retry['failures'] == retry['errors'] == retry['skipped'] == 0
assert all(retry[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged'])
for path,digest in retry['frozen_inputs'].items():
    assert sha(Path(path).read_bytes()) == digest
failed = json.loads((P/'friendly-command-gena-performance-audit-first-failed-originals.json').read_bytes())
assert failed['actual_session_id'] == 38220 and failed['exit_code'] == 1 and failed['tests_run'] == 0
timing = json.loads((P/'friendly-command-gena-performance.json').read_bytes())
originals = {name: gzip.decompress(Path(row['path']).read_bytes()) for name,row in failed['originals'].items()}
for name,row in failed['originals'].items():
    assert sha(originals[name]) == row['sha256'] and sha(Path(row['path']).read_bytes()) == row['archive_sha256']
artifacts = {'first-failed-'+name:raw for name,raw in originals.items()}
artifacts.update({name:(P/name).read_bytes() for name in [
    'friendly-command-gena-performance.json','capture_friendly_command_gena_performance.py',
    'friendly-command-gena-performance-audit-first-failed-originals.json',
    'friendly-command-gena-performance-audit-validation-retry1.json',
    'friendly-command-gena-performance-audit-validation-retry1.log',
    'validate_friendly_command_gena_performance_audit_retry1.py',
    'friendly_command_gena_performance_audit.py','test_friendly_command_gena_performance_audit.py',
    Path(__file__).name]})
for path,digest in timing['frozen_inputs'].items():
    file = Path(path)
    if not file.is_absolute(): file = P.parents[1]/file
    if file.parent == P:
        raw = file.read_bytes()
        assert sha(raw) == digest
        assert file.name not in artifacts or artifacts[file.name] == raw
        artifacts[file.name] = raw
manifest = dict(schema_version=1,state='complete-original-timing-and-audit-evidence',
                capture_head=retry['head'],files={},
                original_timing_samples=80,original_full_novel_cache_streams=6,
                successful_independent_controls=23,
                failed_audit=dict(actual_session_id=38220,exit_code=1,tests_run=0),
                passed_audit=dict(actual_session_id=75816,exit_code=0,tests_run=23),
                scope='Full available original timing data, original frozen prerequisite receipts, complete before/after installed captures and original broad outputs, original failed live-file preflight and successful captured-fingerprint retry. Historical executables are not currently read by the successful audit. Host isolation, statistical equivalence, context/register precision, independent Korean review, shared/main promotion and checklist completion are not established.')
for name,raw in artifacts.items():
    filename='friendly-command-gena-performance-proof-'+name+'.gz'
    output=DOCS/filename
    assert not output.exists()
    packed=gzip.compress(raw,mtime=0)
    output.write_bytes(packed)
    assert gzip.decompress(output.read_bytes()) == raw
    manifest['files'][name]=dict(path=filename,source_sha256=sha(raw),archive_sha256=sha(packed),original_bytes=len(raw),archive_bytes=len(packed))
MANIFEST.write_text(json.dumps(manifest,indent=2)+'\n')
receipt=dict(state='passed',originals=len(artifacts),manifest=str(MANIFEST),manifest_sha256=sha(MANIFEST.read_bytes()),
             actual_first_failed_session_id=38220,actual_passed_retry_session_id=75816,
             producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
             scope=manifest['scope'],finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
OUT.write_text(json.dumps(receipt,indent=2)+'\n')
print('Archived',len(artifacts),'full original timing/audit/prerequisite artifacts:',receipt['manifest_sha256'],flush=True)
