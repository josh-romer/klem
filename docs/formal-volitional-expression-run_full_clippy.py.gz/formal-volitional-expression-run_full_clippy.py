"""Check every target with warnings denied on the unchanged complete expression branch."""
import datetime
import hashlib
import json
import os
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent / 'formal-volitional-expression-integration'
RECEIPT = OUT / 'full-clippy.json'
LOG = OUT / 'full-clippy.log'
assert not RECEIPT.exists() and not LOG.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
previous = json.loads((OUT / 'full-rust.json').read_bytes())
assert previous['state'] == 'passed' and previous['exit_code'] == 0 and previous['inputs_unchanged']
frozen = previous['frozen_source_files']
assert len(frozen) == 1679 and all(sha(ROOT / name) == digest for name, digest in frozen.items())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
index = subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT)
assert head.startswith('c28912c') and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
command = ['cargo', 'clippy', '--locked', '--offline', '--all-targets', '--features', 'web', '--', '-D', 'warnings']
env = {**os.environ, 'CARGO_TARGET_DIR': '/tmp/klem-formal-expression-target',
       'CARGO_BUILD_JOBS': '4', 'CARGO_PROFILE_DEV_DEBUG': '0',
       'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_INCREMENTAL': '0'}
receipt = {'state': 'running', 'command': command, 'head': head,
           'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'frozen_source_files': frozen,
           'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)},
           'scope': 'Actual complete all-targets/web-feature Clippy with warnings denied on the exact complete1153Rust-tested branch. All1679selected inputs and cleanHEAD/index remain frozen. No prior reference CLI is rebuilt; Nix package build uses immutable separate source/output paths. Installed/main/distribution/contextual review remain separate.'}
RECEIPT.write_text(json.dumps(receipt, indent=2) + '\n')
with LOG.open('xb') as stream:
    job = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
unchanged = all(sha(ROOT / name) == digest for name, digest in frozen.items())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == head
assert subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT) == index
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
receipt.update(state='passed' if job.returncode == 0 and unchanged else 'failed',
               exit_code=job.returncode, inputs_unchanged=unchanged,
               log_sha256=sha(LOG), finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
RECEIPT.write_text(json.dumps(receipt, indent=2) + '\n')
print({k: receipt[k] for k in ['state', 'exit_code', 'inputs_unchanged']}, flush=True)
assert unchanged
raise SystemExit(job.returncode)
