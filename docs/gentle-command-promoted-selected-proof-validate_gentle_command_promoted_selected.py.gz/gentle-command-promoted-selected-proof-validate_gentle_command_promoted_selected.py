"""Verify the promotion and its audits in the actual Git-backed Nix source."""
import datetime, hashlib, json, os, re, subprocess
from pathlib import Path
PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-gentle-command')
OUT = PREP/'gentle-command-promoted-selected.json'
LOG = PREP/'gentle-command-promoted-selected.log'
assert not OUT.exists() and not LOG.exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
sha = lambda p: hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
index = hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK)).hexdigest()
names = subprocess.check_output(['git','ls-files','-z'],cwd=WORK).decode().split('\0')[:-1]
frozen = {name:sha(WORK/name) for name in names}
SOURCE = Path(subprocess.check_output(['nix','eval','--offline','--raw','git+file://'+str(WORK)+'#checks.x86_64-linux.inventory-review.src'],cwd=WORK,text=True).strip())
selected = {str(p.relative_to(SOURCE)):sha(p) for p in SOURCE.rglob('*') if p.is_file()}
assert all(frozen[name] == digest for name,digest in selected.items())
for name in ['tools/gentle_command_ledger_audit.py','tools/test_gentle_command_ledger_audit.py',
             'tools/gentle_command_installed_audit.py','tools/test_gentle_command_installed_audit.py',
             'docs/gentle-command-parent-validity.json.gz','docs/gentle-command-parent-inventory-reviews.json.gz',
             'docs/gentle-command-scoped-reviews.json','tests/fixtures/validity.json']:
    assert name in selected
commands=[]
for module in ['gentle_command_ledger','expression_conjectural_ledger','gentle_command_installed']:
    commands += [['python3','tools/'+module+'_audit.py'],['python3','-m','unittest','discover','-s','tools','-p','test_'+module+'_audit.py']]
commands += [['python3','tools/review_inventory.py','--verify'],['python3','-m','unittest','discover','-s','tools','-p','test_review_inventory.py']]
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,selected_source=str(SOURCE),source_files=selected,results=[],
       producer=dict(text=Path(__file__).read_text(),sha256=sha(__file__)),
       scope='Actual Git-backed Nix selected-source complete current35704-case/517review append and original installed proof; 97 corruption controls. This source-selection execution is not the full inventory or newly built four-package/main proof.')
save=lambda:OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
with LOG.open('xb') as stream:
    for command in commands:
        job=subprocess.run(command,cwd=SOURCE,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        stream.write(job.stdout);stream.flush()
        controls=sum(map(int,re.findall(r'Ran (\d+) tests? in',job.stdout.decode())))
        r['results'].append(dict(command=command,exit_code=job.returncode,output=job.stdout.decode(),controls=controls));save()
        print(command[-1],job.returncode,controls,flush=True)
        if job.returncode:break
r.update(inputs_unchanged=all(sha(WORK/name)==digest for name,digest in frozen.items()),
         selected_unchanged=all(sha(SOURCE/name)==digest for name,digest in selected.items()),
         head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,
         index_unchanged=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK)).hexdigest()==index,
         controls=sum(row['controls'] for row in r['results']),log_sha256=sha(LOG),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
r['state']='passed' if len(r['results'])==len(commands) and all(row['exit_code']==0 for row in r['results']) and r['controls']==97 and r['inputs_unchanged'] and r['selected_unchanged'] and r['head_unchanged'] and r['index_unchanged'] else 'failed'
save();print(r['state'],r['controls'],'controls;',len(selected),'selected files',flush=True)
raise SystemExit(0 if r['state']=='passed' else 1)
