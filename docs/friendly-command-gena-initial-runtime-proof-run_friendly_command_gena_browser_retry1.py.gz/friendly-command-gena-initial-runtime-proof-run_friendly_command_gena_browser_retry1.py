import datetime,hashlib,json,os,re,signal,subprocess,urllib.request
from pathlib import Path
PREP=Path(__file__).resolve().parent;WORK=Path('/home/josh/projects/klem/.direnv/friendly-command-gena');TARGET=Path('/home/josh/projects/klem/.direnv/friendly-command-gena-target')
OUT=PREP/'friendly-command-gena-browser-runtime-retry1.json';LOG=PREP/'friendly-command-gena-browser-runtime-retry1.log';PREFIX=PREP/'friendly-command-gena';DRIVER=PREP/'friendly-command-gena-browser.mjs'
DB=Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db');CHROMIUM=Path('/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium')
assert not OUT.exists() and not LOG.exists() and not Path(str(PREFIX)+'-browser.json').exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
runtime=json.loads((PREP/'friendly-command-gena-runtime.json').read_bytes());build=json.loads((PREP/'friendly-command-gena-frontend-build.json').read_bytes());assert runtime['state']=='passed' and build['state']=='passed';assert all(sha(WORK/n)==digest for n,digest in runtime['frozen_inputs'].items())
assets=WORK/'web/dist';assert {str(p.relative_to(assets)):sha(p) for p in assets.rglob('*') if p.is_file()}==build['assets']
files=[DB,CHROMIUM,DRIVER,Path(__file__),TARGET/'debug/klem',TARGET/'debug/klem-web',WORK/'tests/fixtures/friendly-command-gena-validity.json',WORK/'tests/fixtures/friendly-command-gena-native-entries.json',WORK/'web/src/grammar-labels.json']+[p for p in assets.rglob('*') if p.is_file()];frozen={str(p):sha(p) for p in files}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip();index=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK)).hexdigest()
command=[str(TARGET/'debug/klem-web'),'--port','0','--assets',str(assets),'--dictionary',str(DB)]
temp=Path('/home/josh/projects/klem/.direnv/gc');temp.mkdir(exist_ok=True)
r=dict(state='running',command=command,head=head,index_sha256=index,frozen_inputs=frozen,source_inputs=runtime['frozen_inputs'],producer=dict(text=Path(__file__).read_text(),sha256=sha(__file__)),driver=dict(text=DRIVER.read_text(),sha256=sha(DRIVER)),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Current isolated -게나 actual builtSolidJS frontend/Rustbackend/CLI/full imported dictionary. All24preauthored cases,144 Unicode/filter policy decisions,102required diagrams42forbidden exclusions, sixexactCLIexports and31completeNative APIrecords. Source/head/index/binaries/assets pinned. InstalledNix,fullbroad/gold/novel,promotion/main/quiet/context/register/independent review remain separate.')
def save():OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save();job=subprocess.Popen(command,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
try:
 line=job.stderr.readline();match=re.search(r'http://127\.0\.0\.1:\d+',line);assert match,line;url=match.group();r.update(url=url,owned_server_pid=job.pid)
 with urllib.request.urlopen(url+'/api/status',timeout=10) as response:r['status']=json.load(response)
 with urllib.request.urlopen(url,timeout=10) as response:html=response.read();assert html==(assets/'index.html').read_bytes()
 r['served_assets']=[]
 for path in re.findall(r'(?:src|href)="(/assets/[^"?#]+\.(?:js|css))"',html.decode()):
  with urllib.request.urlopen(url+path,timeout=10) as response:raw=response.read();assert raw==(assets/path.lstrip('/')).read_bytes()
  r['served_assets'].append(dict(path=path,sha256=hashlib.sha256(raw).hexdigest()))
 env=dict(os.environ,KLEM_WEB_URL=url,KLEM_BIN=str(TARGET/'debug/klem'),KLEM_CAPTURE_PREFIX=str(PREFIX),CHROMIUM_PATH=str(CHROMIUM),TMPDIR=str(temp))
 with LOG.open('xb') as stream:run=subprocess.run(['node',str(DRIVER)],env=env,stdout=stream,stderr=subprocess.STDOUT)
 r.update(exit_code=run.returncode,log_sha256=sha(LOG));assert run.returncode==0
 result=json.loads(Path(str(PREFIX)+'-browser.json').read_bytes());assert result['state']=='source-bound-friendly-command-gena-browser-passed' and not result['errors'];assert len(result['policyDecisions'])==144 and len(result['exports'])==6 and len(result['nativeEntries'])==31;assert sum(d.get('verdict')=='forbidden' for d in result['policyDecisions'])==42;assert len(result['diagrams'])==102
 r.update(state='passed',decisions=144,diagrams=102,exports=6,native_entries=31,result_sha256=sha(Path(str(PREFIX)+'-browser.json')))
except Exception as error:
 r.update(state='failed',error=str(error));raise
finally:
 if job.poll() is None:job.send_signal(signal.SIGINT)
 r.update(server_exit_code=job.wait(timeout=20),server_stopped=True,inputs_unchanged=all(sha(p)==v for p,v in frozen.items()),source_unchanged=all(sha(WORK/n)==v for n,v in runtime['frozen_inputs'].items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,index_unchanged=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK)).hexdigest()==index,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
assert r['state']=='passed' and all(r[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged']) and r['server_exit_code'] in [0,-signal.SIGINT]
print('Passed currentSolid24cases/144policies/102diagrams/6exports/31Native; ownedserverstopped.',flush=True)
