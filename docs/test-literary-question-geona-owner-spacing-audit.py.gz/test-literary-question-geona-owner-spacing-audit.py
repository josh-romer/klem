"""Reject marker/role conflation, Native loss and invented spacing coverage."""
import copy,importlib.util,unittest
spec=importlib.util.spec_from_file_location('audit','/tmp/klem-literary-question-geona-owner-spacing-audit.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);R=a.inputs()
class Controls(unittest.TestCase):
 def reject(self,index,fn):
  reports=list(R);reports[index]=copy.deepcopy(reports[index]);fn(reports[index])
  with self.assertRaises((AssertionError,KeyError,ValueError,TypeError,StopIteration)):a.inspect(*reports)
 def test_actual_full_owner_and_spacing_capture(self):self.assertEqual(a.inspect(*R)['complete_native_entries'],241)
 def test_auxiliary_role_is_not_lexical(self):self.reject(0,lambda r:next(c for c in r['cases'] if c['id'].endswith('aux-result-auxiliary-role')).__setitem__('expected_status','compatible'))
 def test_direct_honorific_copula_stays_conditional(self):self.reject(0,lambda r:next(c for c in r['cases'] if c['proposal']=='conditional').__setitem__('proposal','required'))
 def test_own_past_marker_case_is_preserved(self):self.reject(0,lambda r:r['observations'].pop())
 def test_source_kind_is_not_collapsed(self):self.reject(0,lambda r:next(c for c in r['cases'] if c['id'].endswith('aux-result-lexical-role'))['lemma_kinds'].__setitem__(1,'auxiliary'))
 def test_original_spacing_offsets(self):self.reject(1,lambda r:r['observations'][0]['hypothesis']['inserted_at'].__setitem__(0,0))
 def test_missing_auxiliary_template_is_not_coverage(self):self.reject(1,lambda r:r['cases'][2].__setitem__('expected_split_present',True))
 def test_unicode_spacing_modes(self):self.reject(1,lambda r:r['runs'].pop())
 def test_native_definitions(self):self.reject(2,lambda r:r['complete_native_entries']['krdict:80970']['senses'][0].__setitem__('definition','invented'))
 def test_every_original_source_owner(self):self.reject(2,lambda r:r['matched_owner_ids'].pop())
if __name__=='__main__':unittest.main()
