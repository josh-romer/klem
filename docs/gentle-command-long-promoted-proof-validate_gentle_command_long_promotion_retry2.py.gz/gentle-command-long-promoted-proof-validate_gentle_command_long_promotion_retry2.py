import hashlib,json,os,re,subprocess,time
from pathlib import Path
ROOT=Path('/tmp/klem-gentle-command-long-promotion');PREP=Path(__file__).resolve().parent
OUT=PREP/'gentle-command-long-promotion-validation-retry2.json';LOG=PREP/'gentle-command-long-promotion-validation-retry2.log'
assert not OUT.exists() and not LOG.exists() and not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT).decode().strip()
names=git('ls-files').splitlines();frozen={n:sha((ROOT/n).read_bytes()) for n in names};head=git('rev-parse','HEAD');index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT))
selected=['gentle_command','gentle_command_long','validity']
test_args=[item for name in selected for item in ['--test',name]]
commands=[['cargo','fmt','--all','--','--check'],['cargo','test','--locked','--offline','--features','web',*test_args],['cargo','clippy','--locked','--offline','--features','web',*test_args,'--','-D','warnings'],['python3','-m','unittest','discover','-s','tools','-p','test_expression_conjectural_ledger_audit.py'],['python3','-m','unittest','discover','-s','tools','-p','test_gentle_command_ledger_audit.py'],['python3','-m','unittest','discover','-s','tools','-p','test_gentle_command_long_installed_audit.py'],['python3','-m','unittest','discover','-s','tools','-p','test_gentle_command_long_ledger_audit.py'],['python3','-m','unittest','discover','-s','tools','-p','test_literary_question_geona_runtime.py'],['python3','-m','unittest','discover','-s','tools','-p','test_gentle_command_long_source_audit.py'],['python3','tools/review_inventory.py','--verify'],['git','diff','--check']]
env=dict(os.environ,CARGO_TARGET_DIR='/home/josh/projects/klem/.direnv/main-willingness-integration-target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4')
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),results=[],started_at=time.time(),scope='Actual isolated longsharedpromotion35740cases519reviews: all35704parentcasebytes/source declarations/517orderedreviews retained; onlyexact25preauthored8honestly postruntimeNovel3correctderived cases andtwobounded endingownerreviews appended.19Rust gentle/long/fullsharedledger suites,fmt/focusedClippy,fullcurrent and historical source/ledger/installed-browser controls, complete715queue. All44production inputs remainexactcurrentMain/currentLonginstalled. RootMain and originalLong four-checkNixgates separate andsourcefrozen. Promotion Git-backedselected/fullNix,mainmerge,quietperformance/contextualindependent review and196unreviewed owners/fullchecklist remainseparate.')
def save():OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
with LOG.open('w') as stream:
 for command in commands:
  job=subprocess.run(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);stream.write('COMMAND '+json.dumps(command)+'\n'+job.stdout);stream.flush();r['results'].append(dict(command=command,exit_code=job.returncode,output=job.stdout));save()
  if job.returncode:break
r.update(inputs_unchanged=all(sha((ROOT/n).read_bytes())==h for n,h in frozen.items()),head_unchanged=git('rev-parse','HEAD')==head,index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT))==index,log_sha256=sha(LOG.read_bytes()),finished_at=time.time())
batches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',LOG.read_text());r['rust_totals']={k:sum(int(b[i+1]) for b in batches) for i,k in enumerate(['passed','failed','ignored'])};r['rust_batches']=len(batches)
r['state']='passed' if len(r['results'])==len(commands) and all(s['exit_code']==0 for s in r['results']) and all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged']) else 'failed';save();print(json.dumps({k:r[k] for k in ['state','rust_totals','rust_batches','inputs_unchanged','head_unchanged','index_unchanged']}),flush=True);raise SystemExit(0 if r['state']=='passed' else 1)
