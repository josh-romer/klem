"""Run the four new offline audits from the actual evaluated Nix inventory source."""
import datetime,gzip,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');PATH=Path('/tmp/klem-literary-future-kko-inventory-source-path.txt')
SOURCE=Path(PATH.read_text());assert str(SOURCE).startswith('/nix/store/') and SOURCE.is_dir()
OUT=Path('/tmp/klem-literary-future-kko-nix-source-audits.json');LOG=OUT.with_suffix('.log');assert not OUT.exists() and not LOG.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
helpers=['tools/literary_future_kko_audit.py','tools/test_literary_future_kko_audit.py','tools/literary_future_kko_preservation.py','tools/test_literary_future_kko_preservation.py']
for n in helpers:assert sha(ROOT/n)==sha(SOURCE/n)
commands=[[sys.executable,'tools/literary_future_kko_audit.py'],[sys.executable,'-m','unittest','discover','-s','tools','-p','test_literary_future_kko_audit.py'],[sys.executable,'tools/literary_future_kko_preservation.py'],[sys.executable,'-m','unittest','discover','-s','tools','-p','test_literary_future_kko_preservation.py']]
r={'schema_version':1,'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'nix_inventory_source':str(SOURCE),'evaluation_expression':Path('/tmp/klem-literary-future-kko-inventory-source.nix').read_text(),'flake_sha256':sha(ROOT/'flake.nix'),'helper_hashes':{n:sha(SOURCE/n) for n in helpers},'commands':commands,'results':[],'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'The actual updated flake inventory source is evaluated with the locked nixpkgs revision and both new audits and all31 corruption controls run from its immutable source. This is source-closure validation of the four new commands, not a complete inventory derivation build or an all-package Nix gate. Production939 inputs are still unchanged.'}
OUT.write_text(json.dumps(r,indent=2)+'\n')
with LOG.open('xb') as log:
 for command in commands:
  p=subprocess.run(command,cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT)
  r['results'].append({'command':command,'exit_code':p.returncode});assert p.returncode==0,command
r.update(state='passed',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=sha(LOG));OUT.write_text(json.dumps(r,indent=2)+'\n');print('Actual Nix source:both new audits and31 controls passed.',flush=True)
