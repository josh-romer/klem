"""Build the isolated feature with unchanged actual flake package definitions."""
import datetime,hashlib,json,os,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');P=Path('/tmp/klem-possessive-bound-noun-final-prototype');PREFIX=Path('/tmp/klem-possessive-bound-noun-nix-retry1');OUT=Path(str(PREFIX)+'.json');LOG=Path(str(PREFIX)+'.log');assert not OUT.exists() and not LOG.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=subprocess.check_output(['nix','eval','--impure','--offline','--raw','--file','/tmp/klem-possessive-bound-noun-nix-packages.nix','klem.src'],text=True).strip();assert source.startswith('/nix/store/') and source.endswith('-source')
files={}
for p in Path(source).rglob('*'):
 assert not p.is_symlink()
 if not p.is_file():continue
 name=str(p.relative_to(source));assert p.read_bytes()==(P/name).read_bytes(),name
 files[name]={'bytes':p.stat().st_size,'sha256':sha(p)}
assert len(files)==960
expr=Path('/tmp/klem-possessive-bound-noun-nix-packages.nix');frozen={str(p):sha(p) for p in [ROOT/'flake.nix',expr,Path(__file__)]}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();index=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT)).hexdigest();assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
build=Path('/tmp/klem-possessive-bound-noun-nix-build-retry1');build.mkdir(exist_ok=True)
command=['nix','build','--impure','--offline','--file',str(expr),'--option','build-dir',str(build),'--cores','4','--max-jobs','1','--no-link','--print-out-paths','-L','klem','web-assets','corpus-adapter']
r={'schema_version':1,'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'command':command,'source_profile':{'source':source,'files':files},'root_head':head,'root_index_sha256':index,'frozen_inputs':frozen,'evaluation_expression':expr.read_text(),'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Actual isolated flake CLI/server/frontend/adapter package build, with only Rust source overridden to the960-file prototype. Root flake definitions, dependencies, features and checks unchanged. This is not current-Root integration or its combined inventory gate, and does not certify wider linguistic/contextual correctness.'}
def save():OUT.write_text(json.dumps(r,indent=2)+'\n')
save();env=os.environ.copy();env['TMPDIR']=str(build)
with LOG.open('xb') as log:job=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
r.update(state='passed' if job.returncode==0 else 'failed',exit_code=job.returncode,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_unchanged=all(sha(P/n)==v['sha256'] for n,v in files.items()),inputs_unchanged=all(sha(p)==v for p,v in frozen.items()),root_head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==head,root_index_unchanged=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT)).hexdigest()==index,log_sha256=sha(LOG),outputs=[line for line in LOG.read_text().splitlines() if line.startswith('/nix/store/')])
save();print('Isolated actual flake packages:',r['state'],'exit',job.returncode,'source files:',len(files),'Root HEAD/index unchanged:',r['root_head_unchanged'],r['root_index_unchanged'],flush=True)
assert r['source_unchanged'] and r['inputs_unchanged'] and r['root_head_unchanged'] and r['root_index_unchanged']
if job.returncode==0:assert len(r['outputs'])==3
raise SystemExit(job.returncode)
