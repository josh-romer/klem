"""Compare every complete current policy output with the immutable installed baseline."""
import datetime,gzip,hashlib,json,subprocess,unicodedata
from pathlib import Path
PREP=Path(__file__).resolve().parent
WORK=Path('/home/josh/projects/klem/.direnv/friendly-command-gena')
CLI=Path('/home/josh/projects/klem/.direnv/friendly-command-gena-target/debug/klem')
DB=Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db')
OUT=PREP/'friendly-command-gena-runtime.json';CAP=PREP/'friendly-command-gena-runtime-records.json.gz';LOG=PREP/'friendly-command-gena-runtime.log'
assert not OUT.exists() and not CAP.exists() and not LOG.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
baseline_path=PREP/'friendly-command-gena-baseline.json';baseline=json.loads(baseline_path.read_bytes());assert baseline['state']=='passed'
old_capture_path=PREP/baseline['capture_path'];assert sha(old_capture_path.read_bytes())==baseline['capture_sha256']
old=json.loads(gzip.decompress(old_capture_path.read_bytes()));suite=json.loads((WORK/'tests/fixtures/friendly-command-gena-validity.json').read_bytes())
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=WORK).decode().split('\0')[:-1];frozen={n:sha((WORK/n).read_bytes()) for n in names}
external={str(p):sha(p.read_bytes()) for p in [CLI,DB,baseline_path,old_capture_path]}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip();index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK))
def typed(a,j):
 return [l['text'] for l in a['lemmas']]==j['lemmas'] and [l['kind'] for l in a['lemmas']]==j['lemma_kinds'] and [m['form'] for m in a['morphemes']]==j['morphemes'] and [m['kind'] for m in a['morphemes']]==j['morpheme_kinds'] and all(r in a['rules'] for r in j['required_rules'])
r=dict(state='running',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),frozen_inputs=frozen,external_inputs=external,head=head,index_sha256=index,producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),scope='Actual current36 full original/24private/unjudged policies compared against immutable installed baseline. Original hypotheses/order, each old own-entry annotation/conflict and complete31Native responses retained. Required/forbidden preauthored exact typed paths checked in all applicable modes, Unicode/cache/span parity. No new lexical or contextual judgments and no shared promotion. Full broad/gold/novel/browser/installed/Nix/main/performance/independent review remain separate.')
def save():OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save();captures=[];native={};old_paths=0;additions=0;required_checked=0;forbidden_checked=0
with LOG.open('x') as log:
 for before in old['captures']:
  command=[str(CLI),*before['command'][1:]];run=subprocess.run(command,input=before['input'].encode(),capture_output=True);assert run.returncode==0,(command,run.stderr.decode())
  frames=[json.loads(line) for line in run.stdout.splitlines()];assert len(frames)==len(before['frames']);cursor=0;new_paths=[];observations=[]
  for previous,current in zip(before['frames'],frames,strict=True):
   assert {k:previous[k] for k in ['surface','span','kind']}=={k:current[k] for k in ['surface','span','kind']};assert current['span']['start']==cursor;cursor=current['span']['end'];assert before['input'].encode()[current['span']['start']:cursor].decode()==current['surface']
   if current['kind']!='word':assert current==previous;continue
   aa=previous['analysis']['analyses'];bb=current['analysis']['analyses'];assert [a for a in bb if a in aa]==aa,('old path/order lost',current['surface']);old_paths+=len(aa)
   assert current['analysis']['normalized']==previous['analysis']['normalized']
   for ordinal,a in enumerate(aa):
    new_index=bb.index(a);assert previous['dictionary']['readings'][ordinal]==current['dictionary']['readings'][new_index],('old own-entry assessment changed',current['surface'],a)
   for matched in previous['dictionary']['lemmas']:assert matched in current['dictionary']['lemmas'],('old native owners changed',current['surface'])
   for a in bb:
    if a not in aa:
     additions+=1;new_paths.append(dict(surface=current['surface'],span=current['span'],analysis=a,assessment=current['dictionary']['readings'][bb.index(a)]));assert 'ending.friendly_command.gena' in a['rules'],'only declared ending adds paths'
   for case in suite['cases']:
    if unicodedata.normalize('NFC',current['surface'])!=case['surface']:continue
    j=case['judgments'][0];found=[a for a in bb if typed(a,j)]
    if j['verdict']=='required':assert found,('required path missing',before['mode'],case['id']);required_checked+=1
    else:assert not found,('forbidden path emitted',case['id']);forbidden_checked+=1
    observations.append(dict(case_id=case['id'],span=current['span'],verdict=j['verdict'],present=bool(found)))
  assert cursor==len(before['input'].encode())
  capture=dict(family=before['family'],normalization=before['normalization'],mode=before['mode'],cache_bytes=before['cache_bytes'],input=before['input'],command=command,exit_code=0,stdout=run.stdout.decode(),stderr=run.stderr.decode(),frames=frames,observations=observations,new_paths=new_paths)
  captures.append(capture);log.write(json.dumps(dict(family=capture['family'],normalization=capture['normalization'],mode=capture['mode'],cache_bytes=capture['cache_bytes'],frames=len(frames),additions=len(new_paths)),ensure_ascii=False)+'\n');log.flush()
  print('Compared',capture['family'],capture['normalization'],capture['mode'],capture['cache_bytes'],'additions',len(new_paths),flush=True)
 for ident,expected in old['native_entries'].items():
  command=[str(CLI),*expected['command'][1:]];run=subprocess.run(command,capture_output=True);assert run.returncode==0;assert run.stdout.decode()==expected['stdout'] and run.stderr.decode()==expected['stderr'];native[ident]=dict(command=command,stdout=run.stdout.decode(),stderr=run.stderr.decode(),exit_code=0,response=json.loads(run.stdout))
for capture in captures:
 for other in captures:
  if all(capture[k]==other[k] for k in ['family','normalization','mode']) and capture['cache_bytes']!=other['cache_bytes']:assert capture['stdout']==other['stdout']
  if all(capture[k]==other[k] for k in ['family','mode','cache_bytes']) and capture['normalization']!=other['normalization']:
   assert [(f['kind'],unicodedata.normalize('NFC',f['surface']),f['analysis'],f['dictionary']) for f in capture['frames']]==[(f['kind'],unicodedata.normalize('NFC',f['surface']),f['analysis'],f['dictionary']) for f in other['frames']]
packed=gzip.compress((json.dumps(dict(captures=captures,native_entries=native),ensure_ascii=False)+'\n').encode(),mtime=0);CAP.write_bytes(packed)
r.update(inputs_unchanged=all(sha((WORK/n).read_bytes())==v for n,v in frozen.items()),external_inputs_unchanged=all(sha(Path(p).read_bytes())==v for p,v in external.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK))==index,runs=len(captures),frames=sum(len(c['frames']) for c in captures),complete_native_owners=len(native),old_paths_preserved=old_paths,new_unjudged_paths=additions,required_checks=required_checked,forbidden_checks=forbidden_checked,capture_path=CAP.name,capture_sha256=sha(packed),log_sha256=sha(LOG.read_bytes()),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
r['state']='passed' if all(r[k] for k in ['inputs_unchanged','external_inputs_unchanged','head_unchanged','index_unchanged']) and len(captures)==36 and len(native)==31 else 'failed';save();print(r['state'],r['runs'],'runs;',r['old_paths_preserved'],'old paths;',r['required_checks'],'required and',r['forbidden_checks'],'forbidden checks',flush=True);raise SystemExit(0 if r['state']=='passed' else 1)
