"""Validate the unapplied append proposal and freeze its original inputs."""
import datetime
import gzip
import hashlib
import importlib.util
import json
import subprocess
import sys
import unittest
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-gentle-command')
OUT = PREP/'gentle-command-ledger-promotion-draft-controls.json'
LOG = PREP/'gentle-command-ledger-promotion-draft-controls.log'
assert not OUT.exists() and not LOG.exists()
sys.path.insert(0,str(WORK/'tools'));sys.path.insert(0,str(PREP))
import gentle_command_ledger_audit as audit
import gentle_command_source_audit as source_audit

sha = lambda p: hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
raw = lambda name:gzip.decompress((PREP/name).read_bytes())
files = [Path(__file__),PREP/'gentle_command_ledger_audit.py',PREP/'test_gentle_command_ledger_audit.py',
         PREP/'gentle-command-ledger-promotion-preflight.json',
         *[PREP/name for name in ['gentle-command-parent-validity.json.gz','gentle-command-parent-inventory-reviews.json.gz','gentle-command-proposed-validity.json.gz','gentle-command-proposed-inventory-reviews.json.gz','gentle-command-scoped-reviews.json']]]
names = subprocess.check_output(['git','ls-files','-z'],cwd=WORK).decode().split('\0')[:-1]
files += [WORK/name for name in names]
frozen = {str(p):sha(p) for p in files}
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
index = hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK)).hexdigest()
values = dict(parent_raw=raw('gentle-command-parent-validity.json.gz'),
              parent_reviews_raw=raw('gentle-command-parent-inventory-reviews.json.gz'),
              current_raw=raw('gentle-command-proposed-validity.json.gz'),
              current_reviews=json.loads(raw('gentle-command-proposed-inventory-reviews.json.gz')),
              scoped_raw=(PREP/'gentle-command-scoped-reviews.json').read_bytes(),
              source_evidence=source_audit.inputs())
audit.inputs = lambda:values
r = dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,
         applied_to_worktree=False,producer=dict(text=Path(__file__).read_text(),sha256=sha(__file__)),
         scope='Draft-only 23independentcase/twoboundedreview append; every35681originalcase/515reviewbyte andfield retained. No active ledger/review/queue changes. Actual installed/browser preconditions remain required before promotion.')
save = lambda:OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
r['append_inspection'] = audit.inspect(values)
suite = unittest.defaultTestLoader.discover(str(PREP),pattern='test_gentle_command_ledger_audit.py')
with LOG.open('x') as stream: result = unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
r.update(controls=result.testsRun,failures=len(result.failures),errors=len(result.errors),
         inputs_unchanged=all(sha(p)==digest for p,digest in frozen.items()),
         head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,
         index_unchanged=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK)).hexdigest()==index,
         log_sha256=sha(LOG),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
r['state'] = 'draft-controls-passed-not-promoted' if result.wasSuccessful() and result.testsRun==25 and all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged']) else 'failed'
save()
print(r['state'],r['controls'],'controls; actual active ledger and reviews unchanged',flush=True)
raise SystemExit(0 if r['state']=='draft-controls-passed-not-promoted' else 1)
