import datetime,hashlib,json,subprocess
from pathlib import Path
PREP=Path(__file__).resolve().parent
WORK=Path('/tmp/klem-gentle-command-long-promotion')
OUT=PREP/'gentle-command-long-ledger-draft-validation.json'
LOG=PREP/'gentle-command-long-ledger-draft-validation.log'
assert not OUT.exists() and not LOG.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=WORK).decode().split('\0')
frozen={n:sha((WORK/n).read_bytes()) for n in paths if n and (WORK/n).is_file()}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK))
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),commands=[])
def save():OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
commands=[['python3','tools/gentle_command_long_ledger_audit.py','--draft'],['env','KLEM_LONG_PROMOTION_DRAFT=1','python3','-m','unittest','discover','-s','tools','-p','test_gentle_command_long_ledger_audit.py','-v']]
try:
 with LOG.open('xb') as stream:
  for command in commands:
   row=dict(command=command);r['commands'].append(row);save();job=subprocess.run(command,cwd=WORK,stdout=stream,stderr=subprocess.STDOUT);row['exit_code']=job.returncode;save();assert job.returncode==0,command
 r.update(inputs_unchanged=all(sha((WORK/n).read_bytes())==digest for n,digest in frozen.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK))==index);assert all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged']);r['state']='passed'
except Exception as error:r.update(state='failed',error=str(error));raise
finally:r.update(log_sha256=sha(LOG.read_bytes()),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
print('Passed exact long36-case/two-review DRAFT auditor and corruption controls; shared35704 unchanged;',len(frozen),'source files unchanged',flush=True)
