"""Reconstruct all53502 actual installed Gena word records from75whole commands."""
import datetime,gzip,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent;OUT=P/'friendly-command-gena-promoted-installed-cohort-stream-audit.json';assert not OUT.exists();sha=lambda b:hashlib.sha256(b).hexdigest();path=P/'friendly-command-gena-promoted-installed-runtime-retry1.json.gz';packed=path.read_bytes();r=json.loads(gzip.decompress(packed));assert r['state']=='passed';attempts=iter(r['cohort_command_attempts']);assert len(r['cohort_command_attempts'])==75 and len(r['cohort_runs'])==2;streams=set();total=0
cli=r['binaries']['klem']['path']
def decode(a):
 assert a['exit_code']==0 and set(a['streams'])=={'stdout','stderr'}
 text=a['input'];assert a['input_sha256']==(None if text is None else sha(text.encode()))
 values={}
 for key,row in a['streams'].items():
  assert row['path'] not in streams;streams.add(row['path']);data=Path(row['path']).read_bytes();assert sha(data)==row['archive_sha256']==r['frozen_inputs'][row['path']];raw=gzip.decompress(data);assert sha(raw)==row['source_sha256'] and len(raw)==row['bytes'];values[key]=raw
 assert values['stderr']==b'';return values['stdout']
for run in r['cohort_runs']:
 words=run['words'];ordered=sorted(words);text='\n'.join(ordered)+'\n';a=next(attempts);assert a['command']==[cli,'text','-'] and a['input']==text
 raw=text.encode();cursor=offset=0;starts={};whole={}
 for word in ordered:starts[offset]=word;offset+=len(word.encode())+1
 for line in decode(a).splitlines():
  frame=json.loads(line);span=frame['span'];assert span['start']==cursor and raw[cursor:span['end']].decode()==frame['surface'];cursor=span['end']
  if frame['kind']=='word' and starts.get(span['start'])==frame['surface'] and span['end']==span['start']+len(frame['surface'].encode()):whole[frame['surface']]=frame['analysis']
 assert cursor==len(raw);missing=set(words)-set(whole)
 for _ in range(len(missing)):
  a=next(attempts);command=a['command'];assert len(command)==3 and command[:2]==[cli,'word'] and command[2] in missing and a['input'] is None;word=command[2];missing.remove(word);whole[word]=json.loads(decode(a))
 assert not missing and whole==words and len(words)==run['surfaces'];total+=len(words)
assert next(attempts,None) is None and total==53502 and len(streams)==150
prefix=r['reused_completed_prefix'];assert prefix['actual_completed_commands']==149 and prefix['whole_streams']==298 and prefix['prefix_commands_replayed']==0
OUT.write_text(json.dumps(dict(state='passed',head=r['captured_head'],installed_receipt_sha256=sha(packed),cohort_words=total,actual_cohort_commands=75,whole_cohort_streams=150,original_full_candidate_fields_and_order_retained=True,actual_prefix_commands_reused=149,prefix_commands_replayed=0,executable_replays=0,producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n');print('All53502 installed whole word records independently reconstructed from75commands/150streams;149completed prefix calls not replayed.',flush=True)
