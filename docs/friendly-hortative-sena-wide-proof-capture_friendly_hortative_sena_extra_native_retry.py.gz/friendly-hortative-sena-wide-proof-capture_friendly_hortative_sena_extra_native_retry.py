import datetime,gzip,hashlib,json,subprocess,sys
from pathlib import Path
PREP=Path(__file__).resolve().parent;ROOT=PREP.parents[1];WORK=ROOT/'.direnv/friendly-hortative-sena';CLI=ROOT/'.direnv/friendly-hortative-sena-target/debug/klem';DB=ROOT/'.direnv/dictionary-restoration/krdict.db'
OUT=PREP/'friendly-hortative-sena-extra-native.json.gz';assert not OUT.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest();sys.path.insert(0,str(WORK/'tools'));from native_lmf import entry,array,features
runtime_path=PREP/'friendly-hortative-sena-runtime-records.json.gz';runtime=json.loads(gzip.decompress(runtime_path.read_bytes()));history_path=PREP/'friendly-hortative-sena-history.json';history=json.loads(history_path.read_bytes());broad_path=PREP/'friendly-hortative-sena-broad.json.gz';broad=json.loads(gzip.decompress(broad_path.read_bytes()));assert broad['inputs_unchanged'] and broad['state']=='complete-friendly-hortative-sena-broad-comparison-passed'
paths=[p['analysis'] for c in runtime['captures'] for p in c['new_paths']]+[p['analysis'] for p in history['individual_additions']]+[a for r in broad['runs'] for c in r['changed_frames'] for a in c['new_paths']]
heads={l['text'] for a in paths for l in a['lemmas']};old=json.loads(gzip.decompress((PREP/'friendly-hortative-sena-original-native-closure-reviewed.json.gz').read_bytes()))
raws={};entries={};exports={};queries={}
binding_path=PREP/'friendly-hortative-sena-complete-runtime-binding.json';binding=json.loads(binding_path.read_bytes());assert binding['state']=='passed' and sha(CLI.read_bytes())==binding['binaries']['klem']['sha256']
captured_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip();index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK));names=subprocess.check_output(['git','ls-files','-z'],cwd=WORK).decode().split('\0')[:-1];source_inputs={n:sha((WORK/n).read_bytes()) for n in names}
protected={str(p):sha(p.read_bytes()) for p in [CLI,DB,runtime_path,history_path,broad_path,binding_path,Path(__file__)]}
for path in sorted((ROOT/'.direnv/dictionary-restoration/2026-09').glob('*.json')):
 raw=path.read_bytes();exports[path.name]=dict(sha256=sha(raw),bytes=len(raw));lex=json.loads(raw)['LexicalResource']['Lexicon']
 for item in array(lex['LexicalEntry']):
  if not ({h for lemma in array(item['Lemma']) for h in features(lemma,'writtenForm')} & heads):continue
  value=entry(item);raws[value['id']]=item;entries[value['id']]=value
assert exports==old['source_exports'],'same11originalexports only'
for head in sorted(heads):
 command=[str(CLI),'dict','lookup',str(DB),head];job=subprocess.run(command,capture_output=True);assert job.returncode==0;queries[head]=dict(command=command,exit_code=0,stdout=job.stdout.decode(),stderr=job.stderr.decode())
records={}
for ident,value in entries.items():
 command=[str(CLI),'dict','entry',str(DB),ident];job=subprocess.run(command,capture_output=True);assert job.returncode==0;response=json.loads(job.stdout);assert response['entry']==value;records[ident]=dict(command=command,stdout=job.stdout.decode(),stderr=job.stderr.decode(),exit_code=0,response=response)
assert all(sha(Path(p).read_bytes())==v for p,v in protected.items())
assert all(sha((WORK/n).read_bytes())==digest for n,digest in source_inputs.items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==captured_head and sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK))==index
extra={ident:value for ident,value in entries.items() if ident not in old['complete_native_entries']}
record=dict(state='complete-original-native-closure-for-every-new-runtime-history-broad-lemma-passed',captured_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),frozen_inputs=protected,source_inputs=source_inputs,captured_head=captured_head,index_sha256=index,source_unchanged=True,head_unchanged=True,index_unchanged=True,inputs_unchanged=True,selected_heads=sorted(heads),original_lmf=raws,complete_native_entries=entries,source_exports=exports,actual_headword_queries=queries,actual_complete_entry_responses=records,additional_native_entries=extra,contextual_verdict='unjudged',independent_review='pending',scope='All same-head original dictionary owners for every newly observed rule-bearing path in36policies/53502cohorts/1128312broadframes, including unmatched hypothetical lemma lookups. Every full LMF and actual complete Native response retained; no source, dictionary, fixture, gold or linguistic judgment changed. Post-runtime attribution supplies no contextual precision/register certification.')
OUT.write_bytes(gzip.compress((json.dumps(record,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Passed extraNative closure:',len(heads),'heads;',len(entries),'full owners;',len(extra),'additional original owners;',len(heads)-len({e['headword'] for e in entries.values()}),'unmatched hypothetical heads',flush=True)
