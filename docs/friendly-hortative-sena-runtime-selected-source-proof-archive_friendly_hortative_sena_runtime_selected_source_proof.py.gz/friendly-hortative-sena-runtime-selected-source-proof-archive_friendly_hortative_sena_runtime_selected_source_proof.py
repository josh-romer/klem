"""Archive the actual independent Source audit and its complete controls."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = Path('/home/josh/projects/klem/.direnv/friendly-hortative-sena')
D = W / 'docs'
sha = lambda b: hashlib.sha256(b).hexdigest()
receipt = P / 'friendly-hortative-sena-runtime-selected-source.json'
r = json.loads(receipt.read_bytes())
assert r['state'] == 'passed' and r['controls'] == 105
assert len(r['results']) == 6 and all(x['exit_code'] == 0 for x in r['results'])
assert all(r[k] for k in ['inputs_unchanged', 'parent_binding_unchanged', 'head_unchanged', 'index_unchanged'])
assert all(sha((W / name).read_bytes()) == digest for name, digest in r['frozen_inputs'].items())
assert r['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
assert r['index_sha256'] == sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=W))
assert sha((P / 'friendly-hortative-sena-runtime-selected-source.log').read_bytes()) == r['log_sha256']
files = {}
for path in [P / 'preflight_friendly_hortative_sena_runtime_selected_source.py', receipt,
             P / 'friendly-hortative-sena-runtime-selected-source.log', Path(__file__),
             W / 'tools/friendly_hortative_sena_source_audit.py',
             W / 'tools/test_friendly_hortative_sena_source_audit.py',
             W / 'tools/friendly_hortative_sena_runtime_audit.py',
             W / 'tools/test_friendly_hortative_sena_runtime_audit.py']:
    raw = path.read_bytes()
    name = 'friendly-hortative-sena-runtime-selected-source-proof-' + path.name + '.gz'
    output = D / name
    assert not output.exists()
    packed = gzip.compress(raw, mtime=0)
    output.write_bytes(packed)
    files[path.name] = dict(path=name, source_sha256=sha(raw), archive_sha256=sha(packed))
output = D / 'friendly-hortative-sena-runtime-selected-source-proof-archive.json'
assert not output.exists()
output.write_text(json.dumps(dict(
    state='actual-Git-backed-Nix-selected-Sena-source-and-runtime105controls-passed', files=files,
    source_baseline_manifest_sha256='1a2e9d3f9430b00c743e47ef262623ab19e33c29429af8a9fe50a72e34a3257b',
    source_groups=5, private_cases=25, required=19, forbidden=6, full_native_owners=36,
    baseline_runs=36, baseline_frames=1608, required_observations=324, original_raw_words=63,
    independent_controls=105, own_Sena_source_controls=42, own_Sena_runtime_controls=41, preserved_Gena_controls=22, selected_source_files=len(r['selected_files']), tracked_source_files=len(r['frozen_inputs']), production_inputs=r['production_inputs'], declared_production_changes=r['declared_production_changes'], compiled_profiles={k:len(v['files']) for k,v in r['profiles'].items()}, baseline_canonical_typed_matches=0, baseline_required_lemma_role_matches=0,
    actual_source_head_index_and_parent_inputs_unchanged=True,
    shared_cases_and_reviews_changed=False, original_metadata_correction_retained=True,
    full_Rust_history_broad_gold_CLI_browser_installed_Nix_main_quiet_context_register_independent_review='pending',
    full_coverage_complete=False), indent=2) + '\n')
print('Archived eight full originals for actual Nix-selected Sena105 source/runtime controls; all44 compiled production inputs/five changes and18 frontend files exact.', flush=True)
