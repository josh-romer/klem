"""Reject incomplete, borrowed, failed, and altered all-target command evidence."""
import copy
import hashlib
import json
import unittest

import audit_friendly_command_gena_promotion_full_rust as audit


class FullOriginalRustEvidence(unittest.TestCase):
    def setUp(self):
        targets = [dict(kind=['lib'], name='klem'), dict(kind=['example'], name='evaluate')]
        commands = [(['cargo', 'fmt', '--all', '--', '--check'], None)]
        for target in targets:
            selector = ['--lib'] if target['kind'] == ['lib'] else ['--example', target['name']]
            commands.append((['cargo', 'test', '--locked', '--offline', '--features', 'web', '--message-format', 'json', *selector], target))
        commands += [(c, None) for c in [
            ['cargo', 'clippy', '--locked', '--offline', '--all-targets', '--features', 'web', '--', '-D', 'warnings'],
            ['python3', 'tools/review_inventory.py', '--verify'], ['git', 'diff', '--check'],
        ]]
        self.outputs = [b'', b'{"reason":"build-finished","success":true}\ntest result: ok. 3 passed; 0 failed; 1 ignored; 0 measured; 0 filtered out;\n',
                        b'{"reason":"build-finished","success":true}\ntest result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;\n', b'', b'', b'']
        self.report = dict(state='failed', cargo_metadata=dict(packages=[dict(manifest_path=str(audit.W / 'Cargo.toml'), targets=targets)]),
                           all_targets=copy.deepcopy(targets), results=[dict(command=c, target=t, exit_code=0) for c, t in commands],
                           rust_totals=dict(passed=3, failed=0, ignored=1), rust_batches=2)

    def inspect(self):
        log = b''.join(b'COMMAND ' + json.dumps(row['command']).encode() + b'\n' + output
                       for row, output in zip(self.report['results'], self.outputs, strict=True))
        self.report['log_sha256'] = hashlib.sha256(log).hexdigest()
        return audit.inspect_commands(self.report, log)

    def test_complete_original_commands_include_zero_test_example(self):
        result = self.inspect()
        self.assertEqual((result['targets'], result['commands'], result['batches']), (2, 6, 2))
        self.assertEqual(result['totals'], dict(passed=3, failed=0, ignored=1))

    def test_running_job_is_not_terminal_evidence(self):
        self.report['state'] = 'running'
        with self.assertRaises(AssertionError): self.inspect()

    def test_missing_metadata_target_cannot_shrink_scope(self):
        self.report['all_targets'].pop()
        with self.assertRaises(AssertionError): self.inspect()

    def test_missing_last_gate_cannot_pass(self):
        self.report['results'].pop(); self.outputs.pop()
        with self.assertRaises(AssertionError): self.inspect()

    def test_metadata_target_execution_cannot_be_reordered(self):
        self.report['results'][1:3] = reversed(self.report['results'][1:3])
        with self.assertRaises(AssertionError): self.inspect()

    def test_nonzero_command_rejected_even_with_ok_summary(self):
        self.report['results'][1]['exit_code'] = 1
        with self.assertRaises(AssertionError): self.inspect()

    def test_failed_rust_summary_rejected(self):
        self.outputs[1] = self.outputs[1].replace(b'ok. 3 passed; 0 failed', b'FAILED. 2 passed; 1 failed')
        with self.assertRaises(AssertionError): self.inspect()

    def test_missing_zero_test_summary_rejected(self):
        self.outputs[2] = b'{"reason":"build-finished","success":true}\n'
        with self.assertRaises(AssertionError): self.inspect()

    def test_duplicate_summary_cannot_borrow_tests(self):
        self.outputs[2] += self.outputs[2]
        with self.assertRaises(AssertionError): self.inspect()

    def test_missing_successful_build_event_rejected(self):
        self.outputs[1] = self.outputs[1].split(b'\n', 1)[1]
        with self.assertRaises(AssertionError): self.inspect()

    def test_failed_build_event_rejected(self):
        self.outputs[1] = self.outputs[1].replace(b'"success":true', b'"success":false')
        with self.assertRaises(AssertionError): self.inspect()

    def test_test_summary_cannot_be_attached_to_diff_gate(self):
        self.outputs[-1] = self.outputs[2]
        with self.assertRaises(AssertionError): self.inspect()

    def test_inflated_test_total_rejected(self):
        self.report['rust_totals']['passed'] += 1
        with self.assertRaises(AssertionError): self.inspect()

    def test_old_batch_count_rejected(self):
        self.report['rust_batches'] = 1
        with self.assertRaises(AssertionError): self.inspect()


if __name__ == '__main__':
    unittest.main()
