"""Preserve complete installed prototype derivations/source NARs against the tested baseline."""
import argparse,gzip,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from predicate_auxiliary_spacing_sources import package_source_texts_cached
from reported_deoni_complete_sources import source_store_path
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(p):
 p=Path(p);return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--package',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args();assert not args.output.exists();receipt=read(args.package)
assert receipt['state']=='passed' and receipt['exit_code']==0 and receipt['source_unchanged'] and receipt['inputs_unchanged'] and receipt['root_head_unchanged'] and receipt['root_index_unchanged']
baseline_path=ROOT/'docs/bound-noun-spacing-installed-sources.json.gz';baseline=read(baseline_path);texts=dict(package_source_texts_cached())
for name,update in baseline['updates'].items():
 assert update['before_sha256']==(sha(texts[name].encode()) if name in texts else None);texts[name]=update['after_text']
assert len(texts)==973
for name,text in texts.items():assert baseline['snapshot_files'][name]=={'bytes':len(text.encode()),'sha256':sha(text.encode())}
profiles={};snap={};actual_texts={};outputs={}
for label,suffix in [('klem','-klem-0.1.0'),('web-assets','-klem-web-assets-0.1.0'),('corpus-adapter','-klem-corpus-adapter-0.1.0')]:
 output=next(o for o in receipt['outputs'] if o.endswith(suffix));outputs[label]=output
 drv=subprocess.check_output(['nix-store','--query','--deriver',output],text=True).strip();drv_text=subprocess.check_output(['nix','derivation','show',drv],text=True);d=json.loads(drv_text);assert len(d)==1 and d[drv]['outputs']['out']['path']==output;source=d[drv]['env']['src']
 if label!='web-assets':assert source==receipt['source_profile']['source']
 files={};directories=[]
 for path in Path(source).rglob('*'):
  assert not path.is_symlink();relative=str(path.relative_to(source))
  if path.is_dir():directories.append(relative);continue
  name='web/'+relative if label=='web-assets' else relative;raw=path.read_bytes();record={'bytes':len(raw),'sha256':sha(raw)}
  if label!='web-assets':assert record==receipt['source_profile']['files'][name]
  if name in snap:assert snap[name]==record and actual_texts[name]==raw.decode()
  snap[name]=record;actual_texts[name]=raw.decode();files[relative]=dict(record,snapshot_path=name,executable=bool(path.stat().st_mode&0o111))
 assert len(files)==(18 if label=='web-assets' else 960)
 command=['nix-store','--dump',source];job=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE);h=hashlib.sha256();count=0
 while chunk:=job.stdout.read(1048576):h.update(chunk);count+=len(chunk)
 error=job.stderr.read();assert job.wait()==0,error;assert source_store_path(h.hexdigest())==source
 profiles[label]={'source':source,'package':output,'derivation':drv,'derivation_json_text':drv_text,'derivation_json_sha256':sha(drv_text.encode()),'files':files,'directories':sorted(directories),'nar_sha256':h.hexdigest(),'nar_bytes':count,'nar_command':command,'actual_dump_verified':True};print(label,len(files),'actual files;',count,'source NAR bytes',flush=True)
assert len(snap)==977 and set(texts)<=set(actual_texts)
updates={n:{'before_sha256':sha(texts[n].encode()) if n in texts else None,'after_sha256':sha(value.encode()),'after_text':value} for n,value in actual_texts.items() if n not in texts or value!=texts[n]}
assert len(updates)==6 and sum(u['before_sha256'] is None for u in updates.values())==4
assert profiles['klem']['files']==profiles['corpus-adapter']['files'] and profiles['klem']['nar_sha256']==profiles['corpus-adapter']['nar_sha256']
assert profiles['web-assets']['source']==baseline['profiles']['web-assets']['source']
report={'schema_version':1,'state':'passed','receipt_sha256':sha(args.package.read_bytes()),'baseline':{'proof':'docs/bound-noun-spacing-installed-sources.json.gz','proof_sha256':sha(baseline_path.read_bytes())},'snapshot_files':snap,'updates':updates,'profiles':profiles,'actual_source_profiles_verified':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'scope':'Actual isolated installed prototype977source union:960Rust,18frontend withone overlap; six exact changes from the973input tested package. Four new files, two updated files; all unmodified inputs and complete derivations/sourceNARs retained. Root integration or a later modified README/source is not certified by this historical proof.'}
args.output.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Retained all977source inputs with6exact deltas and3actual derivation/NAR profiles.')
