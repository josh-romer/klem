"""Execute current audits from the actual Git-selected immutable Nix inventory source."""
import datetime
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path('/tmp/klem-expression-conjectural-main')
PREP = Path(__file__).resolve().parent
OUT = PREP / 'combined-selected-inventory-source.json'
assert not OUT.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')[:-1]
frozen = {name: hashlib.file_digest((ROOT / name).open('rb'), 'sha256').hexdigest() for name in tracked}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
index = sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT))
source = Path(subprocess.check_output(['nix', 'eval', '--offline', '--raw', 'git+file://' + str(ROOT) + '#checks.x86_64-linux.inventory-review.src'], cwd=ROOT, text=True).strip())
files = {}
for path in source.rglob('*'):
    assert not path.is_symlink()
    if not path.is_file(): continue
    name = str(path.relative_to(source))
    raw = path.read_bytes()
    assert name in frozen and raw == (ROOT / name).read_bytes(), ('actual selected source differs from committed worktree', name)
    files[name] = {'bytes': len(raw), 'sha256': sha(raw)}
audits = [
    ('conjectural_additive_source_audit', 13),
    ('conjectural_additive_prototype_audit', 38),
    ('conjectural_additive_distribution_audit', 17),
    ('conjectural_additive_ledger_audit', 14),
    ('conjectural_additive_novel_audit', 14),
    ('formal_volitional_expression_ledger_audit', 8),
    ('expression_conjectural_ledger_audit', 16),
    ('conjectural_additive_installed_audit', 25),
]
commands = []
for name, controls in audits:
    assert 'tools/' + name + '.py' in files and 'tools/test_' + name + '.py' in files
    commands.extend([([ 'python3', 'tools/' + name + '.py'], None),
                     ([ 'python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_' + name + '.py'], controls)])
commands.extend([(['python3', 'tools/review_inventory.py', '--verify'], None),
                 (['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_review_inventory.py'], 10)])
r = {'state': 'running', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'head': head, 'index_sha256': index, 'all_tracked_files': frozen,
     'actual_inventory_source': str(source), 'actual_selected_files': files, 'runs': [],
     'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())}}
OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
env.pop('KLEM_NOVEL_AUDIT_ROOT', None)
for ordinal, (command, controls) in enumerate(commands):
    log = PREP / f'combined-selected-inventory-audit-{ordinal}.log'
    assert not log.exists()
    with log.open('xb') as stream:
        code = subprocess.run(command, cwd=source, env=env, stdout=stream, stderr=subprocess.STDOUT).returncode
    if code == 0 and controls is not None:
        assert f'Ran {controls} tests' in log.read_text() and log.read_text().rstrip().endswith('OK'), 'actual complete expected control suite'
    r['runs'].append({'command': command, 'exit_code': code, 'controls': controls, 'log_sha256': sha(log.read_bytes())})
    r['inputs_unchanged'] = all(hashlib.file_digest((ROOT / name).open('rb'), 'sha256').hexdigest() == digest for name, digest in frozen.items())
    r['head_unchanged'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == head
    r['index_unchanged'] = sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT)) == index
    OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
    print(ordinal, command, code, 'all frozen invariants', r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged'], flush=True)
    if code or not all(r[key] for key in ['inputs_unchanged', 'head_unchanged', 'index_unchanged']):
        r['state'] = 'failed'
        OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
        raise SystemExit(code or 1)
r.update(state='passed', exit_code=0, controls=sum(count for _, count in commands if count),
         finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Actual Git-selected combined Nix inventory source at ea34949. Every selected input byte-equals the committed worktree. Original Source/prototype/Native/browser/distribution/novel evidence, both strict historical ledgers, active35651ledger, original511manualreviews and2boundedreviews, complete installed proof andqueue checked directly from immutable Nix source, including all155controls. Every trackedfile/HEAD/index remains frozen. Whole combined Rust/newpackages/fullinventory Nix/currentinstalled/main/timing andwidercontextual/independent review remain separate.')
OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
print('Actual selected source audits passed;', r['controls'], 'controls', flush=True)
