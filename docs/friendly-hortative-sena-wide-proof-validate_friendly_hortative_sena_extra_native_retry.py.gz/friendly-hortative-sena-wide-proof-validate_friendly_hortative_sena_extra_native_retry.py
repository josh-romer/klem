"""Run the corrected collector with a durable complete log and input receipt."""
import datetime
import hashlib
import json
import os
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
O = P / 'friendly-hortative-sena-extra-native-retry.json'
L = P / 'friendly-hortative-sena-extra-native-retry.log'
C = P / 'capture_friendly_hortative_sena_extra_native_retry.py'
assert not O.exists() and not L.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=W)
assert not git('status', '--porcelain')
names = git('ls-files', '-z').decode().split('\0')[:-1]
frozen = {n: sha((W / n).read_bytes()) for n in names}
head, index = git('rev-parse', 'HEAD').decode().strip(), sha(git('ls-files', '--stage', '-z'))
r = dict(state='running', head=head, index_sha256=index, frozen_inputs=frozen,
         producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
         collector_sha256=sha(C.read_bytes()),
         command=['python3', str(C)],
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
def save():
    O.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
save()
try:
    with L.open('xb') as log:
        job = subprocess.run(r['command'], cwd=W,
                             env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
                             stdout=log, stderr=subprocess.STDOUT)
    r.update(exit_code=job.returncode, state='passed' if job.returncode == 0 else 'failed')
except BaseException as error:
    r.update(state='failed', error=repr(error))
    raise
finally:
    r.update(inputs_unchanged=all(sha((W / n).read_bytes()) == d for n, d in frozen.items()),
             head_unchanged=git('rev-parse', 'HEAD').decode().strip() == head,
             index_unchanged=sha(git('ls-files', '--stage', '-z')) == index,
             collector_unchanged=sha(C.read_bytes()) == r['collector_sha256'],
             log_sha256=sha(L.read_bytes()) if L.exists() else None,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged', 'collector_unchanged']):
        r['state'] = 'failed'
    save()
assert r['state'] == 'passed', 'Actual retry failed; full log and receipt retained.'
result = P / 'friendly-hortative-sena-extra-native.json.gz'
r['result_sha256'] = sha(result.read_bytes())
save()
print(L.read_text(), end='', flush=True)
