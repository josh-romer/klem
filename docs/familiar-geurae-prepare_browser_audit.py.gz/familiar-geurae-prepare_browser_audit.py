"""Apply complete independently derived browser invariants to the particle family."""
import gzip
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
PARENT = BASE / 'explanatory-se-integration'
ROOT = BASE / 'familiar-geurae-prototype'
PREP = BASE / 'familiar-geurae-prepared'
code = (PARENT / 'tools/explanatory_se_browser_audit.py').read_text()
code = code[:code.index('\ndef inputs(')]
code = code.replace("len(suites) == 3 and [len(suite['cases']) for suite in suites] == [46, 2, 14]", "len(suites) == 1 and [len(suite['cases']) for suite in suites] == [27]")
code = code.replace("len(cases) == 53 and len({case['id'] for case in cases}) == 53", "len(cases) == 19 and len({case['id'] for case in cases}) == 19")
code = code.replace("api['rules'].get('ending.explanatory_se') and api['rules'].get('particle.familiar_gryeo')", "api['rules'].get('particle.familiar_geurae') and api['rules'].get('ending.exclamation_variant')")
code = code.replace("== 105", "== 37").replace("len(decisions) == 318", "len(decisions) == 114").replace("len(diagrams) == 314", "len(diagrams) == 114")
code = code.replace("expected_exclusions = [('explanatory-se-gold-MH2_0110-s387-3', encoding, mode) for encoding in ['NFC', 'NFD'] for mode in ['headword', 'compatible']]", "expected_exclusions = []")
code = code.replace("len(native) == 170", "len(native) == 50").replace("'original_api_frames': 210", "'original_api_frames': 74")
code += '''
def inputs():
    docs = ROOT / 'docs'
    browser = read(docs / 'familiar-geurae-closure-browser.json.gz')
    runtime = read(docs / 'familiar-geurae-closure-browser-runtime.json.gz')
    suites = [read(ROOT / 'tests/fixtures/familiar-geurae-validity.json')]
    native = read(ROOT / 'tests/fixtures/familiar-geurae-additional-native-entries.json')
    labels = read(ROOT / 'web/src/grammar-labels.json')
    driver = gzip.decompress((docs / 'familiar-geurae-closure-browser.mjs.gz').read_bytes()).decode()
    supervisor = gzip.decompress((docs / 'familiar-geurae-closure-browser-supervisor.py.gz').read_bytes()).decode()
    return browser, runtime, suites, native, labels, driver, supervisor

if __name__ == '__main__':
    print(inspect(*inputs()))
'''
target = ROOT / 'tools/familiar_geurae_browser_audit.py'
assert not target.exists()
target.write_text(code)
tests = (PARENT / 'tools/test_explanatory_se_browser_audit.py').read_text()
tests = tests.replace('explanatory_se_browser_audit', 'familiar_geurae_browser_audit').replace('(318, 314, 170)', '(114, 114, 50)')
start = tests.index('    def test_unmatched_dictionary_path_cannot_be_offered(')
end = tests.index('    def test_supported_path_not_hidden(', start)
tests = tests[:start] + '''    def test_original_selected_path_index(self):
        self.reject(lambda v: v[0]['policyDecisions'][0].update(raw_analysis_index=999), 'all independent policy decisions')

''' + tests[end:]
start = tests.index('    def test_no_match_message_preserved(')
end = tests.index('    def test_missing_authored_diagram(', start)
tests = tests[:start] + '''    def test_offered_indices_preserved(self):
        self.reject(lambda v: v[0]['policyDecisions'][0].update(offered_indices=['999']), 'all independent policy decisions')

''' + tests[end:]
(ROOT / 'tools/test_familiar_geurae_browser_audit.py').write_text(tests)
for suffix in ['.json', '-runtime.json', '-runtime.log', '.mjs', '-supervisor.py', '-supervisor.log']:
    name = 'familiar-geurae-closure-browser' + suffix
    (ROOT / 'docs' / (name + '.gz')).write_bytes(gzip.compress((PREP / name).read_bytes(), mtime=0))
for suffix in ['-desktop.png', '-mobile.png']:
    name = 'familiar-geurae-closure-browser' + suffix
    (ROOT / 'docs' / name).write_bytes((PREP / name).read_bytes())
print('Prepared complete114policy/114diagram/6export/50Native browser audit and19controls', flush=True)
