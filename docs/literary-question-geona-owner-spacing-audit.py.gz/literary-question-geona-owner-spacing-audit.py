"""Derive typed owner policies, original spacing byte offsets and complete Native/importer closure."""
import gzip,hashlib,json,sys,unicodedata
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from literary_future_kko_audit import matches
from native_lmf import entry,verify_native_lmf
sha=lambda raw:hashlib.sha256(raw).hexdigest();read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes())
def rows(run):assert run['exit_code']==0 and sha(run['jsonl'].encode())==run['sha256'];return list(map(json.loads,run['jsonl'].splitlines()))
def conserve(a,b):
 assert len(a)==len(b)
 for old,new in zip(a,b,strict=True):
  for k in ['surface','span','kind']:assert old[k]==new[k]
  if not old.get('analysis'):assert old==new;continue
  x,y=old['analysis']['analyses'],new['analysis']['analyses'];assert [p for p in y if p in x]==x
  for p,assessment in zip(x,old['dictionary']['readings'],strict=True):assert new['dictionary']['readings'][y.index(p)]==assessment

def inspect(owner,spacing,native):
 for report in [owner,spacing,native]:
  assert report['state']=='passed' and report['inputs_unchanged'] is True
  assert sha(report['producer']['text'].encode())==report['producer']['sha256']
 entries=native['complete_native_entries'];assert len(entries)==241 and len(native['matched_owner_ids'])==216
 assert {i:entry(raw) for i,raw in native['original_lmf'].items()}==entries;verify_native_lmf(native['english_projection'],entries)
 older=read(Path('/tmp/klem-literary-question-geona-matched-owner-preparation.json.gz'))
 assert all(entries[i]==e for i,e in older['complete_native_entries'].items())
 assert len(owner['cases'])==27 and {v:sum(c['proposal']==v for c in owner['cases']) for v in ['required','conditional','forbidden','native-policy-only']}=={'required':15,'conditional':4,'forbidden':6,'native-policy-only':2}
 assert [(r['encoding'],r['mode']) for r in owner['runs']]==[(e,m) for e in ['NFC','NFD'] for m in ['raw','headword','compatible']]
 expected=[]
 for run in owner['runs']:
  before,after=rows(run['before']),rows(run['after']);conserve(before,after)
  for c in owner['cases']:
   row=next(r for r in after if r.get('analysis') and r['analysis']['normalized']==c['surface']);hits=[(i,p) for i,p in enumerate(row['analysis']['analyses']) if matches(p,c)];assessments=[row['dictionary']['readings'][i] for i,_ in hits]
   assert bool(hits)==c['expected_presence'][run['mode']]
   assert all(a['status']==c['expected_status'] for a in assessments)
   expected.append({'encoding':run['encoding'],'mode':run['mode'],'case_id':c['id'],'paths':[p for _,p in hits],'assessments':assessments,'present':bool(hits),'expected_present':c['expected_presence'][run['mode']],'contextual_verdict':'unjudged','independent_review':'pending'})
 assert expected==owner['observations'] and len(expected)==162
 assert len(spacing['cases'])==4 and [(r['encoding'],r['mode']) for r in spacing['runs']]==[(e,m) for e in ['NFC','NFD'] for m in ['headword','compatible']]
 expected=[]
 for run in spacing['runs']:
  before,after=rows(run['before']),rows(run['after']);conserve(before,after);assert len(after)==7
  for c in spacing['cases']:
   row=next(r for r in after if r.get('analysis') and r['analysis']['normalized']==c['surface']);left,right=(unicodedata.normalize(run['encoding'],c[k]) for k in ['left','right']);h=next((h for h in row['spacing']['alternatives'] if h['spaced']==left+' '+right),None)
   assert (h is not None)==c['expected_split_present']==c['id'].endswith(('return','live'))
   paths=[]
   if h:
    at=row['span']['start']+len(left.encode());assert h['inserted_at']==[at];assert [r['surface'] for r in h['records']]==[left,right];assert [r['span'] for r in h['records']]==[{'start':row['span']['start'],'end':at},{'start':at,'end':row['span']['end']}]
    paths=[p for p in h['records'][1]['analysis']['analyses'] if p['lemmas'][0]['text']==c['right_head'] and 'ending.literary_question_geona' in p['rules']];assert paths
   expected.append({'case_id':c['id'],'encoding':run['encoding'],'mode':run['mode'],'original_span':row['span'],'hypothesis':h,'right_paths':paths,'contextual_verdict':'unjudged','independent_review':'pending'})
 assert expected==spacing['observations'] and len(expected)==16
 return {'typed_owner_observations':162,'spacing_observations':16,'complete_native_entries':241,'matched_native_owners':216,'conditional_owner_cases':4,'auxiliary_role_conflicts_separate':2,'predicate_auxiliary_spacing_gap':'still unimplemented; not linguistic prohibition','full_main_and_contextual_review':'pending'}
def inputs():return [read(Path('/tmp/klem-literary-question-geona-'+n+'.json.gz')) for n in ['owner-extension-typed','spacing-preflight','complete-owner-preparation']]
if __name__=='__main__':print(inspect(*inputs()))
