"""Author source, boundary and spelling judgments before modifying the engine."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = PREP.parents[1]
PROTO = PREP.parent / 'familiar-geurae-prototype'
source = json.loads(gzip.decompress((PREP / 'full-native-preparation.json.gz').read_bytes()))
decision = json.loads((PREP / 'canonical-guman-decision.json').read_bytes())
cases = []


def case(ident, surface, lemmas, morphs, verdict='required', variant=False, source_id='particle'):
    rules = ['particle.familiar_geurae'] if morphs[-1] == '그래' else []
    if variant:
        rules.append('written.colloquial_guman')
    kinds = ['nominal', 'copula'] if len(lemmas) == 2 else ['predicate']
    judgment = {'id': 'path', 'lemmas': lemmas, 'lemma_kinds': kinds,
                'morphemes': morphs,
                'morpheme_kinds': ['particle' if m == '그래' else 'prefinal' if m in ['시', '었', '겠'] else 'ending' for m in morphs],
                'required_rules': rules, 'verdict': verdict, 'source': source_id,
                'reason': 'Independent structural judgment from complete original sources or their named attachment boundary, authored before new implementation. Canonical 구먼 variants follow the separate NIKL decision. The finite family does not certify contextual sense or independent linguistic precision; other candidates remain unjudged.'}
    if verdict == 'forbidden':
        judgment['reason'] = 'This finite source-owned final-particle family cannot attach directly to a bare noun/verb, nominalized or connective/quoted base, or borrow the distinct 그려 followers. This excludes the named path, not every conceivable lexical or contextual interpretation.'
    cases.append({'id': 'familiar-geurae-' + ident, 'surface': surface, 'judgments': [judgment]})


case('source-group-1', '쉬지그래', ['쉬다'], ['지', '그래'])
case('source-group-2', '생각이군그래', ['생각', '이다'], ['군', '그래'])
case('source-group-3-guman', '오랜만이구만그래', ['오랜만', '이다'], ['구먼', '그래'], variant=True)
case('source-group-4', '쏠쏠하겠구먼그래', ['쏠쏠하다'], ['겠', '구먼', '그래'])
for ident, surface, lemmas, morphs in [
    ('closed-verb-ji', '읽지그래', ['읽다'], ['지', '그래']),
    ('adjective-gun', '좋군그래', ['좋다'], ['군', '그래']),
    ('adjective-gumeon', '넓구먼그래', ['넓다'], ['구먼', '그래']),
    ('verb-neungun', '먹는군그래', ['먹다'], ['는군', '그래']),
    ('verb-neungumeon', '먹는구먼그래', ['먹다'], ['는구먼', '그래']),
    ('past-gun', '먹었군그래', ['먹다'], ['었', '군', '그래']),
    ('past-gumeon', '먹었구먼그래', ['먹다'], ['었', '구먼', '그래']),
    ('honorific-modal', '아시겠군그래', ['알다'], ['시', '겠', '군', '그래']),
    ('copula-gun', '학생이군그래', ['학생', '이다'], ['군', '그래']),
    ('copula-gumeon', '학생이구먼그래', ['학생', '이다'], ['구먼', '그래']),
]:
    case(ident, surface, lemmas, morphs)
for ident, surface, lemmas, morphs in [
    ('guman-adjective', '좋구만', ['좋다'], ['구먼']),
    ('guman-nikl-neun', '맞는구만', ['맞다'], ['는구먼']),
    ('guman-nikl-past', '됐구만', ['되다'], ['었', '구먼']),
    ('guman-adjective-particle', '좋구만그래', ['좋다'], ['구먼', '그래']),
    ('guman-verb-particle', '먹는구만그래', ['먹다'], ['는구먼', '그래']),
]:
    case(ident, surface, lemmas, morphs, variant=True, source_id='guman')
for ident, surface, lemmas, morphs in [
    ('forbidden-bare-noun', '학생그래', ['학생'], ['그래']),
    ('forbidden-bare-verb', '먹그래', ['먹다'], ['그래']),
    ('forbidden-nominal-particle', '학생도그래', ['학생'], ['도', '그래']),
    ('forbidden-nominalization', '먹기그래', ['먹다'], ['기', '그래']),
    ('forbidden-connective', '먹고그래', ['먹다'], ['고', '그래']),
    ('forbidden-quoted', '먹는다고그래', ['먹다'], ['는다고', '그래']),
    ('forbidden-other-familiar-formal', '먹습니다그래', ['먹다'], ['습니다', '그래']),
    ('forbidden-other-familiar-se', '먹을세그래', ['먹다'], ['을세', '그래']),
]:
    case(ident, surface, lemmas, morphs, verdict='forbidden')
    j = cases[-1]['judgments'][0]
    j['lemma_kinds'] = ['nominal'] if surface.startswith('학생') else ['predicate']
    j['morpheme_kinds'] = ['particle' if m in ['도', '그래'] else 'ending' for m in morphs]
suite = {'schema_version': 1, 'review_status': 'Independent source and explicit-family-boundary judgments before implementation; canonical guman decision and initial literal proposals retained. Wider distributions, contextual selection and independent review remain open.',
         'sources': {'particle': source['expression_entries']['krdict:83913']['url'],
                     'guman': decision['sources'][0]['url']}, 'cases': cases}
assert len(cases) == 27
assert sum(j['verdict'] == 'required' for c in cases for j in c['judgments']) == 19
path = PROTO / 'tests/fixtures/familiar-geurae-validity.json'
assert not path.exists()
path.write_text(json.dumps(suite, ensure_ascii=False, indent=2) + '\n')
for name, value in [('familiar-geurae-native-entries.json', source['complete_imported_entries']),
                    ('familiar-geurae-native.json', {'LexicalResource': {'Lexicon': {'LexicalEntry': list(source['original_native_entries'].values())}}})]:
    (PROTO / 'tests/fixtures' / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
binary = PREP.parent / 'explanatory-se-target/debug/klem'
captures = {}
for surface in sorted({c['surface'] for c in cases} | {'그래', '그려', '오랜만이구먼', '좋구먼', '먹는구먼'}):
    result = subprocess.run([str(binary), 'word', surface], capture_output=True, check=True)
    assert not result.stderr
    captures[surface] = json.loads(result.stdout)
(PROTO / 'tests/fixtures/familiar-geurae-baselines.json').write_text(json.dumps(captures, ensure_ascii=False, indent=2) + '\n')
(PREP / 'independent-authoring.json').write_text(json.dumps({'state': 'authored-before-implementation', 'cases': 27, 'required': 19, 'forbidden': 8, 'suite_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'native_owners': len(source['complete_imported_entries']), 'canonical_decision_sha256': hashlib.sha256((PREP / 'canonical-guman-decision.json').read_bytes()).hexdigest(), 'baseline_surfaces': len(captures), 'producer': {'text': Path(__file__).read_text(), 'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}, ensure_ascii=False, indent=2) + '\n')
print('Authored27 cases/19required/8forbidden; all completeNative owners and32exact previous word baselines preserved.')
