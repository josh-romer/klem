"""Preserve actual installed conjectural proofs, failures and source bindings."""
import gzip
import hashlib
import json
import re
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-conjectural-additive-integration')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(gzip.decompress(p.read_bytes()) if p.suffix == '.gz' else p.read_bytes())
binding_path = PREP / 'conjectural-integration-installed-source-binding.json'
binding = read(binding_path)
selected = read(PREP / 'conjectural-integration-selected-inventory-source.json')
assert binding['state'] == selected['state'] == 'passed'
assert binding['exit_code'] == selected['exit_code'] == 0
assert binding['all_tracked_inputs_unchanged']
assert all(record[k] for record in [binding, selected] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged'])
assert selected['controls'] == 106
families = ['source', 'copula', 'novel', 'cohorts', 'gold', 'broad']
for family in families:
    r = read(PREP / ('conjectural-installed-' + family + '.json.gz'))
    assert r['state'] == 'passed' and r['exit_code'] == 0 and r['inputs_unchanged']
    assert r['binding_sha256'] == sha(binding_path.read_bytes())
runtime = read(PREP / 'conjectural-additive-installed-novel-retry1-browser-runtime.json')
browser = read(PREP / 'conjectural-additive-installed-novel-retry1-browser.json')
assert runtime['state'] == 'passed' and runtime['exit_code'] == 0 and runtime['inputs_unchanged'] and runtime['server_stopped']
assert len(browser['diagrams']) == len(browser['policyDecisions']) == 288
assert len(browser['exports']) == 6 and len(browser['nativeEntries']) == 57 and not browser['errors']
release = PREP / 'conjectural-installed-release-tests.log'
batches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', release.read_text())
totals = {key: sum(int(batch[i + 1]) for batch in batches) for i, key in enumerate(['passed', 'failed', 'ignored'])}
assert totals == {'passed': 1161, 'failed': 0, 'ignored': 1} and len(batches) == 250
release_receipt = {'state': 'passed', 'derivation': binding['profiles']['klem']['derivation'],
                   'package': binding['profiles']['klem']['package'], 'totals': totals,
                   'batches': len(batches), 'log_sha256': sha(release.read_bytes()),
                   'scope': 'Actual retained Nix daemon build log of the installed package; all Rust test result batches counted without predictions.'}
(PREP / 'conjectural-installed-release-tests.json').write_text(json.dumps(release_receipt, indent=2) + '\n')
names = ['conjectural-integration-installed-source-binding.json', 'conjectural-integration-installed-source-binding.log',
         'bind_conjectural_integration_installed_source.py', 'conjectural-integration-selected-inventory-source.json',
         'validate_conjectural_selected_source.py', 'replay_installed_conjectural.py',
         'conjectural-installed-release-tests.json', 'conjectural-installed-release-tests.log',
         'installed-browser-initial-harness-failure.json', 'novel-browser-native-union.json',
         'conjectural-additive-installed-novel-browser-runtime.json',
         'conjectural-additive-novel-browser.mjs', 'run_installed_conjectural_novel_browser.py',
         'conjectural-additive-installed-novel-retry1-browser-runtime.json',
         'conjectural-additive-installed-novel-retry1-browser.json',
         'conjectural-additive-novel-browser-retry1.mjs', 'run_installed_conjectural_novel_browser_retry1.py']
names += ['conjectural-selected-inventory-audit-' + str(i) + '.log' for i in range(12)]
names += ['conjectural-installed-' + family + '.json.gz' for family in families]
names += ['installed-broad-' + mode + '.stderr' for mode in ['candidate-raw', 'candidate-headword', 'candidate-compatible', 'novel-raw', 'novel-headword', 'novel-compatible', 'novel-headword-spacing', 'novel-compatible-spacing']]
names += ['conjectural-additive-installed-novel-browser-runtime.log', 'conjectural-additive-installed-novel-retry1-browser-runtime.log']
names += [Path(__file__).name]
archived = []
for name in names:
    source = PREP / name
    assert source.exists(), name
    destination = WORK / 'docs' / ('conjectural-additive-installed-proof-' + name + ('' if name.endswith('.gz') else '.gz'))
    assert not destination.exists(), destination
    raw = source.read_bytes()
    destination.write_bytes(raw if name.endswith('.gz') else gzip.compress(raw, mtime=0))
    archived.append({'path': str(destination.relative_to(WORK)), 'original_bytes': len(raw), 'original_sha256': sha(raw), 'archive_sha256': sha(destination.read_bytes())})
for size in ['desktop', 'mobile']:
    source = PREP / ('conjectural-additive-installed-novel-retry1-browser-' + size + '.png')
    destination = WORK / 'docs' / ('conjectural-additive-installed-browser-' + size + '.png')
    assert not destination.exists()
    destination.write_bytes(source.read_bytes())
    archived.append({'path': str(destination.relative_to(WORK)), 'original_sha256': sha(source.read_bytes())})
receipt = {'state': 'actual-installed-proofs-preserved', 'head': binding['head'], 'artifacts': archived,
           'release_tests': totals, 'selected_source_controls': 106, 'browser_diagrams': 288,
           'exports': 6, 'native_endpoints': 57, 'full_coverage_complete': False,
           'scope': 'Actual Nix packages and selected source, complete installed CLI/adapter workloads and browser. Initial Playwright module resolution failure and corrected harness retained separately. Quiet performance, main promotion, complete new inventory Nix gate and contextual/independent review remain open.'}
out = PREP / 'installed-archive.json'
assert not out.exists()
out.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
(WORK / 'docs/conjectural-additive-installed-archive.json.gz').write_bytes(gzip.compress(out.read_bytes(), mtime=0))
print('Preserved', len(archived), 'actual installed proof artifacts; release', totals, flush=True)
