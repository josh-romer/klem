"""Preserve the complete current all-target Rust retry and every available earlier failure."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
D = W / 'docs'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
r = json.loads((P/'friendly-hortative-sena-full-rust-serial-retry.json').read_bytes())
assert r['state']=='passed' and r['rust_totals']['failed']==0 and r['rust_totals']['passed']>=1211
assert len(r['all_targets'])==262 and len(r['results'])==266
assert [row['target'] for row in r['results'] if row['target'] is not None]==r['all_targets']
assert all(row['exit_code']==0 for row in r['results'])
assert all(r[k] for k in ['inputs_unchanged','protected_binaries_unchanged','head_unchanged','index_unchanged'])
assert all(sha((W/p).read_bytes())==d for p,d in r['frozen_inputs'].items())
assert r['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
assert r['index_sha256']==sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))
assert all(sha(Path(p).read_bytes())==d for p,d in r['protected_binaries'].items())
log=(P/'friendly-hortative-sena-full-rust-serial-retry.log').read_bytes()
assert sha(log)==r['log_sha256']
for name in ['original_corpus_case_keeps_full_sentence_token_gold_and_unjudged_hypothesis',
             'corpus_candidate_preserves_old_order_and_original_noun_dictionary_owner',
             'whole_corpus_sentence_cli_matches_library_with_filters_unicode_cache_and_byte_spans']:
    assert ('test '+name+' ... ok').encode() in log
first=json.loads((P/'friendly-hortative-sena-full-rust-serial.json').read_bytes())
assert first['state']=='failed' and first['error']=="AssertionError('only this run disposable test harnesses')"
assert all(row['exit_code']==0 for row in first['results'])
assert sha((P/'friendly-hortative-sena-full-rust-serial.json').read_bytes())==r['original_serial_receipt_sha256']
names=[
    'run_friendly_hortative_sena_full_rust.py','friendly-hortative-sena-full-rust.json','friendly-hortative-sena-full-rust.log',
    'friendly-hortative-sena-full-rust-original-run_friendly_hortative_sena_full_rust.py.gz',
    'friendly-hortative-sena-full-rust-original-friendly-hortative-sena-full-rust.json.gz',
    'friendly-hortative-sena-full-rust-original-friendly-hortative-sena-full-rust.log.gz',
    'friendly-hortative-sena-full-rust-original-failure-observation.json',
    'run_friendly_hortative_sena_full_rust_serial.py','friendly-hortative-sena-full-rust-serial.json','friendly-hortative-sena-full-rust-serial.log',
    'friendly-hortative-sena-full-rust-serial-original-run_friendly_hortative_sena_full_rust_serial.py.gz',
    'friendly-hortative-sena-full-rust-serial-original-friendly-hortative-sena-full-rust-serial.json.gz',
    'friendly-hortative-sena-full-rust-serial-original-friendly-hortative-sena-full-rust-serial.log.gz',
    'friendly-hortative-sena-full-rust-serial-original-observation.json',
    'run_friendly_hortative_sena_full_rust_serial_retry.py','friendly-hortative-sena-full-rust-serial-retry.json','friendly-hortative-sena-full-rust-serial-retry.log',
    'friendly-hortative-sena-current-queue-race-observation.json']
files={}
for path in [P/n for n in names]+[Path(__file__)]:
    raw=path.read_bytes();name='friendly-hortative-sena-full-rust-proof-'+path.name+'.gz'
    output=D/name;assert not output.exists();packed=gzip.compress(raw,mtime=0);output.write_bytes(packed)
    item=dict(path=name,source_sha256=sha(raw),archive_sha256=sha(packed))
    if path.name=='friendly-hortative-sena-full-rust.json':
        try:json.loads(raw)
        except json.JSONDecodeError:pass
        else:raise AssertionError('original disk-full receipt must retain its incomplete original bytes')
        item.update(valid_json=False,scope='Incomplete original receipt bytes from disk-full write; never reconstructed or relabelled.')
    files[path.name]=item
out=D/'friendly-hortative-sena-full-rust-proof-archive.json';assert not out.exists()
out.write_text(json.dumps(dict(state='actual-entire-current-Sena-Rust-target-inventory-passed',files=files,
    source_head=r['head'],source_files=len(r['frozen_inputs']),rust_totals=r['rust_totals'],rust_batches=r['rust_batches'],
    cargo_targets=262,all_target_inventory_and_commands_retained=True,warning_denied_all_target_Clippy=True,
    original715_source_rows_519_reviews_196_unreviewed_unchanged=True,
    every_original_source_assertion_and_case_retained=True,protected_binaries=r['protected_binaries'],
    corpus_case_three_Rust_tests_passed=True,
    original_disk_full_failure_and_incomplete_log_receipt_bytes_retained=True,
    original_serial_example_cleanup_guard_failure_retained=True,original_concurrent_queue_verification_failure_retained=True,
    only_own_passed_test_harnesses_removed=True,removed_test_harness_count=len(r['removed_disposable_test_executables']),
    scope='Actual full lib/bin/integration/example Cargo target inventory, same Source and complete original assertions. Bounded disk use changes execution scheduling only. No actual fullNix/browser/installed/quiet/contextual-review claim.',
    full_coverage_complete=False),indent=2)+'\n')
print('Archived',len(files),'full available originals;actual',r['rust_totals'],'across262targets.',flush=True)
