"""Retain the complete actual committed-source Nix sandbox run."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent/'friendly-command-gena'
OUT = P/'friendly-command-gena-completed-sandbox-archive.json'
MANIFEST = W/'docs/friendly-command-gena-completed-sandbox-proof-archive.json'
assert not OUT.exists() and not MANIFEST.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
report = json.loads((P/'friendly-command-gena-completed-evidence-sandbox.json').read_bytes())
assert report['state'] == 'passed' and report['exit_code'] == 0 and report['controls'] == 81
assert all(report[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged','actual19_host_paths_absent'])
assert len(report['frozen_inputs']) == 7075 and len(report['selected_files']) == 7033
assert {k:len(v['files']) for k,v in report['profiles'].items()} == {'klem':1146,'corpus-adapter':1146,'web-assets':18}
assert all(sha((W/p).read_bytes()) == d for p,d in report['frozen_inputs'].items())
names = ['friendly-command-gena-completed-evidence-sandbox.json',
         'friendly-command-gena-completed-evidence-sandbox.log',
         'friendly-command-gena-completed-evidence-sandbox.nix',
         'run_friendly_command_gena_completed_evidence_sandbox.py',
         Path(__file__).name]
files = {n:(P/n).read_bytes() for n in names}
assert sha(files[names[1]]) == report['log_sha256']
assert report['producer'] == dict(text=files[names[3]].decode(),sha256=sha(files[names[3]]))
assert report['nix_expression'] == dict(text=files[names[2]].decode(),sha256=sha(files[names[2]]))
manifest = dict(state='actual-committed-Gena-Nix81-archive-controls-passed',files={},
                actual_session_id=34334,exit_code=0,controls=81,
                captured_head=report['head'],tracked_files=7075,selected_files=7033,
                captured_host_paths_absent=19,all_original_compile_profiles_unchanged=True,
                actual_shared_promotion=False,full_coverage_complete=False,
                scope='Complete original Nix producer, expression, terminal receipt and full log; actual clean committed Git-selected source and81 controls/715queue with19 host paths absent. All1146/1146/18 compile inputs and every old selected tool byte unchanged. Does not replace the broader original four-check gate or establish shared/main promotion or context/register/independent review completion.')
for name,raw in files.items():
    filename = 'friendly-command-gena-completed-sandbox-proof-'+name+'.gz'
    dest = W/'docs'/filename;assert not dest.exists()
    packed = gzip.compress(raw,mtime=0);dest.write_bytes(packed)
    assert gzip.decompress(dest.read_bytes()) == raw
    manifest['files'][name] = dict(path=filename,source_sha256=sha(raw),archive_sha256=sha(packed),original_bytes=len(raw))
MANIFEST.write_text(json.dumps(manifest,indent=2)+'\n')
r = dict(state='passed',originals=5,actual_validated_session_id=34334,manifest=str(MANIFEST),manifest_sha256=sha(MANIFEST.read_bytes()),
         producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
         finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope=manifest['scope'])
OUT.write_text(json.dumps(r,indent=2)+'\n')
print('Archived5 full original committed-source Nix81 artifacts:',r['manifest_sha256'],flush=True)
