"""Verify already completed four-check build without changing its failed wrapper."""
import datetime,gzip,hashlib,json,os,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent/'friendly-command-gena';OUT=P/'friendly-command-gena-promoted-completed-nix-output-audit.json';LOG=P/'friendly-command-gena-promoted-completed-nix-output-audit.log';assert not OUT.exists() and not LOG.exists();sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=W)
original_path=P/'friendly-command-gena-promoted-complete-nix-gate-retry2.json';original_bytes=original_path.read_bytes();original=json.loads(original_bytes);manifest_path=P/'friendly-command-gena-promoted-nix-output-type-failure-originals.json';manifest=json.loads(manifest_path.read_bytes())
for name,row in manifest['files'].items():
 packed=Path(row['archive']).read_bytes();assert sha(packed)==row['archive_sha256'];raw=gzip.decompress(packed);assert sha(raw)==row['sha256'] and len(raw)==row['bytes'] and raw==(P/name).read_bytes()
assert original['state']=='failed' and original['exit_code']==1 and original['error']=='AssertionError()'
assert len(original['results'])==13 and all(row['exit_code']==0 for row in original['results'])
last=original['results'][-1];assert last['command']==original['command'] and last['command'][0:2]==['nix','build'];outputs=last['stdout'].splitlines();assert len(outputs)==len(set(outputs))==4
assert original['selected_controls']==214 and all(original[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged'])
assert sha((P/'friendly-command-gena-promoted-complete-nix-gate-retry2.log').read_bytes())==original['log_sha256']
assert sha(original['producer']['text'].encode())==original['producer']['sha256']==sha((P/'run_friendly_command_gena_promoted_nix_gate_retry2.py').read_bytes())
assert git('rev-parse','HEAD').decode().strip()==original['head'] and sha(git('ls-files','--stage','-z'))==original['index_sha256'] and not git('status','--porcelain')
assert {n:sha((W/n).read_bytes()) for n in git('ls-files','-z').decode().split('\0')[:-1]}==original['frozen_inputs'];assert all(sha(Path(p).read_bytes())==d for p,d in original['protected_binaries'].items())
assert 'touch "$out"' in (W/'flake.nix').read_text(),'actual inventory contract is a file'
result=original.copy();result.update(state='running',phase='independent-completed-output-verification',original_wrapper_state='failed',original_wrapper_receipt_sha256=sha(original_bytes),original_wrapper_failure_preserved=True,independent_audit_results=[],producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Independent verification of actual already completed four-check Nix build and214selectedcontrols. All13 original subcommands exit0. Original wrapper failed a directory-only assertion on the inventory marker file and remains failed. No Nix build replay. Exact expected attribute/output identity and file-type contract verified. Installed/source-current/main/quiet/contextual work remains separate.')
def save():OUT.write_text(json.dumps(result,indent=2)+'\n')
save();env=dict(os.environ,TMPDIR='/var/tmp/klem-friendly-command-gena-promoted-nix-build',PYTHONDONTWRITEBYTECODE='1')
try:
 with LOG.open('xb') as log:
  for name,output in zip(['klem','web-assets','corpus-adapter','inventory-review'],outputs,strict=True):
   command=['nix','eval','--offline','--raw','git+file://'+str(W)+'#checks.x86_64-linux.'+name+'.outPath'];j=subprocess.run(command,cwd=W,env=env,capture_output=True);row=dict(command=command,exit_code=j.returncode,stdout=j.stdout.decode(),stderr=j.stderr.decode());result['independent_audit_results'].append(row);log.write(('COMMAND '+json.dumps(command)+'\n').encode()+j.stdout+j.stderr);log.flush();save();assert j.returncode==0 and j.stdout.decode().strip()==output
   path=Path(output);assert not path.is_symlink() and output.startswith('/nix/store/')
   if name=='inventory-review':assert path.is_file() and path.stat().st_size==0
   else:assert path.is_dir()
  assert Path(outputs[0]+'/bin/klem').is_file() and Path(outputs[0]+'/bin/klem-web').is_file()
  assert Path(outputs[1]+'/share/klem-web/index.html').is_file() and Path(outputs[2]+'/bin/klem-corpus-adapter').is_file()
 result.update(state='passed',exit_code=0,phase='complete',outputs=outputs,Nix_build_replays=0,expected_output_types=['directory','directory','directory','empty-file'])
except BaseException as error:result.update(state='failed',error=repr(error));raise
finally:
 result.update(inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in original['frozen_inputs'].items()),head_unchanged=git('rev-parse','HEAD').decode().strip()==original['head'],index_unchanged=sha(git('ls-files','--stage','-z'))==original['index_sha256'],protected_binaries_unchanged=all(sha(Path(p).read_bytes())==d for p,d in original['protected_binaries'].items()),original_wrapper_unchanged=original_path.read_bytes()==original_bytes,log_sha256=sha(LOG.read_bytes()) if LOG.exists() else None,original_build_log_sha256=original['log_sha256'],finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 if not all(result[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged','original_wrapper_unchanged']):result['state']='failed'
 save()
assert result['state']=='passed';print('Actual completed Gena4Nixchecks/214controls independently verified; original wrapper stillfailed;0 builds replayed.',flush=True)
