"""Prepare exact independent-case appends; do not mutate the frozen worktree."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-gentle-command')
OUT = PREP/'gentle-command-ledger-promotion-preflight.json'
assert not OUT.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
source_raw = (WORK/'tests/fixtures/gentle-command-source.json').read_bytes()
suite_raw = (WORK/'tests/fixtures/gentle-command-validity.json').read_bytes()
parent_raw = (WORK/'tests/fixtures/validity.json').read_bytes()
reviews_raw = (WORK/'docs/inventory-reviews.json').read_bytes()
assert sha(suite_raw) == 'bd886ed1a45ebcf67e2cfbc3e123f33ca3f0cb33b449cc88a99f58bab6b21fb7'
assert sha(parent_raw) == 'e5bf297ad75bfec83b8836c16e718796827deb71caf96f4332979e4102cad88e'
assert sha(reviews_raw) == 'fd6a487eeaf98e0166f04115f1d3c664d695f4b1e2dc88a2cd47faac8a018950'
source,suite,parent,reviews = [json.loads(raw) for raw in [source_raw,suite_raw,parent_raw,reviews_raw]]
assert len(parent['cases']) == 35681 and len(reviews['entries']) == 515
dump = lambda value: (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
assert dump(parent) == parent_raw and dump(reviews) == reviews_raw, 'original canonical serialization'
spec = importlib.util.spec_from_file_location('inventory',WORK/'tools/review_inventory.py')
inventory = importlib.util.module_from_spec(spec);spec.loader.exec_module(inventory)
scope = ('Bounded structural coverage of original ending owners 79340 and 79343: canonical 으렴, '
         'short 렴 after vowel or ㄹ verb stems and full 으렴 after other codas. All eight complete '
         'original Native example groups have independently authored typed lemma/role/morpheme/rule '
         'targets. Complete original source fields, homonyms, dialogue and trailing spaces are retained. '
         'The exact 23 preauthored judgments cover 15 required source, regular/irregular allomorph and '
         'auxiliary paths plus eight forbidden allomorph/known copula/derived-adjective paths. '
         'Original Native owners receive separate POS/allomorph compatibility assessments; valid '
         'unknown alternatives are preserved. Source and runtime audits retain all original baselines, '
         'and the catalog cites only the two original ending owners. This is structural scope, '
         'not a contextual sense, pragmatic/register or full-entry precision certification.')
remaining = ('Unlisted past, modal and honorific prefinals and outer particles retain Unknown compatibility; '
             'these source entries do not attest their licenses. Wider predicate/auxiliary/particle interactions, '
             'source register and social conditions, contextual sense choice and independent Korean-language '
             'review remain open. Eighteen new legacy raw paths and five novel-policy records remain '
             'contextually unjudged; the novel 주렴 noun inference is bounded and does not forbid the valid '
             'standalone 주다 command or import a missing noun into KRDict. No all-Korean or semantic precision claim.')
new_reviews = []
for ident in source['ending_owner_ids']:
    owner = source['owners'][ident]
    citations = [{'case':c['id'],'judgment':j['id']} for c in suite['cases'] for j in c['judgments']
                 if c['id'].startswith('gentle-command-'+ident.split(':')[1]+'-')
                 and j['verdict'] == 'required' and suite['sources'][j['source']] == owner['url']]
    assert len(citations) == 4
    new_reviews.append(dict(id=ident,source_sha256=inventory.digest(inventory.source_entry(owner)),
        status='scoped',checklist=['COV-017cz'],scope=scope,remaining=remaining,
        evidence=[dict(path='tests/gentle_command.rs',test=name) for name in [
            'all_independent_source_stem_class_and_auxiliary_judgments_pass',
            'required_paths_keep_native_owners_ordered_components_and_unicode',
            'native_import_preserves_every_complete_field_and_homonym',
            'verb_and_adjective_homonyms_receive_separate_ending_assessments',
            'unlisted_prefinal_combinations_keep_unknown_compatibility']]
            +[dict(path=path) for path in ['tests/fixtures/gentle-command-source.json',
                    'docs/gentle-command-runtime-proof-archive.json','tools/gentle_command_source_audit.py',
                    'tools/gentle_command_runtime_audit.py']],judgments=citations))
scoped = dict(schema_version=1,review_status=reviews['review_status'],entries=new_reviews)
current = {**parent,'sources':dict(parent['sources']),'cases':list(parent['cases'])+suite['cases']}
assert not set(suite['sources']) & set(parent['sources']), 'new independent citation aliases'
current['sources'].update(suite['sources'])
current_reviews = {**reviews,'entries':list(reviews['entries'])+new_reviews}
raw = dump(current); review_raw = dump(current_reviews)
case_body = lambda b:b.split(b'"cases": [',1)[1].rsplit(b'\n  ]\n}',1)[0]
assert case_body(raw).startswith(case_body(parent_raw))
assert current['cases'][:35681] == parent['cases'] and current['cases'][35681:] == suite['cases']
assert current_reviews['entries'][:515] == reviews['entries']
assert len({c['id'] for c in current['cases']}) == len(current['cases']) == 35704
counts = {v:sum(j['verdict']==v for c in current['cases'] for j in c['judgments']) for v in ['required','forbidden']}
assert counts == {'required':31427,'forbidden':4294}
files = {}
for name,payload in [('gentle-command-parent-validity.json.gz',gzip.compress(parent_raw,mtime=0)),
                     ('gentle-command-parent-inventory-reviews.json.gz',gzip.compress(reviews_raw,mtime=0)),
                     ('gentle-command-proposed-validity.json.gz',gzip.compress(raw,mtime=0)),
                     ('gentle-command-proposed-inventory-reviews.json.gz',gzip.compress(review_raw,mtime=0)),
                     ('gentle-command-scoped-reviews.json',dump(scoped))]:
    path = PREP/name;assert not path.exists();path.write_bytes(payload)
    files[name] = dict(path=str(path),sha256=sha(payload))
assert all((WORK/name).read_bytes() == original for name,original in [
    ('tests/fixtures/validity.json',parent_raw),('docs/inventory-reviews.json',reviews_raw),
    ('tests/fixtures/gentle-command-source.json',source_raw),('tests/fixtures/gentle-command-validity.json',suite_raw)])
r = dict(state='draft-prepared-not-promoted',parent_case_count=35681,proposed_case_count=35704,
         added_cases=23,added_required=15,added_forbidden=8,proposed_counts=counts,
         original_reviews=515,proposed_reviews=517,proposed_unreviewed=198,
         exact_parent_case_bytes_sha256=sha(case_body(parent_raw)),
         exact_parent_case_bytes=len(case_body(parent_raw)),
         source_sha256=sha(source_raw),private_suite_sha256=sha(suite_raw),
         parent_raw_sha256=sha(parent_raw),parent_reviews_raw_sha256=sha(reviews_raw),
         proposed_raw_sha256=sha(raw),proposed_reviews_raw_sha256=sha(review_raw),
         scoped_reviews_raw_sha256=sha(dump(scoped)),files=files,
         frozen_branch_source_unchanged=True,
         promotion_preconditions=['Actual current Nix packages passed with frozen source',
             'Actual installed36source/47Native/66570gold/1128312broad comparison',
             'Actual installed Solid23case/138policy/sixexport/47Native browser proof',
             'End all dependent source freezes before mutation; preserve every old case/source/review byte',
             'Wire strict independently pinned append audit and corruption controls; no unjudged novel/history promotion'],
         producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
         full_coverage_complete=False)
OUT.write_bytes(dump(r))
print('Prepared exact 23-case and two-scoped-review append; every original35681case/515review preserved. Frozen branch unchanged.',flush=True)
