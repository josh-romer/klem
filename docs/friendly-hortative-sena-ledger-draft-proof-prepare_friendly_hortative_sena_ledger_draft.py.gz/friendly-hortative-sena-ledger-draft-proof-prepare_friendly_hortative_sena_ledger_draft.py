"""Prepare the original Sena cases against the current promoted Gena parent."""
import copy
import datetime
import gzip
import hashlib
import json
import subprocess
import sys
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = P.parents[1]
GENA = ROOT / '.direnv/friendly-command-gena'
SENA = ROOT / '.direnv/friendly-hortative-sena'
DRAFT = P / 'friendly-hortative-sena-promotion-draft'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
sys.path.insert(0, str(ROOT / 'tools'))
from native_lmf import entry
from review_inventory import digest, source_entry


def git_state(work):
    git = lambda *args: subprocess.check_output(['git', *args], cwd=work)
    assert not git('status', '--porcelain')
    return dict(head=git('rev-parse', 'HEAD').decode().strip(), index_sha256=sha(git('ls-files', '--stage', '-z')))


def main():
    assert not DRAFT.exists(), 'never overwrite an earlier draft'
    states = {name: git_state(work) for name, work in [('gena', GENA), ('sena', SENA)]}
    original_paths = {
        'parent-validity.json': GENA / 'tests/fixtures/validity.json',
        'parent-inventory-reviews.json': GENA / 'docs/inventory-reviews.json',
        'parent-inventory-review-queue.json': GENA / 'docs/inventory-review-queue.json',
        'sena-original-validity.json': SENA / 'tests/fixtures/friendly-hortative-sena-validity.json',
        'sena-reviewed-source.json': SENA / 'tests/fixtures/friendly-hortative-sena-source.json',
        'sena-original-source-manifest.json': SENA / 'docs/friendly-hortative-sena-source-baseline-proof-archive.json',
    }
    originals = {name: path.read_bytes() for name, path in original_paths.items()}
    parent, reviews, queue, suite, author = [json.loads(originals[name]) for name in [
        'parent-validity.json', 'parent-inventory-reviews.json', 'parent-inventory-review-queue.json',
        'sena-original-validity.json', 'sena-reviewed-source.json']]
    assert len(parent['cases']) == 35764 and len(reviews['entries']) == 520 and len(queue['entries']) == 715
    assert sha(originals['sena-original-validity.json']) == 'd85973f2aa29dc5f82b3710f23b46f7dad8e67785cbf4b04d8edfc81056f91be'
    assert sha(originals['sena-original-source-manifest.json']) == '1a2e9d3f9430b00c743e47ef262623ab19e33c29429af8a9fe50a72e34a3257b'
    assert len(suite['cases']) == 25 and not author['candidate_runtime_observed']
    assert author['suite_sha256'] == sha(originals['sena-original-validity.json'])
    assert all(not j.get('required_rules') for c in suite['cases'] for j in c['judgments'])
    counts = {kind: sum(j['verdict'] == kind for c in suite['cases'] for j in c['judgments']) for kind in ['required', 'forbidden']}
    assert counts == dict(required=19, forbidden=6)
    assert not {c['id'] for c in parent['cases']} & {c['id'] for c in suite['cases']}
    assert all(k not in parent['sources'] or parent['sources'][k] == value for k, value in suite['sources'].items())
    owner = author['owners']['krdict:78469']
    assert entry(author['original_lmf']['krdict:78469']) == owner
    queued = next(row for row in queue['entries'] if row['source']['id'] == owner['id'])
    assert queued['source'] == source_entry(owner) and queued['source_sha256'] == digest(queued['source'])
    assert queued['review']['status'] == 'unreviewed' and all(r['id'] != owner['id'] for r in reviews['entries'])
    original_groups = suite['cases'][:5]
    assert [c['surface'] for c in original_groups] == ['하세나', '지켜보세나', '그만두세나', '사세나', '일하세나']
    candidate = copy.deepcopy(parent)
    candidate['cases'].extend(copy.deepcopy(suite['cases']))
    candidate['sources'].update(suite['sources'])
    review = dict(id=owner['id'], source_sha256=queued['source_sha256'], status='scoped', checklist=['COV-017dc'],
                  scope='Proposed finite structural coverage of the complete original -세나 entry: five original example groups and dialogue, the exact 25 preauthored cases (19 required and six forbidden), consonant-initial attachment and ㄹ deletion, verbal honorifics and attached auxiliaries, known bare adjective/copula/답다 and invalid irregular boundaries. Canonical target authoring predates runtime and intentionally contains no new rule-ID requirements. This is an external draft; all actual installed validation and integration gates are prerequisites for shared promotion.',
                  remaining='Other prefinals, honorific adjective/copula predicates and outer particles remain Unknown where not licensed. The original 중세나 corpus observation retains its noun gold, complete sentence and additional unjudged word hypothesis. Contextual homonym/sense choice, social appropriateness, wider register and independent Korean-language review remain separate. Quiet performance and complete main integration remain required; this draft certifies neither.',
                  evidence=[dict(path=name) for name in [
                      'tests/friendly_hortative_sena.rs', 'tests/fixtures/friendly-hortative-sena-source.json',
                      'tests/fixtures/friendly-hortative-sena-validity.json',
                      'docs/friendly-hortative-sena-source-baseline-proof-archive.json',
                      'docs/friendly-hortative-sena-wide-proof-archive.json',
                      'docs/friendly-hortative-sena-corpus-regression-proof-archive.json',
                      'tools/friendly_hortative_sena_source_audit.py', 'tools/friendly_hortative_sena_runtime_audit.py']],
                  judgments=[dict(case=c['id'], judgment=j['id']) for c in original_groups for j in c['judgments']])
    proposed_reviews = copy.deepcopy(reviews)
    proposed_reviews['entries'].append(review)
    DRAFT.mkdir()
    files = {}
    for name, raw in originals.items():
        packed = gzip.compress(raw, mtime=0)
        (DRAFT / (name + '.gz')).write_bytes(packed)
        files[name] = dict(original_path=str(original_paths[name]), source_sha256=sha(raw), archive_sha256=sha(packed))
    outputs = {
        'proposed-cases.json': dict(sources=suite['sources'], cases=suite['cases']),
        'proposed-scoped-reviews.json': dict(entries=[review]),
        'proposed-validity.json': candidate,
        'proposed-inventory-reviews.json': proposed_reviews,
    }
    for name, value in outputs.items():
        raw = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
        (DRAFT / name).write_bytes(raw)
        files[name] = dict(source_sha256=sha(raw))
    record = dict(state='prepared-not-promoted', prepared_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  reference_parent_states=states, parent_cases=35764, proposed_cases=35789,
                  parent_reviews=520, proposed_reviews=521, unreviewed_after_promotion=194,
                  added_cases=25, added_required=19, added_forbidden=6,
                  original_authoring_precedes_runtime=True, review_draft_authored_after_runtime=True,
                  original_unjudged_corpus_hypothesis_promoted=False, shared_ledger_changed=False,
                  reference_queue_may_receive_later_evidence_updates=True,
                  prerequisites=['Both actual complete four-check Nix gates passed with full source bindings.',
                                 'Both actual four-package builds, original full installed replays and packaged browsers passed.',
                                 'Actual 33 Gena and 40 Sena installed controls passed; screenshots visually inspected.',
                                 'Integrate the validated Gena parent into Sena, retain fresh parent queue evidence, then run actual promotion/full Rust/Nix/installed/main checks.'],
                  files=files, full_coverage_complete=False,
                  producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())))
    (DRAFT / 'draft.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    assert all(path.read_bytes() == originals[name] for name, path in original_paths.items())
    assert {name: git_state(work) for name, work in [('gena', GENA), ('sena', SENA)]} == states
    print('Prepared exact 25 original Sena cases and one bounded review: proposed35789cases/521reviews; actual shared ledger unchanged.', flush=True)


if __name__ == '__main__':
    main()
