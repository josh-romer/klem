"""Execute the original library doctest omitted by Cargo's metadata target loop."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-command-gena'
OUT = P / 'friendly-command-gena-promotion-doctest.json'
LOG = P / 'friendly-command-gena-promotion-doctest.log'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    assert not OUT.exists() and not LOG.exists()
    audit_path = P / 'friendly-command-gena-promotion-full-rust-results-audit.json'
    audit = json.loads(audit_path.read_bytes())
    original = json.loads((P / 'friendly-command-gena-promotion-full-rust.json').read_bytes())
    assert audit['state'] == 'passed' and audit['targets'] == 260 and audit['commands'] == 264
    assert sha((P / 'friendly-command-gena-promotion-full-rust.json').read_bytes()) == audit['original_receipt_sha256']
    git = lambda *args: subprocess.check_output(['git', *args], cwd=W)
    frozen, protected = original['frozen_inputs'], original['protected_binaries']
    assert all(sha((W / name).read_bytes()) == digest for name, digest in frozen.items())
    assert all(sha(Path(name).read_bytes()) == digest for name, digest in protected.items())
    assert git('rev-parse', 'HEAD').decode().strip() == original['head']
    assert sha(git('ls-files', '--stage', '-z')) == original['index_sha256']
    command = ['cargo', 'test', '--locked', '--offline', '--features', 'web', '--doc']
    r = dict(state='running', command=command, head=original['head'], index_sha256=original['index_sha256'],
             frozen_inputs=frozen, protected_binaries=protected,
             all_target_audit_sha256=sha(audit_path.read_bytes()),
             producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
             started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             scope='Actual original lib.rs documentation test supplementation after complete260-target/264-command results audit. Retains the default cargo test doctest scope omitted by metadata targets; no passing target rerun. Same frozen promotion source, HEAD, index and six protected binaries. No Nix/package/browser/main/timing/context/register/independent-review claim.')
    def save(): OUT.write_text(json.dumps(r, indent=2) + '\n')
    save()
    try:
        with LOG.open('xb') as log:
            metadata_command = original['cargo_metadata_command']
            log.write(('COMMAND ' + json.dumps(metadata_command) + '\n').encode()); log.flush()
            metadata = subprocess.run(metadata_command, cwd=W, env=dict(os.environ, **original['environment_overrides']), stdout=subprocess.PIPE, stderr=log)
            r.update(metadata_exit_code=metadata.returncode, current_metadata_raw=metadata.stdout.decode(), current_metadata_sha256=sha(metadata.stdout))
            save()
            assert metadata.returncode == 0
            assert json.loads(metadata.stdout) == original['cargo_metadata']
            assert sha(metadata.stdout) == original['cargo_metadata_sha256'], 'fresh authoritative complete Cargo inventory equals original captured metadata'
            r['current_cargo_inventory_verified'] = True
            log.write(('COMMAND ' + json.dumps(command) + '\n').encode()); log.flush()
            job = subprocess.run(command, cwd=W, env=dict(os.environ, **original['environment_overrides']), stdout=log, stderr=subprocess.STDOUT)
            r['exit_code'] = job.returncode
            assert job.returncode == 0
        text = LOG.read_text()
        batches = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, flags=re.M)
        assert batches == [('ok', '1', '0', '0')] and 'test src/lib.rs - (line 3) ... ok' in text
        r.update(state='passed', rust_totals=dict(passed=1, failed=0, ignored=0), rust_batches=1,
                 combined_rust_totals={key: audit['totals'][key] + (1 if key == 'passed' else 0) for key in ['passed', 'failed', 'ignored']},
                 combined_rust_batches=audit['batches'] + 1, combined_commands=audit['commands'] + 1)
    except BaseException as error:
        r.update(state='failed', error=repr(error)); raise
    finally:
        names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').decode().split('\0')[:-1]
        r.update(inputs_unchanged=set(names) == set(frozen) and all(sha((W / n).read_bytes()) == d for n, d in frozen.items()),
                 head_unchanged=git('rev-parse', 'HEAD').decode().strip() == original['head'],
                 index_unchanged=sha(git('ls-files', '--stage', '-z')) == original['index_sha256'],
                 protected_binaries_unchanged=all(sha(Path(n).read_bytes()) == d for n, d in protected.items()),
                 log_sha256=sha(LOG.read_bytes()) if LOG.exists() else None,
                 finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
        if not all(r[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged']): r['state'] = 'failed'
        save()
    assert r['state'] == 'passed'
    print('Original doctest passed; combined full Rust scope:', r['combined_rust_totals'], r['combined_rust_batches'], 'batches.', flush=True)


if __name__ == '__main__': main()
