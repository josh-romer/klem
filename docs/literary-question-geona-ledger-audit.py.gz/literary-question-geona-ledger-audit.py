"""Independently audit proposed finite raw judgments and the actual complete CLI transcripts."""
import collections,gzip,hashlib,json,unicodedata
from pathlib import Path
P=Path('/tmp/klem-literary-question-geona-prototype/tests/fixtures')
def read(p):
 p=Path(p);return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
def verify(proposal,replay,base,original,boundary,owner):
 cases=proposal['new_cases'];assert len(cases)==61 and len({c['id'] for c in cases})==61,'case count/IDs'
 expected={c['id']:c for c in original};expected.update({c['id']:c for c in boundary['cases']+owner['cases'] if c['proposal'] in {'required','forbidden'}})
 assert set(expected)=={c['id'] for c in cases},'finite scope'
 excluded={c['id']:c['proposal'] for c in boundary['cases']+owner['cases'] if c['proposal'] not in {'required','forbidden'}}
 assert len(excluded)==21 and {c['id']:c['proposal'] for c in proposal['excluded_conditional_native_cases']}==excluded,'conditional/Native exclusions'
 assert proposal['before_case_count']==len(base['cases'])==34920,'old case count'
 ledger=proposal['proposed_ledger'];assert ledger['cases']==base['cases']+cases,'append-only old case prefix'
 assert ledger['schema_version']==base['schema_version'] and ledger['review_status']==base['review_status'],'old scope preserved'
 assert ledger['sources']=={**base['sources'],**{f'literary-question-geona-{i}':f'https://krdict.korean.go.kr/kor/dicSearch/SearchView?ParaWordNo={i}' for i in [80970,80972]}},'exact original source IDs'
 counts=collections.Counter()
 for c in cases:
  source=expected[c['id']];assert c['surface']==source['surface'],'original surface'
  assert len(c['judgments'])==1,'single exact path';j=c['judgments'][0];e=source.get('expected',source)
  for key in ['lemmas','lemma_kinds','morphemes','morpheme_kinds','required_rules']:assert j[key]==e[key],'typed exact path '+key
  assert j['verdict']==source.get('proposal','required'),'structural verdict'
  sid=source['source_occurrence']['source'].split(':')[1] if 'source_occurrence' in source else '80970' if c['surface'].endswith('을거나') else '80972'
  assert j['source']=='literary-question-geona-'+sid,'original allomorph source'
  assert 'independent review' in j['reason'].lower() and 'unjudged' in j['reason'].lower() or 'remain separate' in j['reason'],'review limit retained'
  counts[j['verdict']]+=1
 assert counts=={'required':50,'forbidden':11} and proposal['new_counts']==dict(counts),'new finite counts'
 runs=replay['runs'];assert len(runs)==2 and {r['unicode'] for r in runs}=={'NFC','NFD'},'complete Unicode runs'
 actual=[]
 for r in runs:
  form=r['unicode'];text='\n'.join(unicodedata.normalize(form,c['surface']) for c in cases)+'\n'
  assert r['stdin']==text and r['exit_code']==0 and r['stderr']=='','successful exact command input'
  assert r['sha256']==hashlib.sha256(r['jsonl'].encode()).hexdigest(),'full raw stream hash'
  rows=list(map(json.loads,r['jsonl'].splitlines()));assert len(rows)==122,'all122original frames';words=[];offset=0
  for row in rows:
   raw=row['surface'].encode();assert row['span']=={'start':offset,'end':offset+len(raw)},'exact original UTF8 spans';offset+=len(raw)
   if row.get('analysis'):assert row['kind']=='word';words.append(row)
   else:assert row['kind']=='whitespace' and row['surface']=='\n','whitespace retained'
  assert ''.join(row['surface'] for row in rows)==text and len(words)==61,'entire original input conserved'
  for c,row in zip(cases,words,strict=True):
   assert row['surface']==unicodedata.normalize(form,c['surface']) and row['analysis']['normalized']==c['surface'],'Unicode input and normalization'
   j=c['judgments'][0];matches=[a for a in row['analysis']['analyses'] if [l['text'] for l in a['lemmas']]==j['lemmas'] and [l['kind'] for l in a['lemmas']]==j['lemma_kinds'] and [m['form'] for m in a['morphemes']]==j['morphemes'] and [m['kind'] for m in a['morphemes']]==j['morpheme_kinds'] and set(j['required_rules'])<=set(a['rules'])]
   assert bool(matches)==(j['verdict']=='required'),'required presence/forbidden exact absence'
   actual.append({'id':c['id'],'unicode':form,'verdict':j['verdict'],'matching_paths':matches,'record':row})
 assert replay['observations']==actual,'complete individual observations'
 return {'new_cases':61,'required':50,'forbidden':11,'retained_old_cases':34920,'excluded':21,'actual_frames':244,'individual_observations':122}
def inputs():
 return [read('/tmp/klem-literary-question-geona-proposed-ledger.json.gz'),read('/tmp/klem-literary-question-geona-proposed-ledger-check.json.gz'),read(P/'validity.json'),read(P/'literary-question-geona-original-cases.json'),read(P/'literary-question-geona-authored-boundaries.json'),read(P/'literary-question-geona-owner-extension-cases.json')]
if __name__=='__main__':print('Independently verified finite raw scope, complete original inputs/transcripts and append-only proposal:',verify(*inputs()))
