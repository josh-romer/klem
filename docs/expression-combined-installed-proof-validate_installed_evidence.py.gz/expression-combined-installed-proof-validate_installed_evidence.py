"""Audit new installed captures without editing the still-frozen integration source."""
import gzip
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

prep = Path(__file__).resolve().parent
work = Path('/tmp/klem-expression-conjectural-main')
root = prep / 'installed-audit-inputs'
out = prep / 'combined-installed-evidence-audit.json'
assert not root.exists() and not out.exists()
(root / 'docs').mkdir(parents=True)
(root / 'tools').mkdir()
(root / 'tests').symlink_to(work / 'tests', target_is_directory=True)
(root / 'web').symlink_to(work / 'web', target_is_directory=True)
references = [
    'conjectural-additive-phase2-copula-source-streams.json.gz',
    'conjectural-additive-phase2-copula-cli-streams.json.gz',
    'conjectural-additive-novel-context-prototype-regressions-retry1.json.gz',
    'conjectural-additive-phase2-copula-cohorts.json.gz',
    'conjectural-additive-phase2-copula-corpora.json.gz',
    'conjectural-additive-phase2-copula-broad.json.gz',
    'formal-volitional-expression-source-streams.json.gz',
    'conjectural-additive-original-native-closure.json.gz',
    'conjectural-additive-phase2-copula-native-closure.json.gz',
    'conjectural-additive-novel-context-native-closure.json.gz',
]
for name in references:
    (root / 'docs' / name).symlink_to(work / 'docs' / name)
families = ['source', 'copula', 'novel', 'cohorts', 'gold', 'broad', 'expression']
names = ['combined-installed-source-binding.json', 'combined-installed-release-tests.json',
         'combined-installed-release-tests.log', 'combined-installed-browser.json',
         'combined-installed-browser-runtime.json', 'combined-browser.mjs',
         'run_installed_browser.py']
for family in families:
    name = 'combined-installed-' + family + '.json.gz'
    d = json.loads(gzip.decompress((prep / name).read_bytes()))
    assert d['state'] == 'passed' and d['inputs_unchanged']
    names.append(name)
for name in names:
    source = prep / name
    target = root / 'docs' / ('expression-combined-installed-proof-' + name + ('' if name.endswith('.gz') else '.gz'))
    target.write_bytes(source.read_bytes() if name.endswith('.gz') else gzip.compress(source.read_bytes(), mtime=0))
for name in ['expression_conjectural_installed_audit.py', 'test_expression_conjectural_installed_audit.py']:
    (root / 'tools' / name).write_bytes((prep / name).read_bytes())
sha = lambda path: hashlib.file_digest(Path(path).open('rb'), 'sha256').hexdigest()
frozen_paths = [p for p in (root / 'docs').iterdir() if p.is_file()]
frozen_paths.extend((root / 'tools').glob('*.py'))
frozen_paths.extend([work / 'web/src/grammar-labels.json', Path(__file__)])
frozen_paths.extend((work / 'tests/fixtures' / name) for name in [
    'conjectural-additive-validity.json', 'conjectural-additive-copula-validity.json',
    'conjectural-additive-novel-validity.json', 'formal-volitional-expression-validity.json',
    'formal-volitional-expression-native-entries.json'])
frozen_paths.extend((work / 'tools' / name) for name in [
    'conjectural_additive_novel_audit.py', 'formal_volitional_browser_audit.py'])
frozen = {str(p): sha(p) for p in frozen_paths}
env = dict(os.environ, PYTHONPATH=str(root / 'tools') + os.pathsep + str(work / 'tools'), PYTHONDONTWRITEBYTECODE='1')
commands = [[sys.executable, str(root / 'tools/expression_conjectural_installed_audit.py')],
            [sys.executable, '-m', 'unittest', 'test_expression_conjectural_installed_audit', '-v']]
receipt = {'state': 'running', 'frozen_inputs': frozen, 'commands': [],
           'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))}}
out.write_text(json.dumps(receipt, indent=2) + '\n')
try:
    for i, command in enumerate(commands):
        log = prep / ('combined-installed-evidence-audit-' + str(i) + '.log')
        with log.open('xb') as stream:
            result = subprocess.run(command, env=env, cwd=root / 'tools', stdout=stream, stderr=subprocess.STDOUT)
        receipt['commands'].append({'command': command, 'exit_code': result.returncode,
                                    'log': str(log), 'log_sha256': sha(log)})
        assert result.returncode == 0, log
    receipt.update(state='passed', exit_code=0, inputs_unchanged=all(sha(p) == digest for p, digest in frozen.items()))
    assert receipt['inputs_unchanged']
except Exception as error:
    receipt.update(state='failed', error=str(error))
    raise
finally:
    out.write_text(json.dumps(receipt, indent=2) + '\n')
print('Independent installed evidence audit and negative controls passed')
