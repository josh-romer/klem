"""Preserve complete expression evidence outside the four-POS coverage inventory."""
import gzip,hashlib,json,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'.direnv/formal-b-prototype/tools'))
from native_lmf import entry,feature
ids={f'krdict:{i}' for i in [86336,86337,86338,86339,86674,86678,86680,86683,86687,86692]}
DB=(ROOT/'data/dictionaries/krdict/krdict.db').resolve()
with sqlite3.connect(DB.as_uri()+'?mode=ro',uri=True) as db:
 imported={ident:json.loads(raw) for ident,raw in db.execute('select id,data from entries where id in ('+','.join('?' for _ in ids)+') order by id',sorted(ids))}
assert set(imported)==ids and all(e['pos']=='품사 없음' for e in imported.values())
raw_entries={};exports={}
for p in sorted((ROOT/'.direnv/dictionary-restoration/2026-09').rglob('*.json')):
 raw=p.read_bytes();selected=[]
 for value in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
  ident='krdict:'+str(value.get('val'))
  if ident not in ids or feature(value,'lexicalUnit') in {'관용구','속담'}:continue
  assert ident not in raw_entries
  assert entry(value)==imported[ident]
  raw_entries[ident]=value;selected.append(ident)
 if selected:exports[p.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'ids':selected}
assert set(raw_entries)==ids
text='';groups=[]
for ident,value in imported.items():
 for sense in value['senses']:
  for ordinal,lines in enumerate(sense['examples'],1):
   start=len(text.encode());block='\n'.join(lines);text+=block+'\n'
   groups.append({'id':f"reported-experience-source-{ident.split(':')[1]}-{sense['id']}-{ordinal}",'entry_id':ident,'sense_id':sense['id'],'group':ordinal,'complete_original_examples':lines,'span':{'start':start,'end':start+len(block.encode())},'contextual_verdict':'unjudged','independent_review':'pending'})
fixture={'LexicalResource':{'Lexicon':{'LexicalEntry':[raw_entries[i] for i in sorted(raw_entries)]}}}
(OUT/'native.json').write_text(json.dumps(fixture,ensure_ascii=False,indent=2)+'\n')
report={'state':'complete-original-expression-sources-preserved','complete_imported_entries':imported,'original_native_entries':raw_entries,'complete_groups':groups,'complete_source_text':text,'source_text_sha256':hashlib.sha256(text.encode()).hexdigest(),'source_exports':exports,'native_fixture_sha256':hashlib.sha256((OUT/'native.json').read_bytes()).hexdigest(),'producer':{'text':Path(__file__).read_text(),'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},'scope':'Ten original reported-experience expressions retain POS 품사 없음 and all source notes/senses/example groups, outside the 715-entry four-POS inventory. No authored judgments or implementation yet. Preserve the cross-source 했답디까 example under -는답디까 and distinct command, copular/factual and emphatic senses of -랍디까/-랍디다. Formal literal endings alone do not establish these contractions.','full_coverage_complete':False}
(OUT/'source-preparation.json.gz').write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Preserved',len(imported),'expression entries and',len(groups),'complete original groups',flush=True)
for ident,e in imported.items():print(ident,e['headword'],e['notes'],[(s['id'],s['notes'],s['patterns']) for s in e['senses']],flush=True)
