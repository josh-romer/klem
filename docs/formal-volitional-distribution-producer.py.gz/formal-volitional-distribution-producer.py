"""Archive complete captures without claiming the pending browser or integration gates."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
PREP = ROOT / '.direnv/formal-volitional-prepared'
PROTO = ROOT / '.direnv/formal-volitional-prototype'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def read(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)


controls = {}
for name, count in [('source', 30), ('cohort', 5), ('corpora', 10), ('broad', 23)]:
    log = PREP / (name + '-controls' + ('-retry1' if name == 'broad' else '') + '.log')
    text = log.read_text()
    assert f'Ran {count} tests' in text and text.rstrip().endswith('OK'), name
    controls[name] = count
cohorts = read(PREP / 'cohorts.json.gz')
gold = read(PREP / 'corpora.json.gz')
broad = read(PREP / 'broad.json.gz')
assert cohorts['state'] == 'complete-corpus-history-preservation-passed'
assert gold['state'] == 'passed' and broad['state'] == 'draft-complete-broad-preservation-passed'
assert all(report['inputs_unchanged'] for report in [cohorts, gold, broad])
assert sum(run['surfaces'] for run in cohorts['runs']) == 53502
assert all(not run['changed_words'] for run in cohorts['runs'])
assert len(gold['runs']) == 4 and sum(run['rows'] for run in gold['runs']) == 66570
assert not gold['individual_changed_rows'] and all(not r['summary_changes'] for r in gold['runs'])
assert len(broad['comparisons']) == 8 and sum(run['records'] for run in broad['comparisons']) == 1128312
assert len(broad['individual_additions']) == 32
assert len(broad['individual_spacing_additions']) == len(broad['individual_probe_diagnostics']) == 2
assert all(o['contextual_verdict'] == 'unjudged' for o in broad['individual_additions'])
assert all(o['contextual_verdict'] == 'unjudged' for o in broad['individual_spacing_additions'])
suite = read(PROTO / 'tests/fixtures/formal-volitional-validity.json')
assert sha((PROTO / 'tests/fixtures/formal-volitional-validity.json').read_bytes()) == read(PREP / 'independent-authoring.json')['suite_sha256']
assert len(suite['cases']) == 59
novel = read(PROTO / 'tests/fixtures/formal-volitional-novel-validity.json')
assert [case['surface'] for case in novel['cases']] == ['되렵니다', '가렵니다', '버리렵니다', '뜯어먹으렵니다']
assert all(len(c['judgments']) == 1 and c['judgments'][0]['verdict'] == 'required' for c in novel['cases'])
native = read(PROTO / 'tests/fixtures/formal-volitional-novel-native.json')
assert sha(json.dumps(native, ensure_ascii=False, sort_keys=True).encode()) == '8ef49d8a69358d3fdef5c0c74d72930a409a5a6d824512736d4634c068d193e8'
protected = {p: sha((ROOT / p).read_bytes()) for p in ['tests/fixtures/validity.json', 'docs/inventory-reviews.json']}
archives = {}


def archive(path, label):
    raw = path.read_bytes()
    target = ROOT / 'docs' / ('formal-volitional-distribution-' + label + ('' if label.endswith('.gz') else '.gz'))
    assert not target.exists(), target
    target.write_bytes(raw if path.suffix == '.gz' else gzip.compress(raw, mtime=0))
    archives[target.name] = {'sha256': sha(target.read_bytes()), 'original_sha256': sha(raw)}


for name in [
    'source-audit.log', 'source-audit-retry1.log', 'source-controls.log',
    'capture_cohorts.py', 'capture_cohorts.log', 'cohorts.json.gz', 'cohort-audit.log', 'cohort-controls.log',
    'capture_corpora.py', 'capture_corpora.log', 'corpora.json.gz', 'corpora-audit.log', 'corpora-controls.log',
    'capture_broad.py', 'capture_broad.log', 'broad.json.gz', 'broad-audit.log', 'broad-controls.log',
    'broad-audit-retry1.log', 'broad-audit-retry2.log', 'broad-controls-retry1.log',
    'novel-preparation.json', 'frontend-preparation.json', 'frontend-build.log',
    'supplemental-audit-dependencies.json', 'supplemental-example-module-inputs.json', 'adapter-build.log',
    'distribution-archive.log',
]:
    archive(PREP / name, name)
for name in ['source', 'cohort', 'corpora', 'broad']:
    for prefix in ['', 'test_']:
        filename = prefix + 'formal_volitional_' + name + '_audit.py'
        archive(PROTO / 'tools' / filename, filename)
for name in ['native', 'entries', 'history', 'validity']:
    filename = 'formal-volitional-novel-' + name + '.json'
    archive(PROTO / 'tests/fixtures' / filename, filename)
archive(PROTO / 'tests/formal_volitional_novel.rs', 'novel-regressions-prepared.rs')
proof = {
    'state': 'complete-private-source-and-distribution-captures-passed',
    'original_source_groups': 17, 'source_controls': controls['source'],
    'cohort_words': 53502, 'cohort_changes': 0, 'gold_rows': 66570, 'gold_changes': 0,
    'broad_frames': 1128312, 'new_paths': 32, 'new_spacing': 2, 'probe_diagnostics': 2,
    'novel_native_owners': 11, 'manually_reviewed_novel_targets': 4,
    'audit_controls': controls, 'authored_cases': 59, 'original_judgments_unchanged': True,
    'novel_rust_regressions': 'prepared, not executed', 'frontend_build': 'passed',
    'browser': 'not executed', 'main_implementation': 'not integrated',
    'full_coverage_complete': False, 'archives': archives,
    'scope': 'Actual complete private captures and independent audits. All original judgments and prior ordered paths/assessments retained. Four lexical novel targets are manually reviewed; all32observed paths and two spacing options remain separately unjudged. Initial source-audit homonym assumption, broad invocation failure and earlier control logs retained. Whole-parent restoration, raw53+novel4 ledger appends, dictionary59 regressions, novel Rust, browser, whole Rust, actual Nix/installed/main integration, quiet performance and broader contextual/independent review remain required. Expression owners89455/89456 are distinct from the four ending owners and remain separately unreviewed.',
    'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())},
}
(ROOT / 'docs/formal-volitional-distribution-validation.json.gz').write_bytes(
    gzip.compress((json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
archive(Path(__file__), 'producer.py')
assert all(sha((ROOT / p).read_bytes()) == digest for p, digest in protected.items())
print('Archived complete53502word/66570gold/1128312frame private evidence; 30/5/10/23 controls; browser and integration pending', flush=True)
