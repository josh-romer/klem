"""Read source targets independently, then preserve their exact pre-change outputs."""
import gzip,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
readings={83919:[('났기로서','나다',['었','기로서']),('없기로서','없다',['기로서']),('쳤기로서','치다',['었','기로서']),('바쁘기로서','바쁘다',['기로서'])],83918:[('급하기로서니','급하다',['기로서니']),('아름답기로서니','아름답다',['기로서니']),('어른스럽기로서니','어른스럽다',['기로서니']),('취했기로서니','취하다',['었','기로서니'])]}
prepared=json.loads(gzip.decompress((OUT/'source-preparation.json.gz').read_bytes()));proposals=[]
# Author all eight readings before invoking any lemmatizer.
for group in prepared['complete_groups']:
 ident=int(group['source_entry_id'].split(':')[1]);surface,lemma,morphs=readings[ident][group['group_ordinal']];text='\n'.join(group['complete_original_group']);offset=text.encode().find(surface.encode());assert offset>=0
 proposals.append({'id':group['id']+'-byte-'+str(offset),'source_group_id':group['id'],'source_entry_id':group['source_entry_id'],'surface':surface,'proposed_lemmas':[lemma],'proposed_morphemes':morphs,'complete_original_group':group['complete_original_group'],'surface_byte_offset':offset,'review_status':'Agent-authored structural source reading; does not select a homonym sense or certify contextual precision. Independent Korean review pending.'})
assert len(proposals)==8 and len({p['id'] for p in proposals})==8
(OUT/'authored-proposals.json').write_text(json.dumps(proposals,ensure_ascii=False,indent=2)+'\n')
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
cli=ROOT/'.direnv/reported-experience-target/debug/klem';db=ROOT/'data/dictionaries/krdict/krdict.db';frozen={str(p):sha(p) for p in [cli,db,Path(__file__),OUT/'source-preparation.json.gz',OUT/'authored-proposals.json']}
for proposal in proposals:
 records={}
 for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
  command=[str(cli),'word',proposal['surface'],'--dictionary',str(db),*flags];job=subprocess.run(command,cwd=ROOT,capture_output=True,check=True);assert not job.stderr
  value=json.loads(job.stdout);records[mode]={'command':command,'analysis':{k:value[k] for k in ['normalized','analyses']},'dictionary':value['dictionary'],'exit_code':0,'stdout_sha256':hashlib.sha256(job.stdout).hexdigest()}
 proposal['baseline_records']=records
assert all(sha(p)==digest for p,digest in frozen.items())
report={'state':'independent-source-proposals-and-exact-baselines-preserved','proposals':proposals,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'All8original source groups receive independently authored targets before any engine observation, then exact3filter-mode baselines from actual reported-experience prototype1115test source. These observations are not promoted to additional gold.'}
(OUT/'proposals.json.gz').write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Authored8source targets before engine observation;preserved24actualbaseline records',flush=True)
