"""Restore the exact parent without overwrites and append independent judgments only."""
import gzip
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
PARENT = BASE / 'familiar-geurae-integration'
ROOT = BASE / 'fear-lsera-prototype'
PREP = BASE / 'fear-lsera-prepared'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=PARENT, text=True).strip()
assert head.startswith('d2deff5'), 'exact actual parent'
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=PARENT).decode().split('\0')[:-1]
allowed = {'src/engine.rs', 'src/grammar.rs', 'src/bin/klem-web/grammar_labels.rs', 'web/src/grammar-labels.json'}
existing = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in ROOT.rglob('*')
            if p.is_file() and not {'node_modules', 'dist', '__pycache__'} & set(p.parts)}
# Check all differences before copying any missing file.
for name in tracked:
    target = ROOT / name
    if target.exists():
        assert name in allowed or target.read_bytes() == (PARENT / name).read_bytes(), ('unexpected parent difference', name)
missing = []
for name in tracked:
    source, target = PARENT / name, ROOT / name
    if target.exists():
        continue
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    missing.append({'path': name, 'sha256': sha(source.read_bytes())})
assert all(sha((ROOT / name).read_bytes()) == value for name, value in existing.items()), 'all private inputs conserved'
path = ROOT / 'tests/fixtures/validity.json'
raw = path.read_bytes()
ledger = json.loads(raw)
parent = json.loads((PARENT / 'tests/fixtures/validity.json').read_bytes())
assert ledger == parent and len(ledger['cases']) == 35484
suite_path = ROOT / 'tests/fixtures/fear-lsera-validity.json'
suite = json.loads(suite_path.read_bytes())
authored = json.loads((PREP / 'independent-authoring.json').read_bytes())
assert sha(suite_path.read_bytes()) == authored['suite_sha256']
assert len(suite['cases']) == 46 and not set(ledger['sources']) & set(suite['sources'])
assert not {case['id'] for case in ledger['cases']} & {case['id'] for case in suite['cases']}
ledger['cases'].extend(suite['cases'])
ledger['sources'].update(suite['sources'])
assert ledger['cases'][:35484] == parent['cases'] and ledger['cases'][35484:] == suite['cases']
assert {k:v for k,v in ledger.items() if k not in ['cases','sources']} == {k:v for k,v in parent.items() if k not in ['cases','sources']}
counts = {v: sum(j['verdict'] == v for case in ledger['cases'] for j in case['judgments']) for v in ['required', 'forbidden']}
assert counts == {'required': 31300, 'forbidden': 4246}
path.write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n')
registry = ROOT / 'tools/literary_question_geona_runtime.py'
text = registry.read_text()
assert 'fear-lsera-validity.json' not in text
marker = "    ('familiar-geurae-validity.json',27,'e2b927b7691731277b429a7322639d26562b9946741d1bcd029943d87d61f9f5','familiar-geurae'),\n"
assert text.count(marker) == 1
addition = "    ('fear-lsera-validity.json',46,'" + authored['suite_sha256'] + "','fear-lsera'),\n"
registry.write_text(text.replace(marker, marker + addition))
receipt = {'state': 'exact-parent-restored-and-authored-append-preserved', 'parent': head,
           'restored_files': missing, 'existing_files_conserved': len(existing), 'previous_cases': 35484,
           'cases': len(ledger['cases']), 'before_sha256': sha(raw), 'after_sha256': sha(path.read_bytes()),
           'suite_sha256': sha(suite_path.read_bytes()), 'counts': counts,
           'scope': 'Every existing private file and all35484parent cases/source/metadata preserved exactly. '
                    'Only46independently authored37required/9forbidden Source and boundary cases appended. '
                    'Observed628alternative paths remain contextually unjudged and are not added as gold.'}
(PREP / 'shared-ledger-append.json').write_text(json.dumps(receipt, indent=2) + '\n')
(ROOT / 'docs/fear-lsera-shared-ledger-append.json.gz').write_bytes(gzip.compress((json.dumps(receipt, indent=2) + '\n').encode(), mtime=0))
print('Restored', len(missing), 'files; preserved', len(existing), 'private inputs; ledger35484+46=', len(ledger['cases']), counts, flush=True)
