"""Replay complete prior fixture surfaces with stable individual new-path provenance."""
import datetime
import gzip
import hashlib
import json
import sys
from pathlib import Path

ROOT=Path('/home/josh/projects/klem')
sys.path.insert(0,str(ROOT/'tools'))
from doeda_native_corpora import words_from_cli

OLD=Path('/nix/store/zzzi7ks8mnfl9cypx630yyszhwpnxfjy-klem-0.1.0/bin/klem')
NEW=Path('/tmp/klem-literary-future-kko-catalog-cli')
PRIOR=ROOT/'docs/literary-question-go-prototype-legacy-history.json.gz'
OUTPUT=Path('/tmp/klem-literary-future-kko-prototype-legacy-history.json.gz')
assert not OUTPUT.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
digest=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
prior=json.loads(gzip.decompress(PRIOR.read_bytes()))
sources={}
origins={}
fields={'before_words','before_analyses','source_before_analyses','source_cohort_before_analyses'}

def add(surface,name,pointer):
    item={'source':name,'source_sha256':sources[name],'pointer':pointer}
    if item not in origins.setdefault(surface,[]):origins[surface].append(item)

def visit(v,name,pointer=''):
    if isinstance(v,dict):
        if isinstance(v.get('surface'),str) and isinstance(v.get('before'),dict) and 'analyses' in v['before']:
            add(v['surface'],name,pointer+'/before')
        for key,item in v.items():
            at=pointer+'/'+key
            if key in fields and isinstance(item,dict):
                for surface in item:add(surface,name,at+'/'+surface)
            else:visit(item,name,at)
    elif isinstance(v,list):
        for i,item in enumerate(v):visit(item,name,pointer+'/'+str(i))

for name,h in prior['source_files_sha256'].items():
    assert sha(ROOT/name)==h
    sources[name]=h
    visit(json.loads((ROOT/name).read_bytes()),name)
assert len(sources)==51 and len(origins)>=21353
for name in ['tests/fixtures/literary-question-go-original-cases.json','tests/fixtures/literary-question-go-mode-scope.json','tests/fixtures/literary-question-go-authored-boundaries.json','tests/fixtures/literary-question-go-spacing-boundaries.json']:
    sources[name]=sha(ROOT/name)
    visit(json.loads((ROOT/name).read_bytes()),name)
producer=Path(__file__)
frozen={str(p):sha(p) for p in [OLD,NEW,PRIOR,producer,ROOT/'tools/doeda_native_corpora.py']}
print('Capturing complete older current-main candidates:',len(origins),'surfaces',flush=True)
before=words_from_cli(OLD,sorted(origins))
print('Capturing complete new isolated candidates',flush=True)
after=words_from_cli(NEW,sorted(origins))
changes={}
observations=[]
for surface,b in before.items():
    a=after[surface]
    assert {k:v for k,v in b.items() if k!='analyses'}=={k:v for k,v in a.items() if k!='analyses'}
    assert [p for p in a['analyses'] if p in b['analyses']]==b['analyses'],surface
    if a==b:continue
    additions=[]
    for candidate in a['analyses']:
        if candidate in b['analyses']:continue
        assert 'ending.literary_future_question_kko' in candidate['rules'],(surface,candidate)
        observation={'id':'literary-future-kko-legacy-'+digest([surface,candidate])[:24],
                     'surface':surface,'analysis':candidate,'origins':origins[surface],
                     'structural_verdict':'unjudged broader composition','contextual_verdict':'unjudged','independent_review':'pending'}
        additions.append(observation)
        observations.append(observation)
    changes[surface]={'before':b,'after':a,'origins':origins[surface],'additions':additions}
assert all(sha(ROOT/name)==h for name,h in sources.items())
assert all(sha(p)==h for p,h in frozen.items())
report={'schema_version':1,'state':'complete-legacy-candidate-preservation-passed',
        'source_files_sha256':sources,'before_cli_sha256':sha(OLD),'cli_sha256':sha(NEW),
        'surfaces':len(origins),'changed_words':len(changes),'added_paths':len(observations),
        'before_words':before,'after_words':after,'before_words_sha256':digest(before),'after_words_sha256':digest(after),
        'changes':changes,'individual_additions':observations,'origins':origins,
        'frozen_inputs':frozen,'inputs_unchanged':True,
        'producer':{'text':producer.read_text(),'sha256':sha(producer)},
        'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope':'Actual full current-main/prototype WordAnalysis replay for all51 immutable older fixture cohorts and the complete literary-question-go original/mode/authored/spacing fixtures. Every prior candidate retains exact fields and relative order; new alternatives have stable per-path IDs and original fixture pointers. No older fixtures or judgments rewritten. Preservation alone does not establish precision, lexical licensing, contextual speaker attitude or independent review.',
        'contextual_verdict':'unjudged','independent_review':'pending'}
OUTPUT.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Preserved',len(sources),'archives,',len(origins),'surfaces;',len(changes),'changed words,',len(observations),'unjudged additions.',flush=True)
