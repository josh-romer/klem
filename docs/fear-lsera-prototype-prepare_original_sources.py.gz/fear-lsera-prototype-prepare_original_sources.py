"""Preserve complete original entries and author lexical targets before baseline probes."""
import gzip
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
PREP = BASE / 'fear-lsera-prepared'
sys.path.insert(0, str(BASE / 'familiar-geurae-prototype/tools'))
from native_lmf import entry, feature

sha = lambda raw: hashlib.sha256(raw).hexdigest()
database = BASE / 'dictionary-restoration/krdict.db'
db = sqlite3.connect(database.resolve().as_uri() + '?mode=ro', uri=True)
source_ids = ['krdict:86497', 'krdict:86619']
owners = {ident: json.loads(db.execute('select data from entries where id=?', (ident,)).fetchone()[0]) for ident in source_ids}
# Every target is manually selected from the complete original source groups.
# No engine output is read while constructing this proposal.
targets = [
    ('볼세라', '보다', []), ('놓칠세라', '놓치다', []), ('질세라', '지다', []),
    ('들릴세라', '들리다', []), ('뒤질세라', '뒤지다', []), ('버릴세라', '버리다', []),
    ('걸릴세라', '걸리다', []), ('깨질세라', '깨지다', []), ('잃어버릴세라', '잃어버리다', []),
    ('따뜻할세라', '따뜻하다', []), ('아늑할세라', '아늑하다', []), ('훌륭할세라', '훌륭하다', []),
    ('넓으실세라', '넓다', ['시']), ('들을세라', '듣다', []), ('집을세라', '집다', []),
    ('갔을세라', '가다', ['었']), ('눈치챘을세라', '눈치채다', ['었']), ('닳을세라', '닳다', []),
    ('낡을세라', '낡다', []), ('들을세라', '듣다', []), ('묻을세라', '묻다', []),
    ('넓을세라', '넓다', []), ('좋을세라', '좋다', []), ('맑을세라', '맑다', []), ('밝을세라', '밝다', []),
]
groups = []
for ident, owner in owners.items():
    assert owner['id'] == ident and owner['pos'] == '어미'
    for sense in owner['senses']:
        for ordinal, lines in enumerate(sense['examples'], 1):
            groups.append({'id': f'fear-lsera-{ident.split(":")[1]}-sense-{sense["id"]}-group-{ordinal}',
                           'source_entry_id': ident, 'source_headword': owner['headword'], 'sense_id': sense['id'],
                           'group_ordinal': ordinal - 1, 'complete_original_group': lines,
                           'source_notes': owner['notes'], 'sense_notes': sense['notes'], 'definition': sense['definition']})
assert len(groups) == len(targets) == 25
proposals = []
for group, (surface, lemma, prefinals) in zip(groups, targets, strict=True):
    raw = '\n'.join(group['complete_original_group']).encode()
    assert raw.count(surface.encode()) == 1, group['id']
    proposals.append({'id': group['id'], 'surface': surface, 'surface_byte_offset': raw.index(surface.encode()),
                      'source_entry_id': group['source_entry_id'], 'sense_id': group['sense_id'],
                      'complete_original_group': group['complete_original_group'], 'proposed_lemmas': [lemma],
                      'proposed_lemma_kinds': ['predicate'], 'proposed_morphemes': [*prefinals, '을세라'],
                      'proposed_morpheme_kinds': ['prefinal'] * len(prefinals) + ['ending'],
                      'proposed_required_rules': ['ending.apprehensive_lsera'],
                      'scope': 'Independent structural target in complete original context; three source senses remain separate. Canonical 을세라 represents the original short/full allomorph pair. No candidate or contextual homonym sense is certified.'})
needed = set(owners)
lexical_heads = {lemma for _, lemma, _ in targets} | {'이다', '아니다'}
for headword in lexical_heads:
    for ident, raw in db.execute('select id,data from entries where headword=?', (headword,)):
        value = json.loads(raw)
        if value['lexical_unit'] == '단어':
            needed.add(ident)
expected = {ident: json.loads(db.execute('select data from entries where id=?', (ident,)).fetchone()[0]) for ident in sorted(needed)}
originals, exports = {}, {}
for path in sorted((BASE / 'dictionary-restoration/2026-09').glob('*.json')):
    raw = path.read_bytes()
    selected = []
    for value in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
        ident = 'krdict:' + value['val']
        if ident not in needed or feature(value, 'lexicalUnit') in {'관용구', '속담'}:
            continue
        assert ident not in originals and entry(value) == expected[ident], ident
        originals[ident] = value
        selected.append(ident)
    if selected:
        exports[path.name] = {'bytes': len(raw), 'sha256': sha(raw), 'ids': selected}
assert set(originals) == needed and all(entry(value) == expected[ident] for ident, value in originals.items())
producer = {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())}
prepared = {'state': 'complete-original-sources-and-independent-proposals-before-baseline',
            'expression_entries': owners, 'complete_groups': groups,
            'complete_source_text': '\n'.join(line for group in groups for line in group['complete_original_group']),
            'complete_imported_entries': expected, 'original_native_entries': originals,
            'original_exports': exports, 'dictionary_metadata': dict(db.execute('select key,value from metadata')),
            'independent_proposals': proposals, 'producer': producer,
            'scope': 'Both original ending entries, every sense, all25complete groups, original attachment notes and full Native lexical homonyms preserved before any baseline probe or implementation. Wider examples, boundary judgments, implementation/corpus/browser/Nix/performance/integration and independent linguistic review remain.'}
path = PREP / 'source-preparation.json.gz'
assert not path.exists()
path.write_bytes(gzip.compress((json.dumps(prepared, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
(PREP / 'independent-source-proposals.json').write_text(json.dumps({'state': 'authored-before-baseline-and-implementation',
            'source_preparation_sha256': sha(path.read_bytes()), 'proposals': proposals, 'producer': producer}, ensure_ascii=False, indent=2) + '\n')
print('Preserved two ending identities,25complete groups,25independent targets and', len(originals), 'full Native owners before baseline observation', flush=True)
