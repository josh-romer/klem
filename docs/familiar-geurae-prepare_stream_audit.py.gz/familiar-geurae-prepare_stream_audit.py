"""Adapt complete stream invariants to the separately captured particle family."""
import gzip
import json
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
PARENT = BASE / 'explanatory-se-integration'
ROOT = BASE / 'familiar-geurae-prototype'
PREP = BASE / 'familiar-geurae-prepared'
code = (PARENT / 'tools/explanatory_se_streams_audit.py').read_text()
code = code.replace('explanatory-se', 'familiar-geurae')
code = code.replace('len(rows) == 317', 'len(rows) == 43')
code = code.replace("['ending.explanatory_se','particle.familiar_gryeo']", "['particle.familiar_geurae']")
code = code.replace('len(additions) == 632', 'len(additions) == 152')
code = code.replace('92adfb02498e840ec7808d906a1cd5b44f4e045ae09bf8fdd5198c0350391a4b', '33ae7ea88f3d97bda6309532f43c5dd9e2bf127acd8beffdba22ef6508300f55')
code = code.replace('len(entries) == 80', 'len(entries) == 50')
code = code.replace("authored['entries']", "authored['complete_imported_entries']")
code = code.replace("len(authored['complete_imported_entries']) == 57", "len(authored['complete_imported_entries']) == 45")
start = code.index("== {'krdict:50557'")
end = code.index(", 'complete additional homonym exports'", start)
code = code[:start] + "== {'krdict:65194', 'krdict:65195', 'krdict:65198', 'krdict:65199', 'krdict:89775'}" + code[end:]
code = code.replace('docs/familiar-geurae-authored-native-closure.json.gz', 'docs/familiar-geurae-full-native-preparation.json.gz')
target = ROOT / 'tools/familiar_geurae_streams_audit.py'
assert not target.exists() or target.read_text() == code
target.write_text(code)
tests = (PARENT / 'tools/test_explanatory_se_streams_audit.py').read_text()
tests = tests.replace('explanatory_se_streams_audit', 'familiar_geurae_streams_audit').replace('3804', '516').replace('krdict:65980', 'krdict:65194')
(ROOT / 'tools/test_familiar_geurae_streams_audit.py').write_text(tests)
streams = json.loads(gzip.decompress((PREP / 'source-streams.json.gz').read_bytes()))
assert len(streams['individual_additions']) == 152
for name in ['source-streams.json.gz', 'native-closure.json.gz']:
    (ROOT / 'docs' / ('familiar-geurae-' + name)).write_bytes((PREP / name).read_bytes())
(ROOT / 'tests/fixtures/familiar-geurae-source-observations.json').write_text(json.dumps(streams['individual_additions'], ensure_ascii=False, indent=2) + '\n')
rust = (PARENT / 'tests/explanatory_se.rs').read_text()
start = rust.index('#[test]\nfn every_observed_source_path_has_exact_complete_native_ownership()')
end = rust.find('\n#[test]', start + 1)
if end < 0:
    end = len(rust)
test = rust[start:end].replace('explanatory-se', 'familiar-geurae').replace('entries.len(), 80', 'entries.len(), 50').replace('observations.len(), 632', 'observations.len(), 152')
rust_target = ROOT / 'tests/familiar_geurae.rs'
assert 'every_observed_source_path_has_exact_complete_native_ownership' not in rust_target.read_text()
rust_target.write_text(rust_target.read_text() + '\n' + test + '\n')
print('Prepared complete12stream/152path/50Native audit,18controls and fourth Rust regression', flush=True)
