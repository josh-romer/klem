"""Extend only the independently authored expression ledger in a separate branch."""
import copy
import gzip
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

BASE = Path('/home/josh/projects/klem')
PREP = BASE / '.direnv/formal-volitional-expression-prepared'
WORK = BASE / '.direnv/formal-volitional-expression-integration'
PARENT = BASE / '.direnv/formal-volitional-integration'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', '--short', 'HEAD'], cwd=WORK, text=True).strip() == 'ffa542f'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
assert not (PREP / 'library-preparation.json').exists()
protected = {str(p.relative_to(WORK)): sha(p.read_bytes())
             for folder in ['src', 'web/src'] for p in (WORK / folder).rglob('*') if p.is_file()}
suite_path = BASE / 'tests/fixtures/formal-volitional-expression-validity.json'
suite = json.loads(suite_path.read_bytes())
packet = json.loads(gzip.decompress((BASE / 'docs/formal-volitional-expression-source-preparation.json.gz').read_bytes()))
assert len(suite['cases']) == 8
assert suite['sources'] == {ident: owner['url'] for ident, owner in packet['expression_entries'].items()}
assert suite['cases'] == [{'id': proposal['id'], 'surface': proposal['surface'], 'judgments': [proposal['judgment']]}
                          for proposal in packet['independent_proposals']]
for source in sorted((BASE / 'docs').glob('formal-volitional-expression-*')):
    target = WORK / 'docs' / source.name
    assert not target.exists()
    shutil.copyfile(source, target)
for name in ['formal_volitional_expression_audit.py', 'test_formal_volitional_expression_audit.py',
             'formal_volitional_expression_streams_audit.py', 'test_formal_volitional_expression_streams_audit.py']:
    source = BASE / 'tools' / name
    target = WORK / 'tools' / name
    assert not target.exists()
    shutil.copyfile(source, target)
shutil.copyfile(suite_path, WORK / 'tests/fixtures' / suite_path.name)
native = {'LexicalResource': {'Lexicon': {'LexicalEntry': list(packet['original_native_entries'].values())}}}
fixtures = WORK / 'tests/fixtures'
(fixtures / 'formal-volitional-expression-native.json').write_text(json.dumps(native, ensure_ascii=False, indent=2) + '\n')
(fixtures / 'formal-volitional-expression-native-entries.json').write_text(json.dumps(packet['complete_imported_entries'], ensure_ascii=False, indent=2) + '\n')
assert len(packet['original_native_entries']) == 16
prior = json.loads((WORK / 'tests/fixtures/validity.json').read_bytes())
assert prior == json.loads((PARENT / 'tests/fixtures/validity.json').read_bytes())
assert len(prior['cases']) == 35587 and not set(prior['sources']) & set(suite['sources'])
assert not {c['id'] for c in prior['cases']} & {c['id'] for c in suite['cases']}
current = copy.deepcopy(prior)
current['cases'].extend(suite['cases'])
current['sources'].update(suite['sources'])
assert current['cases'][:35587] == prior['cases']
assert {k: v for k, v in current.items() if k not in ['sources', 'cases']} == {k: v for k, v in prior.items() if k not in ['sources', 'cases']}
counts = {v: sum(j['verdict'] == v for c in current['cases'] for j in c['judgments']) for v in ['required', 'forbidden']}
assert counts == {'required': 31345, 'forbidden': 4266}
(fixtures / 'validity.json').write_text(json.dumps(current, ensure_ascii=False, indent=2) + '\n')
path = WORK / 'tests/validity.rs'
text = path.read_text()
assert text.count('assert_eq!(report.required_total, 31337);') == 1
path.write_text(text.replace('assert_eq!(report.required_total, 31337);', 'assert_eq!(report.required_total, 31345);'))
path = WORK / 'tools/literary_question_geona_runtime.py'
text = path.read_text()
marker = "    ('formal-volitional-novel-validity.json',4,'db0853ac54c5ca0ab8995511e6d40f4c20b1a9b1020b9358a31d9ee19efaea41','formal-volitional novel'),\n"
assert text.count(marker) == 1
text = text.replace(marker, marker + "    ('formal-volitional-expression-validity.json',8,'" + sha(suite_path.read_bytes()) + "','formal-volitional expression'),\n")
path.write_text(text)
path = WORK / 'tools/test_literary_question_geona_runtime.py'
text = path.read_text()
old = "'formal-volitional-novel-validity.json']"
assert text.count(old) == 2
text = text.replace(old, "'formal-volitional-novel-validity.json','formal-volitional-expression-validity.json']")
marker = "if __name__=='__main__':unittest.main()"
assert text.count(marker) == 1
tests = ''' def test_exact_pre_formal_expression_ledger_still_passes(self):
  self.assertEqual(audit.verify_ledger(self.ledger_through(35587),self.proposal)['preserved_cases'],34920)
 def test_formal_expression_case_order_cannot_change(self):
  c=copy.deepcopy(self.current);c['cases'][35587],c['cases'][35588]=c['cases'][35588],c['cases'][35587]
  with self.assertRaisesRegex(AssertionError,'append-only ledger'):audit.verify_ledger(c,self.proposal)
 def test_formal_expression_source_cannot_borrow_ending_owner(self):
  c=copy.deepcopy(self.current);c['sources']['krdict:89455']='https://krdict.korean.go.kr/kor/dicSearch/SearchView?ParaWordNo=86548'
  with self.assertRaisesRegex(AssertionError,'append-only ledger'):audit.verify_ledger(c,self.proposal)
 def test_coordinated_formal_expression_fixture_rewrite(self):
  self.coordinated_append_mutation('formal-volitional-expression-validity.json',35594,'formal-volitional expression')
'''
path.write_text(text.replace(marker, tests + marker))
assert all(sha((WORK / relative).read_bytes()) == digest for relative, digest in protected.items())
proof = {'state': 'expression-library-regressions-prepared', 'parent': 'ffa542f',
         'original_cases': 35587, 'new_cases': 8, 'ledger_cases': 35595, 'counts': counts,
         'suite_sha256': sha(suite_path.read_bytes()), 'original16_native_owners': True,
         'protected_runtime_sources': protected, 'runtime_sources_unchanged': True,
         'scope': 'Separate branch, exact35587prefix and original59ending/4novel judgments preserved. Only8 independently authored expression judgments appended. Application/label/attachment code unchanged. Library/ledger/audits/browser/installed/Nix/main validation and separate expression dispositions remain open.',
         'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())}}
(PREP / 'library-preparation.json').write_text(json.dumps(proof, indent=2) + '\n')
print('Prepared original16Native owners and8exact ledger appends;35595total/31345required/4266forbidden; no runtime/label changes')
