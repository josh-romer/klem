import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=Path('/home/josh/projects/klem/.direnv/friendly-command-gena')
O=P/'friendly-command-gena-ledger-draft-validation-retry1.json';L=P/'friendly-command-gena-ledger-draft-validation-retry1.log'
assert not O.exists() and not L.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
names=subprocess.check_output(['git','ls-files','-z'],cwd=W).decode().split('\0')[:-1]
frozen={str(W/n):sha((W/n).read_bytes()) for n in names}
for name in ['friendly_command_gena_ledger_audit.py','test_friendly_command_gena_ledger_audit.py','prepare_friendly_command_gena_ledger_draft.py',Path(__file__).name]:frozen[str(P/name)]=sha((P/name).read_bytes())
for path in (P/'friendly-command-gena-promotion-draft').iterdir():frozen[str(path)]=sha(path.read_bytes())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))
assert head=='6cf27565c7891005de12651abcb7f18911495adf' and not subprocess.check_output(['git','status','--porcelain'],cwd=W)
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),results=[],started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Actual external DRAFT audit of exact35740-parent plus24preauthoredGena cases/oneboundedreview; all519originalreviews/715queue unchanged;24corruptioncontrols. Actualshared ledger remains35740/519. CompleteNix gates/liveSource immutable, currentinstalledcontrols independentlypassed. Lateractualselectedsource/promoted/main checks required; fullchecklist incomplete.')
def save():O.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save();env=dict(os.environ,PYTHONPATH=str(P)+os.pathsep+str(W/'tools'),PYTHONDONTWRITEBYTECODE='1',KLEM_GENA_PROMOTION_DRAFT='1')
commands=[['python3',str(P/'friendly_command_gena_ledger_audit.py'),'--draft'],['python3','-m','unittest','discover','-s',str(P),'-p','test_friendly_command_gena_ledger_audit.py','-v']]
with L.open('xb') as log:
 for command in commands:
  job=subprocess.run(command,cwd=W,env=env,capture_output=True);raw=job.stdout+job.stderr;log.write(raw);log.flush();count=re.search(rb'Ran (\d+) tests',raw);r['results'].append(dict(command=command,exit_code=job.returncode,controls=int(count.group(1)) if count else 0));save()
  if job.returncode:break
r.update(inputs_unchanged=all(sha(Path(p).read_bytes())==d for p,d in frozen.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==head,index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))==index,controls=sum(x['controls'] for x in r['results']),log_sha256=sha(L.read_bytes()),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
r['state']='passed' if len(r['results'])==2 and all(x['exit_code']==0 for x in r['results']) and r['controls']==24 and all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged']) else 'failed'
save();print(L.read_text(),flush=True);print(r['state'],r['controls'],'actual Gena ledger DRAFT controls; sharedledger unchanged',flush=True);raise SystemExit(0 if r['state']=='passed' else 1)
