"""Preserve every Native owner identity without merging lexical homonyms."""
import gzip
import hashlib
import json
import sqlite3
import sys
import zipfile
from pathlib import Path

ROOT = Path('/home/josh/projects/klem/.direnv/coverage-integration')
DB = Path('/home/josh/projects/klem/data/dictionaries/krdict/krdict.db')
ZIP = Path('/home/josh/projects/klem/data/dictionaries/krdict/2026-09.zip')
SOURCE = Path('/tmp/klem-dapnikka-source-preparation.json.gz')
OUT = Path('/tmp/klem-dapnikka-native-closure.json.gz')
FIXTURE = Path('/tmp/klem-dapnikka-native.json')
assert not OUT.exists() and not FIXTURE.exists()
sys.path.insert(0, str(ROOT / 'tools'))
from native_lmf import entry, feature

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

prepared = json.loads(gzip.decompress(SOURCE.read_bytes()))
heads = {lemma for proposal in prepared['proposals'] for lemma in proposal['proposed_lemmas']}
heads |= {'예쁘다', '바쁘다', '좋다', '읽다', '먹다', '아니다', '이다', '없다', '있다', '곱다', '춥다', '돕다', '듣다', '낫다', '짓다', '푸다', '부르다', '놀다', '달다'}
with sqlite3.connect(DB.resolve().as_uri() + '?mode=ro', uri=True) as db:
    owners = {ident: json.loads(raw) for ident, raw in db.execute('select id,data from entries where headword in (' + ','.join('?' for _ in heads) + ')', sorted(heads))}
assert {e['headword'] for e in owners.values()} == heads
expected = {**prepared['complete_imported_entries'], **owners}
raw_entries = dict(prepared['original_native_entries'])
needed = set(expected) - set(raw_entries)
exports = {}
with zipfile.ZipFile(ZIP) as archive:
    for name in archive.namelist():
        if not name.endswith('.json'):
            continue
        raw = archive.read(name)
        values = json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']
        selected = []
        for value in values:
            ident = 'krdict:' + str(value.get('val'))
            if ident not in needed or feature(value, 'lexicalUnit') in {'관용구', '속담'}:
                continue
            assert ident not in raw_entries, 'Native owner collision'
            projected = entry(value)
            assert projected == expected[ident], (ident, 'complete source projection')
            raw_entries[ident] = value
            selected.append(ident)
        if selected:
            exports[name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw), 'ids': selected}
assert set(raw_entries) == set(expected)
assert {ident: entry(raw) for ident, raw in raw_entries.items()} == expected
fixture = {'LexicalResource': {'Lexicon': {'LexicalEntry': [raw_entries[i] for i in sorted(raw_entries)]}}}
FIXTURE.write_text(json.dumps(fixture, ensure_ascii=False, indent=2) + '\n')
frozen = {str(p): sha(p) for p in [SOURCE, DB, ZIP, Path(__file__), ROOT / 'tools/native_lmf.py']}
report = {'state': 'complete-source-and-owner-native-closure-passed', 'entries': expected, 'owner_headwords': sorted(heads), 'source_exports': exports, 'fixture': str(FIXTURE), 'fixture_sha256': sha(FIXTURE), 'frozen_inputs': frozen, 'inputs_unchanged': all(sha(p) == digest for p, digest in frozen.items()), 'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)}, 'scope': 'All46authored source target headwords, finite boundary/spelling controls and all lexical homonyms retain complete original Native entries. Ending/expression owners stay separate; idioms never replace parent word IDs. This supplies fixture evidence, not an implementation or contextual linguistic judgment.', 'full_coverage_complete': False}
assert report['inputs_unchanged']
OUT.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
print('Preserved', len(expected), 'complete Native identities across', len(heads), 'owner headwords', flush=True)
