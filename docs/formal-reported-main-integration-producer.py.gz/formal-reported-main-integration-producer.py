"""Record the actual merged main tree and its unchanged installed package sources."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

assert not git('status', '--porcelain'), 'main must be clean before proof capture'
head = git('rev-parse', 'HEAD').decode().strip()
parents = git('show', '-s', '--format=%P', head).decode().split()
prep = json.loads((ROOT / '.direnv/formal-reported-main-integration-preparation.json').read_text())
assert parents == [prep['previous_main'], prep['integration_parent']]
assert git('rev-parse', head + '^{tree}') == git('rev-parse', prep['integration_parent'] + '^{tree}'), 'actual complete merged tree'
binding = json.loads((ROOT / '.direnv/reported-experience-prepared/installed-source-binding.json').read_text())
assert binding['state'] == 'passed' and binding['exit_code'] == 0
profiles = {}
for name, profile in binding['profiles'].items():
    source = Path(profile['source'])
    local_source = ROOT / 'web' if name == 'web-assets' else ROOT
    files = {}
    for relative, expected in profile['files'].items():
        raw = (local_source / relative).read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        assert raw == (source / relative).read_bytes(), relative
        assert digest == expected['sha256'] and len(raw) == expected['bytes'], relative
        files[relative] = {'bytes': len(raw), 'sha256': digest}
    profiles[name] = {'source': str(source), 'package': profile['package'], 'files': files}
assert {name: len(p['files']) for name, p in profiles.items()} == {'klem': 1015, 'web-assets': 18, 'corpus-adapter': 1015}
old = json.loads(git('show', prep['previous_main'] + ':tests/fixtures/validity.json'))
new = json.loads((ROOT / 'tests/fixtures/validity.json').read_text())
assert new['cases'][:len(old['cases'])] == old['cases'], 'exact previous-main ledger prefix'
proof = {'state': 'passed', 'head': head, 'parents': parents, 'tree': git('rev-parse', head + '^{tree}').decode().strip(),
         'all_parent_tracked_bytes_identical': True, 'actual_installed_profiles': profiles,
         'previous_main_cases': len(old['cases']), 'main_cases': len(new['cases']), 'exact_previous_main_ledger_prefix': True,
         'scope': 'Actual local main merge with complete tree equality to validated integration and byte equality to every actual installed Rust/frontend/adapter source. Quiet performance, wider coverage and contextual/independent review remain open.'}
docs = ROOT / 'docs'
(docs / 'formal-reported-main-integration.json.gz').write_bytes(gzip.compress((json.dumps(proof, indent=2) + '\n').encode(), mtime=0))
(docs / 'formal-reported-main-integration-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
tracker = docs / 'coverage-checklist.md'
text = tracker.read_text()
text = text.replace('Partial: finite original source scope implemented in the private formal-ending prototype.', 'Partial: finite original source scope implemented and merged into main.')
text = text.replace('Partial: finite original source scope implemented on coverage/reported-experience.', 'Partial: finite original source scope implemented and merged into main.')
text = text.replace('Remaining: main merge, quiet novel performance,', 'The [main integration proof](formal-reported-main-integration.json.gz) verifies the actual merge and all installed source bytes. Remaining: quiet novel performance,')
text = text.replace('at 9841000 with all tracked inputs and HEAD/index unchanged. Remaining:\n  main integration, quiet performance, wider', 'at 9841000 with all tracked inputs and HEAD/index unchanged. The\n  [main integration proof](formal-reported-main-integration.json.gz) verifies\n  merge 170e773 and every installed source byte. Remaining: quiet performance, wider')
tracker.write_text(text)
for name in ['formal-b-draft.md', 'reported-experience-draft.md']:
    p = docs / name
    text = p.read_text().replace('main integration, ', '').replace('main merge, ', '')
    text += '\nLocal main integration is complete at `170e773`. The [actual merge proof](formal-reported-main-integration.json.gz) records both parents, complete tree equality to the validated branch, every installed source byte, and the exact previous-main ledger prefix. Quiet performance and wider/contextual/independent review remain open.\n'
    p.write_text(text)
reviews = docs / 'inventory-reviews.json'
data = json.loads(reviews.read_text())
changed = 0
for entry in data['entries']:
    if any(item['path'] == 'docs/formal-b-draft.md' for item in entry['evidence']):
        entry['evidence'].append({'path': 'docs/formal-reported-main-integration.json.gz'})
        changed += 1
assert changed == 10, changed
reviews.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
print('Actual merge and installed source proof passed; ledger prefix', len(old['cases']), '->', len(new['cases']), '; updated', changed, 'finite reviews', flush=True)
