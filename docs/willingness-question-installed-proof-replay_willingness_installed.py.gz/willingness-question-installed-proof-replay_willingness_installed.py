"""Replay the complete committed prototype captures through the actual Nix outputs."""
import argparse,datetime,gzip,hashlib,json,os,subprocess,sys,unicodedata
from pathlib import Path
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('family',choices=['source','cohorts','gold','broad']);args=parser.parse_args()
prep=Path(__file__).resolve().parent;work=Path('/tmp/klem-willingness-question-prototype');main=Path('/home/josh/projects/klem')
binding_path=prep/'willingness-installed-source-binding-retry1.json';out=prep/('willingness-installed-'+args.family+'.json.gz');progress=prep/('willingness-installed-'+args.family+'-progress.json')
assert not out.exists() and not progress.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest();digest=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
binding=read(binding_path);assert binding['state']=='passed' and binding['all_tracked_inputs_unchanged']
cli=Path(binding['profiles']['klem']['package'])/'bin/klem';adapter=Path(binding['profiles']['corpus-adapter']['package'])/'bin/klem-corpus-adapter';db=main/'.direnv/dictionary-restoration/krdict.db'
frozen={str(p):sha(p) for p in [binding_path,cli,adapter,db,Path(__file__)]}
r={'state':'running','family':args.family,'cwd':str(main),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binding_sha256':sha(binding_path),'frozen_inputs':frozen,'runs':[],'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__))}}
def save():progress.write_text(json.dumps(dict(r,completed_runs=len(r['runs'])),ensure_ascii=False,indent=2)+'\n')
def reference(relative):
 p=work/relative;frozen[str(p)]=sha(p);return read(p)
def run(command,data=None):
 job=subprocess.run(command,cwd=main,input=data,capture_output=True);assert job.returncode==0 and not job.stderr,(command,job.returncode,job.stderr.decode());return job.stdout
def flags(mode):return ['--dict-compatible'] if 'compatible' in mode else ['--dict-only'] if 'headword' in mode else []
save()
try:
 expected=reference('docs/willingness-question-distribution-proof-willingness-'+{'source':'source-streams','cohorts':'cohorts','gold':'corpora','broad':'broad'}[args.family]+'.json.gz')
 assert expected['inputs_unchanged']
 if args.family=='source':
  packet=reference('tests/fixtures/willingness-question-source.json');items=packet['items']+packet['separate_expression_groups']
  # Independently exercise the installed Native importer with both original fixtures.
  folder=prep/'installed-willingness-native-import';assert not folder.exists();folder.mkdir()
  for name in ['willingness-question-native.json','willingness-question-pos-native.json']:
   source=work/'tests/fixtures'/name;frozen[str(source)]=sha(source);target=folder/name;target.write_bytes(source.read_bytes());frozen[str(target)]=sha(target)
  native_db=prep/'installed-willingness-native.db';assert not native_db.exists()
  import_command=[str(cli),'dict','import-krdict',str(folder),str(native_db),'--snapshot','independent-current-willingness-native']
  run(import_command)
  owners=reference('tests/fixtures/willingness-question-native-entries.json')
  supplemental=reference('docs/willingness-question-source-proof-supplemental-pos-native-closure.json.gz')['complete_imported_entries']
  assert not (owners.keys()&supplemental.keys());owners.update(supplemental);assert len(owners)==30
  imported_entries={};entry_queries=[]
  for ident,owner in owners.items():
   query=[str(cli),'dict','entry',str(native_db),ident];entry=json.loads(run(query))['entry']
   assert entry==owner,('complete original Native field',ident);imported_entries[ident]=entry;entry_queries.append(query)
  frozen[str(native_db)]=sha(native_db);r['native_import']={'command':import_command,'database':str(native_db),'original_native_owners':30,'every_complete_original_field_exact':True,'complete_imported_entries':imported_entries,'entry_queries':entry_queries}
  for old in expected['runs']:
   groups=['\n'.join(item['complete_original_group']) if old['family']=='complete-original-source' else item['surface'] for item in items]
   text=unicodedata.normalize(old['encoding'],('\n' if old['family']=='complete-original-source' else ' ').join(groups));raw=text.encode();assert digest(raw)==old['input_sha256']
   command=[str(cli),'text','-','--dictionary',str(db),*flags(old['mode']),'--cache-bytes',str(old['cache_bytes'])];output=run(command,raw)
   assert output.decode()==old['jsonl'] and digest(output)==old['jsonl_sha256'],'every committed current source output byte'
   rows=[json.loads(line) for line in output.splitlines()];assert len(rows)==old['records'] and ''.join(row['surface'] for row in rows)==text
   r['runs'].append({'family':old['family'],'encoding':old['encoding'],'mode':old['mode'],'cache_bytes':old['cache_bytes'],'command':command,'exit_code':0,'records':len(rows),'input_sha256':digest(raw),'stdout_sha256':digest(output),'reference_stdout_sha256':old['jsonl_sha256'],'exact_all_output_bytes':True});save();print(args.family,len(r['runs']),len(rows),'exact frames',flush=True)
 elif args.family=='cohorts':
  helper=work/'tools/doeda_native_corpora.py';frozen[str(helper)]=sha(helper);sys.path.insert(0,str(work/'tools'))
  from doeda_native_corpora import words_from_cli
  for old in expected['runs']:
   words=old['captures'][1]['words'];actual=words_from_cli(cli,sorted(words));assert actual==words,'every committed current word and ordered path'
   value=digest(json.dumps(actual,ensure_ascii=False,sort_keys=True).encode());r['runs'].append({'family':old['family'],'binary':str(cli),'surfaces':len(words),'every_committed_word_and_path_identical':True,'actual_words_sha256':value,'reference_words_sha256':digest(json.dumps(words,ensure_ascii=False,sort_keys=True).encode())});save();print(old['family'],len(words),'exact words',flush=True)
 elif args.family=='gold':
  for old in expected['runs']:
   source=main/old['source'];assert sha(source)==old['source_sha256'];frozen[str(source)]=sha(source)
   command=[str(adapter),old['corpus'],old['source']];output=run(command)
   assert output.decode()==old['jsonl'] and digest(output)==old['stdout_sha256'],'every current annotated row, original gold and candidate summary'
   assert len(output.splitlines())==old['rows']+1
   r['runs'].append({'corpus':old['corpus'],'partition':old['partition'],'source':old['source'],'source_sha256':sha(source),'command':command,'exit_code':0,'rows':old['rows'],'stdout_sha256':digest(output),'reference_stdout_sha256':old['stdout_sha256'],'every_committed_annotated_row_and_summary_identical':True});save();print(old['corpus'],old['partition'],old['rows'],'exact annotated rows',flush=True)
 else:
  originals=reference('docs/reported-deoni-broad-inputs.json.gz');folder=prep/'willingness-installed-broad-inputs';folder.mkdir(exist_ok=True)
  for old in expected['runs']:
   raw=originals['sources'][old['source']]['text'].encode();assert digest(raw)==old['source_sha256']
   source=folder/Path(old['source']).name
   if source.exists():assert source.read_bytes()==raw
   else:source.write_bytes(raw)
   frozen[str(source)]=sha(source);command=[str(cli),'text',str(source),'--dictionary',str(db),*flags(old['mode']),*(['--suggest-spacing'] if 'spacing' in old['mode'] else [])]
   h=hashlib.sha256();cursor=records=0;changed={item['record_index']:item['after'] for item in old['changed_frames']};observed=0
   stderr=prep/('willingness-installed-broad-'+old['mode']+'.stderr')
   with stderr.open('xb') as errors:
    job=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=errors)
    try:
     for line in job.stdout:
      h.update(line);record=json.loads(line);assert record['span']['start']==cursor and raw[cursor:record['span']['end']].decode()==record['surface'];cursor=record['span']['end']
      if records in changed:assert record==changed[records],'every committed individual broad observation';observed+=1
      records+=1
     code=job.wait()
    finally:
     if job.poll() is None:job.terminate();job.wait()
   assert code==0 and not stderr.read_bytes() and records==old['records'] and cursor==len(raw) and observed==len(changed)
   assert h.hexdigest()==old['after_jsonl_sha256'],'every committed complete broad output byte'
   r['runs'].append({'source':old['source'],'source_sha256':digest(raw),'mode':old['mode'],'command':command,'exit_code':code,'records':records,'stdout_sha256':h.hexdigest(),'reference_stdout_sha256':old['after_jsonl_sha256'],'original_bytes_conserved':True,'all_individual_changed_records_exact':observed,'exact_all_output_bytes':True});save();print(old['mode'],records,'exact broad frames',flush=True)
 r.update(state='passed',exit_code=0,inputs_unchanged=all(sha(p)==d for p,d in frozen.items()),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Actual Nix current willingness CLI/adapter. All committed complete current prototype outputs match byte-for-byte, including the separately retained original baselines, canonical source paths, individually unjudged corpus/novel hypotheses and independent distribution audit. Current installed browser/full inventory Nix/main/performance/contextual and independent review remain separate.')
 assert r['inputs_unchanged'];out.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));save()
except Exception as error:r.update(state='failed',error=str(error));save();raise
