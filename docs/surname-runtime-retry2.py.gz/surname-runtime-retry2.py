"""Capture every individually tracked surname template case and preserve base CLI output."""
import hashlib,json,subprocess,unicodedata
from pathlib import Path
ROOT=Path('/tmp/klem-surname-prototype');OUT=Path('/tmp/klem-surname-runtime-retry2.json');assert not OUT.exists()
CLI=Path('/home/josh/projects/klem/.direnv/surname-runtime-target/debug/klem');OLD=Path('/nix/store/j4in370si6hf8dv52x2vsxj95grmsnvi-klem-0.1.0/bin/klem');DB=Path('/home/josh/projects/klem/data/dictionaries/krdict/krdict.db')
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
cases=json.loads((ROOT/'tests/fixtures/proper-name-spacing-cases.json').read_text())['cases']
inputs={str(p):sha(p) for p in [CLI,OLD,DB,Path(__file__),ROOT/'src/dictionary/proper_names.json',ROOT/'tests/fixtures/proper-name-spacing-cases.json']}
runs=[];observations=[]
for encoding in ['NFC','NFD']:
 text='前🙂「'+ ' '.join(unicodedata.normalize(encoding,c['surface']) for c in cases)+'」'
 for cache in [0,4096]:
  for mode,flag in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
   common=['text','-','--dictionary',str(DB),'--suggest-spacing','--cache-bytes',str(cache),*flag]
   old=subprocess.run([str(OLD),*common],input=text.encode(),capture_output=True,check=True)
   plain=subprocess.run([str(CLI),*common],input=text.encode(),capture_output=True,check=True)
   current=subprocess.run([str(CLI),*common,'--proper-names'],input=text.encode(),capture_output=True,check=True)
   assert not old.stderr and not plain.stderr and not current.stderr
   before=[json.loads(line) for line in old.stdout.splitlines()]; optout=[json.loads(line) for line in plain.stdout.splitlines()]; after=[json.loads(line) for line in current.stdout.splitlines()]
   assert len(before)==len(after)==len(optout)
   for a,b in zip(before,optout):
    # A new template can consume extra probes, but opt-out cannot add/remove a path.
    if 'spacing' in a and a['spacing'] is not None:
     aa=json.loads(json.dumps(a));bb=json.loads(json.dumps(b));aa['spacing'].pop('segment_probes');bb['spacing'].pop('segment_probes');assert aa==bb
    else: assert a==b
   words=[record for record in after if record['kind']=='word' and record['surface']!='前']
   assert len(words)==len(cases)
   for c,record in zip(cases,words):
    assert record['surface']==unicodedata.normalize(encoding,c['surface'])
    assert text.encode()[record['span']['start']:record['span']['end']].decode()==record['surface']
    h=[h for h in record['spacing']['alternatives'] if h.get('rule')=='spacing.proper_name_title_possession']
    if c['verdict']=='required':
     selected=next(h for h in h if unicodedata.normalize('NFC',h['spaced'])==c['spaced'])
     assert selected['records'][0]['entry_witnesses']==['ud-ko-kaist:proper-name:park']
     for segment in selected['records']:
      assert text.encode()[segment['span']['start']:segment['span']['end']].decode()==segment['surface']
     assert selected['inserted_at']==[s['span']['start'] for s in selected['records'][1:]]
    else: assert not h,c['id']
    observations.append({'case_id':c['id'],'encoding':encoding,'mode':mode,'cache_bytes':cache,'record':record,'contextual_verdict':'unjudged' if c['verdict']=='required' else 'outside-new-template'})
   runs.append({'encoding':encoding,'mode':mode,'cache_bytes':cache,'text':text,'old_records':before,'optout_records':optout,'records':after,'stdout_sha256':hashlib.sha256(current.stdout).hexdigest()})
lexicon_sha=sha(ROOT/'src/dictionary/proper_names.json')
base=json.loads(subprocess.check_output([str(OLD),'word','박','--dictionary',str(DB)]))['dictionary']['fingerprint']
expected=hashlib.sha256((base+':'+lexicon_sha).encode()).hexdigest()
assert all(record['dictionary']['fingerprint']==expected for run in runs for record in run['records'] if record.get('dictionary'))
result={'state':'isolated-runtime-passed','frozen_inputs':inputs,'inputs_unchanged':all(sha(p)==digest for p,digest in inputs.items()),'lexicon_sha256':lexicon_sha,'observations':observations,'runs':runs,'individual_cases':len(cases),'scope':'All new finite structural cases in original/NFD bytes and all dictionary filter/cache modes. Prior opt-out word/dictionary/spacing paths retained; contextual and independent review remain open. This is a debug prototype, not an installed Nix/Main proof.'}
assert result['inputs_unchanged'];OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('Passed',len(observations),'individual Unicode/filter/cache observations and exact compiled lexicon fingerprint')
