"""Run installed checks only after the exact live package-binding producer succeeds."""
import argparse
import datetime
import hashlib
import json
import os
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--binding-pid', type=int, required=True)
args = parser.parse_args()
prep = Path(__file__).resolve().parent
root = Path('/home/josh/projects/klem')
binding_path = prep / 'willingness-installed-source-binding-retry1.json'
out = prep / 'willingness-installed-pipeline.json'
assert not out.exists()
producer = prep / 'bind_willingness_installed_retry1.py'
proc = Path('/proc') / str(args.binding_pid)
cmdline = (proc / 'cmdline').read_bytes()
assert b'bind_willingness_installed_retry1.py' in cmdline and b'willingness-installed-source-binding-retry1.json' in cmdline
identity = (proc / 'stat').read_text().split(') ', 1)[1].split()[19]
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
names = ['bind_willingness_installed_retry1.py', 'capture_willingness_release_tests.py',
         'replay_willingness_installed.py', 'run_willingness_installed_browser.py',
         'willingness-installed-browser.mjs', 'willingness_question_installed_audit.py',
         'test_willingness_question_installed_audit.py', 'run_willingness_installed_audits.py', Path(__file__).name]
frozen = {str(prep / name): sha(prep / name) for name in names}
r = {'state': 'waiting-for-exact-live-binding-producer', 'pid': os.getpid(),
     'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'binding_process': {'pid': args.binding_pid, 'cmdline': cmdline.decode().replace('\0', ' '), 'start_ticks': identity},
     'frozen_producers': frozen, 'runs': [],
     'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)},
     'scope': 'Actual installed release log, all four complete frozen workload comparisons, actual installed SolidJS/CLI exports and Native responses, independent installed audit and41corruptioncontrols. Complete unabridged Nix/source/current-main/timing and contextual/independent review remain separate.'}
save = lambda: out.write_text(json.dumps(r, indent=2) + '\n')
save()


def run(label, command):
    log = prep / ('willingness-installed-pipeline-' + label + '.log')
    assert not log.exists()
    with log.open('xb') as stream:
        job = subprocess.run(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
    return {'label': label, 'command': command, 'exit_code': job.returncode, 'log': str(log), 'log_sha256': sha(log)}


try:
    while proc.exists():
        try:
            stat = (proc / 'stat').read_text().split(') ', 1)[1].split()
            assert stat[19] == identity, 'binding PID reused'
            if stat[0] == 'Z': break
        except FileNotFoundError:
            break
        time.sleep(2)
    binding = json.loads(binding_path.read_text())
    assert binding['state'] == 'passed' and binding['exit_code'] == 0 and binding['all_tracked_inputs_unchanged'], ('exact dependency did not succeed', binding['state'])
    assert binding['producer']['sha256'] == frozen[str(producer)]
    r.update(state='running', binding_sha256=sha(binding_path)); save()
    release = run('release', ['python3', str(prep / 'capture_willingness_release_tests.py')])
    r['runs'].append(release); save(); assert release['exit_code'] == 0, release
    with ThreadPoolExecutor(max_workers=2) as pool:
        jobs = [pool.submit(run, family, ['python3', str(prep / 'replay_willingness_installed.py'), family]) for family in ['source', 'cohorts', 'gold', 'broad']]
        for future in as_completed(jobs):
            result = future.result(); r['runs'].append(result); save()
            print(result['label'], 'exit', result['exit_code'], flush=True)
    assert all(run['exit_code'] == 0 for run in r['runs']), 'preserved workload failure; do not refresh reference output'
    result = run('browser', ['python3', str(prep / 'run_willingness_installed_browser.py')])
    r['runs'].append(result); save(); assert result['exit_code'] == 0, result
    result = run('audits', ['python3', str(prep / 'run_willingness_installed_audits.py'), '--output', str(prep / 'willingness-installed-audit-controls.json')])
    r['runs'].append(result); save(); assert result['exit_code'] == 0, result
    r.update(state='passed', exit_code=0)
except Exception as error:
    r.update(state='failed', error=str(error))
    raise
finally:
    r.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), producers_unchanged=all(sha(p) == digest for p, digest in frozen.items()))
    save()
assert r['producers_unchanged']
print('All actual installed willingness checks passed with frozen producers', flush=True)
