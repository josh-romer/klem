"""Run original Source/copula/novel dropdown regressions through the installed launcher."""
import hashlib
import json
import os
import re
import signal
import subprocess
import urllib.request
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = Path('/tmp/klem-conjectural-additive-integration')
BINDING = PREP / 'conjectural-integration-installed-source-binding.json'
PREFIX = PREP / 'conjectural-additive-installed-novel-browser-runtime'
OUT = Path(str(PREFIX) + '.json')
assert not OUT.exists()
binding = json.loads(BINDING.read_text())
assert binding['state'] == 'passed' and binding['inputs_unchanged']
BIN = Path(binding['profiles']['klem']['package']) / 'bin'
ASSETS = Path(binding['profiles']['web-assets']['package']) / 'share/klem-web'
LAUNCHER = Path(binding['launcher']['package']) / 'bin/klem-web'
DB = Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db')
DRIVER = PREP / 'conjectural-additive-novel-browser.mjs'
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [BIN / 'klem', BIN / 'klem-web', LAUNCHER, DB, DRIVER, Path(__file__), BINDING,
         PREP / 'novel-browser-native-union.json', ROOT / 'web/src/grammar-labels.json']
files.extend(ROOT / 'tests/fixtures' / name for name in ['conjectural-additive-validity.json', 'conjectural-additive-copula-validity.json', 'conjectural-additive-novel-validity.json'])
files.extend(path for path in ASSETS.rglob('*') if path.is_file())
frozen = {str(path): sha(path) for path in files}
command = [str(LAUNCHER), '--port', '0', '--dictionary', str(DB)]
r = {'state': 'running', 'command': command, 'frozen_inputs': frozen,
     'binding_sha256': sha(BINDING), 'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))}}
OUT.write_text(json.dumps(r, indent=2) + '\n')
job = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
try:
    line = job.stderr.readline()
    match = re.search(r'http://127\.0\.0\.1:\d+', line)
    assert match, line
    url = match.group()
    r['url'] = url
    with urllib.request.urlopen(url + '/api/status', timeout=10) as response:
        r['status'] = json.load(response)
    with urllib.request.urlopen(url, timeout=10) as response:
        html = response.read()
        assert html == (ASSETS / 'index.html').read_bytes()
    for path in re.findall(r'(?:src|href)="(/assets/[^"?#]+\.(?:js|css))"', html.decode()):
        with urllib.request.urlopen(url + path, timeout=10) as response:
            assert response.read() == (ASSETS / path.lstrip('/')).read_bytes()
    env = dict(os.environ, KLEM_WEB_URL=url, KLEM_BIN=str(BIN / 'klem'),
               KLEM_CAPTURE_PREFIX=str(PREP / 'conjectural-additive-installed-novel'),
               CHROMIUM_PATH='/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium')
    with Path(str(PREFIX) + '.log').open('xb') as log:
        completed = subprocess.run(['node', str(DRIVER)], env=env, stdout=log, stderr=subprocess.STDOUT)
    r.update(state='passed' if completed.returncode == 0 else 'failed', exit_code=completed.returncode)
finally:
    if job.poll() is None:
        job.send_signal(signal.SIGINT)
    r['server_exit_code'] = job.wait(timeout=20)
    r['server_stopped'] = True
    r['inputs_unchanged'] = all(sha(path) == digest for path, digest in frozen.items())
    OUT.write_text(json.dumps(r, indent=2) + '\n')
assert r['state'] == 'passed' and r['inputs_unchanged']
print('Actual installed Source/copula/novel browser passed; owned server stopped', flush=True)
