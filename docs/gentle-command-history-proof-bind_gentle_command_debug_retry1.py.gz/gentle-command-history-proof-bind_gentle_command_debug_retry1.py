"""Bind actual prototype binaries to terminal source-frozen Cargo validation."""
import hashlib,json,subprocess,datetime
from pathlib import Path
prep=Path(__file__).resolve().parent;work=Path('/tmp/klem-gentle-command');target=Path('/home/josh/projects/klem/.direnv/gentle-command-target/debug');out=prep/'gentle-command-debug-binding.json';assert not out.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest();full=json.loads((prep/'gentle-command-merged-full-rust-retry1.json').read_bytes())
assert full['state']=='failed' and full['exit_code']==101 and full['inputs_unchanged'] and full['head_unchanged'] and full['index_unchanged']
assert full['totals']=={'passed':182,'failed':1,'ignored':0};assert full['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
# These actual binaries were compiled by Cargo before its integration tests.
# Freeze all compiled Rust inputs rather than relying on a binary filename.
compiled={}
for name,digest in full['frozen_inputs'].items():
 p=Path(name)
 if name.startswith(str(work)+'/') and (p.suffix=='.rs' or p.name in ['Cargo.toml','Cargo.lock','grammar-labels.json']):assert sha(p)==digest;compiled[name]=digest
binaries={name:{'path':str(target/name),'sha256':sha(target/name)} for name in ['klem','klem-web']}
r=dict(state='passed',head=full['head'],compiled_inputs=compiled,binaries=binaries,full_rust_receipt_sha256=sha(prep/'gentle-command-merged-full-rust-retry1.json'),full_rust_result='failed-historical-attribution-182passed-1failed-48batches',inputs_unchanged=True,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),producer={'text':Path(__file__).read_text(),'sha256':sha(__file__)},scope='Actual source-bound prototype executables, compiled before the preserved full-suite historical-attribution failure. This does not claim a complete passed Rust/Nix/main run; original source/fixture inputs remain unchanged.')
out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print('Bound actualprototypeCLI/server and',len(compiled),'compiled input files; full-suite failure preserved')
