"""Preserve the complete actual frontend/browser runs, including the port-denied attempt."""
import datetime
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
D = W / 'docs'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda name: json.loads((P / name).read_bytes())
report = read('friendly-hortative-sena-browser-runtime-retry1.json')
build = read('friendly-hortative-sena-frontend-build.json')
failure = read('friendly-hortative-sena-browser-runtime.json')
browser = read('friendly-hortative-sena-browser.json')
for r in [report, build]:
    assert r['state'] == 'passed'
    assert all(r[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged'])
assert report['source_unchanged'] and report['server_stopped'] and report['server_exit_code'] in [0, -2]
assert report['source_inputs'] == build['frozen_inputs']
assert all(sha((W / n).read_bytes()) == d for n, d in report['source_inputs'].items())
assert report['head'] == build['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
assert report['index_sha256'] == build['index_sha256'] == sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=W))
assert all(sha(Path(p).read_bytes()) == d for p, d in report['frozen_inputs'].items())
assert failure['state'] == 'failed' and 'Operation not permitted' in failure['error']
assert failure['server_exit_code'] == 1 and failure['log_sha256'] is None
assert all(failure[k] for k in ['inputs_unchanged', 'source_unchanged', 'head_unchanged', 'index_unchanged'])
assert len(browser['policyDecisions']) == 150 and len(browser['diagrams']) == 114
assert len(browser['exports']) == 12 and len(browser['corpusDecisions']) == 6 and len(browser['nativeEntries']) == 37
assert report['result_sha256'] == sha((P / 'friendly-hortative-sena-browser.json').read_bytes())
for r, name in [(report, 'friendly-hortative-sena-browser-runtime-retry1.log'), (build, 'friendly-hortative-sena-frontend-build.log')]:
    assert r['log_sha256'] == sha((P / name).read_bytes())
visual = P / 'friendly-hortative-sena-browser-visual-observation.json'
assert not visual.exists()
visual.write_text(json.dumps(dict(
    state='actual-images-viewed', screenshots=report['screenshots'],
    observation='Desktop 1440x1000 and mobile 390x844 images actually viewed using view_image. Visible controls and cards are readable; desktop cards wrap into rows and mobile content fits the viewport. Driver separately measured no horizontal document overflow. Mobile image does not show every card below the viewport; this is not a full-page or accessibility audit.',
    dictionary_gloss_scope='Selected dictionary sense glosses may be ambiguous; images do not establish correct contextual sense selection.',
    observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat()), ensure_ascii=False, indent=2) + '\n')
names = [
    'build_friendly_hortative_sena_frontend.py', 'friendly-hortative-sena-frontend-build.json', 'friendly-hortative-sena-frontend-build.log',
    'friendly-hortative-sena-browser.mjs', 'run_friendly_hortative_sena_browser.py', 'friendly-hortative-sena-browser-runtime.json',
    'run_friendly_hortative_sena_browser_retry1.py', 'friendly-hortative-sena-browser-runtime-retry1.json', 'friendly-hortative-sena-browser-runtime-retry1.log',
    'friendly-hortative-sena-browser.json', 'friendly-hortative-sena-browser-desktop.png', 'friendly-hortative-sena-browser-mobile.png',
    visual.name, Path(__file__).name]
files = {}
for name in names:
    raw = (P / name).read_bytes()
    path = 'friendly-hortative-sena-browser-proof-' + name + '.gz'
    assert not (D / path).exists()
    packed = gzip.compress(raw, mtime=0)
    (D / path).write_bytes(packed)
    files[name] = dict(path=path, source_sha256=sha(raw), archive_sha256=sha(packed))
output = D / 'friendly-hortative-sena-browser-proof-archive.json'
assert not output.exists()
output.write_text(json.dumps(dict(
    state='actual-current-Sena-frontend-and-browser-passed', files=files, source_head=report['head'],
    source_files=len(report['source_inputs']), frontend_inputs=18, production_inputs=44,
    browser_cases=25, filter_decisions=150, required_diagrams=114, forbidden_exclusions=36,
    original_corpus_filter_decisions=6, exact_cli_exports=12, complete_native_entries=37,
    original_port_denied_failure_retained=True, screenshots_actually_viewed=True,
    own_server_explicitly_stopped=True, contextual_corpus_verdict='unjudged',
    context_register_independent_review='pending', full_coverage_complete=False,
    remaining='Independent browser audit, strict historical Source guard integration, full Nix inventory/packages/installed checks, shared promotion/main/timing/context/register/Korean review.'
), ensure_ascii=False, indent=2) + '\n')
print('Archived', len(files), 'complete actual browser/frontend originals; SHA', sha(output.read_bytes()), flush=True)
