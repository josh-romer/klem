"""Validate the new runtime auditor with every current source byte frozen."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/home/josh/projects/klem/.direnv/gentle-command-long')
OUT = PREP / 'gentle-command-long-runtime-regressions.json'
LOG = PREP / 'gentle-command-long-runtime-regressions.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=WORK).decode().split('\0')[:-1]
frozen = {str(p): sha(p) for p in [WORK / n for n in names]+[Path(__file__)]}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
index = sha(WORK / '.git') if (WORK / '.git').is_dir() else hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest()
commands = [['python3', 'tools/gentle_command_long_source_audit.py'], ['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_gentle_command_long_source_audit.py'], ['python3', 'tools/gentle_command_ledger_audit.py'], ['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_gentle_command_ledger_audit.py'], ['cargo', 'test', '--locked', '--offline', '--features', 'web', '--test', 'gentle_command_long', '--test', 'gentle_command', '--test', 'derivation'], ['cargo', 'fmt', '--all', '--', '--check'], ['cargo', 'clippy', '--locked', '--offline', '--features', 'web', '--test', 'gentle_command_long', '--test', 'gentle_command', '--test', 'derivation', '--', '-D', 'warnings'], ['git', 'diff', '--check']]
r = dict(state='running', head=head, index_sha256=index, frozen_inputs=frozen, results=[],
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         producer=dict(text=Path(__file__).read_text(), sha256=sha(__file__)),
         scope='Actual separate eight novel structural regressions, three correctly-shaped derived-class interactions and emitted-positive mutation control, original25private/shared35704cases unchanged. OriginalSource/Native/fullbaseline archive checks with20controls plus25shared-append controls;18Rusttests,fmtrandClippy. All currentSource/head/index frozen. Previous full1189suite/36actualstreams/43Native/53502cohort/66570gold/1128312broad receipts remain unchanged; independentcomplete runtime/currentrevision/installed/browser/Nix/main andtiming/contextreview separate.')
save = lambda: OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2)+'\n')
save()
with LOG.open('xb') as stream:
    for command in commands:
        job = subprocess.run(command, cwd=WORK, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1',CARGO_TARGET_DIR='/home/josh/projects/klem/.direnv/gentle-command-target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2'), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        stream.write(job.stdout); stream.flush()
        output = job.stdout.decode()
        tests = sum(map(int, re.findall(r'Ran (\d+) tests? in', output)))
        r['results'].append(dict(command=command, exit_code=job.returncode, output=output, controls=tests))
        save()
        print(command[-1], 'exit', job.returncode, 'controls', tests, flush=True)
        if job.returncode:
            break
r.update(inputs_unchanged=all(sha(p) == digest for p, digest in frozen.items()),
         head_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == head,
         index_unchanged=hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest() == index,
         controls=sum(row['controls'] for row in r['results']), log_sha256=sha(LOG),
         finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
rust_batches = [batch for row in r['results'] for batch in re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',row['output'])]
r['rust_totals']={key:sum(int(batch[i+1]) for batch in rust_batches) for i,key in enumerate(['passed','failed','ignored'])}
r['rust_batches']=len(rust_batches)
r['state'] = 'passed' if len(r['results']) == len(commands) and all(row['exit_code'] == 0 for row in r['results']) and r['controls'] == 45 and r['rust_totals']=={'passed':18,'failed':0,'ignored':0} and r['rust_batches']==3 and r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged'] else 'failed'
save()
print(r['state'], r['controls'], 'controls;', len(frozen), 'frozen sources', flush=True)
raise SystemExit(0 if r['state'] == 'passed' else 1)
