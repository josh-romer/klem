"""Read the next original ending cohort and capture every original clause unchanged."""
import datetime,gzip,hashlib,json,re,sqlite3,subprocess,unicodedata
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');CLI=Path('/nix/store/cc0wxddigm591zabxi46lli9x8s0kfpd-klem-0.1.0/bin/klem');DB=ROOT/'data/dictionaries/krdict/krdict.db';OUT=Path('/tmp/klem-additive-ppundeoreo-source-discovery.json.gz');assert not OUT.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
frozen={str(p):sha(p.read_bytes()) for p in [CLI,DB,Path(__file__)]}
with sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True) as db:
 entries={ident:json.loads(raw) for ident,raw in db.execute('SELECT id,data FROM entries WHERE headword IN (?,?)',('-ㄹ뿐더러','-을뿐더러'))}
assert set(entries)=={'krdict:74341','krdict:74021'}
groups=[];lines=[];targets=[];cursor=0
for ident,value in sorted(entries.items()):
 for sense in value['senses']:
  for index,original in enumerate(sense['examples']):
   groups.append({'source':ident,'sense':sense['id'],'index':index,'original':original})
   for line_index,text in enumerate(original):
    lines.append(text)
    for found in re.finditer(r'[가-힣]+뿐더러(?=$|[\s.,!?])',text):
     assert (ord(found.group()[-4])-0xAC00)%28==8
     targets.append({'source':ident,'sense':sense['id'],'group_index':index,'line_index':line_index,'surface':found.group(),'char_span':{'start':cursor+found.start(),'end':cursor+found.end()}})
    cursor+=len(text)+1
text='\n'.join(lines)+'\n';runs=[];observations=[]
for encoding in ['NFC','NFD']:
 input=unicodedata.normalize(encoding,text).encode()
 for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
  command=[str(CLI),'text','-','--dictionary',str(DB),*flags];p=subprocess.run(command,input=input,capture_output=True,check=True);rows=list(map(json.loads,p.stdout.splitlines()))
  for target in targets:
   span={k:len(unicodedata.normalize(encoding,text[:v]).encode()) for k,v in target['char_span'].items()}
   row=next(r for r in rows if r['span']==span)
   paths=row['analysis']['analyses'] if row.get('analysis') else []
   whole=[a for a in paths if any(m['kind']=='ending' and m['form'] in ['ㄹ뿐더러','을뿐더러'] for m in a['morphemes'])]
   observations.append({'target':target,'encoding':encoding,'mode':mode,'span':span,'whole_additive_ending_paths':whole,'record':row,'structural_verdict':'unjudged','contextual_verdict':'unjudged','independent_review':'pending'})
  runs.append({'encoding':encoding,'mode':mode,'command':command,'input_sha256':sha(input),'jsonl':p.stdout.decode(),'sha256':sha(p.stdout),'records':len(rows),'exit_code':0})
assert len(groups)==len(targets)==10 and len(observations)==60
assert all(sha(Path(p).read_bytes())==h for p,h in frozen.items())
r={'schema_version':1,'state':'passed','preparation_only':True,'sqlite_entries':entries,'all_original_groups':groups,'input':text,'targets':targets,'runs':runs,'target_observations':observations,'frozen_inputs':frozen,'inputs_unchanged':True,'source_notes_retained':'Both original allomorph notes, all senses, all10 example groups and dialogue replies remain intact. No class/marker/copula/composition policy is selected.','producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Next-source discovery only. Complete original dictionary notes/senses/ten groups/dialogue replies and60actual Unicode/filter observations are retained. No implementation, global judgment, main/package validation or precision/contextual claim for this next family.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Ten original groups;',len(observations),'observations;',sum(bool(o['whole_additive_ending_paths']) for o in observations),'whole ending paths. Preparation only.',flush=True)
