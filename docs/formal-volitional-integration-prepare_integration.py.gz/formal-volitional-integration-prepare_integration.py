"""Integrate the complete tested formal-volitional prototype without losing parent evidence."""
import hashlib
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

BASE = Path('/home/josh/projects/klem')
PREP = BASE / '.direnv/formal-volitional-prepared'
PROTO = BASE / '.direnv/formal-volitional-prototype'
WORK = BASE / '.direnv/formal-volitional-integration'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=WORK)
assert git('rev-parse', '--short', 'HEAD').decode().strip() == '41ccd70'
assert not git('status', '--porcelain')
assert not (PREP / 'integration-preparation.json').exists()
full = json.loads((PREP / 'full-rust.json').read_bytes())
assert full['state'] == 'passed' and full['exit_code'] == 0 and full['inputs_unchanged']
assert full['totals'] == {'passed': 1150, 'failed': 0, 'ignored': 1}
assert full['batches'] == 247 and len(full['frozen_source_files']) == 1663
for relative, digest in full['frozen_source_files'].items():
    assert sha((PROTO / relative).read_bytes()) == digest, ('changed tested input', relative)

core = ['src/engine.rs', 'src/grammar.rs', 'src/bin/klem-web/grammar_labels.rs',
        'web/src/grammar-labels.json', 'tests/validity.rs', 'tests/fixtures/validity.json',
        'tools/literary_question_geona_runtime.py', 'tools/test_literary_question_geona_runtime.py']
manual = {'flake.nix', 'docs/coverage-checklist.md', 'docs/inventory-reviews.json',
          'docs/inventory-review-queue.json', 'docs/fear-lsera-draft.md',
          'docs/fear-lsera-full-rust.json.gz', 'docs/fear-lsera-full-rust.log.gz',
          'docs/fear-lsera-run_full_rust.py.gz', 'docs/reported-experience-draft.md'}
tracked = git('ls-files', '-z').decode().split('\0')[:-1]
parent = {relative: sha((WORK / relative).read_bytes()) for relative in tracked}
for relative in tracked:
    if relative not in set(core) | manual:
        assert (PROTO / relative).read_bytes() == (WORK / relative).read_bytes(), ('unexpected parent change', relative)
for relative in core + ['tests/formal_volitional.rs', 'tests/formal_volitional_novel.rs']:
    shutil.copyfile(PROTO / relative, WORK / relative)
copied = []
for folder, patterns in [('tests/fixtures', ['*formal-volitional*']),
                         ('tools', ['formal_volitional*', 'test_formal_volitional*']),
                         ('docs', ['formal-volitional*'])]:
    for pattern in patterns:
        for source in sorted((PROTO / folder).glob(pattern)):
            if not source.is_file():
                continue
            target = WORK / folder / source.name
            assert not target.exists(), target
            shutil.copyfile(source, target)
            copied.append(str(target.relative_to(WORK)))
# Later finite/full-suite receipts are reviewable additions, not replacements of
# the immutable source judgments or previously captured producer snapshots.
for source in sorted((BASE / 'docs').glob('formal-volitional-*')):
    target = WORK / 'docs' / source.name
    assert not target.exists() or target.read_bytes() == source.read_bytes(), source
    shutil.copyfile(source, target)
    if str(target.relative_to(WORK)) not in copied:
        copied.append(str(target.relative_to(WORK)))

formal_flake = (PROTO / 'flake.nix').read_text()
without_formal = ''.join(line for line in formal_flake.splitlines(keepends=True) if 'formal_volitional_' not in line)
assert without_formal == (WORK / 'flake.nix').read_text(), 'unexpected Nix parent difference'
(WORK / 'flake.nix').write_text(formal_flake)

text = (WORK / 'docs/coverage-checklist.md').read_text()
assert 'COV-017cw —' not in text
main = (BASE / 'docs/coverage-checklist.md').read_text()
start, end = main.index('- [ ] **COV-017cw —'), main.index('- [ ] **COV-018 —')
block = main[start:end]
block = block.replace('Main keeps its separate 504/211\n  inventory and has no formal volitional implementation yet.',
                      'This integration has a verified 511/204\n  private inventory; main integration remains pending.')
text = text.replace('- [ ] **COV-018 —', block + '- [ ] **COV-018 —', 1)
text, count = re.subn(r'(The \[manual review ledger\]\(inventory-reviews.json\) records )\d+( scoped\n  dispositions; )\d+( entries await a disposition)',
                     r'\g<1>511\g<2>204\g<3>', text)
assert count == 1
(WORK / 'docs/coverage-checklist.md').write_text(text)
path = WORK / 'docs/formal-volitional-draft.md'
text = path.read_text().replace('whole Rust/Nix/installed/main integration pending', 'Nix/installed/main integration pending')
text = text.replace('Whole Rust, actual Nix/installed/main', 'Actual Nix/installed/main')
text += ('\nThe complete frozen Rust suite passes 1,150 tests with zero failures and\n'
         'one ignored across 247 batches. All 1,663 selected inputs remain unchanged.\n'
         'Actual Nix/installed/main integration, family timing and wider review remain open.\n')
path.write_text(text)

reviews = json.loads((WORK / 'docs/inventory-reviews.json').read_bytes())
private = json.loads((PROTO / 'docs/inventory-reviews.json').read_bytes())
new_ids = {'krdict:86548', 'krdict:86549', 'krdict:86604', 'krdict:86605'}
parent_ids = [row['id'] for row in reviews['entries']]
assert [row['id'] for row in private['entries'] if row['id'] not in new_ids] == parent_ids
assert len(reviews['entries']) == 507
for review in private['entries']:
    if review['id'] not in new_ids:
        continue
    review['evidence'].append({'path': 'docs/formal-volitional-full-rust.json.gz'})
    review['scope'] = review['scope'].replace('Whole Rust, actual Nix/installed/main', 'Actual Nix/installed/main')
    review['scope'] += ' The complete frozen Rust suite passes 1150 tests, zero failures, one ignored across247batches with all1663inputs unchanged.'
    review['remaining'] = review['remaining'].replace('Whole Rust/Nix', 'Actual Nix')
    reviews['entries'].append(review)
(WORK / 'docs/inventory-reviews.json').write_text(json.dumps(reviews, ensure_ascii=False, indent=2) + '\n')

sys.path.insert(0, str(WORK / 'tools'))
import review_inventory as audit
path = WORK / 'docs/inventory-review-queue.json'
queue = json.loads(path.read_bytes())
queue = audit.build_queue(WORK, queue['dictionary_metadata'], [row['source'] for row in queue['entries']])
assert queue['counts']['by_review'] == {'scoped': 511, 'unreviewed': 204}
path.write_text(json.dumps(queue, ensure_ascii=False, indent=2) + '\n')
audit.verify_queue(WORK, queue)
for relative in core:
    assert (WORK / relative).read_bytes() == (PROTO / relative).read_bytes(), relative
changed_parent = {relative: {'before': digest, 'after': sha((WORK / relative).read_bytes())}
                  for relative, digest in parent.items() if sha((WORK / relative).read_bytes()) != digest}
assert set(changed_parent) == set(core) | {'flake.nix', 'docs/coverage-checklist.md',
                                        'docs/inventory-reviews.json', 'docs/inventory-review-queue.json'}
assert all(sha((PROTO / relative).read_bytes()) == digest for relative, digest in full['frozen_source_files'].items())
proof = {'state': 'complete-tested-formal-volitional-integration-prepared', 'parent': '41ccd70',
         'copied_evidence': copied, 'changed_parent': changed_parent, 'complete_rust': full['totals'],
         'rust_batches': 247, 'tested_inputs': 1663, 'prototype_inputs_unchanged': True,
         'queue_counts': queue['counts'], 'preserved_parent_reviews': parent_ids,
         'scope': 'Exact1150test runtime/fixtures/catalog, all507parent reviews and newer apprehensive full-suite evidence retained. Four finite reviews appended. Only documentation/proof updates after the frozenRust run. All actual selected Rust/frontend/adapter package inputs must equal the tested prototype before builds. Seven formal audits/111controls plus84historical, actual Nix/installed/main/fullinventory/performance/wider review remain required.',
         'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())}}
(PREP / 'integration-preparation.json').write_text(json.dumps(proof, indent=2) + '\n')
print('Prepared exact1150test formal-volitional integration with511/204queue; actualNix/installed/main pending', flush=True)
