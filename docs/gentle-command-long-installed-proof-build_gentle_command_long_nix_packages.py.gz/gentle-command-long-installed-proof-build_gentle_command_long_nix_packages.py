"""Build all four actual packages from a clean frozen feature checkpoint."""
import datetime
import hashlib
import json
import os
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/home/josh/projects/klem/.direnv/gentle-command-long')
OUT = PREP / 'gentle-command-long-nix-packages.json'
LOG = PREP / 'gentle-command-long-nix-packages.log'
BUILD = Path('/home/josh/projects/klem/.direnv/gentle-command-long-nix-build')
assert not OUT.exists() and not LOG.exists()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
BUILD.mkdir(exist_ok=True); BUILD.chmod(0o1777)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=WORK).decode().split('\0')[:-1]
frozen = {name: sha((WORK / name).read_bytes()) for name in names}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
index = sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK))
flake = 'git+file://' + str(WORK)
selected = subprocess.check_output(['nix', 'eval', '--offline', '--raw', flake+'#checks.x86_64-linux.inventory-review.src'], cwd=WORK, text=True).strip()
selected_inputs = {}
for p in Path(selected).rglob('*'):
    if not p.is_file(): continue
    name = str(p.relative_to(selected))
    assert sha(p.read_bytes()) == frozen[name], name
    selected_inputs[name] = frozen[name]
command = ['nix', 'build', '--offline', '--option', 'auto-optimise-store', 'true', '--option', 'build-dir', str(BUILD), '--cores', '4', '--max-jobs', '1', '--no-link', '--print-out-paths', '-L']
command += [flake+'#packages.x86_64-linux.'+p for p in ['klem', 'web-assets', 'corpus-adapter', 'web']]
r = dict(state='running', started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         head=head, index_sha256=index, frozen_inputs=frozen, inventory_source=selected,
         inventory_source_files=selected_inputs, command=command,
         producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
         scope='Actual four current-feature Git-backed Nix packages; includes full release Rust package checks, SolidJS assets, corpus adapter and launcher. Inventory selected source recorded; complete inventory gate and new installed runtime/browser/main/performance/contextual independent review remain separate.')
save = lambda: OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2)+'\n')
save()
with LOG.open('xb') as stream:
    job = subprocess.run(command, cwd=WORK, env=dict(os.environ, TMPDIR=str(BUILD)), stdout=stream, stderr=subprocess.STDOUT)
r.update(exit_code=job.returncode, inputs_unchanged=all(sha((WORK/n).read_bytes()) == digest for n, digest in frozen.items()),
         head_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == head,
         index_unchanged=sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)) == index,
         outputs=[line for line in LOG.read_text().splitlines() if line.startswith('/nix/store/')],
         log_sha256=sha(LOG.read_bytes()), finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
r['state'] = 'passed' if job.returncode == 0 and len(r['outputs']) == 4 and r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged'] else 'failed'
save()
print(r['state'], 'four current-source Nix packages;', len(frozen), 'frozen source files', flush=True)
raise SystemExit(0 if r['state'] == 'passed' else 1)
