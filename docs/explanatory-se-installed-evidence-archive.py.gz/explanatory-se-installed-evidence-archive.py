"""Preserve terminal installed captures without changing tested runtime inputs."""
import gzip
import hashlib
import json
import shutil
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
ROOT = BASE / 'explanatory-se-integration'
PREP = BASE / 'explanatory-se-prepared'
RUNS = BASE / 'explanatory-se-installed-validation'
DOCS = ROOT / 'docs'
manifest = []

def archive(source, name):
    raw = source.read_bytes()
    target = DOCS / name
    encoded = raw if source.suffix == '.gz' or target.suffix != '.gz' else gzip.compress(raw, mtime=0)
    if target.exists():
        assert target.read_bytes() == encoded, target
    else:
        target.write_bytes(encoded)
    manifest.append({'source': str(source), 'target': str(target.relative_to(ROOT)),
                     'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})

for stem in ['integration-packages', 'installed-source-binding']:
    report = json.loads((PREP / (stem + '.json')).read_text())
    assert report['state'] == 'passed' and report['exit_code'] == 0 and report['inputs_unchanged']
    archive(PREP / (stem + '.json'), 'explanatory-se-' + stem + '.json.gz')
    archive(PREP / (stem + '.log'), 'explanatory-se-' + stem + '.log.gz')
for producer in ['build-integration-packages.py', 'bind-installed-source.py']:
    archive(PREP / producer, 'explanatory-se-' + producer + '.gz')
for family in ['finite', 'cohorts', 'corpora', 'broad']:
    stem = 'installed-' + family
    report = json.loads(gzip.decompress((RUNS / (stem + '.json.gz')).read_bytes()))
    assert 'passed' in report['state'] and report['inputs_unchanged']
    for suffix in ['.json.gz', '.log', '.py']:
        archive(RUNS / (stem + suffix), 'explanatory-se-' + stem + suffix + ('' if suffix == '.json.gz' else '.gz'))
runtime = json.loads((RUNS / 'explanatory-se-installed-browser-runtime.json').read_text())
assert runtime['state'] == 'passed' and runtime['exit_code'] == 0
assert runtime['inputs_unchanged'] and runtime['server_stopped']
for suffix in ['.json', '-runtime.json', '-runtime.log', '-driver.log', '.mjs', '-supervisor.py']:
    name = 'explanatory-se-installed-browser' + suffix
    archive(RUNS / name, name + '.gz')
for suffix in ['-desktop.png', '-mobile.png']:
    name = 'explanatory-se-installed-browser' + suffix
    archive(RUNS / name, name)
for source in sorted((PREP / 'installed-audit-delta/tools').glob('*.py')):
    target = ROOT / 'tools' / source.name
    assert not target.exists() or target.read_bytes() == source.read_bytes(), target
    shutil.copyfile(source, target)
archive(Path(__file__), 'explanatory-se-installed-evidence-archive.py.gz')
(PREP / 'installed-evidence-archive.json').write_text(json.dumps({'state': 'passed', 'files': manifest}, indent=2) + '\n')
print('Preserved', len(manifest), 'installed evidence artifacts and two independent audit modules', flush=True)
