"""Retain all strict revision/historical controls and the complete failed prefix adapter."""
import gzip,hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent/'friendly-hortative-sena';D=W/'docs';sha=lambda raw:hashlib.sha256(raw).hexdigest()
r=json.loads((P/'friendly-hortative-sena-revision-validation-retry1.json').read_bytes())
assert r['state']=='passed' and r['controls']==168 and len(r['results'])==6 and all(x['exit_code']==0 for x in r['results'])
assert all(r[k] for k in ['inputs_unchanged','external_inputs_unchanged','head_unchanged','index_unchanged','working_tree_status_unchanged'])
assert all(sha((W/n).read_bytes())==d for n,d in r['frozen_inputs'].items())
assert all(sha(Path(p).read_bytes())==d for p,d in r['external_inputs'].items())
assert r['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
assert r['index_sha256']==sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))
assert r['log_sha256']==sha((P/'friendly-hortative-sena-revision-validation-retry1.log').read_bytes())
failed=json.loads((P/'friendly-hortative-sena-revision-validation.json').read_bytes());assert failed['state']=='failed' and [x['exit_code'] for x in failed['results']]==[0,0,0,1]
names=['validate_friendly_hortative_sena_revision.py','validate_friendly_hortative_sena_revision_retry1.py',
 'friendly-hortative-sena-revision-validation.json','friendly-hortative-sena-revision-validation.log',
 'friendly-hortative-sena-revision-validation-retry1.json','friendly-hortative-sena-revision-validation-retry1.log',
 'friendly-hortative-sena-revision-first-failed-originals.json',
 'friendly-hortative-sena-original-friendly_command_gena_revision.py','friendly-hortative-sena-original-friendly_command_gena_browser_audit.py',
 'friendly-hortative-sena-revision-first.log','friendly-hortative-sena-revision-first-smoke-observation.json',
 'friendly-hortative-sena-revision-archive-premature-producer.py.gz',
 'friendly-hortative-sena-revision-archive-premature-observation.json',Path(__file__).name]
names += sorted(p.name for p in P.glob('friendly-hortative-sena-revision-first-failed-*.gz'))
names += sorted(p.name for p in P.glob('friendly-hortative-sena-unchanged-test_*.py'))
paths=[P/n for n in names]+[W/'tools'/n for n in ['friendly_hortative_sena_revision.py','test_friendly_hortative_sena_revision.py','friendly_command_gena_revision.py','friendly_command_gena_browser_audit.py']]
files={}
for f in paths:
 raw=f.read_bytes();path='friendly-hortative-sena-revision-proof-'+f.name+'.gz';assert not (D/path).exists()
 packed=gzip.compress(raw,mtime=0);(D/path).write_bytes(packed);files[f.name]=dict(path=path,source_sha256=sha(raw),archive_sha256=sha(packed))
o=D/'friendly-hortative-sena-revision-proof-archive.json';assert not o.exists()
o.write_text(json.dumps(dict(state='actual-strict-Sena-source-and-original-historical168-controls-passed',files=files,source_head=r['head'],controls=168,new_strict_controls=31,unchanged_Gena_runtime_controls=48,unchanged_Gena_browser_controls=18,unchanged_Long_runtime_controls=34,unchanged_Long_installed_controls=37,production_inputs=44,frontend_inputs=18,compile_inputs={'klem':1158,'corpus-adapter':1158,'web-assets':18},binary_evidence_mode='captured',live_executable_files_verified=False,original_failed_Gena_browser_prefix_adapter_retained=True,all_previous_test_assertions_retained=True,initial_direct_smoke_producer_not_snapshotted_scope_disclosed=True,shared_cases_reviews_changed=False,full_coverage_complete=False,remaining='Actual complete current Git-selected four Nix checks/packages and installedSource/CLI/browser; sharedpromotion/main; quiet timing/context/register/Korean review.'),indent=2)+'\n')
print('Archived',len(files),'full available original strict/historical evidence artifacts;',sha(o.read_bytes()),flush=True)
