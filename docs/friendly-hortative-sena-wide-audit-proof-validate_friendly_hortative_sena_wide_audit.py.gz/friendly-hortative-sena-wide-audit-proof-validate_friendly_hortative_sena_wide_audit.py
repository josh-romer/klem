"""Capture actual independent wide controls against the frozen complete source."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
O = P / 'friendly-hortative-sena-wide-audit-validation.json'
L = P / 'friendly-hortative-sena-wide-audit-validation.log'
assert not O.exists() and not L.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=W)
names = git('ls-files', '-z').decode().split('\0')[:-1]
frozen = {n: sha((W / n).read_bytes()) for n in names}
head, index = git('rev-parse', 'HEAD').decode().strip(), sha(git('ls-files', '--stage', '-z'))
external = {str(p): sha(p.read_bytes()) for p in [Path(__file__), P/'friendly_hortative_sena_wide_audit.py',P/'test_friendly_hortative_sena_wide_audit.py']}
r = dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,external_inputs=external,results=[],
         producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
def save():
    O.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
    with L.open('xb') as log:
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(P)+os.pathsep+str(W/'tools'))
        commands=[['python3',str(P/'friendly_hortative_sena_wide_audit.py')],
                  ['python3','-m','unittest','discover','-s',str(P),'-p','test_friendly_hortative_sena_wide_audit.py']]
        for command in commands:
            log.write(('COMMAND '+json.dumps(command)+'\n').encode());log.flush()
            job=subprocess.run(command,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT)
            r['results'].append(dict(command=command,exit_code=job.returncode));save()
            assert job.returncode==0,'Actual wide audit failed; complete producer/receipt/log retained.'
    r['state']='passed'
except BaseException as error:
    r.update(state='failed',error=repr(error));raise
finally:
    r.update(inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),
             external_inputs_unchanged=all(sha(Path(p).read_bytes())==d for p,d in external.items()),
             head_unchanged=git('rev-parse','HEAD').decode().strip()==head,
             index_unchanged=sha(git('ls-files','--stage','-z'))==index,
             log_sha256=sha(L.read_bytes()) if L.exists() else None,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['inputs_unchanged','external_inputs_unchanged','head_unchanged','index_unchanged']):
        r['state']='failed'
    r['controls']=sum(map(int,re.findall(r'Ran (\d+) tests',L.read_text()))) if L.exists() else 0
    save()
assert r['state']=='passed'
print('Actual independent Sena wide controls passed:',r['controls'],flush=True)
