import collections,hashlib,json,os,time
from pathlib import Path
out=Path('/tmp/klem-geona-temporary-dedup.json');assert not out.exists()
groups=collections.defaultdict(list)
for p in Path('/tmp').glob('klem-*'):
 if not p.is_file() or p.suffix not in {'.json','.jsonl'}:continue
 s=p.stat()
 if s.st_size<30_000_000 or time.time()-s.st_mtime<86400:continue
 h=hashlib.file_digest(p.open('rb'),'sha256').hexdigest();groups[(s.st_size,h)].append((p,s))
changes=[];saved=0
for (size,sha),members in groups.items():
 first,firststat=members[0]
 for p,s in members[1:]:
  if (s.st_dev,s.st_ino)==(firststat.st_dev,firststat.st_ino):continue
  assert p.stat().st_size==s.st_size and p.stat().st_mtime_ns==s.st_mtime_ns
  alias=p.with_name(p.name+'.klem-dedup-link');assert not alias.exists();os.link(first,alias);os.replace(alias,p)
  assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==sha
  changes.append({'path':str(p),'identical_retained_path':str(first),'bytes':size,'sha256':sha,'original_mtime_ns':s.st_mtime_ns});saved+=size
out.write_text(json.dumps({'state':'passed','scope':'Only byte-identical, task-created JSON captures unchanged for more than one day. All original paths, raw bytes and SHA256 remain readable; each duplicate now shares retained storage. No source, executable or running output changed.','changes':changes,'bytes_saved':saved},indent=2)+'\n');print('Identical captures hard-linked:',len(changes),'bytes saved:',saved,flush=True)
