"""Capture complete authored geona boundary modes without promoting conditional hypotheses."""
import datetime,gzip,hashlib,json,subprocess,sys,unicodedata
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from literary_future_kko_audit import matches
BEFORE=Path('/tmp/klem-literary-future-kko-main-cli');AFTER=Path('/tmp/klem-literary-question-geona-cli');DB=ROOT/'data/dictionaries/krdict/krdict.db';PROPOSAL=Path('/tmp/klem-literary-question-geona-authored-boundary-proposal.json');OUT=Path('/tmp/klem-literary-question-geona-boundary-preflight.json.gz');assert not OUT.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest();proposal=json.loads(PROPOSAL.read_bytes());cases=proposal['cases'];text=' '.join(dict.fromkeys(c['surface'] for c in cases));frozen={str(p):sha(p.read_bytes()) for p in [BEFORE,AFTER,DB,PROPOSAL,Path(__file__),ROOT/'tools/literary_future_kko_audit.py']};runs=[];observations=[];mismatches=[];deltas=[];ids=set()
for encoding in ['NFC','NFD']:
 for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
  jobs=[];records=[]
  for cli in [BEFORE,AFTER]:
   command=[str(cli),'text','-','--dictionary',str(DB),*flags];job=subprocess.run(command,input=unicodedata.normalize(encoding,text).encode(),capture_output=True,check=True);jobs.append({'command':command,'exit_code':0,'jsonl':job.stdout.decode(),'sha256':sha(job.stdout)});records.append(list(map(json.loads,job.stdout.splitlines())))
  before,after=records;assert len(before)==len(after)
  for old,new in zip(before,after,strict=True):
   for key in ['surface','span','kind']:assert old[key]==new[key]
   if not old.get('analysis'):assert old==new;continue
   a=old['analysis']['analyses'];b=new['analysis']['analyses'];assert [p for p in b if p in a]==a
   for p,assessment in zip(a,old['dictionary']['readings'],strict=True):assert new['dictionary']['readings'][b.index(p)]==assessment
   added=[(i,p) for i,p in enumerate(b) if p not in a]
   if added:
    deltas.append({'encoding':encoding,'mode':mode,'surface':new['surface'],'span':new['span'],'before':old,'after':new,'new_paths':[{'analysis':p,'assessment':new['dictionary']['readings'][i]} for i,p in added],'contextual_verdict':'unjudged','independent_review':'pending'})
    owners={(v['lemma']['text'],v['lemma']['kind']):v['entries'] for v in new['dictionary']['lemmas']}
    for _,p in added:
     for lemma in p['lemmas']:ids.update(v['id'] for v in owners[(lemma['text'],lemma['kind'])])
  for c in cases:
   row=next(r for r in after if r.get('analysis') and r['analysis']['normalized']==c['surface']);paths=[(i,p) for i,p in enumerate(row['analysis']['analyses']) if matches(p,c)];assessments=[row['dictionary']['readings'][i] for i,p in paths];present=bool(paths);wanted=c['expected_presence'][mode];status_ok=all(a['status']!='incompatible' if c['expected_status']=='not-incompatible' else a['status']==c['expected_status'] for a in assessments)
   record={'encoding':encoding,'mode':mode,'case_id':c['id'],'proposal':c['proposal'],'present':present,'expected_present':wanted,'paths':[p for _,p in paths],'assessments':assessments,'expected_status':c['expected_status'],'matches_proposed_presence':present==wanted,'matches_proposed_status':status_ok,'contextual_verdict':'unjudged','independent_review':'pending'};observations.append(record)
   if present!=wanted or not status_ok:mismatches.append(record)
  runs.append({'encoding':encoding,'mode':mode,'input':unicodedata.normalize(encoding,text),'before':jobs[0],'after':jobs[1],'records':len(after),'all_prior_candidate_paths_and_assessments_preserved':True});print(encoding,mode,len(after),'complete before/after frames;',len(mismatches),'cumulative proposal mismatches',flush=True)
assert len(observations)==282 and all(sha(Path(p).read_bytes())==h for p,h in frozen.items())
producer=Path(__file__);r={'schema_version':1,'state':'captured-proposal-mismatches' if mismatches else 'passed','exit_code':0,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':cases,'input':text,'runs':runs,'observations':observations,'proposal_mismatches':mismatches,'candidate_deltas':deltas,'matched_new_owner_ids':sorted(ids),'proposal_sha256':frozen[str(PROPOSAL)],'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':producer.read_text(),'sha256':sha(producer.read_bytes())},'scope':'Actual independent before/after full CLI boundary modes. Five structural exclusions are separate from four Native spelling exclusions and twelve unreviewed owner/marker/omission extensions. Conditional hypotheses are not global required judgments. Every prior path/assessment is conserved; all added paths remain individually unjudged. Captured expectation errors, if any, require an explicit authored correction rather than silently changing source or gold.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Captured47proposals/282observations;',len(mismatches),'mismatches;',len(ids),'matched new owners',flush=True)
