"""Compare all original annotated rows without changing any source gold."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = PREP.parents[1]
SOURCE = ROOT / 'docs/literary-question-geona-prototype-corpora.json.gz'
BASELINE = Path('/tmp/klem-gentle-command/docs/willingness-question-distribution-proof-willingness-corpora.json.gz')
OUT = PREP / 'gentle-command-corpora.json.gz'
CURRENT_BINDING = PREP / 'gentle-command-adapter-binding.json'
current_binding = json.loads(CURRENT_BINDING.read_bytes())
assert current_binding['state'] == 'passed' and current_binding['inputs_unchanged']
ADAPTER = Path(current_binding['binaries']['after']['path'])
REFERENCE = PREP / 'willingness-installed-source-binding-retry1.json'
assert not OUT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
baseline = json.loads(gzip.decompress(BASELINE.read_bytes()))
reference = json.loads(gzip.decompress(SOURCE.read_bytes()))
binding = json.loads(REFERENCE.read_bytes())
assert binding['state'] == 'passed'
BEFORE = Path(binding['profiles']['corpus-adapter']['package']) / 'bin/klem-corpus-adapter'
assert sha(ADAPTER) == current_binding['binaries']['after']['sha256']
frozen = {str(p): sha(p) for p in [SOURCE, BASELINE, REFERENCE, CURRENT_BINDING, BEFORE, ADAPTER, Path(__file__)]}
closure_path = PREP / 'gentle-command-current-production-closure.json'
closure = json.loads(closure_path.read_bytes())
assert closure['state'] == 'passed'
frozen[str(closure_path)] = sha(closure_path)
frozen.update(closure['production_inputs'])
runs = []
changes = []
for partition in reference['corpora']:
    source = ROOT / partition['source']
    assert sha(source) == partition['source_sha256']
    frozen[str(source)] = sha(source)
    previous = next(run for run in baseline['runs'] if (run['corpus'], run['partition']) == (partition['corpus'], partition['partition']))
    expected = [json.loads(line) for line in previous['jsonl'].splitlines()]
    old_command = [str(BEFORE), partition['corpus'], partition['source']]
    old_job = subprocess.run(old_command, cwd=ROOT, capture_output=True, check=True)
    assert not old_job.stderr and old_job.stdout.decode() == previous['jsonl'], 'actual parent Nix adapter exact baseline'
    command = [str(ADAPTER), partition['corpus'], partition['source']]
    job = subprocess.run(command, cwd=ROOT, capture_output=True, check=True)
    assert not job.stderr
    rows = [json.loads(line) for line in job.stdout.splitlines()]
    assert len(rows) == len(expected) == partition['report_lines']
    for key in ['schema_version', 'input_sha256', 'corpus', 'input', 'rows', 'excluded_rows', 'malformed_rows', 'converted_rows', 'unsupported', 'gold_lemmas', 'transformed_rows', 'adapter_coverage']:
        assert rows[0][key] == expected[0][key], ('original gold metadata', key)
    for old, new in zip(expected[1:], rows[1:], strict=True):
        assert {key: old[key] for key in ['id', 'surface', 'expected']} == {key: new[key] for key in ['id', 'surface', 'expected']}, 'original individual gold'
        assert not old['matched'] or new['matched']
        assert old['recovered'] <= new['recovered'] and all(group in new['recovered_sets'] for group in old['recovered_sets']), 'every original gold recovery'
        if old != new:
            changes.append({'id': new['id'], 'corpus': partition['corpus'], 'partition': partition['partition'],
                            'before': old, 'after': new, 'contextual_verdict': 'unjudged'})
    for key in ['grouped_matches', 'recovered_gold_lemmas', 'transformed_matches', 'grouped_lemma_recall', 'lemma_recall', 'transformed_grouped_recall']:
        assert rows[0][key] >= expected[0][key], ('original gold recall', key)
    assert rows[0]['input_sha256'] == partition['source_sha256']
    assert [{key: row[key] for key in ['id', 'surface', 'expected']} for row in rows[1:]] == [{key: row[key] for key in ['id', 'surface', 'expected']} for row in partition['original_converted_rows']], 'all independently preserved original annotations'
    summary_changes = {key: {'before': expected[0].get(key), 'after': value} for key, value in rows[0].items() if expected[0].get(key) != value}
    runs.append({'corpus': partition['corpus'], 'partition': partition['partition'], 'source': partition['source'],
                 'source_sha256': sha(source), 'before_command': old_command, 'command': command,
                 'exit_code': 0, 'rows': len(rows) - 1, 'summary_changes': summary_changes,
                 'jsonl': job.stdout.decode(), 'stdout_sha256': hashlib.sha256(job.stdout).hexdigest(),
                 'before_stdout_sha256': hashlib.sha256(old_job.stdout).hexdigest()})
    print(partition['corpus'], partition['partition'], len(rows) - 1, 'original gold rows;', len(summary_changes), 'summary deltas', flush=True)
assert sum(run['rows'] for run in runs) == 66570 and all(sha(p) == digest for p, digest in frozen.items())
report = {'state': 'complete-gentle-command-annotated-comparison-passed', 'runs': runs, 'individual_changed_rows': changes,
          'frozen_inputs': frozen, 'inputs_unchanged': True,
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
          'captured_head': current_binding['captured_head'],
          'scope': 'All66570originalrows/fourunchangedKAIST/GSDpartitions with actual bound parent Nix adapter and isolated new-rule adapter. Every original row ID/surface/gold/metadata and prior gold recovery preserved. Complete new rows and any changes are retained separately; contextual candidate precision, novel meanings, newNix/main and broad review remain open.'}
OUT.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
