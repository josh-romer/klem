"""Capture exact old/new owner modes and separate lexical/auxiliary role regression proposals."""
import copy,gzip,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');OLD=Path('/nix/store/jmk0c772h8z0frp6f0x14v6siz0w8zhl-klem-0.1.0/bin/klem');DB=ROOT/'data/dictionaries/krdict/krdict.db';INPUT=Path('/tmp/klem-literary-question-geona-owner-extension-preflight.json.gz');OUT=Path('/tmp/klem-literary-question-geona-owner-extension-typed.json.gz');assert not OUT.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest();initial=json.loads(gzip.decompress(INPUT.read_bytes()));raw=[o for o in initial['observations'] if (o['encoding'],o['mode'])==('NFC','raw')];cases=[];conditional={'derived-dap-vowel','derived-dap-honorific','derived-hada','copula-honorific-conditional'}
for c,o in zip(initial['cases'],raw,strict=True):
 assert c['id']==o['case_id'];tail=c['id'].removeprefix('literary-question-geona-owner-extension-')
 if c['proposal']=='forbidden':
  lk=['nominal'] if tail.startswith('derived-') else ['predicate','predicate' if tail.startswith('aux-rieul') else 'auxiliary'];mk=['suffix','ending'] if tail=='derived-dap-unrecovered' else ['suffix','prefinal','ending'] if tail.startswith('derived-') else ['ending','ending'];cases.append({**c,'lemma_kinds':lk,'morpheme_kinds':mk,'required_rules':['ending.literary_question_geona'],'expected_status':'not-incompatible','expected_presence':{m:False for m in ['raw','headword','compatible']}});continue
 for path in o['paths']:
  roles=[l['kind'] for l in path['lemmas']];incompatible=tail.startswith('aux-result') and roles[-1]=='auxiliary';status='incompatible' if incompatible else 'unknown' if tail in conditional else 'compatible';suffix='-auxiliary-role' if incompatible else '-lexical-role' if tail.startswith('aux-result') else ''
  cases.append({**c,'id':c['id']+suffix,'parent_proposal':c['id'],'lemma_kinds':roles,'morpheme_kinds':[m['kind'] for m in path['morphemes']],'required_rules':['ending.literary_question_geona'],'proposal':'native-policy-only' if incompatible else c['proposal'],'expected_status':status,'expected_presence':{'raw':True,'headword':True,'compatible':not incompatible}})
assert len(cases)==27 and len({c['id'] for c in cases})==27
frozen={str(p):sha(p.read_bytes()) for p in [OLD,DB,INPUT,Path(__file__)]};runs=[];observations=[];ids=set()
def matches(path,c):return [l['text'] for l in path['lemmas']]==c['lemmas'] and [l['kind'] for l in path['lemmas']]==c['lemma_kinds'] and [m['form'] for m in path['morphemes']]==c['morphemes'] and [m['kind'] for m in path['morphemes']]==c['morpheme_kinds'] and set(c['required_rules'])<=set(path['rules'])
for run in initial['runs']:
 command=[str(OLD),*run['command'][1:]];text=initial['input'];import unicodedata;text=unicodedata.normalize(run['encoding'],text);job=subprocess.run(command,input=text.encode(),capture_output=True,check=True);before=list(map(json.loads,job.stdout.splitlines()));after=list(map(json.loads,run['jsonl'].splitlines()));assert len(before)==len(after)
 for a,b in zip(before,after,strict=True):
  for k in ['surface','span','kind']:assert a[k]==b[k]
  if not a.get('analysis'):assert a==b;continue
  old,new=a['analysis']['analyses'],b['analysis']['analyses'];assert [p for p in new if p in old]==old
  for p,assessment in zip(old,a['dictionary']['readings'],strict=True):assert b['dictionary']['readings'][new.index(p)]==assessment
  owned={(l['lemma']['text'],l['lemma']['kind']):l['entries'] for l in b['dictionary']['lemmas']}
  for p in new:
   if p in old:continue
   for l in p['lemmas']:ids.update(e['id'] for e in owned[(l['text'],l['kind'])])
 for c in cases:
  row=next(r for r in after if r.get('analysis') and r['analysis']['normalized']==c['surface']);paths=[(i,p) for i,p in enumerate(row['analysis']['analyses']) if matches(p,c)];assessments=[row['dictionary']['readings'][i] for i,_ in paths];assert bool(paths)==c['expected_presence'][run['mode']],(c['id'],run['mode']);assert all(a['status']==c['expected_status'] for a in assessments),(c['id'],assessments)
  observations.append({'encoding':run['encoding'],'mode':run['mode'],'case_id':c['id'],'paths':[p for _,p in paths],'assessments':assessments,'present':bool(paths),'expected_present':c['expected_presence'][run['mode']],'contextual_verdict':'unjudged','independent_review':'pending'})
 runs.append({'encoding':run['encoding'],'mode':run['mode'],'input':text,'before':{'command':command,'jsonl':job.stdout.decode(),'sha256':sha(job.stdout),'exit_code':0},'after':run,'records':len(after),'all_old_paths_and_native_assessments_preserved':True})
assert len(observations)==162 and all(sha(Path(p).read_bytes())==h for p,h in frozen.items());p=Path(__file__);r={'schema_version':1,'state':'passed','initial_preflight_sha256':frozen[str(INPUT)],'cases':cases,'runs':runs,'observations':observations,'matched_new_owner_ids':sorted(ids),'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':p.read_text(),'sha256':sha(p.read_bytes())},'scope':'Twenty-five authored surfaces expand into27distinct typed structures/162mode observations. Two lexical 되다 vs auxiliary-role alternatives keep different Native policies; four conditional bare owner extensions and two Native-only role conflicts are not promoted to raw required/forbidden judgments. Every actual old path/Native assessment is conserved. Listed past/modal markers bind to their immediate derived/adjective/copular owner; no contextual/sense/precision conclusion.'};OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('27typed owner cases/162observations passed, with lexical vs auxiliary roles and four conditional extensions separate.',flush=True)
