"""Compare all original held-out surfaces and retain every literary-question-geona addition individually."""
import gzip,hashlib,json,subprocess,sys,datetime
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from doeda_native_corpora import words_from_cli,contexts_text
from friendly_command_corpora import outcome
OLD=Path('/nix/store/jmk0c772h8z0frp6f0x14v6siz0w8zhl-klem-0.1.0/bin/klem');CLI=Path('/tmp/klem-literary-question-geona-cli')
PRIOR=ROOT/'docs/literary-future-kko-prototype-corpora.json.gz';OUTPUT=Path('/tmp/klem-literary-question-geona-prototype-corpora.json.gz');assert not OUTPUT.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
digest=lambda d:hashlib.sha256(json.dumps(d,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
prior=json.loads(gzip.decompress(PRIOR.read_bytes()));surfaces=sorted(prior['after_words']);assert len(surfaces)==32096
frozen={str(p):sha(p) for p in [OLD,CLI,PRIOR,ROOT/'examples/evaluate.rs',ROOT/'tools/doeda_native_corpora.py',ROOT/'tools/friendly_command_corpora.py']}
print('Capturing actual baseline words',flush=True);before=words_from_cli(OLD,surfaces);assert before==prior['after_words']
print('Capturing actual isolated literary-question-geona words',flush=True);after=words_from_cli(CLI,surfaces)
changed={};observations=[]
for word in surfaces:
 b,a=before[word],after[word]
 assert {k:v for k,v in b.items() if k!='analyses'}=={k:v for k,v in a.items() if k!='analyses'},word
 assert [p for p in a['analyses'] if p in b['analyses']]==b['analyses'],word
 if b==a:continue
 changed[word]={'before':b,'after':a}
 for path in a['analyses']:
  if path in b['analyses']:continue
  assert 'ending.literary_question_geona' in path['rules'],(word,path)
  observations.append({'id':'literary-question-geona-corpus-'+digest([word,path])[:24],'surface':word,'analysis':path,'source_entries':sorted({ident for morpheme in path['morphemes'] for ident in {'을거나':['krdict:80970','krdict:80972']}.get(morpheme['form'],[])}),'structural_verdict':'unjudged broader composition','contextual_verdict':'unjudged','independent_review':'pending'})
reports=[];locations={};total=0
for original in prior['corpora']:
 p=ROOT/original['source'];assert sha(p)==original['source_sha256'];rows=[{}]+original['original_converted_rows'];contexts=contexts_text(p.read_text());assert len(rows)==original['report_lines'];comparisons=[];gold_changes=[]
 for row in rows[1:]:
  context=contexts[row['id']];assert context['original_row'][1]==row['surface'];word=row['surface'];gold=row['expected'];b=outcome(gold,before[word]['analyses']);a=outcome(gold,after[word]['analyses']);assert a[1]>=b[1] and (a[0] or not b[0]);result={'id':row['id'],'surface':word,'expected':gold,'before':{'matched':b[0],'recovered':b[1],'recovered_sets':b[2],'candidates':len(before[word]['analyses'])},'after':{'matched':a[0],'recovered':a[1],'recovered_sets':a[2],'candidates':len(after[word]['analyses'])}};comparisons.append(result)
  if b!=a:gold_changes.append(result)
  locations.setdefault(word,[]).append({'source':original['source'],'source_sha256':original['source_sha256'],'id':row['id'],**context})
 def summary(mode):
  counts=sorted(r[mode]['candidates'] for r in comparisons);n=len(counts);gold=sum(len(r['expected']) for r in comparisons);return {'converted_rows':n,'grouped_matches':sum(r[mode]['matched'] for r in comparisons),'recovered_gold_lemmas':sum(r[mode]['recovered'] for r in comparisons),'gold_lemmas':gold,'candidate_count_sum':sum(counts),'mean_candidates':sum(counts)/n,'p95_candidates':counts[min(n*95//100,n-1)],'max_candidates':max(counts)}
 total+=len(comparisons);reports.append({k:original[k] for k in ['corpus','partition','source','source_sha256','report_lines']}|{'original_source_text':p.read_text(),'original_converted_rows_sha256':digest(rows[1:]),'original_converted_rows':rows[1:],'comparisons':comparisons,'before_summary':summary('before'),'after_summary':summary('after'),'changed_gold_outcomes':gold_changes});print(original['corpus'],original['partition'],len(comparisons),'rows;',len(gold_changes),'changed gold outcomes',flush=True)
for observation in observations:observation['occurrences']=locations[observation['surface']]
assert total==66570 and all(sha(p)==h for p,h in frozen.items())
producer=Path(__file__);report={'schema_version':1,'preparation_only':True,'state':'prototype-corpus-preservation-passed','captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before_cli_sha256':sha(OLD),'cli_sha256':sha(CLI),'previous_report_sha256':sha(PRIOR),'before_words':before,'after_words':after,'before_words_sha256':digest(before),'after_words_sha256':digest(after),'unique_surfaces':len(surfaces),'converted_rows':total,'corpora':reports,'changed_words':changed,'candidate_changes':observations,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':producer.read_text(),'sha256':sha(producer)},'scope':'All older ordered candidates remain exact; new literary-question-geona alternatives are individually unjudged, without an invented earlier parent or a precision claim. Actual full baseline/prototype WordAnalysis outputs for every original held-out surface. Every original converted row and original context are retained and matched against unchanged source files; gold recovery outcomes recomputed independently from actual CLI candidates. Current Rust adapter replay is pending. Additional candidates remain individually unjudged and cannot establish precision or contextual correctness.','contextual_verdict':'unjudged','independent_review':'pending'}
OUTPUT.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Compared66570 rows,32096 surfaces;',len(changed),'changed words;',len(observations),'individually unjudged literary-question-geona additions.',flush=True)
