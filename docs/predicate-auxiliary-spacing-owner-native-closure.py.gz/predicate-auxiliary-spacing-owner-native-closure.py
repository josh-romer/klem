"""Close actual lemma owner IDs over full same-head dictionary entries and original LMF."""
import copy,datetime,gzip,hashlib,json,sqlite3,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from native_lmf import array,entry,feature,verify_native_lmf
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
OUT=Path('/tmp/klem-predicate-auxiliary-spacing-owner-native-closure.json.gz');assert not OUT.exists()
previous_path=Path('/tmp/klem-predicate-auxiliary-spacing-native-closure.json.gz')
previous=read(previous_path)
preflight_path=Path('/tmp/klem-predicate-auxiliary-spacing-owner-replay.json.gz')
preflight=read(preflight_path);assert preflight['unmet_requirements']==['auxiliary-nominalization-topic']
paths=[previous_path,preflight_path];frozen={str(p):sha(p.read_bytes()) for p in paths}
matched=set(previous['matched_owner_ids'])
def references(value):
    if isinstance(value,dict):
        if 'dictionary' in value:
            for lemma in value['dictionary']['lemmas']:
                matched.update(v['id'] for v in lemma['entries'])
        for v in value.values():references(v)
    elif isinstance(value,list):
        for v in value:references(v)
references(preflight['observations'])
database=ROOT/'data/dictionaries/krdict/krdict.db';frozen[str(database)]=sha(database.read_bytes())
native={};heads=set()
with sqlite3.connect(database.resolve().as_uri()+'?mode=ro',uri=True) as db:
    for ident in sorted(matched):
        row=db.execute('SELECT headword,data FROM entries WHERE id=?',(ident,)).fetchone();assert row
        heads.add(row[0])
    for head in sorted(heads):
        for ident,raw in db.execute('SELECT id,data FROM entries WHERE headword=?',(head,)):
            native[ident]=json.loads(raw)
native.update(previous['complete_native_entries']);assert matched<=set(native)
numeric_ids={i.split(':')[1] for i in native}
original={};sources={}
for path in sorted((ROOT/'data/dictionaries/krdict/json').glob('*.json')):
    raw=path.read_bytes();data=json.loads(raw)
    for value in array(data['LexicalResource']['Lexicon'].get('LexicalEntry')):
        if value.get('val') not in numeric_ids:continue
        projected_entry=entry(value);ident=projected_entry['id']
        if ident not in native:continue
        assert ident not in original,(ident,str(path))
        assert projected_entry==native[ident],ident
        original[ident]=value
    sources[str(path)]={'sha256':sha(raw),'bytes':len(raw)}
assert set(original)==set(native)
assert all(original[i]==v for i,v in previous['original_lmf'].items())
assert all(native[i]==value and original[i]==previous['original_lmf'][i] for i,value in previous['complete_native_entries'].items())
projected=copy.deepcopy(list(original.values()))
for value in projected:
    for sense in array(value.get('Sense')):
        sense['Equivalent']=[v for v in array(sense.get('Equivalent')) if feature(v,'language')=='영어']
lmf={'LexicalResource':{'Lexicon':{'LexicalEntry':projected}}};verify_native_lmf(lmf,native)
assert all(sha(Path(p).read_bytes())==v for p,v in frozen.items())
assert all(sha(Path(p).read_bytes())==v['sha256'] for p,v in sources.items())
producer=Path(__file__)
report={'state':'passed','preparation_only':True,'matched_owner_ids':sorted(matched),'same_headwords':sorted(heads),
        'complete_native_entries':native,'original_lmf':original,'english_projection':lmf,
        'original_primary_entries_preserved':True,'source_exports':sources,'first_failed_producer_sha256':sha(Path('/tmp/klem-additive-ppundeoreo-owner-closure.py').read_bytes()),'first_failed_log_sha256':sha(Path('/tmp/klem-additive-ppundeoreo-owner-closure.log').read_bytes()),'correction':'Resolve the production Native ID, including hashed idiom/proverb lexical units, instead of conflating distinct units by numeric source ID. The initial duplicate-ID failure and producer are retained.','frozen_inputs':frozen,'inputs_unchanged':True,
        'producer':{'text':producer.read_text(),'sha256':sha(producer.read_bytes())},
        'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope':'Close every original owner and every actually referenced finite spacing owner over complete same-head Native entries. Full original LMF equals SQLite and English importer projection. Every previous102-entry original remains unchanged. Production importer/test/API/broad/main/package/context validation remain separate.'}
OUT.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Closed',len(matched),'actual owner IDs over',len(native),'complete Native entries; exact LMF/SQLite and English projection pass.',flush=True)
