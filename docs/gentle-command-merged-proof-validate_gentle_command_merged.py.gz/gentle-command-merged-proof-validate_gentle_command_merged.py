"""Verify merged gentle-command runtime against the exact active willingness ledger/reviews."""
import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
prep=Path(__file__).resolve().parent;work=Path('/tmp/klem-gentle-command');out=prep/'gentle-command-merged-validation.json';assert not out.exists();sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
files=[work/p for p in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=work).decode().split('\0')[:-1]]+[Path(__file__)];frozen={str(p):sha(p) for p in files}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip();index=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=work)).hexdigest()
assert not subprocess.check_output(['git','ls-files','-u'],cwd=work)
commands=[]
for name,count in [('expression_conjectural_ledger_audit',29),('willingness_question_interaction_browser_audit',17),('gentle_command_source_audit',16),('review_inventory',10)]:
 commands += [(['python3','tools/'+name+'.py']+(['--verify'] if name=='review_inventory' else []),None),(['python3','-m','unittest','discover','-s','tools','-p','test_'+name+'.py'],count)]
commands += [(['cargo','test','--locked','--offline','--features','web','--test','validity','--test','gentle_command','--test','willingness_question','--test','candidate_correctness','--test','stress'],35),(['cargo','fmt','--all','--','--check'],None),(['cargo','clippy','--locked','--offline','--features','web','--test','validity','--test','gentle_command','--test','willingness_question','--','-D','warnings'],None)]
env=dict(os.environ,CARGO_TARGET_DIR='/home/josh/projects/klem/.direnv/gentle-command-target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2')
r=dict(state='running',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),head=head,index_sha256=index,frozen_inputs=frozen,runs=[],producer={'text':Path(__file__).read_text(),'sha256':sha(__file__)},scope='Actual merged prototype: unchanged35681 active cases/515manual reviews and private23gentle-command cases. Full original source/Native/baseline histories preserved. Whole current Rust/Nix/new installed/browser/distribution/main/timing and independent contextual review remain separate.')
save=lambda:out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');save()
try:
 for i,(command,count) in enumerate(commands):
  log=prep/('gentle-command-merged-validation-'+str(i)+'.log');assert not log.exists()
  with log.open('xb') as stream:job=subprocess.run(command,cwd=work,env=env,stdout=stream,stderr=subprocess.STDOUT)
  raw=log.read_bytes();actual=None
  if count is not None and job.returncode==0:
   if command[0]=='python3':
    parsed=re.findall(rb'Ran (\d+) tests? in ',raw);assert len(parsed)==1 and int(parsed[0])==count and raw.rstrip().endswith(b'OK');actual=count
   else:
    parsed=re.findall(rb'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw);actual=sum(int(b[1]) for b in parsed);assert len(parsed)==5 and actual==count and all(b[0]==b'ok' and b[2]==b'0' for b in parsed)
  r['runs'].append(dict(command=command,exit_code=job.returncode,tests=actual,log_sha256=sha(log)));save();assert job.returncode==0,(i,str(log));print('passed',i,actual,flush=True)
 r.update(state='passed',exit_code=0,controls=72,rust_tests=35)
except Exception as error:
 r.update(state='failed',error=str(error));raise
finally:
 r.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),inputs_unchanged=all(sha(p)==h for p,h in frozen.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==head,index_unchanged=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=work)).hexdigest()==index);save()
assert r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged'];print('Merged exact-history/Native/queue72controls and35Rust tests passed with every input/HEAD/index unchanged',flush=True)
