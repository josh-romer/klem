"""Verify the unchanged interaction proposals using the library and original Native fixtures."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

root = Path('/tmp/klem-willingness-interactions')
prep = Path(__file__).resolve().parent
out = prep / 'willingness-interaction-focused.json'
assert not out.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [root / name for name in ['Cargo.toml', 'Cargo.lock', 'flake.nix', 'README.md']]
for folder in ['src', 'tests', 'tools', 'docs', 'web/src']:
    files.extend(p for p in (root / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files.append(Path(__file__))
frozen = {str(p): sha(p) for p in files}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
index = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=root)).hexdigest()
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/klem-willingness-interaction-target', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2')
commands = [['cargo', 'fmt', '--all', '--', '--check'],
            ['cargo', 'test', '--locked', '--offline', '--features', 'web', '--test', 'willingness_question'],
            ['cargo', 'clippy', '--locked', '--offline', '--features', 'web', '--test', 'willingness_question', '--', '-D', 'warnings']]
r = {'state': 'running', 'pid': os.getpid(), 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head, 'index_sha256': index, 'frozen_inputs': frozen, 'runs': [], 'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)}, 'scope': 'Actual focused library/Native/Unicode regression target including all inherited willingness tests and two additional independently authored interaction regressions; complete formatting and focused Clippy with warnings denied. Runtime source unchanged. Shared-ledger/browser/installed/current-main, whole new-branch suite and independent contextual review remain separate.'}
save = lambda: out.write_text(json.dumps(r, indent=2) + '\n')
save()
try:
    for i, command in enumerate(commands):
        log = prep / ('willingness-interaction-focused-' + str(i) + '.log')
        assert not log.exists()
        with log.open('xb') as stream:
            job = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
        text = log.read_text()
        batches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
        total = sum(int(batch[1]) for batch in batches)
        r['runs'].append({'command': command, 'exit_code': job.returncode, 'log_sha256': sha(log), 'tests_passed': total})
        save(); assert job.returncode == 0, (i, str(log))
        if i == 1: assert total >= 12 and all(batch[0] == 'ok' and int(batch[2]) == 0 for batch in batches)
    r.update(state='passed', exit_code=0)
except Exception as error:
    r.update(state='failed', error=str(error))
    raise
finally:
    r.update(inputs_unchanged=all(sha(p) == h for p, h in frozen.items()), head_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == head,
             index_unchanged=hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=root)).hexdigest() == index,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
assert r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged']
print('Interaction library/Native/Unicode tests, complete format and focused Clippy passed:', r['runs'][1]['tests_passed'], 'tests', flush=True)
