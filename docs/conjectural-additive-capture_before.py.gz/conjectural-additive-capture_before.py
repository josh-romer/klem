"""Observe complete original source contexts without turning candidates into judgments."""
import gzip
import hashlib
import json
import subprocess
import unicodedata
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
SOURCE = OUT / 'complete-source-preparation.json'
CLI = Path('/tmp/klem-formal-expression-target/debug/klem')
DB = ROOT / '.direnv/dictionary-restoration/krdict.db'
RESULT = OUT / 'before-streams.json.gz'
assert not RESULT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
frozen = {str(p): sha(p) for p in [SOURCE, CLI, DB, Path(__file__)]}
packet = json.loads(SOURCE.read_bytes())
assert packet['state'] == 'complete-original-conjectural-additive-sources-verified-before-probe'
runs = []
for family in ['complete-original-source', 'all-proposed-targets']:
    groups = ['\n'.join(g['complete_original_group']) for g in packet['complete_groups']] if family == 'complete-original-source' else [p['surface'] for p in packet['independent_proposals']]
    text = ('\n' if family == 'complete-original-source' else ' ').join(groups)
    for encoding in ['NFC', 'NFD']:
        original = unicodedata.normalize(encoding, text).encode()
        positions = []
        offset = 0
        for group, proposal in zip(groups, packet['independent_proposals'], strict=True):
            raw = unicodedata.normalize(encoding, group).encode()
            target = unicodedata.normalize(encoding, proposal['surface']).encode()
            assert raw.count(target) == 1
            positions.append(offset + raw.index(target))
            offset += len(raw) + 1
        for mode, flags in [('raw', []), ('headword', ['--dict-only']), ('compatible', ['--dict-compatible'])]:
            uncached = None
            for cache in [0, 4096]:
                command = [str(CLI), 'text', '-', '--dictionary', str(DB), *flags, '--cache-bytes', str(cache)]
                job = subprocess.run(command, input=original, capture_output=True, check=True, cwd=ROOT)
                assert not job.stderr
                rows = [json.loads(line) for line in job.stdout.splitlines()]
                cursor = 0
                for row in rows:
                    assert row['span']['start'] == cursor
                    cursor = row['span']['end']
                    assert original[row['span']['start']:cursor].decode() == row['surface']
                assert cursor == len(original)
                observed = []
                for position, proposal in zip(positions, packet['independent_proposals'], strict=True):
                    index, row = next((i, r) for i, r in enumerate(rows) if r['span']['start'] == position)
                    assert row['surface'] == unicodedata.normalize(encoding, proposal['surface'])
                    paths = (row.get('analysis') or {}).get('analyses', [])
                    matches = [i for i, path in enumerate(paths) if [l['text'] for l in path['lemmas']] == proposal['proposed_lemmas']]
                    observed.append({'id': proposal['id'], 'record_index': index, 'proposed_lemma_indices': matches, 'verdict': 'unjudged'})
                if uncached is None:
                    uncached = job.stdout
                else:
                    assert job.stdout == uncached
                runs.append({'family': family, 'encoding': encoding, 'mode': mode, 'cache_bytes': cache,
                             'command': command, 'exit_code': 0, 'input_sha256': hashlib.sha256(original).hexdigest(),
                             'jsonl': job.stdout.decode(), 'jsonl_sha256': hashlib.sha256(job.stdout).hexdigest(),
                             'records': len(rows), 'observed_proposals': observed, 'original_bytes_conserved': True})
                print(family, encoding, mode, cache, len(rows), 'frames;', sum(bool(r['proposed_lemma_indices']) for r in observed), 'proposed lemma groups found', flush=True)
assert len(runs) == 24 and all(sha(path) == digest for path, digest in frozen.items())
report = {'state': 'complete-before-observation-passed', 'runs': runs, 'frozen_inputs': frozen, 'inputs_unchanged': True,
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)},
          'scope': 'All16independently proposed original occurrences across24Unicode/filter/cache streams. Complete words, candidate paths and dictionary assessments retained; all source bytes and cache output conserved. Matching lemmas alone are not grammar judgments. No source target, source note or baseline is changed to fit the output. Typed authored paths/boundaries/library/Native/browser/distribution/Nix/main/contextual review remain required.'}
RESULT.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
