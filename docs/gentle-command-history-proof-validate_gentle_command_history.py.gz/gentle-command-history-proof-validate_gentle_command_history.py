"""Validate exact historical attribution and the original ledger plus later tails."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-gentle-command')
OUT = PREP / 'gentle-command-history-validation.json'
assert not OUT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [WORK / name for name in subprocess.check_output(
    ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=WORK
).decode().split('\0')[:-1]] + [Path(__file__)]
frozen = {str(p): sha(p) for p in files}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
index = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest()
suites = ['copula_expectation', 'counterfactual_ryeon', 'degree_rimankeum',
          'deoniman', 'friendly_command', 'ssik_adverb']
rust_scope = sum((WORK / ('tests/' + name + '.rs')).read_text().count('#[test]') for name in suites)
commands = []
for tool, count in [('gentle_command_history_audit', 14), ('formal_volitional_ledger_audit', 11),
                    ('literary_question_geona_runtime', 97)]:
    commands += [(['python3', 'tools/' + tool + '.py'], None)] if tool != 'literary_question_geona_runtime' else []
    commands += [(['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_' + tool + '.py'], count)]
commands += [(['cargo', 'test', '--locked', '--offline', '--features', 'web',
              *[arg for name in suites for arg in ['--test', name]]], rust_scope),
             (['cargo', 'fmt', '--all', '--', '--check'], None),
             (['cargo', 'clippy', '--locked', '--offline', '--features', 'web',
               *[arg for name in suites for arg in ['--test', name]], '--', '-D', 'warnings'], None)]
env = dict(os.environ, CARGO_TARGET_DIR='/home/josh/projects/klem/.direnv/gentle-command-target',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2')
r = dict(state='running', started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         frozen_inputs=frozen, head=head, index_sha256=index, runs=[],
         producer=dict(text=Path(__file__).read_text(), sha256=sha(__file__)),
         scope='Exact18gentle-command histories preserve all original fixtures, ordered candidates and unjudged status; strict whole append-only ledger retained. Full suite/current Nix/packages/browser/gold/performance remain separate.')
save = lambda: OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2)+'\n')
save()
try:
    for number, (command, expected) in enumerate(commands):
        log = PREP / f'gentle-command-history-validation-{number}.log'
        assert not log.exists()
        with log.open('xb') as stream:
            job = subprocess.run(command, cwd=WORK, env=env, stdout=stream, stderr=subprocess.STDOUT)
        raw = log.read_bytes()
        count = None
        if expected is not None and job.returncode == 0:
            if command[0] == 'python3':
                matches = re.findall(rb'Ran (\d+) tests? in ', raw)
                assert len(matches) == 1 and int(matches[0]) == expected and raw.rstrip().endswith(b'OK')
                count = expected
            else:
                matches = re.findall(rb'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', raw)
                count = sum(int(item[1]) for item in matches)
                assert len(matches) == len(suites) and count == expected and all(item[0] == b'ok' and item[2] == b'0' for item in matches)
        r['runs'].append(dict(command=command, exit_code=job.returncode, tests=count, log_sha256=sha(log)))
        save()
        assert job.returncode == 0, (number, str(log))
        print('passed', number, count, flush=True)
    r.update(state='passed', controls=122, affected_rust_tests=rust_scope, exit_code=0)
except Exception as error:
    r.update(state='failed', error=str(error))
    raise
finally:
    r.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             inputs_unchanged=all(sha(p) == digest for p, digest in frozen.items()),
             head_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == head,
             index_unchanged=hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest() == index)
    save()
assert r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged']
