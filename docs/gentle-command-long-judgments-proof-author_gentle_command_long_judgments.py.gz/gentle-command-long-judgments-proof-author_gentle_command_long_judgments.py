"""Author bounded structural targets before implementing or observing the new rule."""
import datetime,gzip,hashlib,json
from pathlib import Path
PREP=Path(__file__).resolve().parent
WORK=Path('/home/josh/projects/klem/.direnv/gentle-command-long')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
source_raw=(PREP/'gentle-command-long-original-source.json').read_bytes()
source=json.loads(source_raw)
assert not source['observed_runtime'] and not source['linguistic_judgments_promoted']
sources={f'gentle-command-long-{ident.split(":")[1]}':owner['url'] for ident,owner in source['owners'].items()}
cases=[]
rule='ending.gentle_command_long'
def add(ident,surface,lemma,verdict,owner,reason,kinds=None,forms=None,parts=None):
    cases.append(dict(id=ident,surface=surface,judgments=[dict(id='structural-path',lemmas=[lemma] if isinstance(lemma,str) else lemma,
        lemma_kinds=kinds or ['predicate'],morphemes=forms or ['으려무나'],morpheme_kinds=parts or ['ending'],
        verdict=verdict,required_rules=[rule],source=f'gentle-command-long-{owner}',reason=reason)]))
for item in source['items']:
    add(item['id'],item['surface'],item['independent_typed_proposal']['lemmas'],'required',item['entry_id'].split(':')[1],
        'Original complete dictionary example independently identifies this lexical head and canonical ending. Contextual sense and cross-token auxiliary selection remain unjudged.')
# These forms are independently spelled from the original vowel/ㄹ and other-coda
# attachment notes and lexical inflection classes, without consulting candidates.
for i,(surface,lemma,owner) in enumerate([('오려무나','오다',79266),('살려무나','살다',79266),('먹으려무나','먹다',79265),
    ('들으려무나','듣다',79265),('도우려무나','돕다',79266),('지으려무나','짓다',79265),('나으려무나','낫다',79265)],1):
    add(f'gentle-command-long-boundary-required-{i}',surface,lemma,'required',owner,
        'Independent regular/ㄹ/ㄷ/ㅂ/ㅅ stem proposal under the original verb-only allomorph notes; other lexical homonyms and raw hypotheses remain available.')
for i,(surface,lemma,owner) in enumerate([('오으려무나','오다',79265),('살으려무나','살다',79265),('먹려무나','먹다',79266),
    ('들려무나','듣다',79266),('도려무나','돕다',79266),('지려무나','짓다',79266),('나려무나','낫다',79266)],1):
    add(f'gentle-command-long-boundary-forbidden-{i}',surface,lemma,'forbidden',owner,
        'This exact lexical head and ending violate the source-listed short/full stem boundary. The judgment does not reject other readings of the surface.')
add('gentle-command-long-bare-copula-forbidden','학생이려무나',['학생','이다'],'forbidden',79266,
    'The original notes select a bare verb; the exact nominal plus copula path does not acquire this ending.',
    kinds=['nominal','copula'])
add('gentle-command-long-dapda-forbidden','학생답려무나',['학생','답다'],'forbidden',79266,
    'The known adjective derivation cannot borrow the bare verb-only ending. Unknown lexical predicates remain unjudged.',
    kinds=['nominal','predicate'],forms=['답다','으려무나'],parts=['suffix','ending'])
add('gentle-command-long-joined-auxiliary-required','물어보려무나',['묻다','보다'],'required',79266,
    'The known 어-linked lexical verb and following 보다 auxiliary license this isolated joined structural alternative; lexical 물어보다 and contextual sense alternatives remain separate.',
    kinds=['predicate','auxiliary'],forms=['어','으려무나'],parts=['ending','ending'])
assert len(cases)==25 and sum(c['judgments'][0]['verdict']=='required' for c in cases)==16
suite=dict(schema_version=1,review_status='Source-based structural judgments authored before rule implementation or candidate observation; independent Korean-language/context/register review pending.',sources=sources,cases=cases)
out=PREP/'gentle-command-long-validity.json';assert not out.exists();out.write_text(json.dumps(suite,ensure_ascii=False,indent=2)+'\n')
receipt=dict(state='independent-long-gentle-judgments-authored-before-rule-implementation',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             source_sha256=sha(source_raw),suite_sha256=sha(out.read_bytes()),cases=25,required=16,forbidden=9,
             observed_new_runtime=False,active_shared_cases_or_reviews_changed=False,
             producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())))
(PREP/'gentle-command-long-judgments-authoring.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print('Authored25privatecases:16required/9forbidden; no new runtime observed.')
