"""Prepare independent completed-output audit and remaining browser/audit stages."""
import ast,gzip,hashlib,json,re
from pathlib import Path
P=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=P/'friendly-hortative-sena-completion-audit-preparation.json';assert not manifest.exists()
files={}
for path in [P/'friendly-hortative-sena-installed-runtime-retry3.json.gz',P/'friendly-hortative-sena-installed-runtime-progress-retry3.json',P/'friendly-hortative-sena-installed-continuation-retry3.json',P/'friendly-hortative-sena-installed-continuation-retry3.log']+sorted(P.glob('friendly-hortative-sena-installed-retry3-command-*.gz')):
 raw=path.read_bytes();dest=P/('friendly-hortative-sena-completion-audit-original-'+path.name+'.gz');assert not dest.exists();dest.write_bytes(gzip.compress(raw,mtime=0));files[path.name]=dict(path=dest.name,source_sha256=sha(raw),archive_sha256=sha(dest.read_bytes()))
names=['run_friendly_hortative_sena_installed_browser_retry3.py','validate_friendly_hortative_sena_installed_audit_retry3.py','friendly_hortative_sena_installed_audit_retry3.py','test_friendly_hortative_sena_installed_audit_retry3.py','continue_sena_installed_validation_retry3.py']
mapping={n:n.replace('_retry3.py','_retry4.py') for n in names};tokens={**mapping,**{n[:-3]:v[:-3] for n,v in mapping.items()}};pattern=re.compile(r'\b(?:'+'|'.join(re.escape(n) for n in sorted(tokens,key=len,reverse=True))+r')\b')
new={}
for name in names:
 raw=(P/name).read_bytes();dest=P/('friendly-hortative-sena-completion-audit-original-'+name+'.gz');assert not dest.exists();dest.write_bytes(gzip.compress(raw,mtime=0));files[name]=dict(path=dest.name,source_sha256=sha(raw),archive_sha256=sha(dest.read_bytes()))
 text=pattern.sub(lambda m:tokens[m.group()],raw.decode()).replace('installed-runtime-retry3.json.gz','installed-runtime-completion-audit.json.gz').replace('installed-continuation-retry3','installed-continuation-retry4')
 text=text.replace('capture_friendly_hortative_sena_installed_runtime_retry3.py','audit_completed_sena_runtime.py')
 if name=='friendly_hortative_sena_installed_audit_retry3.py':
  old="queries[head]['stdout'] == row['stdout'] and queries[head]['response'] == row['response']";assert text.count(old)==1;text=text.replace(old,"queries[head]['stdout'] == row['stdout'] and json.loads(queries[head]['stdout']) == json.loads(row['stdout'])")
 if name=='test_friendly_hortative_sena_installed_audit_retry3.py':
  assert {n.name:ast.dump(n) for n in ast.walk(ast.parse(raw)) if isinstance(n,ast.FunctionDef)}=={n.name:ast.dump(n) for n in ast.walk(ast.parse(text)) if isinstance(n,ast.FunctionDef)},'all original40 test bodies'
 if name=='continue_sena_installed_validation_retry3.py':
  needle="            ('installed-runtime', 'audit_completed_sena_runtime.py', prefix + 'installed-runtime-completion-audit.json.gz'),\n";assert text.count(needle)==1;text=text.replace(needle,'')
  text=text.replace("'all-three-replay-browser-audit-stages-passed'","'remaining-browser-and40-audits-passed'")
 ast.parse(text);dest=P/mapping[name];assert not dest.exists();dest.write_text(text);new[dest.name]=dict(sha256=sha(dest.read_bytes()))
manifest.write_text(json.dumps(dict(state='prepared-not-executed',originals=files,new_producers=new,all_original40_test_bodies_retained=True,scope='Independent supplementary audit of all253 completed actual calls. Original failed receipt, full log, producer and every partial stream remain unchanged. No repeat of complete replay.'),indent=2)+'\n')
print('Preserved',len(files),'full originals; new browser and audit bindings prepared; original40 test bodies unchanged.')
