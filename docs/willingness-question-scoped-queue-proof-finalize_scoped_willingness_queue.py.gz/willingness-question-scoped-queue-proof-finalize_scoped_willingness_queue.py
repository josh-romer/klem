"""Refresh final evidence digests, retaining every already reconciled inventory row."""
import gzip,hashlib,json,subprocess,sys
from pathlib import Path
prep=Path(__file__).resolve().parent;work=Path('/tmp/klem-willingness-interactions');out=prep/'willingness-final-scoped-inventory-validation.json';assert not out.exists();sys.path.insert(0,str(work/'tools'));import review_inventory as inventory
sha=lambda raw:hashlib.sha256(raw).hexdigest();path=work/inventory.QUEUE;raw=path.read_bytes();parent=json.loads(raw)
metadata,entries=inventory.dictionary_entries(Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db'));updated=inventory.build_queue(work,metadata,entries);inventory.verify_queue(work,updated)
assert parent['entries']==updated['entries'] and len(updated['entries'])==715 and parent['dictionary_metadata']==updated['dictionary_metadata'] and updated['counts']['by_review']=={'scoped':515,'unreviewed':200}
new=(json.dumps(updated,ensure_ascii=False,indent=2)+'\n').encode();path.write_bytes(new)
r=dict(state='running',parent_queue_sha256=sha(raw),queue_sha256=sha(new),all715_final_source_review_catalog_and_citation_rows_unchanged=True,only_derived_evidence_digests_refreshed=True,counts=updated['counts'],runs=[],producer={'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())});out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
for i,command in enumerate([['python3','tools/review_inventory.py','--verify'],['python3','-m','unittest','discover','-s','tools','-p','test_review_inventory.py'],['python3','tools/expression_conjectural_ledger_audit.py']]):
 log=prep/('willingness-final-scoped-inventory-validation-'+str(i)+'.log');assert not log.exists()
 with log.open('xb') as stream:job=subprocess.run(command,cwd=work,stdout=stream,stderr=subprocess.STDOUT)
 r['runs'].append(dict(command=command,exit_code=job.returncode,log_sha256=sha(log.read_bytes())));out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');assert job.returncode==0
r.update(state='passed',controls=10);out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
manifest=dict(state='passed',artifacts={},counts=updated['counts'],scope='Original715source rows and513manual reviews retained; onlytwo bounded ending reviews/eight exact citations appended, then derived digests refreshed after final browser proof archival. Independent/contextual review remains pending.')
for name in [Path(__file__).name,'reconcile_scoped_willingness_queue.py','willingness-scoped-queue-reconciliation.json',out.name]+['willingness-final-scoped-inventory-validation-'+str(i)+'.log' for i in range(3)]:
 raw=(prep/name).read_bytes();target=work/'docs'/('willingness-question-scoped-queue-proof-'+name+'.gz');assert not target.exists();encoded=gzip.compress(raw,mtime=0);target.write_bytes(encoded);manifest['artifacts'][name]={'path':target.name,'sha256':sha(encoded),'original_sha256':sha(raw)}
p=work/'docs/willingness-question-scoped-inventory-validation.json';assert not p.exists();p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print('Finalqueue10controls and exact-history audit passed; all715reconciled rows unchanged, 515scoped/200unreviewed')
