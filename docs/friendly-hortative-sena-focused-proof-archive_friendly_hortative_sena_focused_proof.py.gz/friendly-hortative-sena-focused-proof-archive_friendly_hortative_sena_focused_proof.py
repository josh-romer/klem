"""Retain the actual focused passes alongside the original Clippy failure."""
import gzip,hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=Path('/home/josh/projects/klem/.direnv/friendly-hortative-sena');D=W/'docs'
sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((P/'friendly-hortative-sena-focused-validation-retry1.json').read_bytes());failure=json.loads((P/'friendly-hortative-sena-first-validation-failure.json').read_bytes())
assert r['state']=='passed' and r['rust_totals']==dict(passed=27,failed=0,ignored=0) and len(r['results'])==5 and all(x['exit_code']==0 for x in r['results'])
assert all(r[k] for k in ['inputs_unchanged','external_inputs_unchanged','protected_parent_binaries_unchanged','gena_parent_inputs_unchanged','head_unchanged','index_unchanged'])
assert all(sha((W/n).read_bytes())==digest for n,digest in r['frozen_inputs'].items())
assert r['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
assert sha((P/'friendly-hortative-sena-focused-validation-retry1.log').read_bytes())==r['log_sha256']
files={}
def add(name,raw):
 path=D/('friendly-hortative-sena-focused-proof-'+name+'.gz');assert not path.exists();packed=gzip.compress(raw,mtime=0);path.write_bytes(packed);files[name]=dict(path=path.name,source_sha256=sha(raw),archive_sha256=sha(packed))
for name in ['validate_friendly_hortative_sena_focused_retry1.py','friendly-hortative-sena-focused-validation-retry1.json','friendly-hortative-sena-focused-validation-retry1.log','friendly-hortative-sena-first-validation-failure.json',Path(__file__).name]:add(name,(P/name).read_bytes())
for name,item in failure['files'].items():
 packed=(P/item['path']).read_bytes();assert sha(packed)==item['archive_sha256'];raw=gzip.decompress(packed);assert sha(raw)==item['source_sha256'];add('original-failure-'+name.replace('/','_'),raw)
path=D/'friendly-hortative-sena-focused-proof-archive.json';assert not path.exists();path.write_text(json.dumps(dict(state='isolated-Sena-focused27-tests-format-Clippy-passed-original-lint-failure-retained',files=files,source_groups=5,private_cases=25,required=19,forbidden=6,complete_native_owners=36,original_word_records=63,focused_rust_passed=27,own_Sena_tests=8,parent_Gena_tests=8,backend_source_label_tests=11,all_7005_source_head_index_and_parent_binaries_unchanged=True,all_old_case_review_fixture_and_gold_bytes_retained=True,shared35740cases519reviews_unchanged=True,initial_rust27_passed_but_final_clippy_failed=True,fix='Initialize the same four ordered Ending records with vec!; no lint suppression or semantic change.',full_Rust_history_broad_gold_CLI_browser_installed_Nix_main_quiet_context_register_independent_review='pending',full_coverage_complete=False),indent=2)+'\n');print('Archived14 full focused/failure artifacts;27 actualRust passes,fmt/Clippy; Source-independent baseline remains separate.',flush=True)
