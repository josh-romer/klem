"""Run the entire merged-main Rust suite with every tracked input frozen."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = PREP.parents[1]
OUT = PREP / 'main-full-rust.json'
LOG = PREP / 'main-full-rust.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
index = sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT))
names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')[:-1]
frozen = {name: sha((ROOT / name).read_bytes()) for name in names}
command = ['cargo', 'test', '--locked', '--offline', '--features', 'web']
env = {**os.environ, 'CARGO_TARGET_DIR': '/tmp/klem-apprehensive-main-target',
       'CARGO_BUILD_JOBS': '4', 'CARGO_PROFILE_DEV_DEBUG': '0',
       'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_INCREMENTAL': '0'}
r = {'state': 'running', 'head': head, 'index_sha256': index, 'frozen_files': frozen,
     'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'command': command,
     'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())},
     'scope': 'Actual complete committed main Rust after source-preserving formal merge de6b8d6 and archived independent omitted-copula prototype proof162e826. All35530oldcases/507reviews retained; only53Source+fourreviewednovelcases/four boundedreviews added:35587/511/204. Actualmain13Source/novel/sharedledgertests, wholeformat andalltargetClippy warningsdenied andqueueverification/10controlspass. Mainalltrackedsource/HEAD/index frozen. ActualmainNix/source/currentinventory/installed/quiettiming andwidercontextual review remain required. Separate expressiongate andconjectural prototype remain unmerged.'}
OUT.write_text(json.dumps(r, indent=2) + '\n')
with LOG.open('xb') as stream:
    job = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
batches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', LOG.read_text())
totals = {key: sum(int(batch[i + 1]) for batch in batches) for i, key in enumerate(['passed', 'failed', 'ignored'])}
unchanged = all(sha((ROOT / name).read_bytes()) == digest for name, digest in frozen.items())
head_same = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == head
index_same = sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT)) == index
r.update(state='passed' if job.returncode == 0 and unchanged and head_same and index_same else 'failed',
         exit_code=job.returncode, inputs_unchanged=unchanged, head_unchanged=head_same, index_unchanged=index_same,
         totals=totals, batches=len(batches), log_sha256=sha(LOG.read_bytes()),
         finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
OUT.write_text(json.dumps(r, indent=2) + '\n')
print(r['state'], totals, len(batches), 'batches;', len(frozen), 'tracked inputs unchanged', unchanged, flush=True)
raise SystemExit(0 if r['state'] == 'passed' else 1)
