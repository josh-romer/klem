"""Independently audit all completed replay results without relabeling the failed attempt."""
import datetime,gzip,hashlib,json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent/'friendly-hortative-sena'
OUT=P/'friendly-hortative-sena-installed-runtime-completion-audit.json.gz'
assert not OUT.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(name):
 raw=(P/name).read_bytes();return json.loads(gzip.decompress(raw) if name.endswith('.gz') else raw)
original_path=P/'friendly-hortative-sena-installed-runtime-retry3.json.gz';original_raw=original_path.read_bytes();original=read(original_path.name)
assert original['state']=='failed' and original['error']=='every actual command stream captured'
assert all(original[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged'])
assert len(original['command_attempts'])==253
package=read('friendly-hortative-sena-nix-packages-retry1.json');assert package['state']=='passed'
sys.path.insert(0,str(W/'tools'));sys.path.insert(0,str(P))
import friendly_hortative_sena_installed_audit_retry4 as audit
v=dict(installed=original,reference=dict(runtime=dict(captures=read('friendly-hortative-sena-runtime-records.json.gz')),native=read('friendly-hortative-sena-extra-native.json.gz'),cohorts=read('friendly-hortative-sena-cohorts.json.gz'),gold=read('friendly-hortative-sena-corpora.json.gz'),broad=read('friendly-hortative-sena-broad.json.gz')),revision=dict(browser=dict(corpus=read('friendly-hortative-sena-corpus-regression-retry.json.gz'))))
audit.inspect_runtime(v)
# Independently bind every recorded actual stream to its complete raw bytes.
streams={}
for attempt in original['command_attempts']:
 assert attempt['exit_code']==0 and set(attempt['streams'])=={'stdout','stderr'}
 if attempt['input'] is not None:assert sha(attempt['input'].encode())==attempt['input_sha256']
 for kind,row in attempt['streams'].items():
  path=Path(row['path']);packed=path.read_bytes();raw=gzip.decompress(packed)
  assert sha(packed)==row['archive_sha256'] and sha(raw)==row['sha256'] and len(raw)==row['bytes'],'complete actual raw stream'
  assert str(path) not in streams;streams[str(path)]=row
# Every finite/native/lookup/gold stdout must be present as an actual command stream.
for key in ['source_runs','corpus_sentence_runs','native_records','lookup_records','corpus_runs']:
 for row in original[key]:
  matches=[a for a in original['command_attempts'] if a['command']==row['command'] and a['streams']['stdout']['sha256']==row['stdout_sha256']]
  assert matches,'all complete captured result bytes bound to actual stream'
for row in original['broad_runs']:
 matched=[a for a in original['command_attempts'] if a['command']==row['command'] and a['streams']['stdout']['sha256']==row['stdout_sha256']]
 assert len(matched)==1
 raw=gzip.decompress(Path(matched[0]['streams']['stdout']['path']).read_bytes())
 assert len(raw.splitlines())==row['records'],'all actual broad frames retained'
for path,digest in original['frozen_inputs'].items():assert sha(Path(path).read_bytes())==digest,'all original runtime inputs unchanged now'
for name,digest in package['frozen_inputs'].items():assert sha((W/name).read_bytes())==digest,'all complete package source inputs unchanged now'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==original['captured_head']
assert sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))==original['index_sha256']
r=dict(original)
r.update(state='passed',completion_kind='independent-completed-output-audit',original_attempt_state='failed',original_attempt_error=original['error'],original_attempt_path=str(original_path),original_attempt_sha256=sha(original_raw),actual_replay_producer=original['producer'],producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),supplementary_audit_executed_cli_commands=0,all253_actual_command_streams_verified=True,complete_stream_count=len(streams),scope='Supplementary independent result audit: all original253 actual replay commands completed before the wrapper failed on a Git metadata capture. Original failed receipt/log/producer/streams retained unchanged. All48 source/corpus policies,46 wholeNative,72headqueries,53502cohort WordAnalysis,66570gold rows and1128312broad frames exactly checked against original current Source references. This audit executes no replay commands and does not turn the original failure into a passing attempt.',supplementary_audited_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
r['frozen_inputs']=dict(original['frozen_inputs']);r['frozen_inputs'][str(Path(__file__))]=sha(Path(__file__).read_bytes());r['frozen_inputs'][str(Path(audit.__file__))]=sha(Path(audit.__file__).read_bytes())
assert original_path.read_bytes()==original_raw
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Independent completed-output audit passed:253 actual commands/506 full streams; original failed attempt unchanged; zero replay commands repeated.',flush=True)
