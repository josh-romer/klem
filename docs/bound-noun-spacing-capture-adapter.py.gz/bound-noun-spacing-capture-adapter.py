"""Bind all original annotated rows to the actual isolated installed Rust adapter."""
import argparse,gzip,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from friendly_command_corpora import outcome
read=lambda p:json.load(gzip.open(p,'rt'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--package',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args();assert not args.output.exists();receipt=json.loads(args.package.read_bytes())
assert receipt['state']=='passed' and receipt['exit_code']==0 and receipt['source_unchanged'] and receipt['inputs_unchanged']
adapter=Path(next(o for o in receipt['outputs'] if o.endswith('-klem-corpus-adapter-0.1.0')))/'bin/klem-corpus-adapter';corpus_path=ROOT/'docs/literary-question-geona-prototype-corpora.json.gz';corpus=read(corpus_path)
frozen={str(p):sha(p) for p in [adapter,corpus_path,args.package,Path(__file__)]};runs=[]
for partition in corpus['corpora']:
 source=ROOT/partition['source'];frozen[str(source)]=sha(source);assert sha(source)==partition['source_sha256']
 command=[str(adapter),partition['corpus'],partition['source']];job=subprocess.run(command,cwd=ROOT,capture_output=True,check=True);rows=list(map(json.loads,job.stdout.splitlines()));assert not job.stderr and len(rows)==partition['report_lines'] and rows[0]['input_sha256']==partition['source_sha256']
 for actual,gold,expected in zip(rows[1:],partition['original_converted_rows'],partition['comparisons'],strict=True):
  for key in ['id','surface','expected']:assert actual[key]==gold[key]==expected[key]
  matched,recovered,sets=outcome(gold['expected'],corpus['after_words'][gold['surface']]['analyses']);assert (actual['matched'],actual['recovered'],actual['recovered_sets'])==(matched,recovered,sets)
 for key in ['converted_rows','grouped_matches','recovered_gold_lemmas','gold_lemmas','mean_candidates','p95_candidates','max_candidates']:assert abs(rows[0][key]-partition['after_summary'][key])<1e-10,key
 runs.append({k:partition[k] for k in ['corpus','partition','source','source_sha256']}|{'command':command,'exit_code':0,'rows':len(rows)-1,'jsonl':job.stdout.decode(),'sha256':hashlib.sha256(job.stdout).hexdigest(),'summary':rows[0],'all_original_rows_and_candidate_summaries_bound':True});print(partition['corpus'],partition['partition'],len(rows)-1,'actual isolated installed rows pass',flush=True)
assert sum(r['rows'] for r in runs)==66570 and all(sha(p)==h for p,h in frozen.items())
r={'schema_version':1,'state':'passed','exit_code':0,'adapter':str(adapter),'adapter_sha256':sha(adapter),'package_sha256':sha(args.package),'source_profile':receipt['source_profile'],'corpus_sha256':sha(corpus_path),'runs':runs,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Every original66570annotated row and candidate-count summary against the actual installed prototype Rust adapter bound to its956selected source files. Root integration, contextual precision and independent review remain separate.','contextual_verdict':'unjudged','independent_review':'pending'}
args.output.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('All66570actual isolated installed rows bound')
