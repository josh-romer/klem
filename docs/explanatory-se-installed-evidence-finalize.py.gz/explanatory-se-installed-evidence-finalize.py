"""Record passed independent installed audits and their finite coverage scope."""
import gzip
import json
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
ROOT = BASE / 'explanatory-se-integration'
PREP = BASE / 'explanatory-se-prepared'
DOCS = ROOT / 'docs'
log = (PREP / 'installed-controls.log').read_text()
assert 'Ran 24 tests' in log and log.rstrip().endswith('OK')
result = (PREP / 'installed-audit-retry1.log').read_text()
assert "'finite_frames': 5280" in result and "'full_coverage_complete': False" in result
for name in ['installed-audit-retry1.log', 'installed-controls.log']:
    (DOCS / ('explanatory-se-' + name + '.gz')).write_bytes(gzip.compress((PREP / name).read_bytes(), mtime=0))
summary = ('All four actual Nix packages and installed source/launcher binding pass with unchanged inputs: '
           '1,044 Rust/adapter source files and 18 frontend files. Installed replay passes all 24 finite '
           'Unicode/filter/cache streams (5,280 frames), 53,502 cohort words, 66,570 original annotated '
           'rows with two gold recoveries, and 1,128,312 broad frames. The actual installed launcher '
           'passes 318 policy decisions, 314 diagrams, six exact exports and 170 complete Native '
           'endpoints; server stopped. The independent complete installed audit and all 24 corruption '
           'controls pass. The initial cache-budget lookup failure is retained; each 4 KiB installed '
           'eviction run is compared to both original 0/8 MiB cache outputs without changing commands '
           'or captures. Seven audit families are wired into Nix. Complete inventory execution, main '
           'integration, quiet performance and wider/contextual/independent review remain open.')
p = DOCS / 'explanatory-se-draft.md'
text = p.read_text()
text = text.replace('Status: isolated private prototype; current main and both running Nix branches\nare unchanged.',
                    'Status: committed source-backed integration on `coverage/explanatory-se`;\nactual Nix packages and complete installed replays pass. Main integration remains pending.')
text = text.replace('Remaining: exact Nix and installed validation, quiet timings, main integration,', 'Remaining: complete Nix inventory execution, quiet timings, main integration,')
text = text.replace('Six new audit families are wired into the Nix gate.', 'Seven new audit families are wired into the Nix gate.')
text = text.replace('Six audit families are wired into\nNix; the actual Nix gate, installed replays and main integration remain separate.', 'Seven audit families are wired into\nNix; complete inventory execution and main integration remain separate.')
text += '\n' + summary + '\n'
p.write_text(text)
p = DOCS / 'coverage-checklist.md'
text = p.read_text().replace('Partial: isolated source-backed implementation; main unchanged.', 'Partial: committed source-backed integration; Nix packages and installed validation pass.')
text = text.replace('  Nix/installed/main validation,\n', '  complete inventory execution and main integration,\n')
text = text.replace('Six audit families are wired into Nix. The older-written', 'Seven audit families are wired into Nix. The older-written')
marker = '\n\n\n- [ ] **COV-018'
assert marker in text
text = text.replace(marker, '\n  ' + summary + marker, 1)
p.write_text(text)
p = DOCS / 'inventory-reviews.json'
data = json.loads(p.read_text())
changed = 0
for item in data['entries']:
    if item['id'] not in ['krdict:79278', 'krdict:79279', 'krdict:83914']:
        continue
    assert any(e['path'] == 'docs/explanatory-se-draft.md' for e in item['evidence'])
    item['scope'] += ' ' + summary
    item['remaining'] = 'Complete inventory execution; main integration; quiet paired performance; wider distributions, contextual sense selection and independent linguistic review. Older-written 살으십니다그려 remains unresolved.'
    for path in ['docs/explanatory-se-integration-packages.json.gz', 'docs/explanatory-se-installed-source-binding.json.gz',
                 'docs/explanatory-se-installed-finite.json.gz', 'docs/explanatory-se-installed-cohorts.json.gz',
                 'docs/explanatory-se-installed-corpora.json.gz', 'docs/explanatory-se-installed-broad.json.gz',
                 'docs/explanatory-se-installed-browser.json.gz', 'docs/explanatory-se-installed-browser-runtime.json.gz',
                 'docs/explanatory-se-installed-audit-retry1.log.gz', 'docs/explanatory-se-installed-controls.log.gz',
                 'tools/explanatory_se_installed_audit.py', 'tools/test_explanatory_se_installed_audit.py']:
        assert (ROOT / path).exists()
        item['evidence'].append({'path': path})
    changed += 1
assert changed == 3
p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
(DOCS / 'explanatory-se-installed-evidence-finalize.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('Updated three finite source reviews, tracker and seven-family Nix wiring; full coverage remains partial', flush=True)
