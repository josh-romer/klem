import json,os,shutil,subprocess,time
from pathlib import Path
root=Path('/tmp/klem-possessive-bound-noun-final-prototype');out=Path('/tmp/klem-possessive-bound-noun-rust-final-retry1.json');assert not out.exists()
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/josh/projects/klem/.direnv/possessive-spacing-target',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
r={'state':'running','steps':[],'started_at':time.time()};out.write_text(json.dumps(r,indent=2)+'\n')
for name,command in [('fmt',['cargo','fmt','--all','--check']),('build',['cargo','build','--offline','--features','web','--bins']),('case-tests',['cargo','test','--offline','--features','web','--test','possessive_bound_noun_spacing']),('full-test',['cargo','test','--offline','--features','web']),('clippy',['cargo','clippy','--offline','--all-targets','--features','web','--','-D','warnings'])]:
 log=Path('/tmp/klem-possessive-bound-noun-'+name+'-final-retry1.log');assert not log.exists()
 with log.open('xb') as stream:job=subprocess.run(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 r['steps'].append({'name':name,'command':command,'exit_code':job.returncode,'log':str(log)});out.write_text(json.dumps(r,indent=2)+'\n')
 if job.returncode:r['state']='failed';out.write_text(json.dumps(r,indent=2)+'\n');raise SystemExit(job.returncode)
 if name=='build':
  for name,source in [('cli','klem'),('server','klem-web')]:shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'debug'/source,'/tmp/klem-possessive-bound-noun-final-'+name)
r.update(state='passed',finished_at=time.time());out.write_text(json.dumps(r,indent=2)+'\n');print(r)
