"""Refresh prototype catalog/evidence links without promoting private judgments or reviews."""
import gzip,hashlib,json,subprocess,sys
from pathlib import Path
prep=Path(__file__).resolve().parent;work=Path('/tmp/klem-gentle-command');out=prep/'gentle-command-inventory-validation.json';assert not out.exists();sys.path.insert(0,str(work/'tools'));import review_inventory as inventory
sha=lambda raw:hashlib.sha256(raw).hexdigest();path=work/inventory.QUEUE;raw=path.read_bytes();parent=json.loads(raw)
metadata,entries=inventory.dictionary_entries(Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db'));updated=inventory.build_queue(work,metadata,entries);inventory.verify_queue(work,updated)
before={r['source']['id']:r for r in parent['entries']};after={r['source']['id']:r for r in updated['entries']};assert set(before)==set(after) and len(after)==715 and parent['dictionary_metadata']==updated['dictionary_metadata']
changed=[]
for ident,old in before.items():
 for field in ['source','source_sha256','review','inventory_evidence','cited_judgments']:assert old[field]==after[ident][field],(ident,field)
 if old['catalog']!=after[ident]['catalog']:
  assert ident in ['krdict:79340','krdict:79343'] and after[ident]['catalog']==old['catalog']+[{'form':'-으렴','kind':'ending'}];changed.append(ident)
assert set(changed)=={'krdict:79340','krdict:79343'} and updated['counts']['by_review']=={'scoped':513,'unreviewed':202}
archive=work/'docs/gentle-command-parent-inventory-queue.json.gz';assert not archive.exists();archive.write_bytes(gzip.compress(raw,mtime=0));path.write_text(json.dumps(updated,ensure_ascii=False,indent=2)+'\n')
r=dict(state='running',parent_queue_sha256=sha(raw),queue_sha256=sha(path.read_bytes()),all715_source_review_and_judgment_rows_unchanged=True,only_new_catalog_links=changed,counts=updated['counts'],runs=[],producer={'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())})
for i,command in enumerate([['python3','tools/gentle_command_source_audit.py'],['python3','-m','unittest','discover','-s','tools','-p','test_gentle_command_source_audit.py'],['python3','tools/review_inventory.py','--verify'],['python3','-m','unittest','discover','-s','tools','-p','test_review_inventory.py']]):
 log=prep/('gentle-command-inventory-validation-'+str(i)+'.log');assert not log.exists()
 with log.open('xb') as stream:job=subprocess.run(command,cwd=work,stdout=stream,stderr=subprocess.STDOUT)
 r['runs'].append(dict(command=command,exit_code=job.returncode,log_sha256=sha(log.read_bytes())));out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');assert job.returncode==0
r.update(state='passed',controls=26);out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print('Gentle-source16 + inventory10 controls pass; all715original review/judgment rows retained, onlytwo catalog links added')
