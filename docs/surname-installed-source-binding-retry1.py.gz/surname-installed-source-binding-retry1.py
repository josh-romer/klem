import hashlib,json
from pathlib import Path
r=json.loads(Path('/tmp/klem-surname-nix-retry1.json').read_text());ds=json.loads(Path('/tmp/klem-surname-installed-derivations.json').read_text());union={};packages=[]
for drv,d in ds.items():
 source=Path(d['env']['src']);files={}
 for p in source.rglob('*'):
  if not p.is_file():continue
  relative=str(p.relative_to(source));name=('web/'+relative) if d['env']['pname']=='klem-web-assets' else relative
  raw=p.read_bytes();h={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};assert r['snapshot_files'][name]==h,name
  files[name]=h
  if name in union:assert union[name]==h
  union[name]=h
 packages.append({'derivation':drv,'source':str(source),'files':files,'outputs':d['outputs']})
expected={k:v for k,v in r['snapshot_files'].items() if k not in ['flake.nix','flake.lock']};assert union==expected,(len(union),len(expected))
p=Path('/tmp/klem-surname-installed-source-binding-retry1.json');assert not p.exists()
p.write_text(json.dumps({'state':'installed-production-source-binding-passed','packages':packages,'union_files':len(union),'nix_receipt_sha256':hashlib.sha256(Path('/tmp/klem-surname-nix-retry1.json').read_bytes()).hexdigest(),'producer':Path(__file__).read_text(),'full_coverage_complete':False},indent=2)+'\n')
print('All',len(union),'installed production inputs match the frozen tested snapshot')
