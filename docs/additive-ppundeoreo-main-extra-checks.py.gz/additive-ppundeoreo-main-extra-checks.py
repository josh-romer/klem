"""Run documentation and downloaded-corpus checks on the unchanged current main inputs."""
import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');OUT=Path('/tmp/klem-additive-ppundeoreo-main-extra-checks.json');assert not OUT.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest();rust=json.loads(Path('/tmp/klem-additive-ppundeoreo-main-rust.json').read_bytes());assert rust['state']=='passed' and rust['inputs_unchanged'] is True
snapshot=rust['snapshot_files'];assert all(sha((ROOT/n).read_bytes())==v['sha256'] for n,v in snapshot.items())
data={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in (ROOT/'data/corpora').rglob('*') if p.is_file()}
common=['cargo','test','--locked','--offline','--features','web','--target-dir','/tmp/klem-additive-ppundeoreo-prototype-target-no-debug']
commands=[('doc',common+['--doc']),('pinned-corpus',common+['--test','corpus','pinned_full_corpus_regressions','--','--ignored'])]
report={'state':'running','snapshot_files':snapshot,'downloaded_corpus_files':data,'runs':[],'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())}}
def save():OUT.write_text(json.dumps(report,indent=2)+'\n')
save();env=dict(os.environ,CARGO_BUILD_JOBS='4',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_INCREMENTAL='0')
for label,command in commands:
 log=Path('/tmp/klem-additive-ppundeoreo-main-'+label+'.log');assert not log.exists()
 with log.open('xb') as stream:job=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
 rows=re.findall(rb'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_bytes(),re.MULTILINE)
 assert len(rows)==1
 report['runs'].append({'name':label,'command':command,'exit_code':job.returncode,'tests':dict(zip(['passed','failed','ignored'],map(int,rows[0]))),'log_sha256':sha(log.read_bytes())});save()
 if job.returncode!=0:report['state']='failed';save();raise SystemExit(job.returncode)
 print(label,'passed',report['runs'][-1]['tests'],flush=True)
report.update(state='passed',exit_code=0,inputs_unchanged=all(sha((ROOT/n).read_bytes())==v['sha256'] for n,v in snapshot.items()),downloaded_corpus_unchanged=all(sha((ROOT/n).read_bytes())==digest for n,digest in data.items()),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save();assert report['inputs_unchanged'] and report['downloaded_corpus_unchanged']
