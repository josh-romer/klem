//! Recorded whole-head origins for separately reported dictionary identity evidence.
use crate::engine::PredicateClass;
use crate::{Lemma, LemmaKind, Morpheme};

pub(crate) struct OriginSource {
    pub base: &'static str,
    pub expected_origins: &'static [&'static str],
    pub whole_entries: &'static [&'static str],
    pub whole_origins_complete: bool,
}

/// Resolve evidence from this owner's represented suffix chain, including
/// the intervening -시. Ordinary nouns and unrelated owners cannot borrow it.
pub(crate) fn owned_source(
    lemma: &Lemma,
    rules: &[String],
    morphs: &[Morpheme],
) -> Option<&'static OriginSource> {
    if let Some(source) = crate::hada_remaining::owned_source(lemma, rules, morphs) {
        return Some(source);
    }
    if lemma.kind != LemmaKind::Nominal {
        return None;
    }
    if let Some(source) = crate::hada_suffix::owned_source(lemma, rules, morphs) {
        return Some(source);
    }
    if crate::nominal_hwa::owner(lemma, rules, morphs)
        && !morphs
            .get(1)
            .is_some_and(|m| m.kind == crate::MorphemeKind::Suffix && m.form == "되다")
    {
        return crate::nominal_hwa::nominal_identity(&lemma.text);
    }
    let class = crate::doeda_suffix::owner_class(lemma, rules, morphs)?;
    if crate::nominal_si::passive_owner(lemma, rules, morphs) {
        crate::nominal_si::identity(&lemma.text)
    } else if crate::nominal_hwa::passive_owner(lemma, rules, morphs) {
        crate::nominal_hwa::identity(&lemma.text)
    } else {
        source(&lemma.text, class)
    }
}

pub(crate) fn source(base: &str, class: PredicateClass) -> Option<&'static OriginSource> {
    if !matches!(class, PredicateClass::Verb) {
        return None;
    }
    SOURCES
        .binary_search_by_key(&base, |s| s.base)
        .ok()
        .map(|i| &SOURCES[i])
        .or_else(|| crate::doeda_originless_forms::source(base))
}

const SOURCES: &[OriginSource] = &[
    OriginSource {
        base: "가공",
        expected_origins: &["加工"],
        whole_entries: &["krdict:27950"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "가산",
        expected_origins: &["加算"],
        whole_entries: &["krdict:14561"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "가설",
        expected_origins: &["假設", "架設"],
        whole_entries: &["krdict:14606", "krdict:14607"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "가정",
        expected_origins: &["假定"],
        whole_entries: &["krdict:25834"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "각색",
        expected_origins: &["脚色"],
        whole_entries: &["krdict:14598"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "각하",
        expected_origins: &["却下"],
        whole_entries: &["krdict:15255"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "간주",
        expected_origins: &["看做"],
        whole_entries: &["krdict:14158"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "강점",
        expected_origins: &["強占"],
        whole_entries: &["krdict:19627"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "개관",
        expected_origins: &["開館"],
        whole_entries: &["krdict:23714"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "개국",
        expected_origins: &["開國"],
        whole_entries: &["krdict:23717"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "개선",
        expected_origins: &["改善"],
        whole_entries: &["krdict:15784"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "개시",
        expected_origins: &["開始"],
        whole_entries: &["krdict:26646"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "개화",
        expected_origins: &["開化"],
        whole_entries: &["krdict:24680"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "거부",
        expected_origins: &["拒否"],
        whole_entries: &["krdict:27286"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "결의",
        expected_origins: &["決議"],
        whole_entries: &["krdict:32118"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "결정",
        expected_origins: &["決定"],
        whole_entries: &["krdict:61093"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "경감",
        expected_origins: &["輕減"],
        whole_entries: &["krdict:30468"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "경도",
        expected_origins: &["傾倒"],
        whole_entries: &["krdict:32369"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "고갈",
        expected_origins: &["枯渴"],
        whole_entries: &["krdict:27994"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "고려",
        expected_origins: &["考慮"],
        whole_entries: &["krdict:23668"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "고시",
        expected_origins: &["告示"],
        whole_entries: &["krdict:18816"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "고조",
        expected_origins: &["高調"],
        whole_entries: &["krdict:27160"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "고지",
        expected_origins: &["告知"],
        whole_entries: &["krdict:27239"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "공고",
        expected_origins: &["公告"],
        whole_entries: &["krdict:19534"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "공론",
        expected_origins: &["公論"],
        whole_entries: &["krdict:88296"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "공인",
        expected_origins: &["公認", "共認"],
        whole_entries: &["krdict:23799", "krdict:23801"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "공제",
        expected_origins: &["控除"],
        whole_entries: &["krdict:23566"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "공포",
        expected_origins: &["公布"],
        whole_entries: &["krdict:15415"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "과장",
        expected_origins: &["誇張"],
        whole_entries: &["krdict:18295"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "관계",
        expected_origins: &["關係"],
        whole_entries: &["krdict:23968"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "관리",
        expected_origins: &["管理"],
        whole_entries: &["krdict:30358"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "교정",
        expected_origins: &["校正", "校訂", "矯正"],
        whole_entries: &["krdict:88799", "krdict:88801", "krdict:88803"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "교차",
        expected_origins: &["交叉"],
        whole_entries: &["krdict:32425"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "구비",
        expected_origins: &["具備"],
        whole_entries: &["krdict:35064"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "구상",
        expected_origins: &["構想"],
        whole_entries: &["krdict:36562"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "구상화",
        expected_origins: &["具象化"],
        whole_entries: &["krdict:88808"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "구속",
        expected_origins: &["拘束"],
        whole_entries: &["krdict:24550"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "구애",
        expected_origins: &["拘礙"],
        whole_entries: &["krdict:35661"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "구인",
        expected_origins: &["拘引"],
        whole_entries: &["krdict:35765"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "구제",
        expected_origins: &["救濟"],
        whole_entries: &["krdict:36916"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "구조",
        expected_origins: &["救助"],
        whole_entries: &["krdict:36926"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "구형",
        expected_origins: &["求刑"],
        whole_entries: &["krdict:36763"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "급수",
        expected_origins: &["給水"],
        whole_entries: &["krdict:89625"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "급전",
        expected_origins: &["急轉"],
        whole_entries: &["krdict:89627"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "기공",
        expected_origins: &["起工"],
        whole_entries: &["krdict:89870"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "기도",
        expected_origins: &["企圖"],
        whole_entries: &["krdict:37950"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "기술",
        expected_origins: &["記述"],
        whole_entries: &["krdict:38349"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "내장",
        expected_origins: &["內藏"],
        whole_entries: &["krdict:39890"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "내정",
        expected_origins: &["內定"],
        whole_entries: &["krdict:41114"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "노후",
        expected_origins: &["老朽"],
        whole_entries: &["krdict:600665"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "녹음",
        expected_origins: &["錄音"],
        whole_entries: &["krdict:40706"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "녹화",
        expected_origins: &["錄畫"],
        whole_entries: &["krdict:40721"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "단수",
        expected_origins: &["斷水"],
        whole_entries: &["krdict:90601"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "단전",
        expected_origins: &["斷電"],
        whole_entries: &["krdict:90392"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "대두",
        expected_origins: &["擡頭"],
        whole_entries: &["krdict:48451"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "대비",
        expected_origins: &["對比"],
        whole_entries: &["krdict:56048"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "동요",
        expected_origins: &["動搖"],
        whole_entries: &["krdict:48606"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "동화",
        expected_origins: &["同化"],
        whole_entries: &["krdict:48164"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "매수",
        expected_origins: &["買收"],
        whole_entries: &["krdict:55603"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "매장",
        expected_origins: &["埋葬", "埋藏"],
        whole_entries: &["krdict:55720", "krdict:55721"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "매진",
        expected_origins: &["賣盡"],
        whole_entries: &["krdict:55732"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "미화",
        expected_origins: &["美化"],
        whole_entries: &["krdict:56704"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "반감",
        expected_origins: &["半減"],
        whole_entries: &["krdict:56748"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "반려",
        expected_origins: &["返戾"],
        whole_entries: &["krdict:56978"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "발병",
        expected_origins: &["發病"],
        whole_entries: &["krdict:56833"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "발전",
        expected_origins: &["發展"],
        whole_entries: &["krdict:15871"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "발포",
        expected_origins: &["發布"],
        whole_entries: &["krdict:57032"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "방면",
        expected_origins: &["放免"],
        whole_entries: &["krdict:57867"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "변경",
        expected_origins: &["變更"],
        whole_entries: &["krdict:58237"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "보고",
        expected_origins: &["報告"],
        whole_entries: &["krdict:59651"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "보도",
        expected_origins: &["報道"],
        whole_entries: &["krdict:14493"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "복권",
        expected_origins: &["復權"],
        whole_entries: &["krdict:59792"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "부수",
        expected_origins: &["附隨"],
        whole_entries: &["krdict:60013"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "부식",
        expected_origins: &["腐蝕"],
        whole_entries: &["krdict:60019"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "부여",
        expected_origins: &["附與"],
        whole_entries: &["krdict:60031"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "부인",
        expected_origins: &["否認"],
        whole_entries: &["krdict:59713"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "부정",
        expected_origins: &["否定"],
        whole_entries: &["krdict:59806"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "분단",
        expected_origins: &["分斷"],
        whole_entries: &["krdict:59348"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "분화",
        expected_origins: &["分化"],
        whole_entries: &["krdict:60279"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "사면",
        expected_origins: &["赦免"],
        whole_entries: &["krdict:61945"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "산재",
        expected_origins: &["散在"],
        whole_entries: &["krdict:91922"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "산정",
        expected_origins: &["算定"],
        whole_entries: &["krdict:61803"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "상관",
        expected_origins: &["相關"],
        whole_entries: &["krdict:62205"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "상장",
        expected_origins: &["上場"],
        whole_entries: &["krdict:600939"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "상정",
        expected_origins: &["上程"],
        whole_entries: &["krdict:62616"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "서양화",
        expected_origins: &["西洋化"],
        whole_entries: &["krdict:62851"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "선발",
        expected_origins: &["選拔"],
        whole_entries: &["krdict:63144"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "선임",
        expected_origins: &["選任"],
        whole_entries: &["krdict:62692"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "선전",
        expected_origins: &["宣傳"],
        whole_entries: &["krdict:62803"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "선정",
        expected_origins: &["選定"],
        whole_entries: &["krdict:64411"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "선행",
        expected_origins: &["先行"],
        whole_entries: &["krdict:63181"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "소요",
        expected_origins: &["所要"],
        whole_entries: &["krdict:49243"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "소장",
        expected_origins: &["所藏"],
        whole_entries: &["krdict:81650"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "수리",
        expected_origins: &["修理", "受理"],
        whole_entries: &["krdict:64928", "krdict:64930"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "수습",
        expected_origins: &["收拾"],
        whole_entries: &["krdict:65030"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "수입",
        expected_origins: &["輸入"],
        whole_entries: &["krdict:15639"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "수장",
        expected_origins: &["水葬"],
        whole_entries: &["krdict:65564"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "수정",
        expected_origins: &["修正", "受精"],
        whole_entries: &["krdict:65444", "krdict:65445"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "수행",
        expected_origins: &["遂行"],
        whole_entries: &["krdict:64733"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "수호",
        expected_origins: &["守護"],
        whole_entries: &["krdict:64765"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "시공",
        expected_origins: &["施工"],
        whole_entries: &["krdict:65837"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "시작",
        expected_origins: &["始作"],
        whole_entries: &["krdict:66566"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "시정",
        expected_origins: &["是正"],
        whole_entries: &["krdict:66053"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "시행",
        expected_origins: &["施行"],
        whole_entries: &["krdict:65755"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "신장",
        expected_origins: &["伸張"],
        whole_entries: &["krdict:91255"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "신축",
        expected_origins: &["新築"],
        whole_entries: &["krdict:91286"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "실례",
        expected_origins: &["失禮"],
        whole_entries: &["krdict:78458"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "안정",
        expected_origins: &["安定"],
        whole_entries: &["krdict:16011"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "양분",
        expected_origins: &["兩分"],
        whole_entries: &["krdict:90574"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "양산",
        expected_origins: &["量産"],
        whole_entries: &["krdict:90576"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "양성",
        expected_origins: &["養成"],
        whole_entries: &["krdict:90582"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "역전",
        expected_origins: &["逆轉"],
        whole_entries: &["krdict:67434"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "연금",
        expected_origins: &["軟禁"],
        whole_entries: &["krdict:67453"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "연기",
        expected_origins: &["延期"],
        whole_entries: &["krdict:14009"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "연상",
        expected_origins: &["聯想"],
        whole_entries: &["krdict:67525"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "연습",
        expected_origins: &["練習/鍊習"],
        whole_entries: &["krdict:91847"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "원조",
        expected_origins: &["援助"],
        whole_entries: &["krdict:70293"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "위장",
        expected_origins: &["僞裝"],
        whole_entries: &["krdict:69655"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "유도",
        expected_origins: &["誘導"],
        whole_entries: &["krdict:72444"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "유리",
        expected_origins: &["遊離"],
        whole_entries: &["krdict:70462"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "유산",
        expected_origins: &["流産"],
        whole_entries: &["krdict:91981"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "유용",
        expected_origins: &["流用"],
        whole_entries: &["krdict:70627"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "유인",
        expected_origins: &["誘引"],
        whole_entries: &["krdict:70079"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "유전",
        expected_origins: &["遺傳"],
        whole_entries: &["krdict:70202"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "유지",
        expected_origins: &["維持"],
        whole_entries: &["krdict:27110"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "유치",
        expected_origins: &["誘致"],
        whole_entries: &["krdict:70221"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "육성",
        expected_origins: &["育成"],
        whole_entries: &["krdict:70953"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "의식",
        expected_origins: &["意識"],
        whole_entries: &["krdict:71889"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "이월",
        expected_origins: &["移越"],
        whole_entries: &["krdict:91748"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "이적",
        expected_origins: &["移籍"],
        whole_entries: &["krdict:72864"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "이전",
        expected_origins: &["移轉"],
        whole_entries: &["krdict:72680"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "이해",
        expected_origins: &["理解"],
        whole_entries: &["krdict:24963"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "인가",
        expected_origins: &["認可"],
        whole_entries: &["krdict:72946"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "인도",
        expected_origins: &["引導", "引渡"],
        whole_entries: &["krdict:72872", "krdict:72875"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "인상",
        expected_origins: &["引上"],
        whole_entries: &["krdict:72908"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "인정",
        expected_origins: &["認定"],
        whole_entries: &["krdict:25100"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "인지",
        expected_origins: &["認知"],
        whole_entries: &["krdict:72638"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "입수",
        expected_origins: &["入手"],
        whole_entries: &["krdict:83518"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "재배",
        expected_origins: &["栽培"],
        whole_entries: &["krdict:74653"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "저지",
        expected_origins: &["沮止"],
        whole_entries: &["krdict:74635"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "저하",
        expected_origins: &["低下"],
        whole_entries: &["krdict:74668"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "전달",
        expected_origins: &["傳達"],
        whole_entries: &["krdict:25147"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "전복",
        expected_origins: &["顚覆"],
        whole_entries: &["krdict:74853"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "전송",
        expected_origins: &["電送"],
        whole_entries: &["krdict:74386"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "전승",
        expected_origins: &["傳承"],
        whole_entries: &["krdict:74700"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "전시",
        expected_origins: &["展示"],
        whole_entries: &["krdict:25320"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "전파",
        expected_origins: &["傳播"],
        whole_entries: &["krdict:75095"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "절제",
        expected_origins: &["節制"],
        whole_entries: &["krdict:81828"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "정립",
        expected_origins: &["定立"],
        whole_entries: &["krdict:76293"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "정의",
        expected_origins: &["定義"],
        whole_entries: &["krdict:75885"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "정지",
        expected_origins: &["停止"],
        whole_entries: &["krdict:75919"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "정체",
        expected_origins: &["停滯"],
        whole_entries: &["krdict:75629"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "정화",
        expected_origins: &["淨化"],
        whole_entries: &["krdict:75450"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "제명",
        expected_origins: &["除名"],
        whole_entries: &["krdict:76082"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "제약",
        expected_origins: &["制約"],
        whole_entries: &["krdict:75723"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "조리",
        expected_origins: &["調理"],
        whole_entries: &["krdict:75439"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "조사",
        expected_origins: &["調査"],
        whole_entries: &["krdict:75308"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "조작",
        expected_origins: &["造作"],
        whole_entries: &["krdict:75481"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "조장",
        expected_origins: &["助長"],
        whole_entries: &["krdict:75491"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "조정",
        expected_origins: &["調整"],
        whole_entries: &["krdict:75495"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "조화",
        expected_origins: &["調和"],
        whole_entries: &["krdict:24604"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "존속",
        expected_origins: &["存續"],
        whole_entries: &["krdict:75871"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "종전",
        expected_origins: &["終戰"],
        whole_entries: &["krdict:75759"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "주",
        expected_origins: &["主"],
        whole_entries: &["krdict:75964"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "주관",
        expected_origins: &["主管"],
        whole_entries: &["krdict:75854"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "주장",
        expected_origins: &["主張"],
        whole_entries: &["krdict:77009"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "주지",
        expected_origins: &["周知"],
        whole_entries: &["krdict:77086"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "중복",
        expected_origins: &["重複"],
        whole_entries: &["krdict:76618"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "중지",
        expected_origins: &["中止"],
        whole_entries: &["krdict:77198"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "지각",
        expected_origins: &["知覺"],
        whole_entries: &["krdict:91668"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "지도",
        expected_origins: &["指導"],
        whole_entries: &["krdict:76924"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "지명",
        expected_origins: &["指名"],
        whole_entries: &["krdict:77425"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "지연",
        expected_origins: &["遲延"],
        whole_entries: &["krdict:76858"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "지원",
        expected_origins: &["支援"],
        whole_entries: &["krdict:601021"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "지적",
        expected_origins: &["指摘"],
        whole_entries: &["krdict:28421"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "진동",
        expected_origins: &["震動"],
        whole_entries: &["krdict:76526"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "진정",
        expected_origins: &["鎭靜"],
        whole_entries: &["krdict:76328"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "착상",
        expected_origins: &["着想"],
        whole_entries: &["krdict:78886"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "처형",
        expected_origins: &["處刑"],
        whole_entries: &["krdict:78030"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "천명",
        expected_origins: &["闡明"],
        whole_entries: &["krdict:77560"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "청산",
        expected_origins: &["淸算"],
        whole_entries: &["krdict:79291"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "초대",
        expected_origins: &["招待"],
        whole_entries: &["krdict:80505"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "추상화",
        expected_origins: &["抽象化"],
        whole_entries: &["krdict:80399"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "침식",
        expected_origins: &["侵蝕", "浸蝕"],
        whole_entries: &["krdict:80795", "krdict:80800"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "통화",
        expected_origins: &["通話"],
        whole_entries: &["krdict:82049"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "투사",
        expected_origins: &["投射"],
        whole_entries: &["krdict:82946"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "평정",
        expected_origins: &["平定"],
        whole_entries: &["krdict:81426"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "필사",
        expected_origins: &["筆寫"],
        whole_entries: &["krdict:86154"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "해산",
        expected_origins: &["解散"],
        whole_entries: &["krdict:601158"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "해체",
        expected_origins: &["解體"],
        whole_entries: &["krdict:85006"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "행사",
        expected_origins: &["行使"],
        whole_entries: &["krdict:84977"],
        whole_origins_complete: true,
    },
    OriginSource {
        base: "협의",
        expected_origins: &["協議"],
        whole_entries: &["krdict:90625"],
        whole_origins_complete: true,
    },
];
