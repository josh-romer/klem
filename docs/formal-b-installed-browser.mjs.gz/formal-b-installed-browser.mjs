import assert from 'node:assert/strict';
import {gunzipSync} from 'node:zlib';
import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root='/home/josh/projects/klem',proto='/home/josh/projects/klem/.direnv/formal-b-integration';
const url=process.env.KLEM_WEB_URL,cli=process.env.KLEM_BIN||'/nix/store/hxcmfinkw976ydd87gbn66nq0qjg27jg-klem-0.1.0/bin/klem',db=root+'/data/dictionaries/krdict/krdict.db',prefix=process.env.KLEM_CAPTURE_PREFIX||'/home/josh/projects/klem/.direnv/formal-installed-validation/formal-b';
const suite=JSON.parse(await readFile(proto+'/tests/fixtures/formal-b-validity.json','utf8'));
const cases=suite.cases.filter(c=>c.judgments.some(j=>j.verdict==='required'));
const {chromium}=createRequire('/home/josh/projects/klem/.direnv/dapnikka-integration/web/package.json')('playwright');
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH,args:['--no-sandbox']});
const errors=[],exports=[],responses=[],diagrams=[],spacingDiagrams=[],nativeEntries=[];
try {
 const page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});
 page.on('pageerror',error=>errors.push(String(error)));await page.goto(url);
 const breakdown=page.getByRole('region',{name:'Sentence breakdown',exact:true});
 for(const encoding of ['NFC','NFD']) {
  const text=cases.map(c=>c.surface.normalize(encoding)).join(' ');
  await page.getByLabel('Your sentence',{exact:true}).fill(text);
  const pending=page.waitForResponse(r=>r.url().endsWith('/api/analyze')&&r.request().postDataJSON()?.text===text);
  await page.getByRole('button',{name:'Analyze sentence',exact:true}).click();
  const response=await pending;assert.equal(response.status(),200);const api=await response.json();responses.push({encoding,api});
  assert.ok(api.rules['ending.formal_b']);
  await page.waitForFunction(t=>document.querySelector('.sentence')?.textContent===t,text);
  for(const [mode,flag]of[['raw',null],['headword','--dict-only'],['compatible','--dict-compatible']]) {
   if(flag){await page.getByLabel('Dictionary matches only').check();if(mode==='compatible')await page.getByLabel('Exclude known grammar conflicts').check();else await page.getByLabel('Exclude known grammar conflicts').uncheck();}
   else await page.getByLabel('Dictionary matches only').uncheck();
   const expected=execFileSync(cli,['text','-','--dictionary',db,...(flag?[flag]:[])],{input:text,encoding:'utf8',maxBuffer:32*1024*1024}).trim().split('\n').map(JSON.parse);
   const pending=page.waitForEvent('download');await page.getByRole('button',{name:'Export JSON',exact:true}).click();
   const exported=JSON.parse(await readFile(await(await pending).path(),'utf8'));assert.deepEqual(exported.records,expected);exports.push({encoding,mode,records:expected});
   for(const [ordinal,c]of cases.entries()) {
    const recordIndex=api.records.findIndex((r,i)=>r.kind==='word'&&api.records.slice(0,i).filter(t=>t.kind==='word').length===ordinal);
    const token=api.records[recordIndex];assert.equal(token.surface,c.surface.normalize(encoding));
    const judgment=c.judgments.find(j=>j.verdict==='required');
    const index=token.analysis.analyses.findIndex(a=>JSON.stringify(a.lemmas.map(l=>l.text))===JSON.stringify(judgment.lemmas)&&(!judgment.morphemes||JSON.stringify(a.morphemes.map(m=>m.form))===JSON.stringify(judgment.morphemes))&&a.rules.includes('ending.formal_b'));
    assert.ok(index>=0,c.id);
    const word=breakdown.locator('.breakdown-word').nth(ordinal),selector=word.getByRole('combobox');
    // The source note's unlisted bare/copular distribution can be Unknown,
    // which Compatible intentionally retains alongside known conflicts.
    const offered=await selector.locator('option').evaluateAll(os=>os.map(o=>o.value));assert.ok(offered.includes(String(index)),c.id+'/'+mode);
    await selector.selectOption(String(index));
    const order=api.breakdowns[recordIndex][index];assert.ok(order);
    assert.equal(await word.locator('.part-form').count(),order.length,c.id);
    const ending=word.locator('.breakdown-component').last();
    const form=token.analysis.analyses[index].morphemes.at(-1).form;
    const details={'습디다':{label:'Report from experience',ids:[80528,80530]},'습디까':{label:'Question about experience',ids:[80533,80536]},'습지요':{label:'Assured statement / question',ids:[80544,80547]},'습죠':{label:'Assured statement / question (contracted)',ids:[80546,80550]},'습네':{label:'Disapproving quotation',ids:[86556,86561]}}[form];
    assert.ok(details,c.id+'/'+form);
    assert.equal(await ending.locator('.part-gloss').textContent(),details.label,c.id);
    const refs=await ending.locator('.grammar-references a').evaluateAll(as=>as.map(a=>a.href));
    const ids=details.ids;
    const hint=await ending.locator('.breakdown-part').getAttribute('title');
    for(const id of ids)assert.ok(hint.includes(String(id)),c.id+'/'+id);
    assert.equal(refs.length,0,'KRDict label sources use the entry button and hint');
    diagrams.push({case_id:c.id,encoding,mode,analysis:token.analysis.analyses[index],forms:await word.locator('.part-form').allTextContents(),references:refs,source_hint:hint});
   }
  }
 }
 await page.getByLabel('Dictionary matches only').uncheck();
 await page.getByLabel('Your sentence',{exact:true}).fill('큽디다 누굽디까 가십지요 아름답네');
 await page.getByRole('button',{name:'Analyze sentence',exact:true}).click();
 await page.waitForFunction(()=>document.querySelector('.sentence')?.textContent==='큽디다 누굽디까 가십지요 아름답네');
 await breakdown.scrollIntoViewIfNeeded();assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 await page.screenshot({path:prefix+'-browser-desktop.png'});
 await page.setViewportSize({width:390,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:prefix+'-browser-mobile.png'});
 const native=JSON.parse(await readFile(proto+'/tests/fixtures/formal-b-native-entries.json','utf8'));
 for(const[id,value]of Object.entries(native)) {
  const response=await page.request.post(url+'/api/entry',{data:{id}});assert.equal(response.status(),200);const data=await response.json();assert.deepEqual(data.entry,value);nativeEntries.push({id,entry:data.entry});
 }
 assert.deepEqual(errors,[]);assert.equal(exports.length,6);assert.equal(diagrams.length,cases.length*6);
 await writeFile(prefix+'-browser.json',JSON.stringify({state:'installed-browser-passed',producer_sha256:createHash('sha256').update(await readFile(new URL(import.meta.url))).digest('hex'),responses,exports,diagrams,spacingDiagrams,nativeEntries,errors,scope:'Actual committed installed formal-ending SolidJS packages with all source owners, complete lexical homonyms and the explicit stem-final-ㅂ source tension, every required individual path across Unicode/filter choices and six exact CLI exports; complete source contexts and contextual review are separate.'},null,2)+'\n');
 console.log('Passed',diagrams.length,'individual diagrams and six exact exports.');
} finally {await browser.close();}
