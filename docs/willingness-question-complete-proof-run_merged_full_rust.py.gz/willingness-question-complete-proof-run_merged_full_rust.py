"""Run the complete new integration suite with its source and artifacts frozen."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-willingness-question-prototype')
OUT = PREP / 'willingness-merged-full-rust.json'
LOG = PREP / 'willingness-merged-full-rust.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [WORK / name for name in ['Cargo.toml', 'Cargo.lock', 'README.md', 'flake.nix']]
for folder in ['src', 'tests', 'tools', 'docs', 'web/src']:
    files.extend(path for path in (WORK / folder).rglob('*') if path.is_file() and '__pycache__' not in path.parts)
files.append(Path(__file__))
frozen = {str(path): sha(path) for path in sorted(set(files))}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
index = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest()
command = ['cargo', 'test', '--locked', '--offline', '--features', 'web']
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/klem-expression-conjectural-main-target',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='4')
r = {'state': 'running', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': os.getpid(),
     'head': head, 'index_sha256': index, 'frozen_inputs': frozen, 'command': command,
     'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
     'scope': 'Actual complete combined expression/conjectural/willingness suite at the captured reconciled HEAD. Active ledger35673cases/31408required/4282forbidden retains all35651parent case bytes and exact22Source/boundary appends. Both historical private ledgers, original511manualreviews plus2boundedconjectural dispositions remain intact. Focused51Rust/fmt/alltargetClippy, Source/distribution188controls, new independent browser17controls and inherited ledger18/current installed28 controls passed. Complete actual debug prototype source/corpus/cohort/broad/browser captures are archived with original parent baselines. Full current-source Nix/new installed packages/browser/performance/main and wider contextual/independent review remain pending. All Source/proofs/HEAD/index remain frozen throughout this complete Rust check.'}
OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
with LOG.open('xb') as stream:
    job = subprocess.run(command, cwd=WORK, env=env, stdout=stream, stderr=subprocess.STDOUT)
batches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', LOG.read_text())
totals = {key: sum(int(batch[i + 1]) for batch in batches) for i, key in enumerate(['passed', 'failed', 'ignored'])}
unchanged = all(sha(Path(path)) == digest for path, digest in frozen.items())
head_same = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == head
index_same = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest() == index
r.update(state='passed' if job.returncode == 0 and unchanged and head_same and index_same else 'failed',
         exit_code=job.returncode, inputs_unchanged=unchanged, head_unchanged=head_same, index_unchanged=index_same,
         totals=totals, batches=len(batches), log_sha256=sha(LOG), finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
print(r['state'], totals, len(batches), 'batches; Sourcefiles', len(frozen), 'unchanged', unchanged, flush=True)
raise SystemExit(0 if r['state'] == 'passed' else 1)
