"""Capture complete Sena corpus/history/gold/novel comparisons with frozen inputs."""
import datetime,hashlib,json,os,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=Path('/home/josh/projects/klem/.direnv/friendly-hortative-sena')
O=P/'friendly-hortative-sena-wide-comparisons.json';L=P/'friendly-hortative-sena-wide-comparisons.log';assert not O.exists() and not L.exists();assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
sha=lambda b:hashlib.sha256(b).hexdigest();names=subprocess.check_output(['git','ls-files','-z'],cwd=W).decode().split('\0')[:-1];frozen={n:sha((W/n).read_bytes()) for n in names};head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))
producers=[P/'capture_friendly_hortative_sena_cohorts.py',P/'capture_friendly_hortative_sena_corpora.py',P/'capture_friendly_hortative_sena_broad.py'];external={str(p):sha(p.read_bytes()) for p in [*producers,Path(__file__)]}
binding=json.loads((P/'friendly-hortative-sena-complete-runtime-binding.json').read_bytes());assert binding['state']=='passed';binaries={b['path']:b['sha256'] for b in binding['binaries'].values()};assert all(sha(Path(p).read_bytes())==d for p,d in binaries.items())
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,external_inputs=external,protected_current_binaries=binaries,results=[],producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Actual all53502originalcorpus/historywords,66570unchangedgoldrows and1128312fullcandidate/novel/filter/spacingframes againstactualboundinstalledGena baseline. Everyoldpath/order/Nativeassessment/token-byte/goldannotation andoldrecovery retained; everynewhypothesis/change captured withstableID andunjudgedstatus. AllcurrentSource/HEAD/index andproducer/binary bytes frozen. Independenthistory/audits/fullRust/browser/installedNix/main/timing/context/Koreanreview remain separate.')
def save():O.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
try:
 with L.open('xb') as log:
  for p in producers:
   c=['python3',str(p)];log.write(('COMMAND '+json.dumps(c)+'\n').encode());log.flush();job=subprocess.run(c,cwd=W,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=log,stderr=subprocess.STDOUT);r['results'].append(dict(command=c,exit_code=job.returncode));save();print(p.name,'exit',job.returncode,flush=True);assert job.returncode==0,'Actual wide comparison failed; original producers/partial records/log retained.'
 r['state']='passed'
except BaseException as error:r.update(state='failed',error=repr(error));raise
finally:
 r.update(inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),external_inputs_unchanged=all(sha(Path(p).read_bytes())==d for p,d in external.items()),protected_current_binaries_unchanged=all(sha(Path(p).read_bytes())==d for p,d in binaries.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==head,index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))==index,log_sha256=sha(L.read_bytes()) if L.exists() else None,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 if not all(r[k] for k in ['inputs_unchanged','external_inputs_unchanged','protected_current_binaries_unchanged','head_unchanged','index_unchanged']):r['state']='failed'
 save()
assert r['state']=='passed';print('Passed all three complete wide comparison collectors;allSource/HEAD/index/binaries unchanged.',flush=True)
