"""Confirm both repaired queues and continuity with the passed code checks."""
import datetime
import hashlib
import json
import re
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
OUT = PREP / 'gentle-command-history-final-queue-controls.json'
assert not OUT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
reconciliation_path = PREP / 'gentle-command-history-queue-reconciliation.json'
reconciliation = json.loads(reconciliation_path.read_bytes())
assert reconciliation['state'] == 'passed'
results = []
for number, row in enumerate(reconciliation['results']):
    work = Path(row['worktree'])
    queue = work / 'docs/inventory-review-queue.json'
    assert sha(queue) == row['new_queue_sha256'] and row['all715rows_exact']
    assert all(sha(p) == digest for p, digest in row['unchanged_inputs'].items())
    previous = (PREP / 'gentle-command-history-validation.json' if number == 0 else
                PREP.parent / 'expression-conjectural-main-prepared/combined-historical-ledger-repair.json')
    previous_report = json.loads(previous.read_bytes())
    assert previous_report['inputs_unchanged'] and previous_report['head_unchanged'] and previous_report['index_unchanged']
    production = {p: digest for p, digest in previous_report['frozen_inputs'].items()
                  if p.startswith(str(work)+'/') and Path(p).relative_to(work).parts[0] != 'docs'}
    assert all(sha(p) == digest for p, digest in production.items()), 'no code drift after passed checks'
    frozen = {str(work / name): sha(work / name) for name in subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=work
    ).decode().split('\0')[:-1]}
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip()
    index = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=work)).hexdigest()
    log = PREP / f'gentle-command-history-final-queue-controls-{number}.log'
    assert not log.exists()
    command = ['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_review_inventory.py']
    with log.open('xb') as stream:
        job = subprocess.run(command, cwd=work, stdout=stream, stderr=subprocess.STDOUT)
    raw = log.read_bytes()
    assert job.returncode == 0 and re.findall(rb'Ran (\d+) tests? in ', raw) == [b'10'] and raw.rstrip().endswith(b'OK')
    assert all(sha(p) == digest for p, digest in frozen.items())
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip() == head
    assert hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=work)).hexdigest() == index
    results.append(dict(worktree=str(work), command=command, controls=10, exit_code=0,
                        captured_head=head, index_sha256=index, frozen_inputs=frozen,
                        source_code_continuity=production, inputs_unchanged=True,
                        log_sha256=sha(log)))
    print(work.name, '10 queue controls passed; all prior checked code unchanged.', flush=True)
OUT.write_text(json.dumps(dict(state='passed', results=results,
               reconciliation_sha256=sha(reconciliation_path),
               finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               producer=dict(text=Path(__file__).read_text(), sha256=sha(__file__))),
               ensure_ascii=False, indent=2)+'\n')
