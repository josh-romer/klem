"""Run the actual Nix web launcher/assets and compare viewer exports with its installed CLI."""
import json,os,re,signal,subprocess,urllib.request,hashlib
from pathlib import Path
receipt_path=Path('/tmp/klem-declarative-dao-nix-retry1.json');receipt=json.loads(receipt_path.read_bytes());assert receipt['state']=='passed' and receipt['exit_code']==0 and receipt['snapshot_unchanged']
prefix=Path('/tmp/klem-declarative-dao-installed-browser-runtime');out=Path(str(prefix)+'.json');assert not out.exists()
assets=Path(next(p for p in receipt['outputs'] if p.endswith('-klem-web-assets-0.1.0')))/'share/klem-web';launcher=Path(next(p for p in receipt['outputs'] if p.endswith('-klem-web')))/'bin/klem-web';package=Path(next(p for p in receipt['outputs'] if p.endswith('-klem-0.1.0')));server=package/'bin/klem-web';cli=package/'bin/klem'
driver=Path('/tmp/klem-declarative-dao-installed-browser.mjs');db=Path('/home/josh/projects/klem/data/dictionaries/krdict/krdict.db')
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
frozen={str(p):sha(p) for p in [launcher,server,cli,driver,db,receipt_path,Path(__file__),*assets.rglob('*')] if p.is_file()}
command=[str(launcher),'--port','0','--dictionary',str(db)]
r={'state':'running','command':command,'frozen_inputs':frozen};out.write_text(json.dumps(r,indent=2)+'\n')
job=subprocess.Popen(command,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
try:
 line=job.stderr.readline();match=re.search(r'http://127\.0\.0\.1:\d+',line);assert match,line
 url=match.group();r['url']=url;r['server_pid']=job.pid
 actual=Path(f'/proc/{job.pid}/cmdline').read_bytes().split(b'\0')[:-1];assert actual[0].decode()==str(server)
 r['actual_exec_command']=[s.decode() for s in actual]
 with urllib.request.urlopen(url,timeout=10) as response:html=response.read();assert html==(assets/'index.html').read_bytes()
 checks=[]
 for path in re.findall(r'(?:src|href)="(/assets/[^"?#]+\.(?:js|css))"',html.decode()):
  with urllib.request.urlopen(url+path,timeout=10) as response:raw=response.read();assert raw==(assets/path.lstrip('/')).read_bytes();checks.append({'path':path,'sha256':hashlib.sha256(raw).hexdigest()})
 assert len(checks)==2;r['served_asset_checks']=checks
 env=dict(os.environ,KLEM_WEB_URL=url,KLEM_BIN=str(cli),KLEM_CAPTURE_PREFIX='/tmp/klem-declarative-dao-installed',CHROMIUM_PATH='/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium')
 with Path(str(prefix)+'.log').open('xb') as output:completed=subprocess.run(['node',str(driver)],env=env,stdout=output,stderr=subprocess.STDOUT)
 r.update(state='passed' if completed.returncode==0 else 'failed',exit_code=completed.returncode)
finally:
 if job.poll() is None:job.send_signal(signal.SIGINT)
 r['server_exit_code']=job.wait(timeout=20);r['server_stopped']=True;r['inputs_unchanged']=all(sha(p)==h for p,h in frozen.items());out.write_text(json.dumps(r,indent=2)+'\n')
assert r['state']=='passed',r['state'];assert r['inputs_unchanged'];print('Actual Nix launcher/browser passed; server stopped.')
