"""Materialize independently authored source targets without consulting new output."""
import gzip
import hashlib
import json
from pathlib import Path

prep = Path(__file__).resolve().parent
work = Path('/tmp/klem-willingness-question-prototype')
packet_path = prep / 'independent-source-authoring.json'
packet = json.loads(packet_path.read_bytes())
rule = 'ending.willingness_question'
cases = []
for item in packet['items']:
    judgment = dict(item['typed_target'])
    judgment['rules'] = [rule]
    cases.append({'id': item['id'], 'surface': item['surface'],
                  'source': item['entry_id'] + '/sense-' + item['sense_id'] + '/group-' + str(item['example_group']),
                  'judgments': [judgment]})
suite = {'schema': 1, 'cases': cases}
boundaries = [
    {'surface': surface, 'lemma': lemma, 'canonical': '으련', 'expected': expected,
     'reason': 'Native76564/76567 vowel-or-ㄹ short form versus other-coda full form; exact lexical analysis only.'}
    for surface, lemma, expected in [
        ('두련', '두다', True), ('주련', '주다', True), ('먹으련', '먹다', True),
        ('살련', '살다', True), ('알련', '알다', True),
        ('두으련', '두다', False), ('주으련', '주다', False), ('가으련', '가다', False),
        ('먹련', '먹다', False), ('잡련', '잡다', False),
        ('살으련', '살다', False), ('알으련', '알다', False),
    ]
]
for name, value in [('willingness-question-validity.json', suite),
                    ('willingness-question-source.json', packet),
                    ('willingness-question-boundaries.json', boundaries)]:
    target = work / 'tests/fixtures' / name
    assert not target.exists()
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
for original, name in [('native.json', 'willingness-question-native.json'),
                       ('native-entries.json', 'willingness-question-native-entries.json')]:
    target = work / 'tests/fixtures' / name
    assert not target.exists()
    target.write_bytes((prep / original).read_bytes())
baseline = json.loads(gzip.decompress((prep / 'original-installed-baseline.json.gz').read_bytes()))
observations = next(run for run in baseline['runs'] if run['family'] == 'all-individual-targets' and run['encoding'] == 'NFC' and run['mode'] == 'raw' and run['cache_bytes'] == 0)['observations']
target = work / 'tests/fixtures/willingness-question-prior-paths.json'
assert not target.exists()
target.write_text(json.dumps(observations, ensure_ascii=False, indent=2) + '\n')
out = prep / 'prototype-preparation.json'
assert not out.exists()
out.write_text(json.dumps({'state': 'source-targets-and-boundaries-prepared-before-new-runtime-probe',
                          'source_authoring_sha256': hashlib.sha256(packet_path.read_bytes()).hexdigest(),
                          'original_required_cases': len(cases), 'boundary_cases': len(boundaries),
                          'scope': 'Ten independently authored ending judgments; twelve exact stem-boundary judgments from original notes. Eight expression homonyms retain their original fields and prior analyses without assigning them the ending homonyms semantic ownership. No new output or expected-output refresh used.',
                          'producer': Path(__file__).read_text()}, indent=2) + '\n')
print('Prepared ten source judgments and twelve authored boundaries')
