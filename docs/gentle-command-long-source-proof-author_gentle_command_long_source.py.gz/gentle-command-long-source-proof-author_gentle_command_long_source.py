"""Author complete dictionary source targets before observing candidate output."""
import datetime
import hashlib
import json
import sqlite3
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = PREP.parents[1]
WORK = Path('/tmp/klem-gentle-command')
DB = ROOT/'.direnv/dictionary-restoration/krdict.db'
OUT = PREP/'gentle-command-long-original-source.json'
assert not OUT.exists()
sha = lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
targets = {'krdict:79266':[('자려무나','자다'),('나가려무나','나가다'),('쓰려무나','쓰다'),('지내려무나','지내다')],
           'krdict:79265':[('벗으려무나','벗다'),('앉으려무나','앉다'),('찾으려무나','찾다'),('있으려무나','있다')]}
frozen = {str(p):sha(p) for p in [DB,Path(__file__),WORK/'docs/inventory-review-queue.json']}
owners = {};lexical = {};items = []
with sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True) as connection:
    metadata = dict(connection.execute('SELECT key,value FROM metadata'))
    for ident,proposals in targets.items():
        owner = json.loads(connection.execute('SELECT data FROM entries WHERE id=?',(ident,)).fetchone()[0])
        assert owner['pos'] == '어미' and len(owner['senses']) == 1 and len(owner['senses'][0]['examples']) == 4
        owners[ident] = owner
        for i,((surface,lemma),group) in enumerate(zip(proposals,owner['senses'][0]['examples'],strict=True),1):
            raw = '\n'.join(group).encode();needle = surface.encode();start = raw.index(needle)
            assert raw.count(needle) == 1
            all_owners = [json.loads(row[0]) for row in connection.execute('SELECT data FROM entries WHERE headword=? ORDER BY id',(lemma,))]
            assert all_owners and any(entry['pos']=='동사' for entry in all_owners)
            lexical[lemma] = all_owners
            items.append(dict(id=f"gentle-command-long-{ident.split(':')[1]}-sense-1-group-{i}",
                entry_id=ident,sense_id='1',example_group=i,complete_original_group=group,
                surface=surface,local_span=dict(start=start,end=start+len(needle)),
                independent_typed_proposal=dict(lemmas=[lemma],lemma_kinds=['predicate'],morphemes=['으려무나'],morpheme_kinds=['ending']),
                contextual_scope=('Isolated token structural target. Original 기다리고 있으려무나 context is retained; '
                    'cross-token auxiliary interpretation and verb/adjective owner choice are not settled by this proposal.' if lemma=='있다' else
                    'Original complete source group retained; contextual sense/register and independent Korean review pending.')))
assert len(items) == 8 and owners['krdict:79266']['headword']=='-려무나' and owners['krdict:79265']['headword']=='-으려무나'
assert all(sha(p)==digest for p,digest in frozen.items())
r = dict(schema_version=1,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         planned_checklist='COV-017da',state='original-source-targets-authored-before-runtime',
         ending_owner_ids=list(owners),canonical_ending='으려무나',owners=owners,
         complete_lexical_homonyms=lexical,items=items,database_sha256=sha(DB),
         dictionary_metadata=metadata,frozen_inputs=frozen,inputs_unchanged=True,
         observed_runtime=False,linguistic_judgments_promoted=False,
         attribution='National Institute of Korean Language, Korean Basic Dictionary, original complete imported entries from the pinned 2026-09 Native-LMF snapshot.',
         source_license='CC BY-SA 2.0 KR',
         producer=dict(text=Path(__file__).read_text(),sha256=sha(__file__)),
         scope='Eight original whole example groups and independent typed lexical proposals, before any new candidate observation. Both verb-only ending notes and every lexical homonym retained. No rule, label, baseline, active ledger, review or frozen branch changes.',
         remaining=['Original complete Native-LMF owner/homonym recovery','Actual prior CLI baseline capture',
                    'Rule/allomorph/verb-class and auxiliary implementation','Positive and forbidden boundary judgments',
                    'Annotated and broad comparison','CLI/dictionary/browser/Nix/main/quiet performance',
                    'Contextual/register and independent Korean-language review'])
OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print('Authored8independenttargets from2completeendingowners and every lexical homonym; no runtime observation or frozen-branch mutation.',flush=True)
