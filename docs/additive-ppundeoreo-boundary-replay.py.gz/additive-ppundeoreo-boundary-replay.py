"""Retain every authored boundary/Native observation, including mismatched proposals."""
import datetime,gzip,hashlib,json,subprocess,unicodedata
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');CLI=Path('/tmp/klem-additive-ppundeoreo-cli')
CASES=Path('/tmp/klem-additive-ppundeoreo-authored-boundaries.json')
OUT=Path('/tmp/klem-additive-ppundeoreo-boundary-preflight.json.gz');assert not OUT.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
fixture=json.loads(CASES.read_bytes());cases=fixture['cases'];text=' '.join(dict.fromkeys(c['surface'] for c in cases))
frozen={str(p):sha(p.read_bytes()) for p in [CLI,CASES,Path(__file__),ROOT/'data/dictionaries/krdict/krdict.db']}
def matches(path,case):
 return ([l['text'] for l in path['lemmas']]==case['lemmas'] and
         [l['kind'] for l in path['lemmas']]==case['lemma_kinds'] and
         [m['form'] for m in path['morphemes']]==case['morphemes'] and
         [m['kind'] for m in path['morphemes']]==case['morpheme_kinds'] and
         set(case['required_rules'])<=set(path['rules']))
runs=[];observations=[];mismatches=[]
for encoding in ['NFC','NFD']:
 raw=unicodedata.normalize(encoding,text).encode()
 for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
  command=[str(CLI),'text','-','--dictionary',str(ROOT/'data/dictionaries/krdict/krdict.db'),*flags]
  job=subprocess.run(command,input=raw,capture_output=True,check=True);assert job.stderr==b''
  rows=list(map(json.loads,job.stdout.splitlines()));words={r['analysis']['normalized']:r for r in rows if r.get('analysis')}
  for case in cases:
   row=words[case['surface']];selected=[(i,a) for i,a in enumerate(row['analysis']['analyses']) if matches(a,case)]
   statuses=[row['dictionary']['readings'][i]['status'] for i,a in selected]
   present=bool(selected);expected=case['expected_presence'][mode]
   correct=present==expected and all(s==case['expected_status'] for s in statuses)
   observation={'case_id':case['id'],'encoding':encoding,'mode':mode,'present':present,
                'expected_present':expected,'statuses':statuses,'expected_status':case['expected_status'],
                'proposal_matches_observation':correct,'record':row,'matched':[a for i,a in selected]}
   observations.append(observation)
   if not correct:mismatches.append({k:v for k,v in observation.items() if k not in ['record','matched']})
  runs.append({'encoding':encoding,'mode':mode,'command':command,'input_sha256':sha(raw),'jsonl':job.stdout.decode(),
               'sha256':sha(job.stdout),'records':len(rows),'exit_code':0})
assert len(observations)==216 and all(sha(Path(p).read_bytes())==v for p,v in frozen.items())
producer=Path(__file__)
r={'state':'observed-proposals-match' if not mismatches else 'observed-proposal-mismatches','preparation_only':True,
   'fixture_sha256':frozen[str(CASES)],'runs':runs,'observations':observations,'mismatches':mismatches,
   'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':producer.read_text(),'sha256':frozen[str(producer)]},
   'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
   'scope':'Actual isolated observations for36 authored cases in both Unicode forms/all3 filters. Mismatches are preserved and require source-backed correction or implementation work. Matching conditional Native/structural proposals are not globally required judgments. Full Native owner closure, independent source verification, broad preservation and Root integration remain open.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Captured216 actual boundary/Native observations; mismatched proposals:',len(mismatches),flush=True)
for v in mismatches:print(v,flush=True)
