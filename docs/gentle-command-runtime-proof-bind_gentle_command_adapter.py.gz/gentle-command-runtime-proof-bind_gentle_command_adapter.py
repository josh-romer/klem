"""Bind the actual adapter and probe the independently authored lexical heads."""
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-gentle-command')
OUT = PREP / 'gentle-command-adapter-binding.json'
PROBE = PREP / 'gentle-command-adapter-source-probe.conllu'
assert not OUT.exists() and not PROBE.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
source_path = WORK / 'tests/fixtures/gentle-command-source.json'
closure_path = PREP / 'gentle-command-current-production-closure.json'
prior_path = PREP / 'willingness-installed-source-binding-retry1.json'
source = json.loads(source_path.read_bytes())
closure = json.loads(closure_path.read_bytes())
prior = json.loads(prior_path.read_bytes())
assert closure['state'] == prior['state'] == 'passed'
assert not source['observed_runtime'] and not source['linguistic_judgments_promoted']
before = Path(prior['profiles']['corpus-adapter']['package']) / 'bin/klem-corpus-adapter'
after = Path('/home/josh/projects/klem/.direnv/gentle-command-target/debug/examples/evaluate')
proposals = []
text = []
for item in source['items']:
    expected = item['independent_typed_proposal']['lemmas']
    assert len(expected) == 1 and expected[0].endswith('다')
    proposals.append(dict(id=item['id'], surface=item['surface'], expected=expected))
    text += [f"# sent_id = {item['id']}", f"# text = {item['surface']}",
             '\t'.join(['1', item['surface'], expected[0][:-1]+'+으렴',
                        'VERB', 'pvg+ef', '_', '0', 'root', '_', '_']), '']
PROBE.write_text('\n'.join(text)+'\n')
frozen = {str(p): sha(p) for p in [source_path, closure_path, prior_path, before,
                                after, PROBE, Path(__file__)]}
frozen.update(closure['production_inputs'])
r = dict(state='running', independently_authored_proposals=proposals,
         synthetic_probe=str(PROBE), synthetic_probe_is_annotated_corpus=False,
         source_proposals_sha256=sha(source_path), frozen_inputs=frozen, captures=[],
         captured_head=closure['captured_head'],
         producer=dict(text=Path(__file__).read_text(), sha256=sha(__file__)))
save = lambda: OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2)+'\n')
save()
try:
    for binary in [before, after]:
        command = [str(binary), 'kaist', str(PROBE)]
        job = subprocess.run(command, capture_output=True)
        assert job.returncode == 0 and not job.stderr, job.stderr
        rows = [json.loads(line) for line in job.stdout.splitlines()]
        assert len(rows) == 9
        assert [row['expected'] for row in rows[1:]] == [row['expected'] for row in proposals]
        assert [row['surface'] for row in rows[1:]] == [row['surface'] for row in proposals]
        r['captures'].append(dict(command=command, exit_code=0, jsonl=job.stdout.decode(),
                                 stdout_sha256=hashlib.sha256(job.stdout).hexdigest(),
                                 recovered_proposals=sum(row['matched'] for row in rows[1:])))
    assert r['captures'][0]['recovered_proposals'] == 0 and r['captures'][1]['recovered_proposals'] == 8
    r.update(state='passed', binaries={'before': dict(path=str(before), sha256=sha(before)),
                                     'after': dict(path=str(after), sha256=sha(after))},
             inputs_unchanged=all(sha(p) == digest for p, digest in frozen.items()),
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             scope='Actual current adapter recovers all8independentlyauthored lexical source proposals; immutable prior adapter recovers0. Synthetic source-based conversion probe is separate from original annotated corpora. Full44file production closure unchanged; full Rust/Nix/main and contextual/independent precision remain separate.')
    assert r['inputs_unchanged']
    save()
    print('Bound actual adapter: all8independentlexicalproposals recovered; prior0. Original corpora untouched.', flush=True)
except Exception as error:
    r.update(state='failed', error=str(error))
    save()
    raise
