"""Verify original successful command outputs after the wrong-count wrapper failed."""
import datetime
import gzip
import hashlib
import json
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent/'friendly-command-gena'
OUT = P/'friendly-command-gena-promotion-results-audit.json'
assert not OUT.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
originals = json.loads((P/'friendly-command-gena-promotion-count-failure-originals.json').read_bytes())
assert originals['actual_session_id'] == 43725 and originals['exit_code'] == 1
payloads = {}
for name, row in originals['originals'].items():
    packed = Path(row['path']).read_bytes()
    assert sha(packed) == row['archive_sha256']
    raw = gzip.decompress(packed);assert sha(raw) == row['source_sha256']
    assert (P/name).read_bytes() == raw
    payloads[name] = raw
report = json.loads(payloads['friendly-command-gena-promotion-validation.json'])
log = payloads['friendly-command-gena-promotion-validation.log']
assert report['state'] == 'failed' and report['error'] == 'AssertionError()'
assert len(report['results']) == 12 and all(r['exit_code'] == 0 and r['rust_failed'] == 0 for r in report['results'])
assert all(report[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged'])
assert sha(log) == report['log_sha256']
chunks = re.split(rb'^COMMAND (.+)\n',log,flags=re.M)
assert chunks[0] == b'' and (len(chunks)-1)//2 == 12
actual_rust = [];actual_controls = []
for row, command, output in zip(report['results'],chunks[1::2],chunks[2::2],strict=True):
    assert json.loads(command) == row['command']
    rust = re.findall(rb'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',output)
    if rust:
        assert row['command'] == ['cargo','test','--locked','--offline','--features','web','--test','validity','--test','friendly_command_gena']
        assert len(rust) == 2 and all(r[0] == b'ok' and int(r[2]) == int(r[3]) == 0 for r in rust)
        actual_rust.extend(int(r[1]) for r in rust)
    counts = re.findall(rb'Ran (\d+) tests',output)
    if counts:
        assert len(counts) == 1 and re.search(rb'\nOK\s*$',output) and b'FAILED' not in output
        actual_controls.append(int(counts[0]))
        assert row['controls'] == int(counts[0])
assert sorted(actual_rust) == [4,8] and actual_controls == [26,32,24,12]
assert sum(actual_rust) == report['rust_passed'] == 12 and sum(actual_controls) == report['controls'] == 94
producer = payloads['validate_friendly_command_gena_promotion.py'].decode()
assert "r['rust_passed'] == 15" in producer and report['producer'] == dict(text=producer,sha256=sha(producer.encode()))
assert all(sha((W/n).read_bytes()) == d for n,d in report['source_inputs'].items())
assert all(sha(Path(p).read_bytes()) == d for p,d in report['protected_binaries'].items())
git = lambda *a: subprocess.check_output(['git',*a],cwd=W)
assert git('rev-parse','HEAD').decode().strip() == report['head'] and sha(git('ls-files','--stage','-z')) == report['index_sha256']
current = json.loads((W/'tests/fixtures/validity.json').read_bytes())
parent_raw = gzip.decompress((W/'docs/friendly-command-gena-parent-validity.json.gz').read_bytes())
parent = json.loads(parent_raw)
suite = json.loads((W/'tests/fixtures/friendly-command-gena-validity.json').read_bytes())
assert len(current['cases']) == 35764 and current['cases'][:35740] == parent['cases'] and current['cases'][35740:] == suite['cases']
body = lambda raw:raw.split(b'"cases": [',1)[1].rsplit(b'\n  ]\n}',1)[0]
assert body((W/'tests/fixtures/validity.json').read_bytes()).startswith(body(parent_raw))
reviews = json.loads((W/'docs/inventory-reviews.json').read_bytes())
old_reviews = json.loads(gzip.decompress((W/'docs/friendly-command-gena-parent-inventory-reviews.json.gz').read_bytes()))
assert len(reviews['entries']) == 520 and reviews['entries'][:519] == old_reviews['entries']
r = dict(state='passed',actual_original_execution_session_id=43725,original_execution_exit_code=1,
         original_receipt_stays_failed=True,actual_rust_tests=12,actual_python_controls=94,
         actual_rust_suites=actual_rust,actual_python_suites=actual_controls,
         successful_command_checks=12,shared_cases=35764,scoped_reviews=520,
         source_unchanged=True,head_unchanged=True,index_unchanged=True,protected_binaries_unchanged=True,
         original_receipt_sha256=sha(payloads['friendly-command-gena-promotion-validation.json']),
         original_log_sha256=sha(log),producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
         finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Actual independent inspection of all complete original successful command outputs, exact12Rust/94Python totals and unchanged current source/HEAD/index/sixdebugbinaries. Original wrapper failed only its incorrect15Rust count and stays failed. No command rerun or new all-target Rust/Nix/installed/main/contextregisterindependent review completion claim.')
OUT.write_text(json.dumps(r,indent=2)+'\n')
print('Verified all original successful commands:12Rust94ledger controls and exact35764/520 promotion. Original incorrect-count receipt remains failed.',flush=True)
