"""Close every actually matched geona source/boundary owner against complete original LMF."""
import copy,gzip,hashlib,json,sqlite3,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from native_lmf import array,entry,verify_native_lmf
sha=lambda raw:hashlib.sha256(raw).hexdigest();read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes())
source_path=Path('/tmp/klem-literary-question-geona-prototype-source-replay.json.gz');boundary_path=Path('/tmp/klem-literary-question-geona-boundary-corrected.json.gz');prepared_path=ROOT/'docs/literary-question-geona-original-preparation.json.gz';OUT=Path('/tmp/klem-literary-question-geona-matched-owner-preparation.json.gz');assert not OUT.exists()
source,boundary,prepared=map(read,[source_path,boundary_path,prepared_path]);ids=set(source['matched_new_owner_ids'])|set(boundary['matched_new_owner_ids']);DB=ROOT/'data/dictionaries/krdict/krdict.db';frozen={str(p):sha(p.read_bytes()) for p in [source_path,boundary_path,prepared_path,DB,Path(__file__)]};names=set(prepared['named_headwords'])
with sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True) as db:
 for ident in ids:names.add(db.execute('SELECT headword FROM entries WHERE id=?',(ident,)).fetchone()[0])
 native={ident:json.loads(raw) for ident,head,raw in db.execute('SELECT id,headword,data FROM entries') if head in names}
assert ids<=native.keys() and all(native[i]==e for i,e in prepared['complete_native_entries'].items())
original={};hashes={}
for path in sorted((ROOT/'data/dictionaries/krdict/json').glob('*.json')):
 raw=path.read_bytes();name=str(path.relative_to(ROOT));hashes[name]=sha(raw);assert hashes[name]==prepared['source_hashes'][name]
 for value in array(json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']):
  base='krdict:'+value['val']
  if base not in native and not any(i.startswith(base+':') for i in native):continue
  projected=entry(value);ident=projected['id']
  if ident in native:assert projected==native[ident] and ident not in original;original[ident]=value
assert set(original)==set(native)
projection={'LexicalResource':{'Lexicon':{'LexicalEntry':[]}}}
for ident in sorted(original):
 value=copy.deepcopy(original[ident])
 for sense in array(value.get('Sense')):sense['Equivalent']=[t for t in array(sense.get('Equivalent')) if any(f.get('att')=='language' and f.get('val')=='영어' for f in array(t.get('feat')))]
 projection['LexicalResource']['Lexicon']['LexicalEntry'].append(value)
verify_native_lmf(projection,native);assert all(sha(Path(p).read_bytes())==h for p,h in frozen.items())
producer=Path(__file__);r={'schema_version':1,'state':'passed','preparation_only':True,'source_capture_sha256':frozen[str(source_path)],'boundary_capture_sha256':frozen[str(boundary_path)],'original_preparation_sha256':frozen[str(prepared_path)],'matched_owner_ids':sorted(ids),'named_headwords':sorted(names),'complete_native_entries':native,'original_lmf':original,'english_projection':projection,'source_hashes':hashes,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':producer.read_text(),'sha256':sha(producer.read_bytes())},'scope':'Complete actually matched owner closure for the original and authored boundary CLI captures, every same-head homonym, original LMF/SQLite equality and English importer projection. All22 earlier source entries remain byte-structurally identical. Verbal/adjectival 크다 and auxiliary/lexical 있다 roles remain separate; no contextual, global raw judgment or precision conclusion.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Complete',len(ids),'actually matched owner IDs and',len(native),'Native entries/LMF/English projection retained.',flush=True)
