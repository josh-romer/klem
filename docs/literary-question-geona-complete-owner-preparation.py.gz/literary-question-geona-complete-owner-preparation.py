"""Close every actually matched geona source/boundary owner against complete original LMF."""
import copy,gzip,hashlib,json,sqlite3,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from native_lmf import array,entry,verify_native_lmf
sha=lambda raw:hashlib.sha256(raw).hexdigest();read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes())
source_path=Path('/tmp/klem-literary-question-geona-prototype-source-replay.json.gz');boundary_path=Path('/tmp/klem-literary-question-geona-boundary-corrected.json.gz');prepared_path=ROOT/'docs/literary-question-geona-original-preparation.json.gz';OUT=Path('/tmp/klem-literary-question-geona-complete-owner-preparation.json.gz');assert not OUT.exists()
source,boundary,prepared=map(read,[source_path,boundary_path,prepared_path]);ids=set(source['matched_new_owner_ids'])|set(boundary['matched_new_owner_ids']);DB=ROOT/'data/dictionaries/krdict/krdict.db';frozen={str(p):sha(p.read_bytes()) for p in [source_path,boundary_path,prepared_path,DB,Path(__file__)]};names=set(prepared['named_headwords'])
prior_path=Path('/tmp/klem-literary-question-geona-matched-owner-preparation.json.gz');prior=read(prior_path);frozen[str(prior_path)]=sha(prior_path.read_bytes());names.update(prior['named_headwords'])
extra={n:Path('/tmp/klem-literary-question-geona-'+n+'.json.gz') for n in ['owner-extension-typed','spacing-preflight','prototype-broad']}
cohorts={n:read(p) for n,p in extra.items()};frozen.update({str(p):sha(p.read_bytes()) for p in extra.values()})
def collect(records):
 for row in records:
  if not isinstance(row,dict):continue
  dictionary=row.get('dictionary',{})
  for owner in dictionary.get('lemmas',[]):ids.update(e['id'] for e in owner['entries'])
  for hypothesis in row.get('spacing',{}).get('alternatives',[]):collect(hypothesis['records'])
for r in source['runs']:collect(map(json.loads,r['jsonl'].splitlines()))
for r in boundary['runs']:collect(map(json.loads,r['after']['jsonl'].splitlines()))
for n in ['owner-extension-typed','spacing-preflight']:
 for r in cohorts[n]['runs']:collect(map(json.loads,r['after']['jsonl'].splitlines()))
for comparison in cohorts['prototype-broad']['comparisons']:
 for pair in comparison['changed_frames']:collect([pair['after']])
names.update({'-답다','-하다','-되다','-어','-게','-지','-고','-더-'})

with sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True) as db:
 for ident in ids:names.add(db.execute('SELECT headword FROM entries WHERE id=?',(ident,)).fetchone()[0])
 native={ident:json.loads(raw) for ident,head,raw in db.execute('SELECT id,headword,data FROM entries') if head in names}
assert ids<=native.keys() and all(native[i]==e for i,e in prior['complete_native_entries'].items())
original={};hashes={}
for path in sorted((ROOT/'data/dictionaries/krdict/json').glob('*.json')):
 raw=path.read_bytes();name=str(path.relative_to(ROOT));hashes[name]=sha(raw);assert hashes[name]==prepared['source_hashes'][name]
 for value in array(json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']):
  base='krdict:'+value['val']
  if base not in native and not any(i.startswith(base+':') for i in native):continue
  projected=entry(value);ident=projected['id']
  if ident in native:assert projected==native[ident] and ident not in original;original[ident]=value
assert set(original)==set(native)
projection={'LexicalResource':{'Lexicon':{'LexicalEntry':[]}}}
for ident in sorted(original):
 value=copy.deepcopy(original[ident])
 for sense in array(value.get('Sense')):sense['Equivalent']=[t for t in array(sense.get('Equivalent')) if any(f.get('att')=='language' and f.get('val')=='영어' for f in array(t.get('feat')))]
 projection['LexicalResource']['Lexicon']['LexicalEntry'].append(value)
verify_native_lmf(projection,native);assert all(sha(Path(p).read_bytes())==h for p,h in frozen.items())
producer=Path(__file__);r={'schema_version':1,'state':'passed','preparation_only':True,'source_capture_sha256':frozen[str(source_path)],'boundary_capture_sha256':frozen[str(boundary_path)],'original_preparation_sha256':frozen[str(prepared_path)],'matched_owner_ids':sorted(ids),'cohort_capture_sha256':{n:frozen[str(p)] for n,p in extra.items()},'previous_complete_owner_sha256':frozen[str(prior_path)],'named_headwords':sorted(names),'complete_native_entries':native,'original_lmf':original,'english_projection':projection,'source_hashes':hashes,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':producer.read_text(),'sha256':sha(producer.read_bytes())},'scope':'Complete actually matched owner closure for all complete original/boundary/typed-owner/spacing outputs and every changed broad record, every same-head homonym, original LMF/SQLite equality and English importer projection. All97 prior entries remain structurally identical; broad novel alternatives and conditional marker/owner cases remain unjudged. Verbal/adjectival 크다 and auxiliary/lexical 있다 roles remain separate; no contextual, global raw judgment or precision conclusion.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Complete',len(ids),'actually matched owner IDs and',len(native),'Native entries/LMF/English projection retained.',flush=True)
