"""Preserve complete wide comparisons, original corpus attribution and Native closure."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
D = W / 'docs'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def read(name):
    raw = (P / name).read_bytes()
    return json.loads(gzip.decompress(raw) if name.endswith('.gz') else raw)

r = read('friendly-hortative-sena-wide-comparisons.json')
n = read('friendly-hortative-sena-extra-native-retry.json')
for report in [r, n]:
    assert report['state'] == 'passed'
    assert all(report[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged'])
    assert all(sha((W / name).read_bytes()) == digest for name, digest in report['frozen_inputs'].items())
    assert report['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
    assert report['index_sha256'] == sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=W))
assert r['frozen_inputs'] == n['frozen_inputs']
assert all(row['exit_code'] == 0 for row in r['results']) and len(r['results']) == 3
assert r['external_inputs_unchanged'] and r['protected_current_binaries_unchanged']
assert all(sha(Path(path).read_bytes()) == digest for path, digest in r['external_inputs'].items())
assert all(sha(Path(path).read_bytes()) == digest for path, digest in r['protected_current_binaries'].items())
assert sha((P / 'friendly-hortative-sena-wide-comparisons.log').read_bytes()) == r['log_sha256']
assert sha((P / 'friendly-hortative-sena-extra-native-retry.log').read_bytes()) == n['log_sha256']
native = read('friendly-hortative-sena-extra-native.json.gz')
assert native['source_inputs'] == r['frozen_inputs'] and native['captured_head'] == r['head']
assert all(native[k] for k in ['source_unchanged', 'head_unchanged', 'index_unchanged', 'inputs_unchanged'])
assert sha((P / 'friendly-hortative-sena-extra-native.json.gz').read_bytes()) == n['result_sha256']
cohorts = read('friendly-hortative-sena-cohorts.json.gz')
gold = read('friendly-hortative-sena-corpora.json.gz')
broad = read('friendly-hortative-sena-broad.json.gz')
assert sum(x['surfaces'] for x in cohorts['runs']) == 53502
assert sum(x['rows'] for x in gold['runs']) == 66570
assert sum(x['records'] for x in broad['runs']) == 1128312
assert gold['individual_changed_rows'] == []
assert all(x['changed_frames'] == [] and x['before_jsonl_sha256'] == x['after_jsonl_sha256'] for x in broad['runs'])
history = read('friendly-hortative-sena-history.json')
observation = read('friendly-hortative-sena-corpus-observations.json')
assert history['historical_fixture_words_changed'] == observation['historical_fixture_words_changed'] == 0
assert not history['historical_allowances_assigned'] and not observation['historical_allowances_assigned']
paths = [P / name for name in [
    'validate_friendly_hortative_sena_wide_comparisons.py',
    'friendly-hortative-sena-wide-comparisons.json', 'friendly-hortative-sena-wide-comparisons.log',
    'capture_friendly_hortative_sena_cohorts.py', 'friendly-hortative-sena-cohorts.json.gz',
    'friendly-hortative-sena-cohorts-progress.json',
    'capture_friendly_hortative_sena_corpora.py', 'friendly-hortative-sena-corpora.json.gz',
    'capture_friendly_hortative_sena_broad.py', 'friendly-hortative-sena-broad.json.gz',
    'friendly-hortative-sena-broad-progress.json',
    'capture_friendly_hortative_sena_history.py', 'friendly-hortative-sena-history.json',
    'friendly-hortative-sena-history.log',
    'capture_friendly_hortative_sena_corpus_observation.py', 'friendly-hortative-sena-corpus-observations.json',
    'capture_friendly_hortative_sena_extra_native.py',
    'friendly-hortative-sena-extra-native-original-producer.py.gz',
    'friendly-hortative-sena-extra-native-original-observation.json',
    'capture_friendly_hortative_sena_extra_native_retry.py',
    'validate_friendly_hortative_sena_extra_native_retry.py',
    'friendly-hortative-sena-extra-native-retry.json', 'friendly-hortative-sena-extra-native-retry.log',
    'friendly-hortative-sena-extra-native.json.gz']]
paths.append(Path(__file__))
files = {}
for path in paths:
    raw = path.read_bytes()
    name = 'friendly-hortative-sena-wide-proof-' + path.name + '.gz'
    output = D / name
    assert not output.exists()
    packed = gzip.compress(raw, mtime=0)
    output.write_bytes(packed)
    files[path.name] = dict(path=name, source_sha256=sha(raw), archive_sha256=sha(packed))
output = D / 'friendly-hortative-sena-wide-proof-archive.json'
assert not output.exists()
output.write_text(json.dumps(dict(
    state='actual-full-Sena-comparisons-and-complete-Native-closure-passed', files=files,
    source_head=r['head'], source_files=len(r['frozen_inputs']),
    production_binary_fingerprints=r['protected_current_binaries'],
    cohort_words=53502, historical_words=21406, corpus_words=32096,
    changed_corpus_words=['중세나'], new_unjudged_cohort_paths=1,
    annotated_rows=66570, changed_annotated_rows=0,
    broad_frames=1128312, broad_streams=8, changed_broad_frames=0,
    native_heads=len(native['selected_heads']), full_native_owners=len(native['complete_native_entries']),
    additional_native_owners=len(native['additional_native_entries']),
    unmatched_heads=len(native['selected_heads']) - len({e['headword'] for e in native['complete_native_entries'].values()}),
    original_KAIST_sentence_and_all_token_fields_retained=True,
    contextual_verdict='unjudged', independent_korean_review='pending',
    historical_fixture_words_changed=0, historical_allowances_assigned=False,
    original_stopped_collector_and_unknown_terminal_status_retained=True,
    shared_cases_reviews_changed=False, full_coverage_complete=False,
    remaining='Independent wide controls, full Rust/history guards, browser, installed Nix, shared promotion/main, quiet timing, context/register and Korean review.'),
    ensure_ascii=False, indent=2) + '\n')
print('Archived', len(files), 'full originals for actual53502/66570/1128312 comparisons, original corpus occurrence and71heads/41Native owners.', flush=True)
