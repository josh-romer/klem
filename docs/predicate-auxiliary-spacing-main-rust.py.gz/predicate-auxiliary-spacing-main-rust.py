"""Run the complete isolated Rust suite on the restored baseline and finite new source scope."""
import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem')
OUT=Path('/tmp/klem-predicate-auxiliary-spacing-main-rust.json');LOG=OUT.with_suffix('.log')
assert not OUT.exists() and not LOG.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
baseline=json.loads(Path('/home/josh/projects/klem/docs/additive-ppundeoreo-package-nix.json').read_bytes())['snapshot']['files']
names=set(baseline)
names.update(str(p.relative_to(ROOT)) for name in ['src','tests'] for p in (ROOT/name).rglob('*') if p.is_file())
snapshot={n:{'sha256':sha((ROOT/n).read_bytes()),'bytes':(ROOT/n).stat().st_size} for n in sorted(names)}
assert len(snapshot)==969,len(snapshot)
command=['cargo','test','--offline','--all-targets','--features','web','--target-dir','/tmp/klem-additive-ppundeoreo-prototype-target-no-debug']
producer=Path(__file__);report={'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'command':command,'cwd':str(ROOT),'snapshot_files':snapshot,'environment':{'CARGO_BUILD_JOBS':'4','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_INCREMENTAL':'0'},
    'producer':{'text':producer.read_text(),'sha256':sha(producer.read_bytes())},
    'scope':'Complete actual main all-targets suite after predicate/auxiliary spacing integration. All969 actual source/test/frontend inputs frozen before/after, including copular/derived/nominalized owners, distinct-span witnesses and API metadata. Global35014-case ledger unchanged. Historical combined Nix gate is terminal failed, with exact25-control ledger repair separately committed. Prototype phases/failures are retained; one original bound-noun requirement remains unmet. Browser/package/performance/combined gates remain separate.'}
def save():OUT.write_text(json.dumps(report,indent=2)+'\n')
save();env=dict(os.environ,CARGO_BUILD_JOBS='4',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_INCREMENTAL='0')
with LOG.open('xb') as stream:job=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
raw=LOG.read_bytes();rows=re.findall(rb'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw,re.MULTILINE)
counts={k:sum(int(row[i]) for row in rows) for i,k in enumerate(['passed','failed','ignored'])};counts['batches']=len(rows)
report.update(state='passed' if job.returncode==0 else 'failed',exit_code=job.returncode,tests=counts,
    inputs_unchanged=all(sha((ROOT/n).read_bytes())==v['sha256'] for n,v in snapshot.items()),log_sha256=sha(raw),
    finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
print('Full isolated Rust:',report['state'],counts,'unchanged969inputs:',report['inputs_unchanged'],flush=True)
assert report['inputs_unchanged']
raise SystemExit(job.returncode)
