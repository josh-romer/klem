"""Verify final installed CLI against all captured complete source, broad and word-cohort outputs."""
import gzip,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from doeda_native_corpora import words_from_cli
read=lambda p:json.loads(gzip.decompress(Path(p).read_bytes()) if str(p).endswith('.gz') else Path(p).read_bytes())
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
receipt_path=Path('/tmp/klem-declarative-dao-nix-retry1.json');receipt=read(receipt_path);assert receipt['state']=='passed' and receipt['exit_code']==0 and receipt['snapshot_unchanged']
cli=Path(next(p for p in receipt['outputs'] if p.endswith('-klem-0.1.0')))/'bin/klem';db=ROOT/'data/dictionaries/krdict/krdict.db'
source=Path('/tmp/klem-declarative-dao-runtime.json.gz');broad=Path('/tmp/klem-declarative-dao-broad-final.json.gz');cohorts=Path('/tmp/klem-declarative-dao-cohorts-revision2.json.gz');prepared=Path('/tmp/klem-declarative-dao-preparation-complete.json.gz');out=Path('/tmp/klem-declarative-dao-installed-cli.json.gz');assert not out.exists()
frozen={str(p):sha(p) for p in [receipt_path,cli,db,source,broad,cohorts,prepared,Path(__file__),ROOT/'tools/doeda_native_corpora.py']};source_runs=[];broad_runs=[];word_runs=[]
text=read(prepared)['complete_source_text']
for expected in read(source)['runs']:
 command=list(expected['command']);command[0]=str(cli);job=subprocess.run(command,input=text.encode(),capture_output=True,check=True);assert not job.stderr
 records=[json.loads(line) for line in job.stdout.splitlines()]
 assert records==expected['records'] and hashlib.sha256(job.stdout).hexdigest()==expected['stdout_sha256']
 source_runs.append({'mode':expected['mode'],'cache_bytes':expected['cache_bytes'],'command':command,'records':records,'stdout_sha256':expected['stdout_sha256'],'exit_code':0})
 print(expected['mode'],expected['cache_bytes'],len(records),'exact installed source frames',flush=True)
for expected in read(broad)['comparisons']:
 source_path=Path(expected['source']);assert sha(source_path)==expected['source_sha256'];frozen[str(source_path)]=sha(source_path)
 command=list(expected['commands'][1]);command[0]=str(cli);job=subprocess.Popen(command,stdout=subprocess.PIPE);h=hashlib.sha256();count=0
 try:
  for line in job.stdout:h.update(line);count+=1
  code=job.wait();assert code==0 and count==expected['records'] and h.hexdigest()==expected['after_jsonl_sha256']
 finally:
  if job.poll() is None:job.terminate();job.wait()
 broad_runs.append({'mode':expected['mode'],'source':str(source_path),'source_sha256':sha(source_path),'command':command,'records':count,'stdout_sha256':h.hexdigest(),'exit_code':code})
 print(expected['mode'],count,'exact installed broad frames',flush=True)
for expected in read(cohorts)['cohorts']:
 words=words_from_cli(cli,sorted(expected['captures'][1]['words']));assert words==expected['captures'][1]['words']
 word_runs.append({'family':expected['family'],'surfaces':len(words),'word_sha256':hashlib.sha256(json.dumps(words,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),'exact_captured_output':True})
assert sum(r['records'] for r in broad_runs)==1128312 and all(sha(p)==h for p,h in frozen.items())
r={'state':'passed','cli':str(cli),'source':source_runs,'broad':broad_runs,'words':word_runs,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Actual installed CLI, six exact417frame source streams, eight full1128312frame streams and complete32096/21406word cohorts. Structural parity does not settle unjudged contextual candidates or independent review.'}
out.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
