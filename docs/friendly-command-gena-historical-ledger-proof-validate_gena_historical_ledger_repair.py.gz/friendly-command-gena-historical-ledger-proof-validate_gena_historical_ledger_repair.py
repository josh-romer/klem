"""Run the actual historical ledger repair and every retained geona control."""
import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent/'friendly-command-gena'
OUT=P/'friendly-command-gena-historical-ledger-validation.json';LOG=P/'friendly-command-gena-historical-ledger-validation.log'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=W)
assert not OUT.exists() and not LOG.exists()
frozen={n:sha((W/n).read_bytes()) for n in git('ls-files','-z').decode().split('\0')[:-1]}
head=git('rev-parse','HEAD').decode().strip();index=sha(git('ls-files','--stage','-z'))
prior=json.loads((P/'friendly-command-gena-promoted-complete-nix-gate-retry1.json').read_bytes());protected=prior['protected_binaries']
assert prior['state']=='failed'
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,protected_binaries=protected,results=[],producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
def save():OUT.write_text(json.dumps(r,indent=2)+'\n')
save()
commands=[
 ['python3','-m','unittest','discover','-s','tools','-p','test_literary_question_geona_runtime.py'],
 ['python3','tools/literary_question_geona_runtime.py','--report','docs/literary-question-geona-packaged-cli-replay.json'],
 ['python3','tools/formal_volitional_ledger_audit.py'],
 ['python3','tools/formal_volitional_expression_ledger_audit.py'],
 ['python3','tools/expression_conjectural_ledger_audit.py'],
 ['python3','tools/friendly_command_gena_ledger_audit.py'],
 ['python3','tools/review_inventory.py','--verify'],
 ['git','diff','--check']]
try:
 with LOG.open('xb') as log:
  for command in commands:
   log.write(('COMMAND '+json.dumps(command)+'\n').encode());log.flush()
   job=subprocess.run(command,cwd=W,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   log.write(job.stdout);log.write(job.stderr);log.flush()
   r['results'].append(dict(command=command,exit_code=job.returncode,stdout=job.stdout.decode(),stderr=job.stderr.decode()));save()
   assert job.returncode==0,(command,job.returncode)
 r['tests']=sum(int(n) for n in re.findall(r'Ran (\d+) tests',r['results'][0]['stderr']))
 assert r['tests']==sum(1 for line in (W/'tools/test_literary_question_geona_runtime.py').read_text().splitlines() if line.startswith(' def test_'))
 r['state']='passed'
except BaseException as error:
 r.update(state='failed',error=repr(error));raise
finally:
 r.update(inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),head_unchanged=git('rev-parse','HEAD').decode().strip()==head,index_unchanged=sha(git('ls-files','--stage','-z'))==index,protected_binaries_unchanged=all(sha(Path(n).read_bytes())==d for n,d in protected.items()),log_sha256=sha(LOG.read_bytes()),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 if not all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged']):r['state']='failed'
 save()
print('Historical ledger repair passed:',r['tests'],'tests and',len(r['results']),'commands.',flush=True)
