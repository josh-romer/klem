let
  definition = import /home/josh/projects/klem/flake.nix;
  nixpkgs = builtins.getFlake "github:NixOS/nixpkgs/79b6d20e55596f80baa35cda2a334da8a1fbf1ea";
  outputs = definition.outputs { self = outputs; inherit nixpkgs; };
in {
  inherit (outputs.checks.x86_64-linux) klem web-assets corpus-adapter;
}
