"""Preserve actual paired release timings and full-novel cache parity."""
import argparse
import datetime
import hashlib
import json
import os
import platform
import statistics
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
sys.path.insert(0, str(ROOT/'.direnv/friendly-command-gena/tools'))
from ostensible_reason_audit import read, sha
from doeda_identity_performance import MODES


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    prepared=Path(__file__).resolve().parent
    worktree=ROOT/'.direnv/friendly-command-gena'
    package=read(args.package)
    prior_path=prepared/'gentle-command-long-nix-packages-retry2.json'
    prior=read(prior_path)
    after_runtime_path=prepared/'friendly-command-gena-installed-runtime.json.gz'
    before_runtime_path=prepared/'gentle-command-long-installed-runtime.json.gz'
    after_runtime=read(after_runtime_path);before_runtime=read(before_runtime_path)
    gates=[prepared/'friendly-command-gena-complete-nix-gate.json',prepared/'gentle-command-long-promoted-complete-nix-gate-retry2.json']
    for gate in gates:
        report=read(gate)
        assert report['state']=='passed' and report['exit_code']==0 and all(report[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged']), 'Both actual full Nix gates must pass before the quiet timing window.'
    for receipt in [prior,package,after_runtime,before_runtime]:
        assert receipt['state']=='passed' and receipt['inputs_unchanged']
    assert set(package['outputs'])==set(after_runtime['packages'].values()) and set(prior['outputs'])==set(before_runtime['packages'].values())
    before=Path(before_runtime['binaries']['klem']['path']);after=Path(after_runtime['binaries']['klem']['path']);assert before!=after
    for cli,report in [(before,before_runtime),(after,after_runtime)]:assert sha(cli.read_bytes())==report['binaries']['klem']['sha256']
    broad_path=prepared/'friendly-command-gena-broad.json.gz'
    broad=read(broad_path)
    novel=next(r for r in broad['runs'] if r['mode']=='novel-raw')
    book=Path(novel['actual_source']);db=ROOT/'.direnv/dictionary-restoration/krdict.db'
    assert sha(book.read_bytes())==novel['source_sha256']
    compiled=read(prepared/'friendly-command-gena-complete-runtime-binding.json')['production_inputs']
    assert len(compiled)==44 and all(sha((worktree/name).read_bytes())==digest for name,digest in compiled.items())
    before_profile=before_runtime['profiles']['klem']['files'];after_profile=after_runtime['profiles']['klem']['files']
    changes={name for name,digest in compiled.items() if before_profile[name]!=digest}
    assert changes=={'src/grammar.rs','src/engine.rs','src/dictionary/attachment.rs','src/bin/klem-web/grammar_labels.rs','web/src/grammar-labels.json'}
    assert all(after_profile[name]==digest for name,digest in compiled.items())
    producer=Path(__file__)
    paths=[before,after,book,db,args.package,prior_path,broad_path,after_runtime_path,before_runtime_path,prepared/'friendly-command-gena-complete-runtime-binding.json',producer,*gates]
    frozen={str(path):sha(path.read_bytes()) for path in paths}
    source_names=subprocess.check_output(['git','ls-files','-z'],cwd=worktree).decode().split('\0')[:-1]
    source_inputs={name:sha((worktree/name).read_bytes()) for name in source_names}
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=worktree,text=True).strip()
    index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=worktree))
    def active_own_jobs():
        active=[]
        for line in subprocess.check_output(['ps','-eo','pid,comm,args'],text=True).splitlines()[1:]:
            parts=line.strip().split(None,2)
            if len(parts)!=3 or int(parts[0])==os.getpid():continue
            pid,comm,command=parts
            own_python=comm.startswith('python') and (str(prepared) in command or '.direnv/willingness-question-prepared/' in command) and any(marker in command for marker in ['run_complete_','build_friendly_','validate_friendly_','capture_friendly_command_gena_installed_','run_friendly_command_gena_installed_browser'])
            own_nix=comm=='nix' and ' build ' in command and ('friendly-command-gena' in command or 'gentle-command-long-promotion' in command)
            own_sena=comm.startswith('python') and '.direnv/friendly-hortative-sena-prepared/' in command
            own_nix=own_nix or (comm=='nix' and ' build ' in command and 'friendly-hortative-sena' in command)
            compiler=comm in ('rustc','cargo')
            if own_python or own_sena or own_nix or compiler:active.append(dict(pid=int(pid),command=command if own_python or own_sena or own_nix else comm))
        return active
    assert not active_own_jobs(), 'An actual compiler or own validation process is live; do not begin timing or restart those jobs.'
    allowed = sorted(os.sched_getaffinity(0))
    cpu = allowed[-1]
    report = {'schema_version':1,'checklist':'COV-017db','state':'running',
              'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'before_cli':str(before),'cli':str(after),'before_cli_sha256':frozen[str(before)],
              'cli_sha256':frozen[str(after)],'input_source':str(book),
              'input_bytes':book.stat().st_size,'input_sha256':frozen[str(book)],
              'dictionary_sha256':frozen[str(db)],'package_sha256':frozen[str(args.package)],
              'previous_package_sha256':frozen[str(prior_path)],'comparison_sha256':frozen[str(broad_path)],
              'allowed_cpus':allowed,'cpu_affinity':[cpu],'system':platform.platform(),
              'workloads':[],'cache_parity':[],'frozen_inputs':frozen,
              'captured_head':head,'index_sha256':index,'source_inputs':source_inputs,
              'before_profile':before_profile,'after_profile':after_profile,'compiled_inputs':compiled,
              'individual_compiled_changes':sorted(changes),'own_active_jobs_before_timing':active_own_jobs(),
              'producer':{'text':producer.read_text(),'sha256':frozen[str(producer)]},
              'scope':'Five interleaved fresh-process pairs for all eight complete novel workloads on one allowed CPU. Includes startup and serialization to /dev/null. Context samples are not evidence of isolation or constant clocks. No statistical equivalence or causality claim. Run only after actual own build/audit/browser handles are confirmed terminal. Passed gate receipts are prerequisites, not evidence of host isolation. This measures the actual installed long-command-to-Gena five-input revision pair. It also records absolute current full-novel times; other earlier-family timing, contextual precision and independent Korean review remain separate.'}
    def save():
        args.output.write_text(json.dumps(report,indent=2)+'\n')
    def context():
        frequency = Path(f'/sys/devices/system/cpu/cpu{cpu}/cpufreq/scaling_cur_freq')
        return {'loadavg':Path('/proc/loadavg').read_text().strip(),
                'cpu_frequency_khz':int(frequency.read_text()) if frequency.exists() else None,
                'active_own_jobs':active_own_jobs()}
    def pin():
        os.sched_setaffinity(0,{cpu})
    save()
    try:
        with tempfile.TemporaryDirectory(prefix='klem-gena-timing-') as directory:
            stats = Path(directory)/'time.txt'
            for mode, cache in MODES:
                assert not active_own_jobs(), 'Own validation started during the timing window.'
                workload = {'mode':mode,'cache_bytes':cache,'samples':[]}
                report['workloads'].append(workload)
                for run in range(5):
                    versions = [('before',before),('after',after)]
                    if run%2:
                        versions.reverse()
                    for version, cli in versions:
                        command = [str(cli),'text',str(book),'--cache-bytes',str(cache)]
                        if mode!='novel-unannotated':
                            command += ['--dictionary',str(db)]
                        if mode not in ['novel-unannotated','novel-raw']:
                            command += ['--dict-compatible' if 'compatible' in mode else '--dict-only']
                        if 'spacing' in mode:
                            command += ['--suggest-spacing']
                        start_context = context()
                        start = time.perf_counter()
                        result = subprocess.run(['/run/current-system/sw/bin/time','-f','%U %S %e %M','-o',str(stats),*command],stdout=subprocess.DEVNULL,preexec_fn=pin,check=True)
                        elapsed = time.perf_counter()-start
                        user, system, gnu, rss = stats.read_text().split()
                        workload['samples'].append({'run':run+1,'version':version,'command':command,'seconds':elapsed,
                                                    'user_seconds':float(user),'system_seconds':float(system),
                                                    'gnu_elapsed_seconds':float(gnu),'peak_rss_kib':int(rss),
                                                    'start_context':start_context,'end_context':context(),'exit_code':result.returncode})
                        save()
                        print(mode,run+1,version,round(elapsed,4),flush=True)
                workload['summary'] = {v:{'median_seconds':statistics.median(r['seconds'] for r in workload['samples'] if r['version']==v),
                                          'median_user_seconds':statistics.median(r['user_seconds'] for r in workload['samples'] if r['version']==v),
                                          'min_seconds':min(r['seconds'] for r in workload['samples'] if r['version']==v),
                                          'max_seconds':max(r['seconds'] for r in workload['samples'] if r['version']==v)} for v in ['before','after']}
                save()
        for mode, flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
            expected = next(r for r in broad['runs'] if r['mode']=='novel-'+mode)
            checks = []
            for cache in [0,8388608]:
                command = [str(after),'text',str(book),'--dictionary',str(db),*flags,'--cache-bytes',str(cache)]
                digest, records = hashlib.sha256(), 0
                job = subprocess.Popen(command,stdout=subprocess.PIPE)
                try:
                    for line in job.stdout:
                        digest.update(line)
                        records += 1
                    assert job.wait()==0
                finally:
                    if job.poll() is None:
                        job.terminate()
                        job.wait()
                assert digest.hexdigest()==expected['after_jsonl_sha256'] and records==expected['records']==179112
                checks.append({'command':command,'cache_bytes':cache,'sha256':digest.hexdigest(),'records':records,'exit_code':0})
                print('cache parity',mode,cache,records,flush=True)
            report['cache_parity'].append({'mode':mode,'checks':checks})
            save()
        assert all(sha(Path(p).read_bytes())==digest for p,digest in frozen.items())
        source_unchanged=all(sha((worktree/name).read_bytes())==digest for name,digest in source_inputs.items())
        head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=worktree,text=True).strip()==head
        index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=worktree))==index
        assert source_unchanged and head_unchanged and index_unchanged and not active_own_jobs()
        report.update(state='passed',exit_code=0,inputs_unchanged=True,source_unchanged=source_unchanged,head_unchanged=head_unchanged,index_unchanged=index_unchanged)
    except BaseException as error:
        report.update(state='failed',error=repr(error))
        raise
    finally:
        report['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()


if __name__=='__main__':
    main()
