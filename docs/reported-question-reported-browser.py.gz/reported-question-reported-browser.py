"""Exercise installed browser assets and binary; stop the owned server on every exit."""
import hashlib
import json
import os
import re
import signal
import subprocess
import urllib.request
from pathlib import Path

ROOT = Path('/home/josh/projects/klem/.direnv/dapnikka-integration')
PACKAGE = Path('/home/josh/projects/klem/.direnv/dapnikka-integration/docs/reported-question-installed-source-binding.json')
DRIVER = Path('/home/josh/projects/klem/.direnv/reported-installed-validation/reported-browser.mjs')
PREFIX = Path('/home/josh/projects/klem/.direnv/reported-installed-validation/reported-browser-runtime')
OUT = PREFIX.with_suffix('.json')
assert not OUT.exists()
package = json.loads(PACKAGE.read_bytes())
assert package['state'] == 'passed' and package['exit_code'] == 0
assert package['inputs_unchanged'] and package['head_unchanged'] and package['index_unchanged']
BIN = Path(next(p for p in package['outputs'] if p.endswith('-klem-0.1.0'))) / 'bin'
ASSETS = Path(next(p for p in package['outputs'] if p.endswith('-klem-web-assets-0.1.0'))) / 'share/klem-web'
DB = Path('/home/josh/projects/klem/data/dictionaries/krdict/krdict.db')
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
inputs = {str(p): sha(p) for p in [PACKAGE, BIN / 'klem', BIN / 'klem-web', DB, DRIVER, Path(__file__), ROOT / 'tests/fixtures/dapnikka-validity.json', ROOT / 'tests/fixtures/dapnikka-novel-validity.json', *[p for p in ASSETS.rglob('*') if p.is_file()]]}
command = [str(BIN / 'klem-web'), '--port', '0', '--assets', str(ASSETS), '--dictionary', str(DB)]
receipt = {'state': 'running', 'command': command, 'frozen_inputs': inputs}
OUT.write_text(json.dumps(receipt, indent=2) + '\n')
server = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
try:
    line = server.stderr.readline()
    match = re.search(r'http://127\.0\.0\.1:\d+', line)
    assert match, line
    url = match.group()
    receipt['url'] = url
    with urllib.request.urlopen(url + '/api/status', timeout=10) as response:
        receipt['status'] = json.load(response)
    with urllib.request.urlopen(url, timeout=10) as response:
        html = response.read()
        assert html == (ASSETS / 'index.html').read_bytes()
    for path in re.findall(r'(?:src|href)="(/assets/[^"?#]+\.(?:js|css))"', html.decode()):
        with urllib.request.urlopen(url + path, timeout=10) as response:
            assert response.read() == (ASSETS / path.lstrip('/')).read_bytes()
    env = dict(os.environ, KLEM_WEB_URL=url, KLEM_BIN=str(BIN / 'klem'), KLEM_CAPTURE_PREFIX='/home/josh/projects/klem/.direnv/reported-installed-validation/reported', CHROMIUM_PATH='/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium')
    with PREFIX.with_suffix('.log').open('xb') as log:
        job = subprocess.run(['node', str(DRIVER)], env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt.update(state='passed' if job.returncode == 0 else 'failed', exit_code=job.returncode)
finally:
    if server.poll() is None:
        server.send_signal(signal.SIGINT)
    receipt['server_exit_code'] = server.wait(timeout=20)
    receipt['server_stopped'] = True
    receipt['inputs_unchanged'] = all(sha(p) == digest for p, digest in inputs.items())
    OUT.write_text(json.dumps(receipt, indent=2) + '\n')
assert receipt['state'] == 'passed' and receipt['inputs_unchanged']
print('Actual installed self-question browser passed; owned server stopped.', flush=True)
