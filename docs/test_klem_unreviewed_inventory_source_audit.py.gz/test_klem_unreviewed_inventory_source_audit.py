import copy,gzip,importlib.util,json,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('audit','/tmp/klem-unreviewed-inventory-source-audit.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
read=lambda suffix:json.load(gzip.open('/tmp/klem-unreviewed-inventory'+suffix,'rt'))
closure=read('-source-closure.json.gz');runtime=read('-preflight.json.gz');discovery=read('-discovery.json.gz')
class Integrity(unittest.TestCase):
 def rejects(self,change):
  c=copy.deepcopy(closure);r=copy.deepcopy(runtime);d=copy.deepcopy(discovery);change(c,r,d)
  with self.assertRaises((AssertionError,KeyError,ValueError)):audit.verify(c,r,d)
 def test_current_full_sources_and_six_streams(self):self.assertEqual(audit.verify(closure,runtime,discovery)['frames'],165288)
 def test_missing_original_group(self):self.rejects(lambda c,r,d:c['groups'].pop())
 def test_clipped_dialogue(self):
  def change(c,r,d):
   group=next(g for g in c['groups'] if len(g['complete_original_examples'])>1);group['complete_original_examples'].pop()
  self.rejects(change)
 def test_false_manual_disposition(self):self.rejects(lambda c,r,d:c['review_entries'][0]['review'].update(status='scoped'))
 def test_changed_source_note(self):self.rejects(lambda c,r,d:c['review_entries'][0]['source']['notes'].append('invented note'))
 def test_hidden_filtered_miss(self):
  def change(c,r,d):next(v for v in r['captures'] if v['mode']=='compatible')['empty_filtered_records'].pop()
  self.rejects(change)
 def test_native_pos_relabel(self):
  def change(c,r,d):next(iter(c['complete_native_entries'].values()))['pos']='unreviewed'
  self.rejects(change)
 def test_complete_claim(self):self.rejects(lambda c,r,d:r.update(full_coverage_complete=True))
if __name__=='__main__':unittest.main()
