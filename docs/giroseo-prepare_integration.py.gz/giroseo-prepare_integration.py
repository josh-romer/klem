"""Integrate the exact tested prototype while preserving newer parent evidence."""
from pathlib import Path
import json, hashlib, shutil, subprocess, sys
ROOT=Path(__file__).resolve().parents[2]
PROTO=ROOT/'.direnv/giroseo-prototype'; WORK=ROOT/'.direnv/giroseo-integration'
BASE='8d72402ac4f6f6b3e7ea87f1b6d606d1714b5bdc'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()=='9841000f15d6139944206088618032930d014da0'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
core=['src/engine.rs','src/grammar.rs','src/bin/klem-web/grammar_labels.rs','web/src/grammar-labels.json','tests/validity.rs','tests/fixtures/validity.json','tools/literary_question_geona_runtime.py','tools/test_literary_question_geona_runtime.py']
for rel in core:
 original=subprocess.check_output(['git','show',BASE+':'+rel],cwd=WORK)
 assert (WORK/rel).read_bytes()==original,('changed parent source',rel)
for rel in core+['tests/giroseo.rs']:
 shutil.copyfile(PROTO/rel,WORK/rel)
for folder,patterns in [('tests/fixtures',['giroseo*','krdict-giroseo*']),('tools',['giroseo*','test_giroseo*']),('docs',['giroseo*'])]:
 for pattern in patterns:
  for p in (PROTO/folder).glob(pattern):
   if p.is_file():shutil.copyfile(p,WORK/folder/p.name)
p=WORK/'flake.nix';s=p.read_text();anchor='                ./tools/test_reported_experience_installed_audit.py\n';assert s.count(anchor)==1
files=[f'{prefix}giroseo_{family}_audit.py' for family in ['source','streams','cohort','broad','corpora'] for prefix in ['', 'test_']]
s=s.replace(anchor,anchor+''.join(f'                ./tools/{name}\n' for name in files))
anchor="            python -m unittest discover -s tools -p 'test_reported_experience_installed_audit.py'\n";assert s.count(anchor)==1
s=s.replace(anchor,anchor+''.join(f"            python tools/giroseo_{family}_audit.py\n            python -m unittest discover -s tools -p 'test_giroseo_{family}_audit.py'\n" for family in ['source','streams','cohort','broad','corpora']));p.write_text(s)
p=WORK/'docs/coverage-checklist.md';s=p.read_text();private=(PROTO/'docs/coverage-checklist.md').read_text();a=private.index('- [ ] **COV-017cs —');b=private.index('\n- [ ] **COV-018 —',a);assert 'COV-017cs —' not in s
anchor='- [ ] **COV-018 —';assert s.count(anchor)==1;p.write_text(s.replace(anchor,private[a:b]+'\n'+anchor))
p=WORK/'docs/inventory-reviews.json';current=json.loads(p.read_bytes());private=json.loads((PROTO/'docs/inventory-reviews.json').read_bytes())
for ident in ['krdict:83919','krdict:83918']:
 assert not any(r['id']==ident for r in current['entries'])
 review=next(r for r in private['entries'] if r['id']==ident)
 review['scope']+=' The complete prototype Rust suite passes1119tests/0failed/1ignored with1540sourcefiles unchanged.'
 review['remaining']=review['remaining'].replace('Full Rust running.','Prototype full Rust passed; integration source parity and Nix remain.')
 review['evidence'].append({'path':'docs/giroseo-full-rust.json.gz'})
 current['entries'].append(review)
p.write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n')
sys.path.insert(0,str(WORK/'tools'));import review_inventory as audit
p=WORK/'docs/inventory-review-queue.json';q=json.loads(p.read_bytes());new=audit.build_queue(WORK,q['dictionary_metadata'],[r['source'] for r in q['entries']]);p.write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n');audit.verify_queue(WORK,new)
manifest={str(p.relative_to(WORK)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [WORK/rel for rel in core+['tests/giroseo.rs']]}
report={'state':'prepared','base':BASE,'parent':'9841000f15d6139944206088618032930d014da0','core_sources':manifest,'queue_counts':new['counts'],'scope':'Exact tested concessive core source copied after every newer parent core file matched its original8d base. New parent reportedquestion and installed evidence retained, five Nix audit families appended, tracker and two scoped reviews merged and finalqueue rebuilt. Full selected Rust/frontend/adapter parity, committed Nix/installed/performance/main validation remain.'}
Path(__file__).with_name('integration-preparation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('Prepared integration on latest parent;',new['counts'],flush=True)
