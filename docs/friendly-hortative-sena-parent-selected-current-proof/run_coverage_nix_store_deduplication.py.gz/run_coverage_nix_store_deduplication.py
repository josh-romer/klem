"""Recover build capacity by Nix's byte-preserving hardlink optimisation."""
import datetime
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = P.parents[1]
OUT = P / 'coverage-nix-store-deduplication.json'
LOG = P / 'coverage-nix-store-deduplication.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
assert not git('status', '--porcelain')
source = {name: sha((ROOT / name).read_bytes()) for name in git('ls-files', '-z').decode().split('\0')[:-1]}
head = git('rev-parse', 'HEAD').decode().strip()
index = sha(git('ls-files', '--stage', '-z'))
prior = json.loads((ROOT / '.direnv/coverage-unused-rust-library-cache-cleanup.json').read_bytes())
keepers = prior['keepers']
assert all(sha(Path(name).read_bytes()) == digest for name, digest in keepers.items())
command = ['nix-store', '--optimise']
r = dict(state='running', command=command, head=head, index_sha256=index,
         source_inputs=source, protected_files=keepers, free_bytes_before=shutil.disk_usage(ROOT).free,
         producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Official Nix deduplication only: content-identical immutable files become hardlinks. No garbage collection, path deletion, dictionary refresh or source edit. Main Source/HEAD/index and683 retained files frozen until actual terminal result.')
def save():
    OUT.write_text(json.dumps(r, indent=2) + '\n')
save()
try:
    with LOG.open('xb') as log:
        job = subprocess.run(command, cwd=ROOT,
                             env=dict(os.environ, TMPDIR='/var/tmp/klem-sena-gena-parent-selected-source'),
                             stdout=log, stderr=subprocess.STDOUT)
        r.update(exit_code=job.returncode, state='passed' if job.returncode == 0 else 'failed')
        assert job.returncode == 0
except BaseException as error:
    r.update(state='failed', error=repr(error)); raise
finally:
    r.update(source_unchanged=all(sha((ROOT / name).read_bytes()) == digest for name, digest in source.items()),
             head_unchanged=git('rev-parse', 'HEAD').decode().strip() == head,
             index_unchanged=sha(git('ls-files', '--stage', '-z')) == index,
             protected_files_unchanged=all(sha(Path(name).read_bytes()) == digest for name, digest in keepers.items()),
             free_bytes_after=shutil.disk_usage(ROOT).free,
             log_sha256=sha(LOG.read_bytes()) if LOG.exists() else None,
             completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ('source_unchanged', 'head_unchanged', 'index_unchanged', 'protected_files_unchanged')):
        r['state'] = 'failed'
    save()
assert r['state'] == 'passed'
print('Nix store deduplicated without deletion; main Source/HEAD/index and683 retained files unchanged.', flush=True)
