"""Archive the actual current-source 81-control run and complete helper bodies."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent/'friendly-command-gena'
OUT = P/'friendly-command-gena-completed-evidence-archive.json'
MANIFEST = W/'docs/friendly-command-gena-completed-evidence-proof-archive.json'
assert not OUT.exists() and not MANIFEST.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
receipt = json.loads((P/'friendly-command-gena-completed-evidence-validation.json').read_bytes())
assert receipt['state'] == 'passed' and receipt['controls'] == 81 and len(receipt['results']) == 8 and all(r['exit_code'] == 0 for r in receipt['results'])
assert all(receipt[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged'])
assert all(sha((W/n).read_bytes()) == d for n,d in receipt['source_inputs'].items())
assert all(sha(Path(p).read_bytes()) == d for p,d in receipt['frozen_inputs'].items())
files = {n:(P/n).read_bytes() for n in [
    'friendly-command-gena-completed-evidence-validation.json',
    'friendly-command-gena-completed-evidence-validation.log',
    'validate_friendly_command_gena_completed_evidence.py',
    'friendly-command-gena-completed-evidence-original-queue.json.gz',
    Path(__file__).name]}
for kind in ['installed','performance','ledger']:
    for prefix in ['', 'test_']:
        name = prefix+'friendly_command_gena_'+kind+'_audit.py'
        files[name] = (W/'tools'/name).read_bytes()
for name in ['flake.nix','docs/coverage-checklist.md','docs/inventory-review-queue.json']:
    files['source-'+name.replace('/','-')] = (W/name).read_bytes()
assert sha(files['friendly-command-gena-completed-evidence-validation.log']) == receipt['log_sha256']
manifest = dict(state='actual-current-archive-aware-Gena81-controls-passed',files={},
                actual_session_id=8393,exit_code=0,controls=81,
                installed_controls=28,performance_controls=29,draft_controls=24,
                captured_head=receipt['head'],captured_source_files=len(receipt['source_inputs']),
                original_installed28_and_draft24_test_bytes_preserved=True,
                original_performance23_test_bodies_preserved=True,new_archive_controls=6,
                actual_shared_promotion=False,full_coverage_complete=False,
                scope='All full original current-source producer, terminal receipt/log, six helper/control bodies, source flake/checklist/queue and previous queue retained. Original installed/timing/draft archives remain independently pinned. This proves current Python/queue checks, not future committed Git-selected Nix execution, shared/main promotion or context/register/Korean review completion.')
for name,raw in files.items():
    filename = 'friendly-command-gena-completed-evidence-proof-'+name+'.gz'
    dest = W/'docs'/filename
    assert not dest.exists()
    packed = gzip.compress(raw,mtime=0);dest.write_bytes(packed)
    assert gzip.decompress(dest.read_bytes()) == raw
    manifest['files'][name] = dict(path=filename,source_sha256=sha(raw),archive_sha256=sha(packed),original_bytes=len(raw))
MANIFEST.write_text(json.dumps(manifest,indent=2)+'\n')
r = dict(state='passed',originals=len(files),manifest=str(MANIFEST),manifest_sha256=sha(MANIFEST.read_bytes()),
         actual_validated_session_id=8393,producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
         finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope=manifest['scope'])
OUT.write_text(json.dumps(r,indent=2)+'\n')
print('Archived',len(files),'full original current-source81-control artifacts:',r['manifest_sha256'],flush=True)
