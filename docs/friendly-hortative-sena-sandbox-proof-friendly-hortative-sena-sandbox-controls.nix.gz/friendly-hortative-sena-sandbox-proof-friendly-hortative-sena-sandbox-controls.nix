let
  flake = builtins.getFlake "git+file:///home/josh/projects/klem/.direnv/friendly-hortative-sena";
  pkgs = flake.inputs.nixpkgs.legacyPackages.x86_64-linux;
in pkgs.runCommand "klem-sena-sandbox-controls" {
  src = flake.checks.x86_64-linux.inventory-review.src;
  nativeBuildInputs = [ pkgs.python3 ];
} ''
  cp -r $src/. .
  export PYTHONDONTWRITEBYTECODE=1
  export KLEM_SENA_BINARY_EVIDENCE=captured
  python - <<'PY'
  from pathlib import Path
  import json
  binding = Path('docs/friendly-hortative-sena-runtime-proof-friendly-hortative-sena-complete-runtime-binding.json.gz')
  import gzip
  data = json.loads(gzip.decompress(binding.read_bytes()))
  paths = {b['path'] for b in data['binaries'].values()}
  paths.update(data['protected_parent_binaries'])
  assert len(paths) == 6 and all(not Path(p).exists() for p in paths), 'actual Nix sandbox must not expose host executables'
  print('Confirmed actual Nix sandbox: all six host executable paths absent.')
  PY
  python tools/friendly_hortative_sena_source_audit.py
  python -m unittest discover -s tools -p 'test_friendly_hortative_sena_source_audit.py'
  python -m unittest discover -s tools -p 'test_friendly_command_gena_source_audit.py'
  python tools/friendly_hortative_sena_runtime_audit.py
  python -m unittest discover -s tools -p 'test_friendly_hortative_sena_runtime_audit.py'
  python -m unittest discover -s tools -p 'test_friendly_hortative_sena_binary_evidence.py'
  python tools/friendly_hortative_sena_wide_audit.py
  python -m unittest discover -s tools -p 'test_friendly_hortative_sena_wide_audit.py'
  python tools/review_inventory.py --verify
  mkdir -p $out
  printf '%s\n' 'Actual isolated Nix sandbox: 146 preserved/new Source and runtime-evidence controls passed; all six host executables absent. Captured artifact replay does not claim live executable verification. Full historical inventory/package/browser/installed/main/timing/context checks remain separate.' > $out/scope.txt
''
