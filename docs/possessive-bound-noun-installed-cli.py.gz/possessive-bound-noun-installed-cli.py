"""Replay complete actual installed CLI streams and both unchanged raw-word cohorts."""
import gzip,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from doeda_native_corpora import words_from_cli
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.load(gzip.open(p,'rt'))
receipt_path=Path('/tmp/klem-possessive-bound-noun-nix-retry1.json');receipt=json.loads(receipt_path.read_bytes());assert receipt['state']=='passed' and receipt['exit_code']==0 and receipt['source_unchanged'];CLI=Path(next(o for o in receipt['outputs'] if o.endswith('-klem-0.1.0')))/'bin/klem';DB=ROOT/'data/dictionaries/krdict/krdict.db';BROAD=Path('/tmp/klem-possessive-bound-noun-broad-final.json.gz');HISTORY=ROOT/'docs/additive-ppundeoreo-main-corpus-history.json.gz';OUT=Path('/tmp/klem-possessive-bound-noun-installed-cli.json');assert not OUT.exists()
frozen={str(p):sha(p) for p in [CLI,DB,BROAD,HISTORY,receipt_path,Path(__file__)]};r={'state':'running','cli':str(CLI),'cli_sha256':sha(CLI),'package_sha256':sha(receipt_path),'source_profile':receipt['source_profile'],'broad':[],'words':[],'frozen_inputs':frozen,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Actual isolated installed Nix CLI against all1,128,312stream frames and32,096/21,406raw-word cohorts. Complete output bytes must match independently captured prototype; no Root integration or contextual precision claim.'}
def save():OUT.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 for expected in read(BROAD)['comparisons']:
  source=Path(expected['source']);assert sha(source)==expected['source_sha256'];frozen[str(source)]=sha(source);command=list(expected['commands'][1]);command[0]=str(CLI);job=subprocess.Popen(command,stdout=subprocess.PIPE);h=hashlib.sha256();count=0
  try:
   for line in job.stdout:h.update(line);count+=1
   code=job.wait();assert code==0 and count==expected['records'] and h.hexdigest()==expected['after_jsonl_sha256']
  finally:
   if job.poll() is None:job.terminate();job.wait()
  r['broad'].append({'mode':expected['mode'],'source':str(source),'source_sha256':sha(source),'command':command,'records':count,'stdout_sha256':h.hexdigest(),'exit_code':code,'exact_captured_output':True});save();print(expected['mode'],count,'exact installed frames',flush=True)
 for expected in read(HISTORY)['cohorts']:
  words=words_from_cli(CLI,sorted(expected['after_words']));assert words==expected['after_words'];digest=hashlib.sha256(json.dumps(words,ensure_ascii=False,sort_keys=True).encode()).hexdigest();assert digest==expected['after_word_sha256'];r['words'].append({'family':expected['family'],'surfaces':len(words),'word_sha256':digest,'exact_captured_output':True});save();print(expected['family'],len(words),'exact installed words',flush=True)
 assert sum(c['records'] for c in r['broad'])==1128312 and all(sha(p)==h for p,h in frozen.items());r.update(state='passed',exit_code=0,inputs_unchanged=True)
except BaseException as error:r.update(state='failed',error=repr(error));raise
finally:save()
