"""Record completed draft validation and preserve the original/main scope distinctions."""
import datetime,gzip,hashlib,json,re,tarfile
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');PROTO=Path('/tmp/klem-declarative-dao-prototype');STAGE=Path('/tmp/klem-declarative-dao-evidence-staging')
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
read=lambda p:json.loads(gzip.decompress(Path(p).read_bytes()) if str(p).endswith('.gz') else Path(p).read_bytes())
prior=read(ROOT/'docs/possessive-bound-noun-installed-sources.json.gz');package=read('/tmp/klem-declarative-dao-nix-retry1.json')
snapshot={n:v for n,v in package['snapshot_files'].items() if n not in ['flake.nix','flake.lock']}
assert len(snapshot)==985 and all(sha(PROTO/n)==v['sha256'] for n,v in snapshot.items())
updates=[n for n,v in prior['snapshot_files'].items() if snapshot[n]!=v];new=sorted(set(snapshot)-set(prior['snapshot_files']))
assert len(updates)==11 and len(new)==8
full=Path('/tmp/klem-declarative-dao-full-test-retry3.log').read_text();rows=[tuple(map(int,v)) for v in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',full)]
assert sum(r[0] for r in rows)==1083 and sum(r[1] for r in rows)==0 and sum(r[2] for r in rows)==1 and len(rows)==233
focused=Path('/tmp/klem-declarative-dao-ledger-tests.log').read_text();assert '7 passed; 0 failed' in focused and '4 passed; 0 failed' in focused
assert 'Finished' in Path('/tmp/klem-declarative-dao-final-clippy.log').read_text()
browser=read('/tmp/klem-declarative-dao-revision2-browser.json');runtime=read('/tmp/klem-declarative-dao-browser-runtime-revision2.json');assert browser['state']=='draft-browser-passed' and runtime['state']=='passed' and runtime['server_stopped'] and runtime['inputs_unchanged']
assert len(browser['diagrams'])==198 and len(browser['exports'])==6 and not browser['errors']
binding=read('/tmp/klem-declarative-dao-final-debug-binding.json');assert all(v['identical'] for v in binding.values())
broad=read('/tmp/klem-declarative-dao-broad-final.json.gz');assert sum(c['records'] for c in broad['comparisons'])==1128312 and len(broad['individual_additions'])==27 and len(broad['individual_spacing_additions'])==2
cohorts=read('/tmp/klem-declarative-dao-cohorts-revision2.json.gz');assert [(c['family'],c['surfaces'],len(c['changed_words'])) for c in cohorts['cohorts']]==[('corpus',32096,0),('history',21406,1)]
old=read(ROOT/'tests/fixtures/validity.json');current=read(PROTO/'tests/fixtures/validity.json');batch=read(PROTO/'tests/fixtures/declarative-dao-validity.json')
assert current['cases'][:len(old['cases'])]==old['cases'] and current['cases'][len(old['cases']):]==batch['cases']
assert all(current['sources'][k]==v for k,v in old['sources'].items())
assert len(old['cases'])==35014 and len(current['cases'])==35050
counts={v:sum(j['verdict']==v for c in batch['cases'] for j in c['judgments']) for v in ['required','forbidden']};assert counts=={'required':33,'forbidden':3}
assert 'Ran 11 tests' in Path('/tmp/klem-declarative-dao-portable-controls.log').read_text()
archive=STAGE/'docs/declarative-dao-validated-delta.tar.gz'
with archive.open('wb') as out:
 with gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name in sorted(updates+new):
    info=tar.gettarinfo(str(PROTO/name),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with (PROTO/name).open('rb') as stream:tar.addfile(info,stream)
report={'schema_version':1,'state':'isolated-dao-full-regression-browser-and-broad-validation-passed','recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prototype':str(PROTO),'snapshot_files':snapshot,'updated_files':updates,'new_files':new,'full_rust':{'passed':1083,'failed':0,'ignored':1,'batches':233,'scope':'Complete run before the shared-ledger append and additional ledger-link test.'},'final_affected_rust':{'passed':11,'failed':0,'targets':['declarative_dao','validity']},'clippy_all_targets_passed':True,'case_counts':{'preserved':35014,'appended':36,'total':35050,**counts},'browser':{'diagrams':198,'exports':6,'owned_server_stopped':True,'desktop_and_mobile_inspected':True},'broad':{'frames':1128312,'individually_tracked_path_observations':27,'individually_tracked_spacing_observations':2,'all_prior_paths_and_assessments_preserved':True},'cohorts':[{'family':c['family'],'surfaces':c['surfaces'],'changed_words':len(c['changed_words'])}for c in cohorts['cohorts']],'fresh_debug_binaries_identical':binding,'portable_source_controls':11,'nix':{'receipt':'/tmp/klem-declarative-dao-nix-retry1.json','state_at_checkpoint':package['state'],'session':92997},'root_combined_gate':{'receipt':'/tmp/klem-possessive-bound-noun-combined-nix.json','session':66182,'root_inputs_frozen':True},'root_integration_complete':False,'manual_inventory_dispositions_changed':False,'contextual_review_complete':False,'independent_review_complete':False,'full_coverage_complete':False,'evidence':{str(p):sha(p) for p in map(Path,['/tmp/klem-declarative-dao-full-test-retry3.log','/tmp/klem-declarative-dao-ledger-tests.log','/tmp/klem-declarative-dao-final-clippy.log','/tmp/klem-declarative-dao-final-debug-binding.json','/tmp/klem-declarative-dao-broad-final.json.gz','/tmp/klem-declarative-dao-cohorts-revision2.json.gz','/tmp/klem-declarative-dao-revision2-browser.json','/tmp/klem-declarative-dao-browser-runtime-revision2.json','/tmp/klem-declarative-dao-portable-controls.log'])},'source_delta_sha256':sha(archive),'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'remaining':['Wait for the same live Nix handles; do not modify Root tracked files/HEAD/index or frozen prototype inputs.','Verify actual installed source profiles, CLI/API/browser and all66570 adapter rows; measure novel performance after owned jobs stop.','Release Root freeze only on terminal receipt, integrate the exact final source delta and update manual queue/tracker without overwriting baselines.','Continue all remaining checklist/inventory gaps, proper-name data and contextual/independent review.']}
Path('/tmp/klem-declarative-dao-checkpoint-revision2.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(STAGE/'docs/declarative-dao-validated-checkpoint.json.gz').write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print({k:v for k,v in report.items() if k in ['state','updated_files','new_files','full_rust','final_affected_rust','case_counts','browser','broad','cohorts','nix']})
