"""Run new browser corruption controls in live and captured evidence modes."""
import datetime,hashlib,json,os,re,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent/'friendly-hortative-sena'
O=P/'friendly-hortative-sena-browser-audit-controls.json';L=P/'friendly-hortative-sena-browser-audit-controls.log'
assert not O.exists() and not L.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=W)
frozen={n:sha((W/n).read_bytes()) for n in git('ls-files','-z').decode().split('\0')[:-1]}
head,index=git('rev-parse','HEAD').decode().strip(),sha(git('ls-files','--stage','-z'))
external={}
for path in [Path(__file__),P/'friendly_hortative_sena_browser_audit.py',P/'test_friendly_hortative_sena_browser_audit.py']:
 external[str(path)]=sha(path.read_bytes())
manifest=W/'docs/friendly-hortative-sena-browser-proof-archive.json';external[str(manifest)]=sha(manifest.read_bytes())
for row in json.loads(manifest.read_bytes())['files'].values():
 path=W/'docs'/row['path'];external[str(path)]=sha(path.read_bytes())
binding=json.loads((P/'friendly-hortative-sena-complete-runtime-binding.json').read_bytes())
for row in binding['binaries'].values(): external[row['path']]=row['sha256']
external.update(binding['protected_parent_binaries'])
assert all(sha(Path(p).read_bytes())==d for p,d in external.items())
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,external_inputs=external,results=[],
 producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
 started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 scope='New independent browser audit rederives150private policies/114diagrams/36forbidden, six original-corpus decisions/twelve complete exports/37Native. Runs32 controls in bothlive/captured modes, preserving original failed state guard and browser port failure. Not full historical inventory, installed packages, shared promotion/main/timing or contextual/register review.')
def save():O.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 with L.open('xb') as log:
  for mode in ['live','captured']:
   env=dict(os.environ,PYTHONPATH=str(P)+os.pathsep+str(W/'tools'),PYTHONDONTWRITEBYTECODE='1',KLEM_SENA_BINARY_EVIDENCE=mode)
   for args,controls in [([str(P/'friendly_hortative_sena_browser_audit.py')],0),(['-m','unittest','discover','-s',str(P),'-p','test_friendly_hortative_sena_browser_audit.py'],32)]:
    command=[sys.executable,*args];job=subprocess.run(command,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT)
    r['results'].append(dict(mode=mode,command=command,exit_code=job.returncode,expected_controls=controls));save()
    assert job.returncode==0,'New browser auditor failed; original producer/log/receipt retained.'
 r['state']='passed'
except BaseException as error:r.update(state='failed',error=repr(error));raise
finally:
 r.update(inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),external_inputs_unchanged=all(sha(Path(p).read_bytes())==d for p,d in external.items()),head_unchanged=git('rev-parse','HEAD').decode().strip()==head,index_unchanged=sha(git('ls-files','--stage','-z'))==index,controls=sum(map(int,re.findall(r'Ran (\d+) tests',L.read_text()))) if L.exists() else 0,log_sha256=sha(L.read_bytes()) if L.exists() else None,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 if not all(r[k] for k in ['inputs_unchanged','external_inputs_unchanged','head_unchanged','index_unchanged']):r['state']='failed'
 if r['state']=='passed' and r['controls']!=64:r['state']='failed'
 save()
assert r['state']=='passed'
print('Passed64 browser corruption controls across live/captured modes; allsource and6binaries unchanged.',flush=True)
