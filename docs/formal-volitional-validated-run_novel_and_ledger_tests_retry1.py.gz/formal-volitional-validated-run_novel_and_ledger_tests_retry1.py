"""Run the complete focused suites after the reserved release benchmark window."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = PREP.parent / 'formal-volitional-prototype'
OUT = PREP / 'novel-and-ledger-tests-retry1.json'
LOG = PREP / 'novel-and-ledger-tests-retry1.log'
assert not OUT.exists() and not LOG.exists()
benchmark = json.loads((PREP.parent / 'reported-experience-prepared/paired-release-performance.json').read_bytes())
assert benchmark['state'] == 'passed' and benchmark['inputs_unchanged'], 'quiet benchmark must finish first'
env = {**os.environ, 'CARGO_TARGET_DIR':str(PREP.parent / 'formal-volitional-target'),
       'CARGO_PROFILE_DEV_DEBUG':'0', 'CARGO_PROFILE_TEST_DEBUG':'0', 'CARGO_INCREMENTAL':'0'}
subprocess.run(['rustfmt','--edition','2024','tests/formal_volitional_novel.rs'],cwd=ROOT,env=env,check=True)
sha = lambda path: hashlib.file_digest(Path(path).open('rb'),'sha256').hexdigest()
paths = [ROOT / name for name in ['Cargo.toml','Cargo.lock','web/src/grammar-labels.json']]
for folder in ['src','tests','tools','examples']:
    paths.extend(p for p in (ROOT / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
frozen = {str(p.relative_to(ROOT)):sha(p) for p in paths}
commands = [
    ['cargo','test','--locked','--offline','--features','web','--test','formal_volitional','--test','formal_volitional_novel','--test','validity'],
    ['cargo','clippy','--locked','--offline','--features','web','--test','formal_volitional','--test','formal_volitional_novel','--test','validity','--bin','klem-web','--','-D','warnings'],
    ['cargo','build','--locked','--offline','--features','web','--bins'],
]
receipt = {'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'frozen_source_files':frozen,'commands':commands,'executions':[],
           'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},
           'scope':'Focused full59dictionary/raw53/Source404 tests, four novel/history/Native/spacing tests, full35587shared raw ledger tests, warnings-denied Clippy and feature-web runtime restoration. Start only after exact80paired+6cache benchmark passes and no prototype runtime capture is active. Whole Rust/Nix/installed/main and wider/contextual review remain separate.'}
def save():
    OUT.write_text(json.dumps(receipt,indent=2)+'\n')
save()
try:
    with LOG.open('xb') as log:
        for command in commands:
            result = subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
            receipt['executions'].append({'command':command,'exit_code':result.returncode})
            save()
            assert result.returncode == 0, command
    batches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',LOG.read_text())
    totals = {name:sum(int(b[i+1]) for b in batches) for i,name in enumerate(['passed','failed','ignored'])}
    assert len(batches) == 3 and totals == {'passed':13,'failed':0,'ignored':0}, totals
    assert all(sha(ROOT / path) == digest for path,digest in frozen.items()), 'source freeze'
    receipt.update(state='passed',exit_code=0,totals=totals,inputs_unchanged=True,
                   cli_sha256=sha(PREP.parent / 'formal-volitional-target/debug/klem'),
                   server_sha256=sha(PREP.parent / 'formal-volitional-target/debug/klem-web'))
except BaseException as error:
    receipt.update(state='failed',error=repr(error))
    raise
finally:
    receipt.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=sha(LOG))
    save()
print('Focused Source/novel/shared-ledger tests and Clippy passed; both feature-web binaries restored',flush=True)
