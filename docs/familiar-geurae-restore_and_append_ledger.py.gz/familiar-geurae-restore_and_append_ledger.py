"""Restore the exact current parent and append only independently authored cases."""
import gzip
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
PARENT = BASE / 'explanatory-se-integration'
ROOT = BASE / 'familiar-geurae-prototype'
PREP = BASE / 'familiar-geurae-prepared'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', '--short', 'HEAD'], cwd=PARENT, text=True).strip() == '46d8825'
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=PARENT).decode().split('\0')[:-1]
allowed = {'src/engine.rs', 'src/grammar.rs', 'src/bin/klem-web/grammar_labels.rs', 'web/src/grammar-labels.json'}
existing = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in ROOT.rglob('*')
            if p.is_file() and 'node_modules' not in p.parts and 'dist' not in p.parts and '__pycache__' not in p.parts}
missing = []
for name in tracked:
    source, target = PARENT / name, ROOT / name
    if target.exists():
        assert name in allowed or source.read_bytes() == target.read_bytes(), ('unexpected parent difference', name)
        continue
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    missing.append({'path': name, 'sha256': sha(source.read_bytes())})
assert all(sha((ROOT / name).read_bytes()) == value for name, value in existing.items()), 'all existing prototype inputs conserved'
path = ROOT / 'tests/fixtures/validity.json'
raw = path.read_bytes()
ledger = json.loads(raw)
parent = json.loads((PARENT / 'tests/fixtures/validity.json').read_bytes())
assert ledger == parent and len(ledger['cases']) == 35457
suite_path = ROOT / 'tests/fixtures/familiar-geurae-validity.json'
suite = json.loads(suite_path.read_bytes())
assert sha(suite_path.read_bytes()) == 'e2b927b7691731277b429a7322639d26562b9946741d1bcd029943d87d61f9f5'
assert len(suite['cases']) == 27 and not set(ledger['sources']) & set(suite['sources'])
assert not {case['id'] for case in ledger['cases']} & {case['id'] for case in suite['cases']}
ledger['cases'].extend(suite['cases'])
ledger['sources'].update(suite['sources'])
assert ledger['cases'][:35457] == parent['cases'] and ledger['cases'][35457:] == suite['cases']
assert {k: v for k, v in ledger.items() if k not in ['cases', 'sources']} == {k: v for k, v in parent.items() if k not in ['cases', 'sources']}
path.write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n')
registry = ROOT / 'tools/literary_question_geona_runtime.py'
text = registry.read_text()
marker = "    ('explanatory-se-novel-validity.json',14,'41ca6b4a824266128de576190bc4389066375bb4e0c1550ebb478caef83bf02c','explanatory-se-novel'),\n"
assert text.count(marker) == 1 and 'familiar-geurae-validity.json' not in text
registry.write_text(text.replace(marker, marker + "    ('familiar-geurae-validity.json',27,'e2b927b7691731277b429a7322639d26562b9946741d1bcd029943d87d61f9f5','familiar-geurae'),\n"))
counts = {v: sum(j['verdict'] == v for case in ledger['cases'] for j in case['judgments']) for v in ['required', 'forbidden']}
assert counts == {'required': 31263, 'forbidden': 4237}
receipt = {'state': 'exact-parent-restored-and-authored-append-preserved', 'parent': '46d8825',
           'restored_files': missing, 'existing_files_conserved': len(existing), 'previous_cases': 35457,
           'cases': len(ledger['cases']), 'before_sha256': sha(raw), 'after_sha256': sha(path.read_bytes()),
           'suite_sha256': sha(suite_path.read_bytes()), 'counts': counts,
           'scope': 'Exact complete parent restored without overwriting existing prototype files. Only27 independently authored19required/8forbidden Source/attachment/variant cases appended. Every earlier case/source/metadata remains exact; observed alternatives and probe-only diagnostics are not gold.'}
(PREP / 'shared-ledger-append.json').write_text(json.dumps(receipt, indent=2) + '\n')
(ROOT / 'docs/familiar-geurae-shared-ledger-append.json.gz').write_bytes(gzip.compress((json.dumps(receipt, indent=2) + '\n').encode(), mtime=0))
print('Restored', len(missing), 'parent files; preserved', len(existing), 'private inputs; ledger35457+27=', len(ledger['cases']), counts, flush=True)
