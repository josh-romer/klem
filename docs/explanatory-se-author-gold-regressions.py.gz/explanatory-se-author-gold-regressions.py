"""Preserve original annotated contexts as independent lemma regression targets."""
import gzip
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
PROTO = BASE / "explanatory-se-prototype"
original = BASE / "giroseo-integration/docs/literary-question-geona-prototype-corpora.json.gz"
source = json.loads(gzip.decompress(original.read_bytes()))
partition = next(p for p in source["corpora"] if (p["corpus"], p["partition"]) == ("kaist", "test"))
assert hashlib.sha256(partition["original_source_text"].encode()).hexdigest() == partition["source_sha256"]
targets = [("MH2_0110-s387", "3", "오랫만일세", ["오랫만", "이다"], ["nominal", "copula"]),
           ("MH2_0110-s395", "5", "아닐세", ["아니다"], ["predicate"])]
cases = []
contexts = []
for sentence, ordinal, surface, lemmas, kinds in targets:
    block = next(b for b in partition["original_source_text"].split("\n\n") if f"# sent_id = {sentence}\n" in b)
    token = next(line.split("\t") for line in block.splitlines() if line.startswith(ordinal + "\t"))
    assert token[1] == surface
    # These targets follow the original annotation and the ending's source note.
    assert token[2] == ("오랫만+이+ㄹ세" if sentence.endswith("s387") else "아니+ㄹ세")
    ident = f"id:{sentence}/{ordinal}"
    row = next(r for r in partition["original_converted_rows"] if r["id"] == ident)
    assert row["surface"] == surface and row["expected"] == lemmas
    text = next(line.removeprefix("# text = ") for line in block.splitlines() if line.startswith("# text = "))
    contexts.append({"id": ident, "surface": surface, "expected": lemmas, "text": text,
                     "complete_original_annotation_block": block, "source_sha256": partition["source_sha256"],
                     "original_annotation": token[2], "original_converted_row": row})
    cases.append({"id": "explanatory-se-gold-" + sentence + "-" + ordinal, "surface": surface,
                  "judgments": [{"id": "original-gold", "lemmas": lemmas, "lemma_kinds": kinds,
                                 "morphemes": ["을세"], "morpheme_kinds": ["ending"],
                                 "required_rules": ["ending.explanatory_se"], "verdict": "required",
                                 "source": "original-kaist-test", "reason": f"Unchanged original annotated row {ident}; lemma target authored from annotation, not emitted candidates. Canonical ending uses the separate complete KRDict short-ending source note."}]})
suite = {"schema_version": 1, "review_status": "Original annotated structural gold; no contextual homonym or whole-sentence precision claim.",
         "sources": {"original-kaist-test": "https://github.com/UniversalDependencies/UD_Korean-Kaist/blob/master/ko_kaist-ud-test.conllu"}, "cases": cases}
dest = PROTO / "tests/fixtures"
(dest / "explanatory-se-gold-validity.json").write_text(json.dumps(suite, ensure_ascii=False, indent=2) + "\n")
(dest / "explanatory-se-gold-contexts.json").write_text(json.dumps(contexts, ensure_ascii=False, indent=2) + "\n")
cohorts = json.loads(gzip.decompress((OUT / "cohorts.json.gz").read_bytes()))
words = next(r for r in cohorts["runs"] if r["family"] == "corpus")["captures"][0]["words"]
preserved = {s: words[s] for s in ["탈세", "통일세"]}
(dest / "explanatory-se-lexical-baselines.json").write_text(json.dumps(preserved, ensure_ascii=False, indent=2) + "\n")
print("Authored two original-gold contexts and two complete pre-change lexical baselines.")
