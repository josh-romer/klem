"""Record the complete finite prototype and its four explicitly bounded source reviews."""
import gzip
import hashlib
import json
import re
import shutil
from pathlib import Path

BASE = Path('/home/josh/projects/klem')
ROOT = BASE / '.direnv/formal-volitional-prototype'
PREP = BASE / '.direnv/formal-volitional-prepared'
DOCS = ROOT / 'docs'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(p.read_bytes())
for filename,count in [
    ('source-controls.log',30), ('streams-controls.log',18), ('cohort-controls.log',5),
    ('corpora-controls.log',10), ('broad-controls-retry1.log',23),
    ('browser-controls.log',19), ('ledger-controls.log',6), ('historical-ledger-controls-retry1.log',84),
]:
    text = (PREP / filename).read_text()
    assert f'Ran {count} tests' in text and text.rstrip().endswith('OK'), filename
tests = read(PREP / 'novel-and-ledger-tests-retry1.json')
assert tests['state'] == 'passed' and tests['inputs_unchanged'] and tests['totals'] == {'passed':13,'failed':0,'ignored':0}
browser = read(PREP / 'formal-volitional-closure-browser.json')
runtime = read(PREP / 'formal-volitional-closure-browser-runtime.json')
assert runtime['state'] == 'passed' and runtime['inputs_unchanged'] and runtime['server_stopped']
assert len(browser['policyDecisions']) == len(browser['diagrams']) == 222 and len(browser['nativeEntries']) == 69
assert len(browser['exports']) == 6 and not browser['errors']
suite = read(ROOT / 'tests/fixtures/formal-volitional-validity.json')
raw = read(ROOT / 'tests/fixtures/formal-volitional-raw-validity.json')
ledger = read(ROOT / 'tests/fixtures/validity.json')
assert len(suite['cases']) == 59 and len(raw['cases']) == 53 and len(ledger['cases']) == 35587
assert sha((ROOT / 'tests/fixtures/formal-volitional-validity.json').read_bytes()) == '4baa4c4bc9da65a9a9c493b7aadd537afd82ff3464daf586dc3e59823d9cd181'
protected = {str(p.relative_to(ROOT)):sha(p.read_bytes())
             for folder in ['src','tests','web/src'] for p in (ROOT / folder).rglob('*') if p.is_file()}
# Bring the already committed main evidence and performance audit into this
# private tree. Its additional familiar/apprehensive runtime and ledger stay.
copied = []
for source in [*sorted((BASE / 'docs').glob('formal-volitional-*')),
               *sorted((BASE / 'docs').glob('reported-experience-performance*')),
               BASE / 'tools/reported_experience_performance.py',
               BASE / 'tools/test_reported_experience_performance.py',
               BASE / 'docs/reported-experience-draft.md']:
    relative = source.relative_to(BASE)
    target = ROOT / relative
    if target.exists() and target.read_bytes() == source.read_bytes():
        continue
    if target.exists():
        assert relative == Path('docs/reported-experience-draft.md'), ('unexpected evidence difference', relative)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source,target)
    copied.append({'path':str(relative),'sha256':sha(source.read_bytes())})
paragraph = (
    'Four original ending owners (86548/86549/86604/86605) preserve their distinct '
    'homonym numbers, full notes/senses and all 17 complete original groups. '
    'Short -렵니까/-렵니다 attaches to vowel/ㄹ verbs or immediate -으시-; '
    'full -으렵니까/-으렵니다 attaches to non-ㄹ consonantal verbs. Separate '
    'canonical questions/statements use ending.formal_volitional and the existing '
    'verbal-intention POS class. All 59 independently authored cases stay unchanged '
    '(33 required/26 forbidden). The pre-implementation evaluation policy checks '
    '53 spelling/prefinal/copular structural cases raw and all 59 with the complete '
    'original Native dictionary; six adjective/negative-copula POS exclusions '
    'remain dictionary-dependent. Five Source, four novel and four full shared-ledger '
    'Rust tests, eight source/label tests and warnings-denied Clippy pass. '
    'Twelve complete Source Unicode/filter/cache modes conserve 3,264 frames and '
    '404 individually tracked alternatives against 63 full Native identities. '
    'All 53,502 corpus/history words and 66,570 unchanged annotated rows retain '
    'their prior output. Eight broad workloads conserve 1,128,312 frames, all '
    'old paths/order/assessments and spacing boundaries; 32 novel paths, two '
    'spacing hypotheses and two diagnostics retain complete original contexts. '
    'Only four separately manually reviewed lexical paths are required: '
    '되렵니다 → 되다, 가렵니다 → 가다, 버리렵니다 → 버리다 and '
    '뜯어먹으렵니다 → 뜯어먹다. Other observed alternatives stay unjudged. '
    'Eleven full novel owners join the Source closure in an exact 69-entry '
    'browser union. The actual SolidJS browser passes 222 policy decisions and '
    'diagrams, six exact CLI exports and all 69 full Native endpoints; no errors '
    'and owned server stopped. Eight Source/stream/cohort/gold/broad/browser/ledger '
    'audit families pass 30/18/5/10/23/19/6 controls, plus 84 historical controls. '
    'The shared raw ledger retains its exact 35,530-case prefix and appends '
    'only 53 original structural and four manual novel cases: 35,587 total, '
    '31,337 required and 4,266 forbidden. Original full59 judgments remain '
    'separately dictionary-enforced. Whole Rust, actual Nix/installed/main '
    'integration, family timing and broader contextual/independent review remain open.')
(DOCS / 'formal-volitional-draft.md').write_text(
    '# Formal volitional endings\n\nStatus: complete finite private prototype; '
    'whole Rust/Nix/installed/main integration pending.\n\n' + paragraph + '\n\n'
    'Original spoken pronunciation notes (-ㄹ랍니다/-을랍니다) remain attributed '
    'notes and do not license automatic spelling aliases. Expression homonyms '
    '89455 (-렵니까) and 89456 (-으렵니까), with POS 품사 없음, are separate '
    'unreviewed owners outside the 715-entry ending/particle/auxiliary inventory. '
    'No contextual sense or linguistic precision is inferred from candidates.\n')
tracker = DOCS / 'coverage-checklist.md'
text = tracker.read_text()
assert 'COV-017cw —' not in text
main = (BASE / 'docs/coverage-checklist.md').read_text()
start,end = main.index('- [ ] **COV-017cw —'),main.index('- [ ] **COV-018 —')
block = main[start:end]
block += '  Four finite ending dispositions are scoped in this private tree; the verified\n  queue has 511 scoped and 204 unreviewed identities. [Finite scope](formal-volitional-draft.md).\n\n'
text = text.replace('- [ ] **COV-018 —',block + '- [ ] **COV-018 —',1)
text,count = re.subn(r'(The \[manual review ledger\]\(inventory-reviews.json\) records )\d+( scoped\n  dispositions; )\d+( entries await a disposition)',r'\g<1>511\g<2>204\g<3>',text)
assert count == 1
tracker.write_text(text)
reviews_path = DOCS / 'inventory-reviews.json'
reviews = read(reviews_path)
queue = read(DOCS / 'inventory-review-queue.json')
assert queue['counts']['by_review'] == {'scoped':507,'unreviewed':208}
evidence = [{'path':path} for path in [
    'docs/formal-volitional-draft.md', 'tests/formal_volitional.rs', 'tests/formal_volitional_novel.rs',
    'tests/fixtures/formal-volitional-validity.json', 'tests/fixtures/formal-volitional-raw-validity.json',
    'tests/fixtures/formal-volitional-evaluation-policy.json', 'tests/fixtures/formal-volitional-native.json',
    'tests/fixtures/formal-volitional-additional-native.json', 'tests/fixtures/formal-volitional-novel-native.json',
    'tests/fixtures/formal-volitional-novel-validity.json',
    'docs/formal-volitional-source-preparation.json.gz', 'docs/formal-volitional-independent-source-proposals.json.gz',
    'docs/formal-volitional-independent-authoring.json.gz', 'docs/formal-volitional-latest-baseline-gap.json.gz',
    'docs/formal-volitional-prototype-validation.json.gz', 'docs/formal-volitional-distribution-validation.json.gz',
    'docs/formal-volitional-ledger-preparation.json.gz', 'docs/formal-volitional-rust-browser-validation.json.gz']]
families = ['source','streams','cohort','corpora','broad','browser','ledger']
for family in families:
    evidence.extend({'path':f'tools/{prefix}formal_volitional_{family}_audit.py'} for prefix in ['', 'test_'])
assert all((ROOT / ref['path']).is_file() for ref in evidence)
for ident in suite['sources']:
    source = next(row for row in queue['entries'] if row['source']['id'] == ident)
    assert source['review']['status'] == 'unreviewed' and not any(r['id'] == ident for r in reviews['entries'])
    judgments = [{'case':case['id'],'judgment':j['id']} for case in raw['cases'] for j in case['judgments'] if j['source'] == ident]
    assert judgments
    reviews['entries'].append({'id':ident,'source_sha256':source['source_sha256'],'status':'scoped',
                              'checklist':['COV-017cw'],'scope':paragraph,
                              'remaining':'Whole Rust/Nix/installed/main integration, actual family timing, wider attachment distributions, separate expression homonyms89455/89456, contextual sense selection and independent linguistic review.',
                              'evidence':evidence,'judgments':judgments})
reviews_path.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n')
flake = ROOT / 'flake.nix'
text = flake.read_text()
assert 'formal_volitional_source_audit.py' not in text and 'reported_experience_performance.py' not in text
marker = '                ./tools/test_reported_experience_installed_audit.py\n'
commands = "            python -m unittest discover -s tools -p 'test_reported_experience_installed_audit.py'\n"
assert text.count(marker) == text.count(commands) == 1
text = text.replace(marker,marker + '                ./tools/reported_experience_performance.py\n                ./tools/test_reported_experience_performance.py\n')
text = text.replace(commands,commands + "            python tools/reported_experience_performance.py\n            python -m unittest discover -s tools -p 'test_reported_experience_performance.py'\n")
marker = '                ./tools/test_fear_lsera_broad_audit.py\n'
commands = "            python -m unittest discover -s tools -p 'test_fear_lsera_broad_audit.py'\n"
assert text.count(marker) == text.count(commands) == 1
files = ''.join(f'                ./tools/{prefix}formal_volitional_{family}_audit.py\n' for family in families for prefix in ['', 'test_'])
runs = ''.join(f"            python tools/formal_volitional_{family}_audit.py\n            python -m unittest discover -s tools -p 'test_formal_volitional_{family}_audit.py'\n" for family in families)
flake.write_text(text.replace(marker,marker+files).replace(commands,commands+runs))
assert all(sha((ROOT / path).read_bytes()) == value for path,value in protected.items())
receipt = {'state':'complete-finite-scope-prepared-queue-regeneration-pending',
           'source_owners':list(suite['sources']),'new_scoped_entries':4,'expected_scoped':511,'expected_unreviewed':204,
           'copied_main_evidence':copied,'runtime_tests_fixtures_and_catalog_unchanged':True,
           'audit_families':families,'family_controls':111,'historical_controls':84,
           'scope':'Seven formal audit families wired; Source/streams/cohort/gold/broad/browser/ledger are separate evidence scopes. Original judgments remain unchanged. Four finite private reviews explicitly retain wholeRust/Nix/installed/main/performance/contextual limits. Main code/reviews unchanged. Regenerate queue last and run controls before freezing completeRust.',
           'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())}}
(PREP / 'finite-scope.json').write_text(json.dumps(receipt,indent=2)+'\n')
(DOCS / 'formal-volitional-finite-scope-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('Prepared four finite source reviews; all runtime/judgments retained; expected511/204queue; regenerate last',flush=True)
