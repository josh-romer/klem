"""Run full committed Rust coverage with immutable tracked source evidence."""
import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem/.direnv/dapnikka-integration')
PREFIX=Path('/tmp/klem-dapnikka-committed-full-tests')
RECEIPT=PREFIX.with_suffix('.json');LOG=PREFIX.with_suffix('.log')
assert not RECEIPT.exists() and not LOG.exists()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert not git('status','--porcelain')
head=git('rev-parse','HEAD').decode().strip();index=hashlib.sha256(git('ls-files','--stage','-z')).hexdigest()
files={name:{'bytes':(ROOT/name).stat().st_size,'sha256':sha(ROOT/name)} for name in git('ls-files','-z').decode().split('\0')[:-1]}
command=['cargo','test','--offline','--features','web','--jobs','4']
env=dict(os.environ,CARGO_TARGET_DIR='/home/josh/projects/klem/.direnv/integration-compact-target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0')
r={'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'index_sha256':index,'snapshot_files':files,'command':command,'workdir':str(ROOT),'target':env['CARGO_TARGET_DIR'],'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Complete committed reported-question/name/title/self-question integration Rust suite, exact expanded35142-case shared ledger, all tracked inputs and Git HEAD/index frozen. This does not prove Nix/installed/timing/contextual or independent review.'}
def save():RECEIPT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
with LOG.open('xb') as stream:job=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
text=LOG.read_text();rows=[tuple(map(int,m)) for m in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)]
r.update(state='passed' if job.returncode==0 else 'failed',exit_code=job.returncode,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),inputs_unchanged=all(sha(ROOT/name)==v['sha256'] for name,v in files.items()),head_unchanged=git('rev-parse','HEAD').decode().strip()==head,index_unchanged=hashlib.sha256(git('ls-files','--stage','-z')).hexdigest()==index,totals={name:sum(row[i] for row in rows) for i,name in enumerate(['passed','failed','ignored'])},batches=len(rows),log_sha256=sha(LOG))
save();assert r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged']
if job.returncode==0:assert r['totals']=={'passed':1102,'failed':0,'ignored':1} and r['batches']==238
print('Committed full Rust:',r['state'],r['totals'],'batches',r['batches'],'frozen sources/HEAD/index',r['inputs_unchanged'],r['head_unchanged'],r['index_unchanged'],flush=True)
raise SystemExit(job.returncode)
