"""Preserve the actual selected parent pass and every preceding failed attempt."""
import gzip
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
OUT = W / 'docs/friendly-hortative-sena-parent-selected-current-proof-archive.json'
assert not OUT.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
r = json.loads((P / 'friendly-hortative-sena-gena-parent-selected-source-retry5.json').read_bytes())
assert r['state'] == 'passed' and r['controls'] == 137
assert len(r['results']) == 9 and all(row['exit_code'] == 0 for row in r['results'])
assert all(r[k] for k in ('source_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged'))
assert all(sha((W / name).read_bytes()) == digest for name, digest in r['source_inputs'].items())
assert len(r['source_inputs']) == 9429 and len(r['selected_files']) == 9387
names = ['verify_sena_gena_parent_selected_source_retry5.py',
         'friendly-hortative-sena-gena-parent-selected-source-retry5.json',
         'friendly-hortative-sena-gena-parent-selected-source-retry5.log',
         'archive_sena_parent_selected_current.py',
         'run_coverage_nix_store_deduplication.py', 'coverage-nix-store-deduplication.json',
         'coverage-nix-store-deduplication.log']
assert r['log_sha256'] == sha((P / names[2]).read_bytes())
assert r['producer'] == dict(text=(P / names[0]).read_text(), sha256=sha((P / names[0]).read_bytes()))
paths = {name: P / name for name in names}
for name in ['sena-gena-parent-selected-first-failure-originals.json',
             'sena-gena-parent-selected-second-failure-originals.json',
             'sena-gena-parent-selected-third-failure-originals.json',
             'sena-gena-parent-selected-fourth-failure-originals.json',
             'sena-parent-selected-missing-handle.json']:
    raw = (P / name).read_bytes(); metadata = json.loads(raw)
    paths[name] = P / name
    for row in metadata['files'].values():
        path = P / row['path']; packed = path.read_bytes()
        assert sha(packed) == row['archive_sha256'] and sha(gzip.decompress(packed)) == row['source_sha256']
        paths[path.name] = path
root_cache = P.parents[1] / '.direnv/coverage-unused-rust-library-cache-cleanup.json'
paths[root_cache.name] = root_cache
files = {}; destination = W / 'docs/friendly-hortative-sena-parent-selected-current-proof'
destination.mkdir()
for name, path in sorted(paths.items()):
    raw = path.read_bytes(); packed = gzip.compress(raw, mtime=0)
    target = destination / (name + '.gz'); target.write_bytes(packed)
    assert gzip.decompress(target.read_bytes()) == raw
    files[name] = dict(path=str(target.relative_to(W / 'docs')), source_sha256=sha(raw),
                       archive_sha256=sha(packed), bytes=len(raw))
OUT.write_text(json.dumps(dict(state='actual137-Git-selected-parent-controls-passed', files=files,
                              head=r['head'], tracked_source_files=9429, selected_source_files=9387,
                              controls=137, inventory_entries=715,
                              compiled_inputs={'klem':1176 if False else 1158, 'corpus-adapter':1158, 'web-assets':18},
                              all_source_HEAD_index_and_six_binaries_unchanged=True,
                              four_actual_fetch_failures_preserved=True,
                              incomplete_prior_receipt_retained_without_terminal_pass=True,
                              no_new_full_Nix_build_or_runtime_replay=True,
                              original25_Sena_cases_remain_private=True,
                              scope='Exact fa50 Git-selected source, whole tested parent profiles, all137 controls and715 queue. All previous failed/partial attempts and content-preserving disk recovery retained. Actual shared promotion/main/quiet/contextual review remain separate.'),
                          indent=2) + '\n')
print(json.dumps(dict(files=len(files), manifest_sha256=sha(OUT.read_bytes()))), flush=True)
