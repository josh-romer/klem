"""Continue one frozen branch after its existing actual Nix gate finishes."""
import argparse
import datetime
import gzip
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

P = Path('/home/josh/projects/klem/.direnv/willingness-question-prepared')
ROOT = P.parents[1]
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def configuration(family):
    if family == 'gena':
        folder, worktree, prefix = P, 'friendly-command-gena', 'friendly-command-gena-promoted-'
        gate = prefix + 'complete-nix-gate-retry1.json'
        steps = [
            ('packages', 'build_friendly_command_gena_promoted_nix_packages.py', prefix + 'nix-packages.json'),
            ('installed-runtime', 'capture_friendly_command_gena_promoted_installed_runtime.py', prefix + 'installed-runtime-completion-audit.json.gz'),
            ('installed-browser', 'run_friendly_command_gena_promoted_installed_browser.py', prefix + 'installed-browser-runtime.json'),
            ('installed-audits', 'validate_friendly_command_gena_promoted_installed_audit.py', prefix + 'installed-audits.json'),
        ]
        additional = ['friendly_command_gena_promoted_installed_audit.py',
                      'test_friendly_command_gena_promoted_installed_audit.py', 'friendly-command-gena-browser.mjs']
    else:
        folder = ROOT / '.direnv/friendly-hortative-sena-prepared'
        worktree, prefix = 'friendly-hortative-sena', 'friendly-hortative-sena-'
        gate = prefix + 'complete-nix-gate.json'
        steps = [
            ('installed-browser', 'run_friendly_hortative_sena_installed_browser_retry4.py', prefix + 'installed-browser-runtime.json'),
            ('installed-audits', 'validate_friendly_hortative_sena_installed_audit_retry4.py', prefix + 'installed-audit-validation.json'),
        ]
        additional = ['friendly_hortative_sena_installed_audit_retry4.py',
                      'test_friendly_hortative_sena_installed_audit_retry4.py', 'friendly-hortative-sena-browser.mjs',
                      'friendly-hortative-sena-documentation-scope.json',
                      'friendly-hortative-sena-documentation-scope.log',
                      'run_friendly_hortative_sena_documentation_scope.py']
    return folder, ROOT / '.direnv' / worktree, prefix, gate, steps, additional


def main(family):
    folder, worktree, prefix, gate_name, steps, additional = configuration(family)
    out, log_path = folder / (prefix + 'installed-continuation-retry4.json'), folder / (prefix + 'installed-continuation-retry4.log')
    assert not out.exists() and not log_path.exists(), 'never restart or overwrite a previous attempt'
    git = lambda *args: subprocess.check_output(['git', *args], cwd=worktree)
    read = lambda path: json.loads(gzip.decompress(path.read_bytes()) if path.name.endswith('.gz') else path.read_bytes())
    gate_path = folder / gate_name
    gate = read(gate_path)
    assert gate['state'] in ('running', 'passed'), 'existing gate must not have failed'
    assert not git('status', '--porcelain')
    head, index = git('rev-parse', 'HEAD').decode().strip(), sha(git('ls-files', '--stage', '-z'))
    source = gate['frozen_inputs']
    assert head == gate['head'] and index == gate['index_sha256']
    assert all(sha((worktree / name).read_bytes()) == digest for name, digest in source.items())
    protected = gate['protected_binaries']
    assert len(protected) == 6
    assert all(sha(Path(path).read_bytes()) == digest for path, digest in protected.items())
    for _, _, receipt in steps:
        assert not (folder / receipt).exists(), 'a stage has already been attempted'
    programs = {str(folder / name): sha((folder / name).read_bytes()) for name in additional + [s[1] for s in steps]}
    programs[str(Path(__file__).resolve())] = sha(Path(__file__).read_bytes())
    original_bodies = {path: Path(path).read_text() for path in programs if path.endswith(('.py', '.mjs'))}
    r = dict(state='running', phase='waiting-for-existing-complete-nix-gate', family=family,
             head=head, index_sha256=index, source_inputs=source, protected_binaries=protected,
             frozen_programs=programs, original_program_bodies=original_bodies,
             existing_gate=str(gate_path), results=[], started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
             scope='Wait for the existing actual full gate without restarting it, then execute all four original prepared installed stages in order. No source edits, replacement results, merge, timing claim or full checklist completion. Original child producers and complete output retained. Desktop/mobile screenshots still require visual inspection after capture.')

    def save():
        out.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')

    def check_freeze(full=True):
        assert git('rev-parse', 'HEAD').decode().strip() == head
        assert sha(git('ls-files', '--stage', '-z')) == index
        assert not git('status', '--porcelain')
        assert all(sha(Path(path).read_bytes()) == digest for path, digest in programs.items())
        if full:
            assert all(sha((worktree / name).read_bytes()) == digest for name, digest in source.items())
            assert all(sha(Path(path).read_bytes()) == digest for path, digest in protected.items())

    save()
    print(f'{family}: waiting on the existing complete gate; frozen installed continuation armed.', flush=True)
    try:
        with log_path.open('xb') as log:
            while True:
                try:
                    terminal_gate = read(gate_path)
                except json.JSONDecodeError:
                    # The producer writes the running receipt directly. A partial
                    # observation is neither a failure nor permission to restart.
                    time.sleep(1)
                    continue
                if terminal_gate['state'] == 'running':
                    time.sleep(5)
                    continue
                assert terminal_gate['state'] == 'passed' and terminal_gate['exit_code'] == 0, 'actual complete prerequisite gate failed'
                assert len(terminal_gate['outputs']) == 4
                assert terminal_gate['frozen_inputs'] == source and terminal_gate['head'] == head
                assert all(terminal_gate[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged'])
                r['complete_gate_sha256'] = sha(gate_path.read_bytes())
                break
            for phase, program, receipt in steps:
                check_freeze()
                r['phase'] = phase
                command = ['python3', str(folder / program)]
                r['active_command'] = command
                save()
                print(f'{family}: executing {phase}.', flush=True)
                log.write(('COMMAND ' + json.dumps(command) + '\n').encode())
                log.flush()
                run = subprocess.run(command, cwd=worktree, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
                                     stdout=log, stderr=subprocess.STDOUT)
                log.flush()
                row = dict(phase=phase, command=command, exit_code=run.returncode, receipt=str(folder / receipt))
                if (folder / receipt).exists():
                    row['receipt_sha256'] = sha((folder / receipt).read_bytes())
                    row['state'] = read(folder / receipt)['state']
                r['results'].append(row)
                save()
                assert run.returncode == 0 and row.get('state') == 'passed', ('installed stage failed', phase)
                check_freeze()
            r.update(state='passed', phase='remaining-browser-and40-audits-passed', screenshots_visually_inspected=False)
    except BaseException as error:
        r.update(state='failed', error=repr(error))
        raise
    finally:
        r.update(head_unchanged=git('rev-parse', 'HEAD').decode().strip() == head,
                 index_unchanged=sha(git('ls-files', '--stage', '-z')) == index,
                 source_unchanged=all(sha((worktree / name).read_bytes()) == digest for name, digest in source.items()),
                 programs_unchanged=all(sha(Path(path).read_bytes()) == digest for path, digest in programs.items()),
                 protected_binaries_unchanged=all(sha(Path(path).read_bytes()) == digest for path, digest in protected.items()),
                 log_sha256=sha(log_path.read_bytes()) if log_path.exists() else None,
                 finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
        if not all(r[k] for k in ['head_unchanged', 'index_unchanged', 'source_unchanged', 'programs_unchanged', 'protected_binaries_unchanged']):
            r['state'] = 'failed'
        save()
    assert r['state'] == 'passed'
    print(f'{family}: three actual remaining installed stages passed; inspect captured screenshots next.', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--family', required=True, choices=['gena', 'sena'])
    main(parser.parse_args().family)
