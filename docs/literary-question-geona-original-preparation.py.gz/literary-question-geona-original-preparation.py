"""Preserve the next source cohort, eight exact earlier parents and full Native ownership."""
import copy,gzip,hashlib,json,sqlite3,subprocess,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from native_lmf import array,entry,verify_native_lmf
read=lambda p:json.loads(gzip.decompress(Path(p).read_bytes()) if str(p).endswith('.gz') else Path(p).read_bytes())
sha=lambda raw:hashlib.sha256(raw).hexdigest()
SOURCE=Path('/tmp/klem-literary-question-geona-source-discovery.json.gz');OUT=Path('/tmp/klem-literary-question-geona-original-preparation.json.gz');assert not OUT.exists()
source=read(SOURCE);CLI=Path('/tmp/klem-literary-future-kko-main-cli');DB=ROOT/'data/dictionaries/krdict/krdict.db'
heads={'삼을거나':'삼다','접을거나':'접다','지을거나':'짓다','좋을거나':'좋다','어쩔거나':'어쩌다','한잔할거나':'한잔하다','볼거나':'보다','어찌할거나':'어찌하다'}
assert set(heads)=={t['surface'] for t in source['targets']}
text=' '.join(w[:-2]+'까' for w in heads);command=[str(CLI),'text','-','--dictionary',str(DB)];p=subprocess.run(command,input=text.encode(),capture_output=True,check=True)
parents={r['surface']:r for r in map(json.loads,p.stdout.splitlines()) if r.get('analysis')};cases=[];owners=set()
baseline=list(map(json.loads,next(r for r in source['runs'] if (r['encoding'],r['mode'])==('NFC','raw'))['jsonl'].splitlines()))
for target in source['targets']:
 word=target['surface'];parent=parents[word[:-2]+'까'];hits=[i for i,a in enumerate(parent['analysis']['analyses']) if [l['text'] for l in a['lemmas']]==[heads[word]] and [l['kind'] for l in a['lemmas']]==['predicate'] and [m['form'] for m in a['morphemes']]==['을까']]
 assert len(hits)==1;index=hits[0];path=parent['analysis']['analyses'][index];assessment=parent['dictionary']['readings'][index]
 owners.update(e['id'] for slot in assessment['lemmas'] for e in slot['entries'])
 span={k:len(source['input'][:v].encode()) for k,v in target['char_span'].items()};before=next(r for r in baseline if r['span']==span)
 expected={'lemmas':[heads[word]],'lemma_kinds':['predicate'],'morphemes':['을거나'],'morpheme_kinds':['ending'],'required_rules':['ending.literary_question_geona']}
 cases.append({'id':f"literary-question-geona-original-{target['source'].split(':')[1]}-{target['sense']}-{target['group_index']}",'surface':word,'source_occurrence':target,'expected':expected,'before':before['analysis'],'earlier_parent':{'surface':parent['surface'],'analysis':path,'assessment':assessment},'structural_verdict':'proposed-required','contextual_verdict':'unjudged','independent_review':'pending'})
names=set(heads.values())|{'-ㄹ거나','-을거나','-ㄹ까','-을까','-시-','-으시-','-었-','-겠-'}
with sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True) as db:
 for ident in owners:names.add(db.execute('SELECT headword FROM entries WHERE id=?',(ident,)).fetchone()[0])
 native={ident:json.loads(raw) for ident,head,raw in db.execute('SELECT id,headword,data FROM entries') if head in names}
pinned=read(ROOT/'docs/reported-dana-source-preparation.json.gz')['source_hashes'];original={};hashes={}
for path in sorted((ROOT/'data/dictionaries/krdict/json').glob('*.json')):
 raw=path.read_bytes();name=str(path.relative_to(ROOT));hashes[name]=sha(raw);assert hashes[name]==pinned[name]
 doc=json.loads(raw)
 for value in array(doc['LexicalResource']['Lexicon']['LexicalEntry']):
  base='krdict:'+value['val']
  if base not in native and not any(i.startswith(base+':') for i in native):continue
  projected=entry(value);ident=projected['id']
  if ident in native:assert projected==native[ident] and ident not in original;original[ident]=value
assert set(original)==set(native) and owners<=native.keys()
projection={'LexicalResource':{'Lexicon':{'LexicalEntry':[]}}}
for ident in sorted(original):
 value=copy.deepcopy(original[ident])
 for sense in array(value.get('Sense')):sense['Equivalent']=[t for t in array(sense.get('Equivalent')) if any(f.get('att')=='language' and f.get('val')=='영어' for f in array(t.get('feat')))]
 projection['LexicalResource']['Lexicon']['LexicalEntry'].append(value)
verify_native_lmf(projection,native)
assert all(sha(Path(p).read_bytes())==h for p,h in source['frozen_inputs'].items())
r={'schema_version':1,'preparation_only':True,'source_capture_sha256':sha(SOURCE.read_bytes()),'original_cases':cases,'primary_entry_ids':sorted(source['sqlite_entries']),'parent_capture':{'command':command,'input':text,'input_sha256':sha(text.encode()),'jsonl':p.stdout.decode(),'sha256':sha(p.stdout),'exit_code':0},'matched_parent_owner_ids':sorted(owners),'named_headwords':sorted(names),'complete_native_entries':native,'original_lmf':original,'english_projection':projection,'source_hashes':hashes,'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'scope':'Eight original case proposals with exact actually emitted prior -(으)ㄹ까 parents and Native assessments; complete original LMF/SQLite equality and English projection preserve every named-head homonym. The restrictive source note and descriptive 좋을거나 remain intact. No implementation or raw/global/contextual judgment has been applied.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Prepared8original cases/8exact earlier parents and',len(native),'completeNative entries. Preparation only.',flush=True)
