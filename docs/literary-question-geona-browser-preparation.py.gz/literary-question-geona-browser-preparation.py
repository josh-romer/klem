import hashlib,json,os,shutil,subprocess
from pathlib import Path
P=Path('/tmp/klem-literary-question-geona-prototype');W=Path('/tmp/klem-literary-question-geona-frontend');OUT=Path('/tmp/klem-literary-question-geona-frontend-build.json');assert not W.exists() and not OUT.exists();W.mkdir();files={}
for p in (P/'web').rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(P/'web');target=W/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes());files[str(rel)]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
os.symlink('/home/josh/projects/klem/web/node_modules',W/'node_modules');r=subprocess.run(['npm','run','build'],cwd=W,capture_output=True,text=True);Path('/tmp/klem-literary-question-geona-frontend-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
assert all(hashlib.sha256((W/n).read_bytes()).hexdigest()==s['sha256'] for n,s in files.items());assets={str(p.relative_to(W/'dist')):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (W/'dist').rglob('*') if p.is_file()}
OUT.write_text(json.dumps({'state':'passed','command':['npm','run','build'],'cwd':str(W),'snapshot_files':files,'assets':assets,'inputs_unchanged':True,'exit_code':0},indent=2)+'\n');print('TypeScript +SolidJS frontend build passed:',len(files),'inputs',len(assets),'assets.')
script=Path('/home/josh/projects/klem/web/tests/literary-future-kko.mjs').read_text();script=script.replace('literary-future-kko','literary-question-geona')
start=script.index('const finite=');end=script.index('const source=',start)
script=script[:start]+"const ownerCases=(await json(proto+'/tests/fixtures/literary-question-geona-owner-extension-cases.json')).cases;\nboundaries.push(...ownerCases);\n"+script[end:]
script=script.replace("root+'/docs/literary-question-geona-source-discovery.json.gz'","process.env.KLEM_GEONA_SOURCE").replace("root+'/docs/literary-question-geona-prototype-source-replay.json.gz'","process.env.KLEM_GEONA_REPLAY").replace("root+'/docs/literary-question-geona-spacing-owner-preparation.json.gz'","process.env.KLEM_GEONA_OWNERS")
script=script.replace("createRequire(root+'/web/package.json')","createRequire(process.env.KLEM_DEPENDENCY_ROOT+'/web/package.json')").replace("root+'/data/dictionaries/krdict/krdict.db'","process.env.KLEM_DICTIONARY")
script=script.replace("assert.equal(expected.length,253)","assert.equal(expected.length,116)").replace("form==='을꼬'","form==='을거나'").replace("Literary future question","Self / opinion question").replace("catalog['-을꼬']","catalog['-을거나']").replace("['krdict:81026','krdict:81032']","['krdict:80970','krdict:80972']")
script=script.replace("['누구일꼬','뜰꼬','먹을꼬','갔을꼬']","['삼을거나','좋을거나','어쩔거나','한잔할거나']")
script=script.replace('diagrams.length,38','diagrams.length,16').replace('native.length,153','native.length,241').replace('modeJudgments.length,504','modeJudgments.length,492')
start=script.index("scope:'Actual configured browser:");end=script.index("',cli_sha256",start)
script=script[:start]+"scope:'Actual isolated configured SolidJS browser:2complete source APIs,8original diagrams in both encodings,6exact CLI exports,47boundary and27typed owner cases with241complete Native endpoints. Conditional and Native-policy-only cases retain their individual filter expectations. Informal source register and adjective-note tension are preserved; context, main integration, package/performance and independent review remain separate"+script[end:]
script=script.replace('Passed38 original diagrams,6 exact exports,153 complete Native endpoints,504 finite mode checks and2x253 source API frames.','Passed16 original diagrams,6 exact exports,241 complete Native endpoints,492 finite mode checks and2x116 source API frames.')
Path('/tmp/klem-literary-question-geona-browser.mjs').write_text(script)
print('Prepared actual browser driver; requires newly built CLI and server, not started.')
