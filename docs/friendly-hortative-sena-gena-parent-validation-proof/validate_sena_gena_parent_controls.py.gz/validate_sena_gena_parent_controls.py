"""Check all current and historical proof guards against the combined parent."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path
P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
OUT = P / 'friendly-hortative-sena-gena-parent-controls.json'
LOG = P / 'friendly-hortative-sena-gena-parent-controls.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *a: subprocess.check_output(['git', *a], cwd=W)
assert not git('status', '--porcelain')
source = {name:sha((W/name).read_bytes()) for name in git('ls-files','-z').decode().split('\0')[:-1]}
head = git('rev-parse','HEAD').decode().strip(); index = sha(git('ls-files','--stage','-z'))
before = json.loads((P/'friendly-hortative-sena-before-gena-parent-merge.json').read_bytes())
assert len(before['production_inputs']) == 44 and all(source[n] == h for n,h in before['production_inputs'].items())
binding = json.loads((P/'friendly-hortative-sena-complete-runtime-binding.json').read_bytes())
protected = {row['path']:row['sha256'] for row in binding['binaries'].values()} | binding['protected_parent_binaries']
assert all(sha(Path(p).read_bytes()) == h for p,h in protected.items())
controls = [('test_friendly_hortative_sena_revision.py',31),
            ('test_friendly_hortative_sena_installed_audit.py',46),
            ('test_friendly_command_gena_promoted_installed_audit.py',46),
            ('test_friendly_command_gena_ledger_audit.py',24),
            ('test_friendly_command_gena_ledger_descendant.py',12),
            ('test_friendly_command_historical_gena.py',8),
            ('test_literary_question_geona_runtime.py',112),
            ('test_gentle_command_long_ledger_audit.py',32),
            ('test_gentle_command_ledger_audit.py',26)]
assert sum(n for _,n in controls) == 337
r = dict(state='running',head=head,index_sha256=index,source_inputs=source,
         protected_binaries=protected,results=[],expected_controls=337,
         producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Fresh combined Gena-parent337 controls and715-row queue with exact unchanged44Sena production inputs. Original25Sena cases remain private; Rust/fullNix/promotion/main/quiet/contextual review are separate.')
def save():OUT.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
    with LOG.open('xb') as log:
        commands = [(['python3','-m','unittest','discover','-s','tools','-p',name],count) for name,count in controls]
        commands += [(['python3','tools/review_inventory.py','--verify'],None),(['git','diff','--check'],None)]
        for command,count in commands:
            r['current_command'] = command;save()
            log.write(('COMMAND '+json.dumps(command)+'\n').encode());log.flush()
            job = subprocess.run(command,cwd=W,env=dict(os.environ,KLEM_SENA_BINARY_EVIDENCE='captured',PYTHONDONTWRITEBYTECODE='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            log.write(job.stdout);log.flush()
            r['results'].append(dict(command=command,exit_code=job.returncode,stdout=job.stdout.decode()));save()
            assert job.returncode == 0
            if count is not None:
                assert re.search(rb'Ran '+str(count).encode()+rb' tests? in ',job.stdout) and job.stdout.rstrip().endswith(b'OK')
    r.update(state='passed',controls=337)
except BaseException as error:r.update(state='failed',error=repr(error));raise
finally:
    r.update(source_unchanged=all(sha((W/n).read_bytes()) == h for n,h in source.items()),
             head_unchanged=git('rev-parse','HEAD').decode().strip() == head,
             index_unchanged=sha(git('ls-files','--stage','-z')) == index,
             protected_binaries_unchanged=all(sha(Path(p).read_bytes()) == h for p,h in protected.items()),
             log_sha256=sha(LOG.read_bytes()) if LOG.exists() else None,
             completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['source_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged']):r['state']='failed'
    save()
assert r['state'] == 'passed'
print('Merged parent337 controls and715 queue passed; allSource/HEAD/index/sixbinaries unchanged.',flush=True)
