"""Check portable installed proofs in actual committed Git-selected Nix inputs."""
import datetime
import hashlib
import json
import os
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-command-gena'
OUT = P / 'friendly-command-gena-promoted-portable-selected-source.json'
LOG = P / 'friendly-command-gena-promoted-portable-selected-source.log'
B = Path('/var/tmp/klem-gena-portable-selected-source')
assert not OUT.exists() and not LOG.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *a: subprocess.check_output(['git', *a], cwd=W)
assert not git('status', '--porcelain')
source = {n: sha((W / n).read_bytes()) for n in git('ls-files', '-z').decode().split('\0')[:-1]}
head = git('rev-parse', 'HEAD').decode().strip()
index = sha(git('ls-files', '--stage', '-z'))
package = json.loads((P / 'friendly-command-gena-promoted-nix-packages.json').read_bytes())
protected = package['protected_binaries']
assert all(sha(Path(p).read_bytes()) == h for p, h in protected.items())
prior = json.loads((P / 'friendly-command-gena-promoted-portable-audit-retry1.json').read_bytes())
assert prior['state'] == 'passed' and prior['controls'] == 46 and prior['original33_test_bodies_unchanged']
B.mkdir(exist_ok=True)
env = dict(os.environ, TMPDIR=str(B), PYTHONDONTWRITEBYTECODE='1')
flake = 'git+file://' + str(W)
r = dict(state='running', head=head, index_sha256=index, source_inputs=source,
         protected_binaries=protected, results=[],
         prerequisite_sha256=sha((P / 'friendly-command-gena-promoted-portable-audit-retry1.json').read_bytes()),
         producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Actual Git-selected portable proof and46 controls,715-row queue; compile profiles match completed promoted packages. No full new Nix build or current main integration claim.')
def save(): OUT.write_text(json.dumps(r, indent=2) + '\n')
save()
try:
    with LOG.open('xb') as log:
        def selected(attr, prefix=''):
            command = ['nix', 'eval', '--offline', '--raw', flake + '#' + attr]
            job = subprocess.run(command, cwd=W, env=env, capture_output=True)
            row = dict(command=command, exit_code=job.returncode, stdout=job.stdout.decode(), stderr=job.stderr.decode())
            r['results'].append(row)
            log.write(job.stdout + job.stderr); log.flush(); save()
            assert job.returncode == 0
            root = Path(job.stdout.decode().strip())
            files = {}
            for path in root.rglob('*'):
                assert not path.is_symlink()
                if path.is_file():
                    name = str(path.relative_to(root)); digest = sha(path.read_bytes())
                    assert source[prefix + name] == digest, 'every selected byte matches committed source'
                    files[name] = digest
            return root, files
        selected_root, files = selected('checks.x86_64-linux.inventory-review.src')
        r.update(selected_source=str(selected_root), selected_files=files)
        for name in ['tools/friendly_command_gena_promoted_installed_audit.py',
                     'tools/friendly_command_gena_promoted_streams.py',
                     'tools/test_friendly_command_gena_promoted_installed_audit.py',
                     'docs/friendly-command-gena-promoted-installed-proof-archive.json']:
            assert files[name] == source[name], 'every portable guard and complete archive selected'
        r['profiles'] = {}
        for attr, name, prefix in [('klem', 'klem', ''), ('corpus-adapter', 'klem-corpus-adapter', ''), ('web-assets', 'klem-web-assets', 'web/')]:
            root, current = selected('packages.x86_64-linux.' + attr + '.src', prefix)
            assert current == package['profiles'][name]['files'], 'all completed1146/1146/18 compiled inputs retained'
            r['profiles'][name] = dict(source=str(root), files=current)
        save()
        for command in [['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_friendly_command_gena_promoted_installed_audit.py'],
                        ['python3', 'tools/review_inventory.py', '--verify']]:
            log.write(('COMMAND ' + json.dumps(command) + '\n').encode()); log.flush()
            job = subprocess.run(command, cwd=selected_root, env=env, stdout=log, stderr=subprocess.STDOUT)
            r['results'].append(dict(command=command, exit_code=job.returncode)); save()
            assert job.returncode == 0
        r.update(state='passed', controls=46, executable_replays=0, full_build_replays=0)
except BaseException as error:
    r.update(state='failed', error=repr(error)); raise
finally:
    r.update(source_unchanged=all(sha((W / n).read_bytes()) == h for n, h in source.items()),
             head_unchanged=git('rev-parse', 'HEAD').decode().strip() == head,
             index_unchanged=sha(git('ls-files', '--stage', '-z')) == index,
             protected_binaries_unchanged=all(sha(Path(p).read_bytes()) == h for p, h in protected.items()),
             log_sha256=sha(LOG.read_bytes()) if LOG.exists() else None,
             completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['source_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged']): r['state'] = 'failed'
    save()
assert r['state'] == 'passed'
print('Actual Git-selected portable Gena proof:46 controls and715 inventory rows passed;1146/1146/18 compiled inputs unchanged.', flush=True)
