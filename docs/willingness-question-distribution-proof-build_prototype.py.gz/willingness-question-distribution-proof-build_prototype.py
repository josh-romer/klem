"""Build and bind current prototype CLI/adapter binaries to their frozen source."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

prep = Path(__file__).resolve().parent
work = Path('/tmp/klem-willingness-question-prototype')
target = Path('/tmp/klem-expression-conjectural-main-target')
out = prep / 'prototype-binaries.json'
log = prep / 'prototype-binaries.log'
assert not out.exists() and not log.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [work / 'Cargo.toml', work / 'Cargo.lock', Path(__file__)]
files.extend(p for folder in ['src', 'tests', 'tools', 'web/src'] for p in (work / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
frozen = {str(p): sha(p) for p in files}
env = dict(os.environ, CARGO_TARGET_DIR=str(target), CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='4')
command = ['cargo', 'build', '--locked', '--offline', '--features', 'web', '--bin', 'klem', '--bin', 'klem-corpus-adapter']
receipt = {'state': 'running', 'command': command, 'frozen_inputs': frozen,
           'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip(),
           'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))}}
out.write_text(json.dumps(receipt, indent=2) + '\n')
with log.open('xb') as stream:
    result = subprocess.run(command, env=env, cwd=work, stdout=stream, stderr=subprocess.STDOUT)
receipt.update(state='passed' if result.returncode == 0 else 'failed', exit_code=result.returncode,
               log_sha256=sha(log), inputs_unchanged=all(sha(p) == digest for p, digest in frozen.items()))
receipt['binaries'] = {name: {'path': str(target / 'debug' / name), 'sha256': sha(target / 'debug' / name)} for name in ['klem', 'klem-corpus-adapter']}
out.write_text(json.dumps(receipt, indent=2) + '\n')
assert result.returncode == 0 and receipt['inputs_unchanged']
print('Current source-bound prototype CLI and adapter built')
