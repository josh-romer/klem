"""Compare complete baseline/default/supplemented streams; retain every lexical or spacing delta."""
import gzip,hashlib,itertools,json,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');BEFORE=Path('/nix/store/j4in370si6hf8dv52x2vsxj95grmsnvi-klem-0.1.0/bin/klem');AFTER=Path('/nix/store/ynaf11fjxw2nd1fxxgmsivy017p0ljgi-klem-0.1.0/bin/klem');DB=ROOT/'data/dictionaries/krdict/krdict.db';PRIOR=ROOT/'docs/declarative-dao-broad-final.json.gz';OUT=Path('/tmp/klem-surname-installed-broad.json.gz');assert not OUT.exists()
PARK='ud-ko-kaist:proper-name:park';RULE='spacing.proper_name_title_possession'
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
frozen={str(p):sha(p) for p in [BEFORE,AFTER,DB,PRIOR,Path(__file__)]};previous=json.loads(gzip.decompress(PRIOR.read_bytes()));comparisons=[];observations=[];spacing_additions=[]
key=lambda h:(h.get('rule'),h['spaced'],tuple(h['inserted_at']))

def lexical_delta(old,new,supplemented):
 assert {k:v for k,v in old.items() if k not in ['dictionary','spacing']}=={k:v for k,v in new.items() if k not in ['dictionary','spacing']}
 if not old.get('dictionary'): assert old.get('dictionary')==new.get('dictionary');return False
 a,b=old['dictionary'],new['dictionary']
 assert len(a['readings'])==len(b['readings']) and len(a['lemmas'])==len(b['lemmas'])
 if not supplemented: assert a==b;return False
 changed=False
 for om,nm in zip(a['lemmas'],b['lemmas'],strict=True):
  assert om['lemma']==nm['lemma']
  assert [e for e in nm['entries'] if e['id']!=PARK]==om['entries']
  additions=[e for e in nm['entries'] if e['id']==PARK]
  if additions:
   assert len(additions)==1 and additions[0]['headword']==om['lemma']['text']=='박' and additions[0]['pos']=='PROPN'
   assert additions[0].get('origins') in [None,[]]
   changed=True
 for or_,nr in zip(a['readings'],b['readings'],strict=True):
  assert {k:v for k,v in or_.items() if k!='lemmas'}=={k:v for k,v in nr.items() if k!='lemmas'}
  assert len(or_['lemmas'])==len(nr['lemmas'])
  for os,ns in zip(or_['lemmas'],nr['lemmas'],strict=True):
   assert {k:v for k,v in os.items() if k!='entries'}=={k:v for k,v in ns.items() if k!='entries'}
   assert [e for e in ns['entries'] if e['id']!=PARK]==os['entries']
 return changed

def inspect(old,new,supplemented):
 changed=lexical_delta(old,new,supplemented);new_options=[]
 if not old.get('spacing'): assert old.get('spacing')==new.get('spacing');return changed,new_options
 a,b=old['spacing'],new['spacing'];assert a['rule']==b['rule'] and a['limits']==b['limits']
 oldkeys=[key(h) for h in a['alternatives']]
 assert [key(h) for h in b['alternatives'] if key(h) in oldkeys]==oldkeys
 for h in a['alternatives']:
  nh=next(n for n in b['alternatives'] if key(n)==key(h))
  assert {k:v for k,v in h.items() if k not in ['records','joined_contexts']}=={k:v for k,v in nh.items() if k not in ['records','joined_contexts']}
  for field in ['records','joined_contexts']:
   assert len(h.get(field,[]))==len(nh.get(field,[]))
   for s,t in zip(h.get(field,[]),nh.get(field,[]),strict=True):changed|=lexical_delta(s,t,supplemented)
 for h in b['alternatives']:
  if key(h) in oldkeys:continue
  assert supplemented and h['rule']==RULE
  assert ''.join(s['surface'] for s in h['records'])==new['surface']
  assert h['spaced']==' '.join(s['surface'] for s in h['records'])
  assert any(s.get('entry_witnesses')==[PARK] for s in h['records'])
  assert h['inserted_at']==[s['span']['start'] for s in h['records'][1:]]
  new_options.append(h)
 return changed,new_options

for previous_run in previous['comparisons']:
 source=Path(previous_run['source']);raw=source.read_bytes();assert sha(source)==previous_run['source_sha256'];frozen[str(source)]=sha(source)
 mode=previous_run['mode'];flags=['--dict-compatible'] if 'compatible' in mode else ['--dict-only'] if 'headword' in mode else []
 common=['text',str(source),'--dictionary',str(DB),*flags,*(['--suggest-spacing'] if 'spacing' in mode else [])]
 commands=[[str(BEFORE),*common],[str(AFTER),*common],[str(AFTER),*common,'--proper-names']]
 jobs=[subprocess.Popen(c,stdout=subprocess.PIPE,cwd=ROOT) for c in commands];digests=[hashlib.sha256() for _ in jobs];count=cursor=default_changed=metadata_only=0;changes=[]
 try:
  for lines in itertools.zip_longest(*(p.stdout for p in jobs)):
   assert all(line is not None for line in lines);count+=1
   for h,line in zip(digests,lines,strict=True):h.update(line)
   old,plain,new=[json.loads(line) for line in lines];span=new['span'];assert span['start']==cursor and raw[cursor:span['end']].decode()==new['surface'];cursor=span['end']
   if lines[0]!=lines[1]:default_changed+=1
   default_lexical,default_options=inspect(old,plain,False);assert not default_lexical and not default_options
   lexical,options=inspect(old,new,True)
   if not lexical and not options:
    if lines[0]!=lines[2]:metadata_only+=1
    continue
   left=raw.rfind(b'\n',0,span['start'])+1;right=raw.find(b'\n',span['end']);right=len(raw) if right<0 else right;context=raw[left:right].decode()
   ident=hashlib.sha256(json.dumps([previous_run['source_sha256'],mode,count,new],ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:24]
   record={'id':'proper-name-broad-'+ident,'source':str(source),'source_sha256':previous_run['source_sha256'],'mode':mode,'record':count,'complete_original_line':context,'before':old,'after':new,'lexical_addition':lexical,'contextual_verdict':'unjudged','independent_review':'pending'}
   observations.append(record);changes.append(record['id'])
   for i,h in enumerate(options):spacing_additions.append({'id':record['id']+'-spacing-'+str(i+1),'parent_observation':record['id'],'hypothesis':h,'contextual_verdict':'unjudged'})
  codes=[p.wait() for p in jobs];assert codes==[0,0,0] and count==previous_run['records'] and cursor==len(raw)
  assert digests[0].hexdigest()==previous_run['after_jsonl_sha256'],mode
 finally:
  for job in jobs:
   if job.poll() is None:job.terminate();job.wait()
 comparisons.append({'source':str(source),'source_sha256':sha(source),'mode':mode,'commands':commands,'exit_codes':codes,'records':count,'jsonl_sha256':[h.hexdigest() for h in digests],'default_changed_frames':default_changed,'supplement_metadata_only_frames':metadata_only,'individual_observations':changes})
 print(mode,count,'frames;',default_changed,'default metadata changes;',len(changes),'lexical/spacing observations',flush=True)
assert len(comparisons)==8 and sum(c['records'] for c in comparisons)==1128312
assert len({o['id'] for o in observations})==len(observations) and all(sha(p)==digest for p,digest in frozen.items())
r={'state':'complete-broad-preservation-passed','comparisons':comparisons,'individual_observations':observations,'individual_spacing_additions':spacing_additions,'inputs_unchanged':True,'frozen_inputs':frozen,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'All three complete streams per workload: actual installed DAO baseline, default installed Nix prototype, optional corpus-backed name provider. All words/candidates/native owners/slot judgments/previous spacing options retained; each lexical/spacing change has a stable ID and complete original context. Global supplement source/fingerprint changes are counted separately. Contextual/independent review and main integration remain open.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Complete broad frames1128312;',len(observations),'individual changes;',len(spacing_additions),'new spacing options')
