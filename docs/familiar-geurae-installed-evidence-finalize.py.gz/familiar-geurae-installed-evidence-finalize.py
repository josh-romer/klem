"""Record verified installed behavior and wire its independent audit into Nix."""
import gzip
import json
import re
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
ROOT = BASE / 'familiar-geurae-integration'
PREP = BASE / 'familiar-geurae-prepared'
DOCS = ROOT / 'docs'
text = (PREP / 'installed-controls.log').read_text()
assert 'Ran 24 tests' in text and text.rstrip().endswith('OK')
audit = (PREP / 'installed-audit.log').read_text()
assert "'finite_frames': 1152" in audit and "'policy_decisions': 114" in audit
assert "'full_coverage_complete': False" in audit
for name in ['installed-audit.log', 'installed-controls.log', 'installed-evidence-archive.log']:
    (DOCS / ('familiar-geurae-' + name + '.gz')).write_bytes(gzip.compress((PREP / name).read_bytes(), mtime=0))
batches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (PREP / 'integration-packages.log').read_text())
totals = {name:sum(int(b[i+1]) for b in batches) for i,name in enumerate(['passed','failed','ignored'])}
assert totals == {'passed':1135,'failed':0,'ignored':1} and len(batches) == 244
summary = (
    'All four actual Nix packages pass; the Nix Rust suite records 1,135 passed, '
    'zero failed and one ignored across 244 batches. Installed source/launcher '
    'binding preserves all 1,053 Rust/adapter and 18 frontend files. Complete '
    'installed replay passes 24 finite Unicode/filter/cache streams (1,152 frames), '
    '53,502 saved corpus/history words, 66,570 original annotated rows and '
    '1,128,312 broad frames. The actual Nix launcher passes 114 policy decisions '
    'and diagrams, six exact exports and 50 complete Native entry endpoints; '
    'its owned server stops. The independent installed audit and all 24 corruption '
    'controls pass. Zero new corpus/history paths or gold recoveries are claimed '
    'for this family; earlier outcomes remain exact. The 398 prototype spacing '
    'probe-only changes retain their individual records and exact installed hashes. '
    'Seven audit families are wired into Nix. Complete inventory execution, main '
    'integration, quiet performance and wider/contextual/independent review remain open.')
p = DOCS / 'familiar-geurae-draft.md'
text = p.read_text().replace('Status: isolated source-backed prototype; main integration pending.',
                           'Status: committed source-backed integration; all four actual Nix packages and complete installed checks pass. Main integration remains pending.')
text = text.replace('Nix/installed/main integration, quiet timing', 'Complete inventory execution, main integration, quiet timing')
text = text.replace('Actual Nix packages, installed/source binding and main integration remain pending.', 'Complete Nix inventory execution and main integration remain pending.')
p.write_text(text + '\n' + summary + '\n')
p = DOCS / 'coverage-checklist.md'
text = p.read_text()
start = text.index('- [ ] **COV-017cu')
end = text.index('- [ ] **COV-018', start)
block = text[start:end].replace('Partial: isolated source-backed prototype; main integration pending.',
                              'Partial: committed source-backed integration; Nix packages and installed checks pass.')
block = block.replace('Nix/installed/main integration, quiet timing', 'Complete inventory execution, main integration, quiet timing')
text = text[:start] + block.rstrip() + '\n  ' + summary + '\n\n' + text[end:]
p.write_text(text)
p = DOCS / 'inventory-reviews.json'
reviews = json.loads(p.read_text())
found = 0
for item in reviews['entries']:
    if item['id'] != 'krdict:83913':
        continue
    item['scope'] += ' ' + summary
    item['remaining'] = 'Complete Nix inventory execution, main integration, quiet paired novel timing, wider attachment licenses, contextual homonym selection and independent linguistic review.'
    for name in ['integration-packages.json.gz','installed-source-binding.json.gz',
                 'installed-finite.json.gz','installed-cohorts.json.gz','installed-corpora.json.gz',
                 'installed-broad.json.gz','installed-browser.json.gz','installed-browser-runtime.json.gz',
                 'installed-audit.log.gz','installed-controls.log.gz']:
        path = 'docs/familiar-geurae-' + name
        assert (ROOT / path).exists(), path
        item['evidence'].append({'path':path})
    item['evidence'].extend({'path':'tools/'+name} for name in ['familiar_geurae_installed_audit.py','test_familiar_geurae_installed_audit.py'])
    found += 1
assert found == 1
p.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n')
p = ROOT / 'flake.nix'
text = p.read_text()
files = '                ./tools/familiar_geurae_installed_audit.py\n                ./tools/test_familiar_geurae_installed_audit.py\n'
commands = "            python tools/familiar_geurae_installed_audit.py\n            python -m unittest discover -s tools -p 'test_familiar_geurae_installed_audit.py'\n"
file_marker = '                ./tools/test_familiar_geurae_browser_audit.py\n'
command_marker = "            python -m unittest discover -s tools -p 'test_familiar_geurae_browser_audit.py'\n"
assert text.count(file_marker) == text.count(command_marker) == 1 and 'familiar_geurae_installed_audit.py' not in text
p.write_text(text.replace(file_marker,file_marker+files).replace(command_marker,command_marker+commands))
(DOCS / 'familiar-geurae-installed-evidence-finalize.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('Preserved complete installed validation; actual Nix1135/0/1; updated one bounded review; regenerate queue last')
