"""Run actual sandboxed146 controls against exact current selected and compile inputs."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P=Path(__file__).resolve().parent
W=P.parent/'friendly-hortative-sena'
O=P/'friendly-hortative-sena-sandbox-controls-retry2.json'
L=P/'friendly-hortative-sena-sandbox-controls-retry2.log'
N=P/'friendly-hortative-sena-sandbox-controls.nix'
B=Path('/var/tmp/klem-friendly-hortative-sena-nix-build')
assert not O.exists() and not L.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=W)
assert not git('status','--porcelain')
frozen={n:sha((W/n).read_bytes()) for n in git('ls-files','-z').decode().split('\0')[:-1]}
head,index=git('rev-parse','HEAD').decode().strip(),sha(git('ls-files','--stage','-z'))
B.mkdir(exist_ok=True);B.chmod(0o1777)
env=dict(os.environ,TMPDIR=str(B),PYTHONDONTWRITEBYTECODE='1')
flake='git+file://'+str(W)
source=lambda attr:Path(subprocess.check_output(['nix','eval','--offline','--raw',flake+'#'+attr],cwd=W,env=env,text=True).strip())
def files(src,prefix=''):
    values={}
    for p in src.rglob('*'):
        assert not p.is_symlink()
        if p.is_file():
            name=str(p.relative_to(src));d=sha(p.read_bytes());assert frozen[prefix+name]==d
            values[name]=d
    return values
selected=source('checks.x86_64-linux.inventory-review.src')
selected_files=files(selected)
assert all(n in selected_files for n in ['tools/test_friendly_hortative_sena_binary_evidence.py',
    'tools/friendly_hortative_sena_runtime_audit.py','tools/friendly_hortative_sena_wide_audit.py'])
profiles={}
prior=json.loads((P/'friendly-hortative-sena-wide-selected-source.json').read_bytes())
for attr,prefix in [('klem',''),('corpus-adapter',''),('web-assets','web/')]:
    s=source('packages.x86_64-linux.'+attr+'.src');profiles[attr]=dict(source=str(s),files=files(s,prefix))
    assert profiles[attr]['files']==prior['profiles'][attr]['files'], 'all1158/1158/18 compiled inputs from actual passing1211Rust/139selected Source remain unchanged'
command=['nix','build','--option','build-dir',str(B),'--option','auto-optimise-store','true','--cores','4','--max-jobs','1','--no-link','--json','-L','--impure','--file',str(N)]
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,selected_source=str(selected),selected_files=selected_files,
       profiles=profiles,previous_selected_sha256=sha((P/'friendly-hortative-sena-wide-selected-source.json').read_bytes()),
       command=command,nix_expression=dict(text=N.read_text(),sha256=sha(N.read_bytes())),
       producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
       started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
       scope='Actual Nix sandbox of current Git-selectedSource with all146own/parent Source/runtime/wide/mode controls and715queue. Same1158/1158/18 compile inputs as passed1211Rust/139selected revision. Checks six host executable paths are absent; explicit captured artifact replay/currentSource hashes, no live executable claim. Entire historical inventory/fourpackages/browser/installed/main/performance/context review remain separate.')
def save():O.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
    with L.open('xb') as log:
        job=subprocess.run(command,cwd=W,env=env,stdout=subprocess.PIPE,stderr=log)
    r.update(exit_code=job.returncode,stdout=job.stdout.decode(),state='passed' if job.returncode==0 else 'failed')
    if job.returncode==0:r['outputs']=json.loads(job.stdout)
except BaseException as error:
    r.update(state='failed',error=repr(error));raise
finally:
    text=L.read_text() if L.exists() else ''
    r.update(inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),
             head_unchanged=git('rev-parse','HEAD').decode().strip()==head,
             index_unchanged=sha(git('ls-files','--stage','-z'))==index,
             controls=sum(map(int,re.findall(r'Ran (\d+) tests',text))),
             actual_sandbox_host_executables_absent='Confirmed actual Nix sandbox: all six host executable paths absent.' in text,
             log_sha256=sha(L.read_bytes()) if L.exists() else None,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged','actual_sandbox_host_executables_absent']):r['state']='failed'
    if r['state']=='passed' and r['controls']!=146:r['state']='failed'
    save()
assert r['state']=='passed','Actual sandbox gate failed; complete producer/expression/log/receipt retained.'
print('PassedactualNixsandbox146controls;all six host executables absent;all currentSourceHEADindex/1158compileinputs unchanged.',flush=True)
