"""Validate portable evidence and controls with every current source byte frozen."""
import ast
import datetime
import hashlib
import json
import subprocess
import sys
import unittest
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-command-gena'
OUT = P / 'friendly-command-gena-promoted-portable-audit-retry1.json'
LOG = P / 'friendly-command-gena-promoted-portable-audit-retry1.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *a: subprocess.check_output(['git', *a], cwd=W)
names = set(git('ls-files', '-z').decode().split('\0')) - {''}
names.update(str(p.relative_to(W)) for p in (W / 'docs/friendly-command-gena-promoted-installed-proof').iterdir())
names.update(['docs/friendly-command-gena-promoted-installed-proof-archive.json',
              'tools/friendly_command_gena_promoted_installed_audit.py',
              'tools/friendly_command_gena_promoted_streams.py',
              'tools/test_friendly_command_gena_promoted_installed_audit.py'])
source = {n: sha((W / n).read_bytes()) for n in sorted(names)}
head = git('rev-parse', 'HEAD').decode().strip()
index = sha(git('ls-files', '--stage', '-z'))
package = json.loads((P / 'friendly-command-gena-promoted-nix-packages.json').read_bytes())
protected = package['protected_binaries']
assert all(sha(Path(p).read_bytes()) == h for p, h in protected.items())
sys.path.insert(0, str(W / 'tools'))
import friendly_command_gena_promoted_installed_audit as audit
import test_friendly_command_gena_promoted_installed_audit as controls
def methods(path):
    return {n.name: ast.dump(n, include_attributes=False) for n in ast.walk(ast.parse(path.read_text()))
            if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')}
old = methods(P / 'test_friendly_command_gena_promoted_installed_audit_retry3.py')
current = methods(W / 'tools/test_friendly_command_gena_promoted_installed_audit.py')
assert len(old) == 33 and all(current[k] == v for k, v in old.items()) and len(current) == 46
suite = unittest.defaultTestLoader.loadTestsFromModule(controls)
assert suite.countTestCases() == 46
r = dict(state='running', source_inputs=source, head=head, index_sha256=index,
         protected_binaries=protected, original33_test_bodies_unchanged=True,
         producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Portable archive verification; no executable replays and no main or linguistic completion claim.')
def save(): OUT.write_text(json.dumps(r, indent=2) + '\n')
save()
try:
    with LOG.open('x') as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
        log.flush()
    r.update(controls=result.testsRun, failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped))
    assert result.wasSuccessful() and result.testsRun == 46 and not result.skipped
    r['summary'] = controls.Controls.summary
    command = ['python3', 'tools/review_inventory.py', '--verify']
    job = subprocess.run(command, cwd=W, capture_output=True, text=True)
    r['inventory_check'] = dict(command=command, exit_code=job.returncode, stdout=job.stdout, stderr=job.stderr)
    assert job.returncode == 0
    command = ['git', 'diff', '--check']
    job = subprocess.run(command, cwd=W, capture_output=True, text=True)
    r['diff_check'] = dict(command=command, exit_code=job.returncode, stdout=job.stdout, stderr=job.stderr)
    assert job.returncode == 0
    r['state'] = 'passed'
except BaseException as error:
    r.update(state='failed', error=repr(error))
    raise
finally:
    r.update(source_unchanged=all(sha((W / n).read_bytes()) == h for n, h in source.items()),
             head_unchanged=git('rev-parse', 'HEAD').decode().strip() == head,
             index_unchanged=sha(git('ls-files', '--stage', '-z')) == index,
             protected_binaries_unchanged=all(sha(Path(p).read_bytes()) == h for p, h in protected.items()),
             log_sha256=sha(LOG.read_bytes()) if LOG.exists() else None,
             completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['source_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged']):
        r['state'] = 'failed'
    save()
assert r['state'] == 'passed'
print('Passed46 portable controls and715-row inventory; full current source and protected binaries unchanged.', flush=True)
