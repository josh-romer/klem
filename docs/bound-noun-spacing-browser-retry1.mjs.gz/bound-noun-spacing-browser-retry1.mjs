import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {gunzipSync} from 'node:zlib';
const root=process.env.KLEM_ROOT,url=process.env.KLEM_WEB_URL,cli=process.env.KLEM_BIN,prefix=process.env.KLEM_CAPTURE_PREFIX;
assert.ok(root&&url&&cli&&prefix);
const fixture=JSON.parse(await readFile(process.env.KLEM_BOUND_CASES,'utf8')),cases=fixture.cases;
const owners=JSON.parse(gunzipSync(await readFile(process.env.KLEM_BOUND_NATIVE))).complete_native_entries;
const {chromium}=createRequire(root+'/web/package.json')('playwright');
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH,args:['--no-sandbox']});
const errors=[],exports=[],responses=[],diagrams=[],native=[],contextDiagrams=[];
try {
 const page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});
 page.on('pageerror',error=>errors.push(String(error)));await page.goto(url);
 async function analyze(text) {
  await page.getByLabel('Your sentence',{exact:true}).fill(text);
  const wait=page.waitForResponse(r=>r.url().endsWith('/api/analyze')&&r.request().method()==='POST'&&r.request().postDataJSON().text===text);
  await page.getByRole('button',{name:'Analyze sentence',exact:true}).click();
  const response=await wait;assert.equal(response.status(),200);
  const api=await response.json();await page.waitForFunction(t=>document.querySelector('.sentence')?.textContent===t,text);return api;
 }
 for(const encoding of ['NFC','NFD']) {
  const text=cases.map(c=>c.surface.normalize(encoding)).join(' ');
  let api=await analyze(text);
  if(!await page.getByLabel('Suggest missing spaces').isChecked()) {
   const wait=page.waitForResponse(r=>r.url().endsWith('/api/analyze')&&r.request().postDataJSON()?.suggest_spacing===true);
   await page.getByLabel('Suggest missing spaces').check();const response=await wait;assert.equal(response.status(),200);api=await response.json();
   await page.getByRole('button',{name:'Export JSON',exact:true}).waitFor();
  }
  assert.ok(api.rules['spacing.modifier_bound_noun']);responses.push({encoding,response:api});
  for(const [mode,flag] of [['raw',null],['headword','--dict-only'],['compatible','--dict-compatible']]) {
   if(flag) {await page.getByLabel('Dictionary matches only').check();if(mode==='compatible')await page.getByLabel('Exclude known grammar conflicts').check();else await page.getByLabel('Exclude known grammar conflicts').uncheck();}
   else await page.getByLabel('Dictionary matches only').uncheck();
   const expected=execFileSync(cli,['text','-','--dictionary',process.env.KLEM_DICTIONARY,'--suggest-spacing',...(flag?[flag]:[])],{input:text,encoding:'utf8',maxBuffer:32*1024*1024}).trim().split('\n').map(JSON.parse);
   const wait=page.waitForEvent('download');await page.getByRole('button',{name:'Export JSON',exact:true}).click();
   const exported=JSON.parse(await readFile(await (await wait).path(),'utf8'));assert.deepEqual(exported.records,expected);exports.push({encoding,mode,records:expected});
   const rendered=page.locator('.spacing-hypothesis');
   const allHypotheses=expected.flatMap(r=>r.spacing?.alternatives??[]);
   assert.deepEqual(await rendered.locator('h3').allTextContents(),allHypotheses.map(h=>h.spaced),'all prior and new options retain exact rendered order');
   for(const c of cases) {
    const source=expected.find(r=>r.analysis?.normalized===c.surface);
    const hypotheses=source.spacing.alternatives.filter(h=>h.rule==='spacing.modifier_bound_noun');
    if(!c.required_spaces.length)assert.equal(hypotheses.length,0,c.id);
    for(const spaced of c.required_spaces)assert.ok(hypotheses.some(h=>h.spaced===spaced.normalize(encoding)),c.id);
    for(const hypothesis of hypotheses) {
     const ordinal=allHypotheses.indexOf(hypothesis);assert.ok(ordinal>=0);
     const articles=rendered.nth(ordinal);
     assert.equal(await articles.locator('h3').textContent(),hypothesis.spaced,c.id);
     const region=articles.getByRole('region',{name:'Spacing breakdown for '+hypothesis.spaced,exact:true});
     const displayed=await region.locator('.breakdown-sentence > .breakdown-word > .breakdown-surface > span').allTextContents();
     assert.deepEqual(displayed,hypothesis.records.map(r=>r.surface),c.id);
     assert.equal(await region.locator('.breakdown-unavailable').count(),0,c.id);
     assert.ok(await region.locator('.breakdown-part').count()>=hypothesis.records.length,c.id);
     const details=articles.locator('.auxiliary-spacing-context');
     assert.equal(await details.count(),hypothesis.joined_contexts?.length??0,c.id);
     for(let index=0;index<(hypothesis.joined_contexts?.length??0);index++) {
      const context=hypothesis.joined_contexts[index],detail=details.nth(index);
      if(!await detail.evaluate(el=>el.open))await detail.locator('summary').click();
      const joined=detail.getByRole('region',{name:'Auxiliary relationship for '+hypothesis.spaced,exact:true});
      await joined.waitFor({state:'visible'});
      assert.deepEqual(await joined.locator('.breakdown-sentence > .breakdown-word > .breakdown-surface > span').allTextContents(),[context.surface]);
      assert.equal(await joined.locator('.breakdown-unavailable').count(),0);
      assert.ok(context.span.end<source.span.end);
      contextDiagrams.push({case_id:c.id,encoding,mode,spaced:hypothesis.spaced,context});
     }
     diagrams.push({case_id:c.id,encoding,mode,spaced:hypothesis.spaced,hypothesis,displayed});
    }
   }
  }
 }
 await page.getByLabel('Dictionary matches only').uncheck();
 const single=await analyze('밥을먹어준것은');assert.ok(single.rules.auxiliary&&single.rules['spacing.modifier_bound_noun']);
 const scene=await analyze('먹어준것은 먹어줘볼것은 공부하기때문에');
 assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 await page.locator('.spacing-suggestions').scrollIntoViewIfNeeded();await page.screenshot({path:prefix+'-desktop.png'});
 await page.setViewportSize({width:390,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 await page.locator('.spacing-suggestions').scrollIntoViewIfNeeded();await page.screenshot({path:prefix+'-mobile.png'});
 for(const [id,expected] of Object.entries(owners)) {
  const response=await page.request.post(url+'/api/entry',{data:{id}});assert.equal(response.status(),200);const body=await response.json();assert.deepEqual(body.entry,expected);native.push({id,response:body});
 }
 assert.equal(exports.length,6);assert.equal(native.length,135);assert.ok(diagrams.length>=38*6);assert.ok(contextDiagrams.length>0);assert.deepEqual(errors,[]);
 await writeFile(prefix+'-browser.json',JSON.stringify({state:'passed',producer_sha256:createHash('sha256').update(await readFile(new URL(import.meta.url))).digest('hex'),fixture,responses,exports,diagrams,contextDiagrams,native,single,scene,errors,scope:'Actual isolated SolidJS: every new finite bound-noun split and optional auxiliary context across Unicode/filter modes, six exact CLI exports,135complete Native endpoints, prefix-only metadata and desktop/mobile geometry. Original unmatched proposal remains separate; broader linguistic review and Root/Nix integration pending.'},null,2)+'\n');
 console.log('Passed',diagrams.length,'spacing diagrams,',contextDiagrams.length,'joined-context diagrams,6 exact exports,135 complete Native endpoints.');
} finally {await browser.close();}
