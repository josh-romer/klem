"""Freeze complete dao ending/expression and lexical owners from the source export."""
import copy, gzip, hashlib, json, sqlite3, sys
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
sys.path.insert(0, str(ROOT / 'tools'))
from native_lmf import array, entry, feature, verify_native_lmf

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
source = Path('/tmp/klem-declarative-dao-preparation-complete.json.gz')
prepared = json.loads(gzip.decompress(source.read_bytes()))
db = ROOT / 'data/dictionaries/krdict/krdict.db'
heads = {p['proposed_lemma'] for p in prepared['proposals']}
heads.update(['먹다', '예쁘다', '학생', '이다', '있다', '아니다', '않다', '계시다'])
for run in prepared['baseline_runs'].values():
    for record in run['records']:
        for path in (record.get('analysis') or {}).get('analyses', []):
            heads.update(l['text'] for l in path['lemmas'])
runtime_path = Path('/tmp/klem-declarative-dao-runtime.json.gz')
runtime = json.loads(gzip.decompress(runtime_path.read_bytes()))
for run in runtime['runs']:
    for record in run['records']:
        heads.update(m['lemma']['text'] for m in (record.get('dictionary') or {}).get('lemmas', []) if m['entries'])
native = copy.deepcopy(prepared['complete_native_entries'])
with sqlite3.connect(db.resolve().as_uri() + '?mode=ro', uri=True) as con:
    for head in sorted(heads):
        for ident, raw in con.execute('SELECT id,data FROM entries WHERE headword=?', (head,)):
            value = json.loads(raw)
            assert ident == value['id'] and value['headword'] == head
            native[ident] = value
original, exports = {}, {}
numeric_ids = {i.split(':')[1] for i in native}
for path in sorted((ROOT / 'data/dictionaries/krdict/json').glob('*.json')):
    exports[str(path)] = {'sha256': sha(path), 'bytes': path.stat().st_size}
    for value in array(json.loads(path.read_bytes())['LexicalResource']['Lexicon'].get('LexicalEntry')):
        if value.get('val') not in numeric_ids:
            continue
        projected = entry(value)
        ident = projected['id']
        if ident not in native:
            continue
        assert projected == native[ident] and ident not in original
        original[ident] = value
assert set(original) == set(native)
for ident, value in prepared['complete_native_entries'].items():
    assert native[ident] == value and original[ident] == prepared['original_lmf'][ident]
projection = copy.deepcopy(list(original.values()))
for value in projection:
    for sense in array(value.get('Sense')):
        sense['Equivalent'] = [v for v in array(sense.get('Equivalent')) if feature(v, 'language') == '영어']
lmf = {'LexicalResource': {'Lexicon': {'LexicalEntry': projection}}}
verify_native_lmf(lmf, native)
report = {
    'state': 'complete-dao-source-and-lexical-closure',
    'preparation_sha256': sha(source), 'runtime_sha256': sha(runtime_path), 'dictionary_sha256': sha(db),
    'source_exports': exports, 'heads': sorted(heads),
    'complete_native_entries': native, 'original_lmf': original,
    'english_projection': lmf, 'complete_groups': prepared['complete_groups'],
    'ending_entries': prepared['inventory_entries'],
    'expression_entries': prepared['expression_entries'],
    'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)},
    'scope': 'All six original identities, all 26 complete groups and all same-head lexical owners for the complete baseline text and authored controls. Source preservation does not establish contextual or independent correctness.',
}
Path('/tmp/klem-declarative-dao-native-revision2.json.gz').write_bytes(gzip.compress(
    (json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
fixtures = Path('/tmp/klem-declarative-dao-prototype/tests/fixtures')
for name, value in [('krdict-declarative-dao-english.json', lmf), ('declarative-dao-native.json', native)]:
    (fixtures / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
print({'complete_native_entries': len(native), 'original_source_groups': len(prepared['complete_groups']), 'all_six_identities_preserved': True})
