"""Replay complete frozen workloads with the actual bound Nix CLI and adapter."""
import argparse
import datetime
import gzip
import hashlib
import json
import subprocess
import sys
import traceback
import unicodedata
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('family', choices=['source', 'copula', 'novel', 'cohorts', 'gold', 'broad', 'expression'])
args = parser.parse_args()
PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-expression-conjectural-main')
MAIN = Path('/home/josh/projects/klem')
BINDING = PREP / 'combined-installed-source-binding.json'
OUT = PREP / ('combined-installed-' + args.family + '.json.gz')
PROGRESS = PREP / ('combined-installed-' + args.family + '-progress.json')
DB = MAIN / '.direnv/dictionary-restoration/krdict.db'
assert not OUT.exists() and not PROGRESS.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
file_sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
read = lambda p: json.loads(gzip.decompress(p.read_bytes()) if p.suffix == '.gz' else p.read_bytes())
binding = read(BINDING)
assert binding['state'] == 'passed' and binding['all_tracked_inputs_unchanged']
CLI = Path(binding['profiles']['klem']['package']) / 'bin/klem'
ADAPTER = Path(binding['profiles']['corpus-adapter']['package']) / 'bin/klem-corpus-adapter'
frozen = {str(p): file_sha(p) for p in [BINDING, CLI, ADAPTER, DB, Path(__file__)]}
r = {'state': 'running', 'family': args.family,
     'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'binding_sha256': file_sha(BINDING), 'frozen_inputs': frozen, 'runs': [],
     'producer': {'text': Path(__file__).read_text(), 'sha256': file_sha(Path(__file__))}}
PROGRESS.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')

def reference(relative):
    path = WORK / relative
    frozen[str(path)] = file_sha(path)
    return read(path)

def run(command, data=None):
    job = subprocess.run(command, input=data, cwd=MAIN, capture_output=True)
    assert job.returncode == 0 and not job.stderr, (command, job.returncode, job.stderr.decode())
    return job.stdout

def save():
    PROGRESS.write_text(json.dumps({**r, 'completed_runs': len(r['runs'])}, ensure_ascii=False, indent=2) + '\n')

def flags(mode):
    return ['--dict-compatible'] if 'compatible' in mode else ['--dict-only'] if 'headword' in mode else []

try:
    if args.family in ['source', 'copula', 'novel', 'expression']:
        if args.family == 'source':
            expected = reference('docs/conjectural-additive-phase2-copula-source-streams.json.gz')
            packet = reference('tests/fixtures/conjectural-additive-sources.json')
            suite = reference('tests/fixtures/conjectural-additive-validity.json')
        elif args.family == 'expression':
            expected = reference('docs/formal-volitional-expression-source-streams.json.gz')
            packet = reference('docs/formal-volitional-expression-source-preparation.json.gz')
            suite = reference('tests/fixtures/formal-volitional-expression-validity.json')
        elif args.family == 'copula':
            expected = reference('docs/conjectural-additive-phase2-copula-cli-streams.json.gz')
            packet = reference('tests/fixtures/conjectural-additive-copula-source.json')
        else:
            expected = reference('docs/conjectural-additive-novel-context-prototype-regressions-retry1.json.gz')
            native = WORK / 'tests/fixtures/conjectural-additive-novel-native.json'
            owners = reference('tests/fixtures/conjectural-additive-novel-native-entries.json')
            frozen[str(native)] = file_sha(native)
            native_db = Path('/tmp/klem-combined-installed-novel-native.db')
            assert not native_db.exists()
            # Keep the original fixture's filename because the importer includes
            # it in the attributed manifest/fingerprint. Bytes remain identical.
            imported = PREP / 'installed-native-import' / 'novel-context-native.json'
            imported.parent.mkdir(exist_ok=True)
            assert not imported.exists()
            imported.write_bytes(native.read_bytes())
            frozen[str(imported)] = file_sha(imported)
            run([str(CLI), 'dict', 'import-krdict', str(imported), str(native_db), '--snapshot', 'independent-novel-context-native'])
            for ident, owner in owners.items():
                actual = json.loads(run([str(CLI), 'dict', 'entry', str(native_db), ident]))
                assert actual['entry'] == owner, ('complete original Native importer field', ident)
            frozen[str(native_db)] = file_sha(native_db)
            r['native_owners_exact'] = len(owners)
        for old in expected['runs']:
            if args.family in ['source', 'expression']:
                groups = ['\n'.join(group['complete_original_group']) for group in packet['complete_groups']] if old['family'] == 'complete-original-source' else [case['surface'] for case in (suite['cases'][:16] if args.family == 'source' else suite['cases'])]
                text = ('\n' if old['family'] == 'complete-original-source' else ' ').join(groups)
                text = unicodedata.normalize(old['encoding'], text)
            elif args.family == 'copula':
                text = packet['original_observation']['complete_original_line'] if old['context'] == 'original-complete-line' else '장래려니와'
                text = unicodedata.normalize(old['encoding'], text)
            else:
                text = old['input']
            original = text.encode()
            assert sha(original) == old['input_sha256'], 'complete original input bytes'
            command = [str(CLI), 'text', '-', '--dictionary', str(native_db if args.family == 'novel' else DB), *flags(old['mode']), '--cache-bytes', str(old['cache_bytes'])]
            output = run(command, original)
            assert output.decode() == old['jsonl'] and sha(output) == old['jsonl_sha256'], ('complete actual finite output changed', args.family, old.get('family', old.get('context')), old['encoding'], old['mode'], old['cache_bytes'])
            rows = [json.loads(line) for line in output.splitlines()]
            assert len(rows) == old['records'] and ''.join(row['surface'] for row in rows) == text
            r['runs'].append({'family': old.get('family', old.get('context')), 'encoding': old['encoding'], 'mode': old['mode'], 'cache_bytes': old['cache_bytes'], 'command': command, 'exit_code': 0, 'records': len(rows), 'input_sha256': sha(original), 'stdout_sha256': sha(output), 'reference_stdout_sha256': old['jsonl_sha256'], 'exact_all_output_bytes': True})
            save()
            print(args.family, len(r['runs']), len(rows), 'frames; exact all output bytes', flush=True)
    elif args.family == 'cohorts':
        expected = reference('docs/conjectural-additive-phase2-copula-cohorts.json.gz')
        helper = WORK / 'tools/doeda_native_corpora.py'
        frozen[str(helper)] = file_sha(helper)
        sys.path.insert(0, str(WORK / 'tools'))
        from doeda_native_corpora import words_from_cli
        for cohort in expected['runs']:
            words = cohort['captures'][1]['words']
            actual = words_from_cli(CLI, sorted(words))
            assert actual == words, ('complete original cohort changed', cohort['family'])
            r['runs'].append({'family': cohort['family'], 'binary': str(CLI), 'surfaces': len(words), 'every_original_word_and_path_identical': True, 'actual_words_sha256': sha(json.dumps(actual, ensure_ascii=False, sort_keys=True).encode()), 'reference_words_sha256': sha(json.dumps(words, ensure_ascii=False, sort_keys=True).encode())})
            save()
            print(cohort['family'], len(words), 'exact original words/paths', flush=True)
    elif args.family == 'gold':
        expected = reference('docs/conjectural-additive-phase2-copula-corpora.json.gz')
        for partition in expected['runs']:
            source = MAIN / partition['source']
            assert file_sha(source) == partition['source_sha256']
            frozen[str(source)] = file_sha(source)
            command = [str(ADAPTER), partition['corpus'], partition['source']]
            output = run(command)
            assert output.decode() == partition['jsonl'] and sha(output) == partition['stdout_sha256'], ('every annotated row/summary unchanged', partition['corpus'], partition['partition'])
            assert len(output.splitlines()) == partition['rows'] + 1
            r['runs'].append({'corpus': partition['corpus'], 'partition': partition['partition'], 'source': partition['source'], 'source_sha256': file_sha(source), 'command': command, 'exit_code': 0, 'rows': partition['rows'], 'stdout_sha256': sha(output), 'reference_stdout_sha256': partition['stdout_sha256'], 'every_original_annotated_row_and_summary_identical': True})
            save()
            print(partition['corpus'], partition['partition'], partition['rows'], 'exact original annotated rows', flush=True)
    else:
        expected = reference('docs/conjectural-additive-phase2-copula-broad.json.gz')
        original = reference('docs/reported-deoni-broad-inputs.json.gz')
        folder = PREP / 'installed-broad-inputs'
        folder.mkdir(exist_ok=True)
        for old in expected['runs']:
            raw = original['sources'][old['source']]['text'].encode()
            assert sha(raw) == old['source_sha256']
            source = folder / Path(old['source']).name
            if source.exists(): assert source.read_bytes() == raw
            else: source.write_bytes(raw)
            frozen[str(source)] = file_sha(source)
            command = [str(CLI), 'text', str(source), '--dictionary', str(DB), *flags(old['mode']), *(['--suggest-spacing'] if 'spacing' in old['mode'] else [])]
            digest = hashlib.sha256()
            cursor = records = 0
            changed = {item['record_index']: item['after'] for item in old['changed_frames']}
            with (PREP / ('installed-broad-' + old['mode'] + '.stderr')).open('xb') as errors:
                job = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=errors)
                try:
                    for line in job.stdout:
                        digest.update(line)
                        row = json.loads(line)
                        assert row['span']['start'] == cursor
                        cursor = row['span']['end']
                        assert raw[row['span']['start']:cursor].decode() == row['surface']
                        if records in changed: assert row == changed[records], ('every individually retained broad observation', old['mode'], records)
                        records += 1
                    code = job.wait()
                finally:
                    if job.poll() is None:
                        job.terminate()
                        job.wait()
            assert code == 0 and cursor == len(raw) and records == old['records']
            assert not (PREP / ('installed-broad-' + old['mode'] + '.stderr')).read_bytes()
            assert digest.hexdigest() == old['after_jsonl_sha256'], ('every complete broad output byte unchanged', old['mode'])
            r['runs'].append({'mode': old['mode'], 'source': old['source'], 'actual_source': str(source), 'source_sha256': sha(raw), 'command': command, 'exit_code': code, 'records': records, 'stdout_sha256': digest.hexdigest(), 'reference_stdout_sha256': old['after_jsonl_sha256'], 'original_bytes_conserved': True, 'all_individual_changed_records_exact': len(changed), 'exact_all_output_bytes': True})
            save()
            print(old['mode'], records, 'exact original broad frames', flush=True)
    assert all(file_sha(path) == digest for path, digest in frozen.items())
    r.update(state='passed', exit_code=0, inputs_unchanged=True,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             scope='Actual bound installed Nix CLI/adapter replay; every original input and every complete ordered output equals the independently audited frozen prototype reference. Original gold, candidate judgments and alternatives remain unchanged. This binds installed behavior; it does not certify contextual precision, new dictionary senses, quiet performance or wider/independent review.')
except Exception as error:
    r.update(state='failed', error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
    raise
finally:
    OUT.write_bytes(gzip.compress((json.dumps(r, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
    save()
