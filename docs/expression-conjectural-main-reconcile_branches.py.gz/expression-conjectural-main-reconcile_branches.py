"""Reconcile branch appends without rewriting either historical ledger or source judgment."""
import gzip
import hashlib
import json
import re
import subprocess
from pathlib import Path

WORK = Path('/tmp/klem-expression-conjectural-main')
PREP = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read_branch = lambda rev, filename: subprocess.check_output(['git', 'show', rev + ':' + filename], cwd=WORK)
raw_expression = read_branch('b7a626b', 'tests/fixtures/validity.json')
raw_conjectural = read_branch('0f7a599', 'tests/fixtures/validity.json')
raw_main = read_branch('162e826', 'tests/fixtures/validity.json')
expression, conjectural, main = map(json.loads, [raw_expression, raw_conjectural, raw_main])
assert len(main['cases']) == 35587 and len(expression['cases']) == 35595 and len(conjectural['cases']) == 35643
assert expression['cases'][:35587] == conjectural['cases'][:35587] == main['cases']
appended = conjectural['cases'][35587:]
assert len(appended) == 56
expected = []
for filename in ['conjectural-additive-validity.json', 'conjectural-additive-copula-validity.json', 'conjectural-additive-novel-validity.json']:
    expected.extend(json.loads((WORK / 'tests/fixtures' / filename).read_bytes())['cases'])
assert appended == expected
combined = {**expression, 'cases': expression['cases'] + appended, 'sources': dict(expression['sources'])}
for key, value in conjectural['sources'].items():
    assert key not in combined['sources'] or combined['sources'][key] == value
    combined['sources'][key] = value
raw = (json.dumps(combined, ensure_ascii=False, indent=2) + '\n').encode()
prefix = raw_expression.split(b'"cases": [', 1)[1].rsplit(b'\n  ]\n}', 1)[0]
assert raw.split(b'"cases": [', 1)[1].startswith(prefix)
assert len({c['id'] for c in combined['cases']}) == 35651
counts = {verdict: sum(j['verdict'] == verdict for case in combined['cases'] for j in case['judgments']) for verdict in ['required', 'forbidden']}
assert counts == {'required': 31393, 'forbidden': 4275}
(WORK / 'tests/fixtures/validity.json').write_bytes(raw)
for name, content in [('formal-volitional-expression-validated-private-validity.json.gz', raw_expression), ('conjectural-additive-validated-private-validity.json.gz', raw_conjectural)]:
    path = WORK / 'docs' / name
    assert not path.exists()
    path.write_bytes(gzip.compress(content, mtime=0))
fixture_test = WORK / 'tests/validity.rs'
text = fixture_test.read_text()
text, changed = re.subn(r'<<<<<<< HEAD\n.*?>>>>>>> 0f7a599\n', '    assert_eq!(report.required_total, 31393);\n    assert_eq!(report.forbidden_total, 4275);\n', text, flags=re.S)
assert changed == 1
fixture_test.write_text(text)
tracker = WORK / 'docs/coverage-checklist.md'
text = tracker.read_text()
text, changed = re.subn(r'<<<<<<< HEAD\n(.*?)=======\n.*?>>>>>>> 0f7a599\n', lambda m: m[1], text, flags=re.S)
assert changed == 1
old = '  integrated privately, with two bounded reviews. Whole branch/Nix/main validation remains pending.**'
assert text.count(old) == 1
text = text.replace(old, '  integrated privately, with two bounded reviews; all 15 original novel cases\n  and actual installed validation also pass. Combined/main validation and wider review remain pending.**')
end = text.index('- [ ] **COV-018 —', text.index('- [ ] **COV-017cx —'))
text = text[:end] + '''  Isolated expression/conjectural reconciliation retains the complete original
  35,595-case expression prefix and appends precisely the 56 independently
  authored conjectural Source/copula/novel cases. The new tree contains 35,651
  cases, 31,393 required and 4,275 forbidden judgments, with every prior source
  citation and all 511 original inventory review records retained. Both exact
  historical private ledgers remain archived separately; audits must validate
  those histories and this active combined ledger. Combined Rust, Nix, installed,
  main, performance and wider review are pending.

''' + text[end:]
links = lambda s: set(re.findall(r'\]\(([^)]+)\)', s))
for rev in ['b7a626b', '0f7a599']:
    assert links(read_branch(rev, 'docs/coverage-checklist.md').decode()) <= links(text), ('lost tracker link', rev)
assert len(re.findall(r'\*\*COV-017cw', text)) == len(re.findall(r'\*\*COV-017cx', text)) == 1
tracker.write_text(text)
old_reviews = json.loads(read_branch('b7a626b', 'docs/inventory-reviews.json'))['entries']
new_reviews = json.loads((WORK / 'docs/inventory-reviews.json').read_bytes())['entries']
indexed = {r['id']: r for r in new_reviews}
assert len(old_reviews) == 511 and len(new_reviews) == 513 and all(indexed[r['id']] == r for r in old_reviews)
for name in ['src/grammar.rs', 'src/engine.rs', 'src/dictionary/attachment.rs', 'src/bin/klem-web/grammar_labels.rs', 'web/src/grammar-labels.json']:
    assert (WORK / name).read_bytes() == read_branch('0f7a599', name)
assert (WORK / 'tests/fear_lsera.rs').read_bytes() == read_branch('162e826', 'tests/fear_lsera.rs')
result = {'state': 'combined-ledger-and-tracker-reconciled', 'main_parent_sha256': sha(raw_main),
          'expression_ledger_sha256': sha(raw_expression), 'conjectural_ledger_sha256': sha(raw_conjectural),
          'combined_ledger_sha256': sha(raw), 'expression_prefix_cases': 35595, 'conjectural_append_cases': 56,
          'cases': 35651, 'counts': counts, 'original511reviews_retained': True,
          'all_source_links_retained': True, 'conjectural_runtime_bytes_retained': True,
          'fear_formatting_retained': True,
          'scope': 'Actual isolated reconciliation, not validation of the combined runtime. Historical source judgments, complete serialized expression prefix and all original Source references/manual review fields retained. Whole combined Rust/Nix/installed/main/timing/contextual/independent review remain required.'}
out = PREP / 'reconciliation.json'; assert not out.exists()
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(WORK / 'docs/expression-conjectural-reconciliation.json.gz').write_bytes(gzip.compress(out.read_bytes(), mtime=0))
print(result['state'], counts, 'original history retained', flush=True)
