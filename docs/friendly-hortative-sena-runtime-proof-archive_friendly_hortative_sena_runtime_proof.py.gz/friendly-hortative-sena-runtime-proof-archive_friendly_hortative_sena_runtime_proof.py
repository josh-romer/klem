"""Preserve the actual Source-bound Sena build and all 36 CLI comparisons."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = Path('/home/josh/projects/klem/.direnv/friendly-hortative-sena')
D = W / 'docs'
sha = lambda b: hashlib.sha256(b).hexdigest()
binding = json.loads((P / 'friendly-hortative-sena-complete-runtime-binding.json').read_bytes())
runtime = json.loads((P / 'friendly-hortative-sena-runtime.json').read_bytes())
for r in [binding, runtime]:
    assert r['state'] == 'passed'
    assert all(r[k] for k in ['inputs_unchanged', 'external_inputs_unchanged', 'head_unchanged', 'index_unchanged'])
    assert all(sha((W / name).read_bytes()) == digest for name, digest in r['frozen_inputs'].items())
    assert r['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
    assert r['index_sha256'] == sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=W))
assert all(binding[k] for k in ['parent_production_unchanged', 'protected_parent_binaries_unchanged'])
assert len(binding['production_inputs']) == 44 and len(binding['frontend_inputs']) == 18
assert all(sha(Path(b['path']).read_bytes()) == b['sha256'] for b in binding['binaries'].values())
assert runtime['runs'] == 36 and runtime['frames'] == 1608 and runtime['complete_native_owners'] == 36
assert runtime['old_paths_preserved'] == 2916 and runtime['new_unjudged_paths'] == 716
assert runtime['required_checks'] == 324 and runtime['forbidden_checks'] == 72
assert sha((P / runtime['capture_path']).read_bytes()) == runtime['capture_sha256']
assert sha((P / 'friendly-hortative-sena-runtime.log').read_bytes()) == runtime['log_sha256']
assert sha((P / 'friendly-hortative-sena-complete-runtime-binding.log').read_bytes()) == binding['log_sha256']
files = {}
for name in ['build_friendly_hortative_sena_runtime_binding.py',
             'friendly-hortative-sena-complete-runtime-binding.json',
             'friendly-hortative-sena-complete-runtime-binding.log',
             'capture_friendly_hortative_sena_runtime.py', 'friendly-hortative-sena-runtime.json',
             'friendly-hortative-sena-runtime.log', 'friendly-hortative-sena-runtime-records.json.gz',
             Path(__file__).name]:
    raw = (P / name).read_bytes()
    output = D / ('friendly-hortative-sena-runtime-proof-' + name + '.gz')
    assert not output.exists()
    packed = gzip.compress(raw, mtime=0)
    output.write_bytes(packed)
    files[name] = dict(path=output.name, source_sha256=sha(raw), archive_sha256=sha(packed))
output = D / 'friendly-hortative-sena-runtime-proof-archive.json'
assert not output.exists()
output.write_text(json.dumps(dict(
    state='actual-Sena-Source-bound-debug-build-and36CLIcomparisons-passed', files=files,
    captured_head=runtime['head'], production_inputs=binding['production_inputs'],
    compiled_profiles={k: len(v['files']) for k, v in binding['compiled_profiles'].items()},
    binaries=binding['binaries'], source_groups=5, private_cases=25, required=19, forbidden=6,
    runs=36, frames=1608, full_native_owners=36, old_paths_preserved=2916,
    new_unjudged_paths=716, required_checks=324, forbidden_checks=72,
    all_original_path_assessment_order_and_Native_bytes_retained=True,
    Unicode_and_cache_parity_passed=True, all_source_head_index_parent_binaries_unchanged=True,
    shared_cases_reviews_changed=False,
    independent_runtime_corruption_audit_full_Rust_history_broad_gold_browser_installed_Nix_main_quiet_context_register_independent_review='pending',
    full_coverage_complete=False), indent=2) + '\n')
print('Archived eight full actual runtime/build originals;36policies/1608frames/2916oldpaths/324required72forbidden/36Native/716newunjudgedpaths.', flush=True)
