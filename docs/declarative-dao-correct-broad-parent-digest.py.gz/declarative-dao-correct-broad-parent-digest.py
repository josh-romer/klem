"""Correct the parent-stream digest field independently without rerunning the paired streams."""
import gzip,json,hashlib,subprocess
from pathlib import Path
src=Path('/tmp/klem-declarative-dao-broad-revision2.json.gz');out=Path('/tmp/klem-declarative-dao-broad-final.json.gz');assert not out.exists()
r=json.loads(gzip.decompress(src.read_bytes()))
cli=Path('/nix/store/mfd8vyfqgmcbz0ns6jg05vglkzz7ldi4-klem-0.1.0/bin/klem')
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
assert sha(cli)==r['frozen_inputs'][str(cli)]
command=[str(cli),'text','-'];text='\n'.join(sorted(r['actual_prior_companions']))+'\n'
job=subprocess.run(command,input=text.encode(),capture_output=True,check=True);assert not job.stderr
companions={f['surface']:f['analysis'] for f in map(json.loads,job.stdout.splitlines()) if f.get('analysis')}
assert companions==r['actual_prior_companions']
r['parent_digest_correction']={'original_capture_sha256':sha(src),'original_field':r['parent_stdout_sha256'],'reason':'The capture reused the job variable for independent spacing replay; its original parent_stdout_sha256 field therefore described the later segment stream. This independent earlier-release replay preserves the full captured parent records and replaces only that mislabeled digest.','command':command,'input':text,'stdout_sha256':hashlib.sha256(job.stdout).hexdigest(),'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)}}
r['parent_stdout_sha256']=hashlib.sha256(job.stdout).hexdigest()
out.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Verified all five actual prior parents and corrected only the mislabeled parent digest.')
