"""Independently audit typed original-source streams, the viewer and candidate queue."""
import argparse
import gzip
import hashlib
import json
import sys
import unicodedata
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
sys.path.insert(0, str(ROOT / 'tools'))
import conjectural_additive_source_audit as original

FIXTURE_SHA = '669e3f979cbb6156dfa2444e67272b4cdd24151a276976b6c5cbe9b137acbb06'
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def read(path):
    raw = Path(path).read_bytes()
    return json.loads(gzip.decompress(raw) if str(path).endswith('.gz') else raw)

def inputs(directory):
    return {
        'source': read(directory / 'complete-source-preparation.json'),
        'before': read(directory / 'before-streams.json.gz'),
        'native': read(directory / 'original-native-closure.json.gz'),
        'authoring': read(directory / 'typed-path-preparation.json'),
        'after': read(directory / 'after-streams.json.gz'),
        'queue': read(directory / 'source-candidate-review-queue.json'),
        'browser': read(directory / 'conjectural-additive-closure-retry2-browser.json'),
        'runtime': read(directory / 'conjectural-additive-closure-retry2-browser-runtime.json'),
        'rust': read(directory / 'focused-rust-with-policy.json'),
        'rust_log': (directory / 'focused-rust-with-policy.log').read_text(),
        'checks': read(directory / 'focused-checks.json'),
    }

def matches(path, judgment):
    return ([lemma['text'] for lemma in path['lemmas']] == judgment['lemmas']
            and [lemma['kind'] for lemma in path['lemmas']] == judgment['lemma_kinds']
            and [morph['form'] for morph in path['morphemes']] == judgment['morphemes']
            and [morph['kind'] for morph in path['morphemes']] == judgment['morpheme_kinds']
            and all(rule in path['rules'] for rule in judgment['required_rules']))

def inspect(values):
    source, before, native = (values[key] for key in ['source', 'before', 'native'])
    base = original.inspect(source, before, native)
    assert base['groups'] == 16 and base['proposed_lemma_groups_found'] == 0, 'complete unchanged original preflight'
    author, after, queue = (values[key] for key in ['authoring', 'after', 'queue'])
    assert author['state'] == 'typed-judgments-authored-before-implementation-probe', 'independent preimplementation authoring'
    assert author['fixture_sha256'] == FIXTURE_SHA, 'original authored fixture identity'
    fixture = after['typed_fixture']
    assert sha((json.dumps(fixture, ensure_ascii=False, indent=2) + '\n').encode()) == FIXTURE_SHA, 'every independently authored judgment unchanged'
    assert len(fixture['cases']) == 35, 'all source and constructed boundary cases'
    cases = fixture['cases'][:16]
    assert [(case['surface'], case['judgments'][0]['lemmas']) for case in cases] == original.TARGETS, 'all independent source lexical targets'
    assert [case['id'] for case in cases] == [group['id'] for group in source['complete_groups']], 'original context IDs'
    for record in [author, after, queue, values['checks']]:
        assert sha(record['producer']['text'].encode()) == record['producer']['sha256'], 'producer identity'
    assert after['state'] == 'complete-after-observation-passed' and after['inputs_unchanged'], 'terminal unchanged after capture'
    assert [(r['family'], r['encoding'], r['mode'], r['cache_bytes']) for r in after['runs']] == [(r['family'], r['encoding'], r['mode'], r['cache_bytes']) for r in before['runs']], 'all original24Unicode/filter/cache streams'
    preserved = additions = 0
    canonical_queue = []
    cached = {}
    for old_run, run in zip(before['runs'], after['runs'], strict=True):
        original_groups = ['\n'.join(g['complete_original_group']) for g in source['complete_groups']] if run['family'] == 'complete-original-source' else [case['surface'] for case in cases]
        text = ('\n' if run['family'] == 'complete-original-source' else ' ').join(original_groups)
        raw = unicodedata.normalize(run['encoding'], text).encode()
        assert run['exit_code'] == 0 and run['original_bytes_conserved'], 'successful original byte capture'
        assert run['input_sha256'] == sha(raw), 'complete unchanged source input'
        assert run['jsonl_sha256'] == sha(run['jsonl'].encode()), 'complete actual JSONL capture'
        command = run['command']
        flags = {'raw': [], 'headword': ['--dict-only'], 'compatible': ['--dict-compatible']}[run['mode']]
        assert command[0] in after['frozen_inputs'] and command[1:4] == ['text', '-', '--dictionary'] and command[4] in after['frozen_inputs'] and command[5:] == [*flags, '--cache-bytes', str(run['cache_bytes'])], 'actual filter/cache command'
        old_rows = [json.loads(line) for line in old_run['jsonl'].splitlines()]
        rows = [json.loads(line) for line in run['jsonl'].splitlines()]
        assert len(rows) == len(old_rows) == run['records'], 'complete original frame coverage'
        cursor = old_count = added_count = 0
        for old, row in zip(old_rows, rows, strict=True):
            assert {key: old[key] for key in ['surface', 'span', 'kind']} == {key: row[key] for key in ['surface', 'span', 'kind']}, 'original token identity'
            assert row['span']['start'] == cursor, 'continuous original byte ownership'
            cursor = row['span']['end']
            assert raw[row['span']['start']:cursor].decode() == row['surface'], 'every original UTF8 byte'
            old_paths = (old.get('analysis') or {}).get('analyses', [])
            paths = (row.get('analysis') or {}).get('analyses', [])
            assert all(path in paths for path in old_paths), 'every original candidate retained'
            new_only = [path for path in paths if path not in old_paths]
            assert all('ending.conjectural_additive' in path['rules'] for path in new_only), 'only new family candidate additions'
            old_count += len(old_paths)
            added_count += len(new_only)
        assert cursor == len(raw), 'complete byte stream'
        assert (old_count, added_count) == (run['original_paths_preserved'], run['new_family_paths']), 'exact preserved and added candidate counts'
        preserved += old_count
        additions += added_count
        observed = []
        offset = 0
        for ordinal, (group, case) in enumerate(zip(original_groups, cases, strict=True)):
            group_bytes = unicodedata.normalize(run['encoding'], group).encode()
            target = unicodedata.normalize(run['encoding'], case['surface']).encode()
            position = offset + group_bytes.index(target)
            offset += len(group_bytes) + 1
            index, row = next((i, r) for i, r in enumerate(rows) if r['span']['start'] == position)
            assert row['surface'].encode() == target, 'original occurrence position'
            paths = row['analysis']['analyses']
            indices = [i for i, path in enumerate(paths) if matches(path, case['judgments'][0])]
            assert indices, 'independent typed original path present'
            observed.append({'id': case['id'], 'record_index': index, 'typed_path_indices': indices})
            if (run['family'], run['encoding'], run['mode'], run['cache_bytes']) == ('complete-original-source', 'NFC', 'raw', 0):
                for path_index, path in enumerate(paths):
                    if path in old_rows[index]['analysis']['analyses']:
                        continue
                    digest = sha(json.dumps(path, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())
                    covered = path_index in indices
                    canonical_queue.append({'id': case['id'] + '-candidate-' + digest,
                         'source_case_id': case['id'], 'source_group': source['complete_groups'][ordinal],
                         'surface': row['surface'], 'span': row['span'], 'record_index': index,
                         'analysis_index': path_index, 'analysis': path,
                         'dictionary_reading': row['dictionary']['readings'][path_index],
                         'coverage': 'covered-by-independent-required-path' if covered else 'unjudged-alternative',
                         'independent_judgment': case['judgments'][0] if covered else None,
                         'contextual_sense_verdict': 'unjudged'})
        assert observed == run['observed_typed_paths'], 'independently rederived typed path indices'
        key = (run['family'], run['encoding'], run['mode'])
        assert key not in cached or cached[key] == run['jsonl'], 'exact zero4096cache parity'
        cached[key] = run['jsonl']
    assert (preserved, additions) == (5576, 808), 'complete actual source candidate totals'
    assert queue['state'] == 'complete-original-context-candidate-queue-preserved', 'candidate tracking state'
    assert queue['items'] == canonical_queue and len(canonical_queue) == 61, 'every original-context candidate and Native assessment tracked'
    assert queue['covered_paths'] == 16 and queue['unjudged_alternatives'] == 45, 'no automatic promotion of unjudged alternatives'
    rust, checks = values['rust'], values['checks']
    assert rust['state'] == 'passed' and rust['exit_code'] == 0 and rust['inputs_unchanged'], 'actual focused Rust completion'
    assert 'test result: ok. 6 passed; 0 failed; 0 ignored;' in values['rust_log'], 'all six focused tests completed'
    assert checks['state'] == 'passed' and checks['inputs_unchanged'] and all(run['exit_code'] == 0 for run in checks['runs']), 'actual focused format and Clippy completion'
    assert checks['runs'][0]['command'] == ['cargo', 'fmt', '--all', '--', '--check'], 'actual formatting check'
    assert checks['runs'][1]['command'][-3:] == ['--', '-D', 'warnings'], 'actual warnings-denied Clippy'
    browser, runtime = values['browser'], values['runtime']
    assert runtime['state'] == 'passed' and runtime['exit_code'] == 0 and runtime['inputs_unchanged'] and runtime['server_stopped'], 'actual browser completion and shutdown'
    assert not browser['errors'], 'no browser errors'
    positive = [case for case in fixture['cases'] if case['judgments'][0]['verdict'] == 'required']
    assert len(positive) == 28 and len(browser['policyDecisions']) == len(browser['diagrams']) == 168, 'all browser source and boundary positives'
    assert [(d['encoding'], d['mode'], d['case_id']) for d in browser['policyDecisions']] == [(encoding, mode, case['id']) for encoding in ['NFC', 'NFD'] for mode in ['raw', 'headword', 'compatible'] for case in positive], 'every browser Unicode/filter decision'
    assert [(e['encoding'], e['mode']) for e in browser['exports']] == [(encoding, mode) for encoding in ['NFC', 'NFD'] for mode in ['raw', 'headword', 'compatible']], 'all six actual browser exports'
    assert len(browser['responses']) == 2 and [r['encoding'] for r in browser['responses']] == ['NFC', 'NFD'], 'both actual API captures'
    for decision, diagram in zip(browser['policyDecisions'], browser['diagrams'], strict=True):
        case = next(c for c in positive if c['id'] == decision['case_id'])
        assert decision['allowed'] and str(decision['raw_analysis_index']) in decision['offered_indices'], 'actual authored path available in viewer'
        assert matches(decision['analysis'], case['judgments'][0]), 'exact typed browser candidate'
        api = next(r['api'] for r in browser['responses'] if r['encoding'] == decision['encoding'])
        index = decision['record_index']
        assert api['records'][index]['surface'] == unicodedata.normalize(decision['encoding'], case['surface']), 'actual API original word'
        assert api['records'][index]['analysis']['analyses'][decision['raw_analysis_index']] == decision['analysis'], 'actual API analysis index'
        exported = next(e for e in browser['exports'] if (e['encoding'], e['mode']) == (decision['encoding'], decision['mode']))
        assert decision['analysis'] in exported['records'][index]['analysis']['analyses'], 'actual exported selected path'
        heads = [head[:-1] if kind in ['predicate', 'auxiliary', 'copula'] and head.endswith('다') else head for head, kind in zip(case['judgments'][0]['lemmas'], case['judgments'][0]['lemma_kinds'], strict=True)]
        forms = case['judgments'][0]['morphemes']
        expected = [heads[0], *forms] if len(heads) == 1 else [heads[0], forms[0], heads[1], *forms[1:]] if case['judgments'][0]['lemma_kinds'][1] == 'auxiliary' else [*heads, *forms]
        if len(heads) == 1 and case['judgments'][0]['lemmas'][0].endswith('하다'):
            expected[1] = '여' + expected[1][1:] if expected[1].startswith('어') else '였' + expected[1][1:] if expected[1].startswith('었') else expected[1]
        assert diagram['analysis'] == decision['analysis'] and diagram['forms'] == expected, 'independent displayed component order'
        assert all(str(owner) in diagram['source_hint'] for owner in [86083, 86084]), 'both original ending source links'
    native_endpoints = {record['id']: record['entry'] for record in browser['nativeEntries']}
    assert len(browser['nativeEntries']) == len(native_endpoints) == 34 and native_endpoints == native['complete_imported_entries'], 'every original Native endpoint field'
    return {'state': 'independent-prototype-audit-passed', 'original_groups': 16,
            'source_streams': 24, 'source_frames': 4080, 'typed_source_occurrences': 384,
            'preserved_candidate_occurrences': preserved, 'new_candidate_occurrences': additions,
            'canonical_source_candidates': 61, 'required_source_paths': 16, 'unjudged_source_alternatives': 45,
            'focused_rust': 6, 'browser_decisions': 168, 'browser_diagrams': 168,
            'browser_exports': 6, 'original_native_owners': 34, 'full_coverage_complete': False}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence-dir', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    print(json.dumps(inspect(inputs(args.evidence_dir)), ensure_ascii=False, indent=2))
