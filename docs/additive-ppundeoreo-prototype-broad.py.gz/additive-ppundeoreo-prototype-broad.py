"""Capture complete candidate/novel differentials with original spans and individual whole-connective observations."""
import gzip,hashlib,itertools,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');OLD=Path('/nix/store/cc0wxddigm591zabxi46lli9x8s0kfpd-klem-0.1.0/bin/klem');NEW=Path('/tmp/klem-additive-ppundeoreo-current-cli');DB=ROOT/'data/dictionaries/krdict/krdict.db';PRIOR=ROOT/'docs/literary-question-geona-prototype-broad.json.gz';OUT=Path('/tmp/klem-additive-ppundeoreo-prototype-broad.json.gz');assert not OUT.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prior=json.loads(gzip.decompress(PRIOR.read_bytes()));frozen={str(p):sha(p) for p in [OLD,NEW,DB,PRIOR]};comparisons=[];observations=[];spacing_observations=[]
for previous in prior['comparisons']:
 path=Path(previous['source']);original=path.read_bytes();assert sha(path)==previous['source_sha256'];frozen[str(path)]=sha(path);mode=previous['mode'];flags=['--dict-compatible'] if 'compatible' in mode else ['--dict-only'] if 'headword' in mode else []
 commands=[[str(cli),'text',str(path),'--dictionary',str(DB),*flags,*(['--suggest-spacing'] if 'spacing' in mode else [])] for cli in [OLD,NEW]]
 jobs=[subprocess.Popen(c,stdout=subprocess.PIPE,cwd=ROOT) for c in commands];hashes=[hashlib.sha256(),hashlib.sha256()];count=0;cursor=0;changed=[]
 try:
  for pair in itertools.zip_longest(*(p.stdout for p in jobs)):
   assert all(l is not None for l in pair);count+=1
   for h,line in zip(hashes,pair,strict=True):h.update(line)
   after=json.loads(pair[1]);span=after['span'];assert span['start']==cursor;assert original[span['start']:span['end']].decode()==after['surface'];cursor=span['end']
   if pair[0]==pair[1]:continue
   before=json.loads(pair[0]);assert {k:v for k,v in before.items() if k not in ['analysis','dictionary','spacing']}=={k:v for k,v in after.items() if k not in ['analysis','dictionary','spacing']},(mode,count,'token or spacing metadata')
   b,a=before['analysis'],after['analysis'];assert {k:v for k,v in b.items() if k!='analyses'}=={k:v for k,v in a.items() if k!='analyses'};assert [p for p in a['analyses'] if p in b['analyses']]==b['analyses'];added=[p for p in a['analyses'] if p not in b['analyses']];assert added or before.get('spacing')!=after.get('spacing')
   for i,p in enumerate(b['analyses']):assert before['dictionary']['readings'][i]==after['dictionary']['readings'][a['analyses'].index(p)]
   for row in before['dictionary']['lemmas']:assert row in after['dictionary']['lemmas']
   for key in ['source','fingerprint']:assert before['dictionary'][key]==after['dictionary'][key]
   changed.append({'record':count,'before':before,'after':after});left=original.rfind(b'\n',0,span['start'])+1;right=original.find(b'\n',span['end']);right=len(original) if right<0 else right
   old_spacing,new_spacing=before.get('spacing'),after.get('spacing')
   if old_spacing is not None:
    assert new_spacing is not None
    for key in ['rule','limits']:assert old_spacing[key]==new_spacing[key]
    # Match prior alternatives by their original inserted UTF-8 boundaries.
    # Every former segment candidate and entry assessment retains its order.
    for hypothesis in old_spacing['alternatives']:
     target=next((h for h in new_spacing['alternatives'] if h['inserted_at']==hypothesis['inserted_at'] and h.get('rule')==hypothesis.get('rule')),None);assert target is not None,(mode,count,'lost spacing alternative')
     assert {k:v for k,v in hypothesis.items() if k!='records'}=={k:v for k,v in target.items() if k!='records'}
     for old_segment,new_segment in zip(hypothesis['records'],target['records'],strict=True):
      assert {k:v for k,v in old_segment.items() if k not in ['analysis','dictionary','breakdowns']}=={k:v for k,v in new_segment.items() if k not in ['analysis','dictionary','breakdowns']}
      op,np=old_segment['analysis']['analyses'],new_segment['analysis']['analyses'];assert [p for p in np if p in op]==op
      assert {k:v for k,v in old_segment['analysis'].items() if k!='analyses'}=={k:v for k,v in new_segment['analysis'].items() if k!='analyses'}
      for i,p in enumerate(op):
       at=np.index(p);assert old_segment['dictionary']['readings'][i]==new_segment['dictionary']['readings'][at];assert old_segment['breakdowns'][i]==new_segment['breakdowns'][at]
      assert all(l in new_segment['dictionary']['lemmas'] for l in old_segment['dictionary']['lemmas'])
      for key in ['source','fingerprint']:assert old_segment['dictionary'][key]==new_segment['dictionary'][key]
    if old_spacing!=new_spacing:
     for hypothesis in new_spacing['alternatives']:
      if hypothesis in old_spacing['alternatives']:continue
      ending_paths=[p for segment in hypothesis['records'] for p in segment['analysis']['analyses'] if 'ending.additive_ppundeoreo' in p['rules']];assert ending_paths
      ident=hashlib.sha256(json.dumps([previous['source_sha256'],mode,count,hypothesis],ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:24]
      spacing_observations.append({'id':'additive-ppundeoreo-spacing-'+ident,'source':str(path),'source_sha256':sha(path),'mode':mode,'record':count,'surface':after['surface'],'span':span,'complete_original_line':original[left:right].decode(),'hypothesis':hypothesis,'earlier_alternative':next((h for h in old_spacing['alternatives'] if h['inserted_at']==hypothesis['inserted_at'] and h.get('rule')==hypothesis.get('rule')),None),'source_entries':sorted({ident for p in ending_paths for m in p['morphemes'] for ident in {'을뿐더러':['krdict:74341','krdict:74021']}.get(m['form'],[])}),'structural_verdict':'unjudged spacing composition','contextual_verdict':'unjudged','independent_review':'pending'})
   for candidate in added:
    assert 'ending.additive_ppundeoreo' in candidate['rules'];ident=hashlib.sha256(json.dumps([previous['source_sha256'],mode,count,candidate],ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:24];assessment=after['dictionary']['readings'][a['analyses'].index(candidate)]
    observations.append({'id':'additive-ppundeoreo-broad-'+ident,'source':str(path),'source_sha256':sha(path),'mode':mode,'record':count,'surface':after['surface'],'span':span,'complete_original_line':original[left:right].decode(),'analysis':candidate,'dictionary_assessment':assessment,'source_entries':sorted({ident for morpheme in candidate['morphemes'] for ident in {'을뿐더러':['krdict:74341','krdict:74021']}.get(morpheme['form'],[])}),'structural_verdict':'unjudged broader composition','contextual_verdict':'unjudged','independent_review':'pending'})
  codes=[p.wait() for p in jobs];assert codes==[0,0] and hashes[0].hexdigest()==previous['after_jsonl_sha256'] and count==previous['records'] and cursor==len(original)
 finally:
  for p in jobs:
   if p.poll() is None:p.terminate();p.wait()
 comparisons.append({'source':str(path),'source_sha256':sha(path),'mode':mode,'commands':commands,'exit_codes':codes,'records':count,'before_jsonl_sha256':hashes[0].hexdigest(),'after_jsonl_sha256':hashes[1].hexdigest(),'previous_capture_after_sha256':previous['after_jsonl_sha256'],'baseline_matches_previous_capture':hashes[0].hexdigest()==previous['after_jsonl_sha256'],'changed_frames':changed,'original_bytes_conserved':True,'previous_spacing_suggestions_conserved':True});print(mode,count,'paired frames;',len(changed),'changed records;',len(observations),'whole-connective additions so far',flush=True)
assert len(comparisons)==8 and sum(r['records'] for r in comparisons)==1128312 and all(sha(p)==h for p,h in frozen.items());assert len(observations)==len({o['id'] for o in observations});producer=Path(__file__)
report={'schema_version':1,'preparation_only':True,'state':'prototype-complete-broad-preservation-passed','before_cli_sha256':sha(OLD),'cli_sha256':sha(NEW),'prior_capture_sha256':sha(PRIOR),'comparisons':comparisons,'individual_additions':observations,'individual_spacing_additions':spacing_observations,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':producer.read_text(),'sha256':sha(producer)},'scope':'Every new additive-ending alternative has individual original-line provenance and remains unjudged; no earlier split parent is invented. All eight complete current-baseline/prototype candidate and novel streams. Every prior candidate, native lemma/reading assessment, token span and previous spacing alternative/segment reading retained. New or expanded spacing alternatives have separate complete original-line observations; work-limit counters remain observable. Each broader new path has a stable original-line observation and remains structurally/contextually unjudged; no precision or contextual certification. No timing claims while other builds run.','contextual_verdict':'unjudged','independent_review':'pending'}
OUT.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Complete broad differential:',1128312,'frames;',len(observations),'unjudged word additions;',len(spacing_observations),'unjudged spacing alternatives.',flush=True)
