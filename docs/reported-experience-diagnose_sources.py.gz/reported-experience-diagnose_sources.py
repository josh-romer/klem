"""Replay authored source targets and report exact before/after paths, never infer gold."""
import gzip,hashlib,json,subprocess,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
CLI=ROOT/'.direnv/reported-experience-target/debug/klem';DB=(ROOT/'data/dictionaries/krdict/krdict.db').resolve()
proposals=json.loads(gzip.decompress((OUT/'proposals.json.gz').read_bytes()))['proposals']
frozen={str(p):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in [CLI,DB,OUT/'proposals.json.gz',Path(__file__)]}
checks=[];failures=[]
for p in proposals:
 for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
  command=[str(CLI),'word',p['surface'],'--dictionary',str(DB),*flags]
  after=json.loads(subprocess.check_output(command,text=True));before=p['baseline_records'][mode]
  nfd=json.loads(subprocess.check_output([str(CLI),'word',unicodedata.normalize('NFD',p['surface']),'--dictionary',str(DB),*flags],text=True));assert nfd==after,(p['id'],mode,'NFD parity')
  old=before['analysis']['analyses'];now=after['analyses']
  assert [a for a in now if a in old]==old,(p['id'],mode,'old path order')
  for a in old:assert before['dictionary']['readings'][old.index(a)]==after['dictionary']['readings'][now.index(a)]
  added=[a for a in now if a not in old];assert all('ending.reported_experience' in a['rules'] for a in added)
  intended=[i for i,a in enumerate(now) if [l['text'] for l in a['lemmas']]==p['proposed_lemmas'] and [m['form'] for m in a['morphemes']]==p['proposed_morphemes'] and 'ending.reported_experience' in a['rules']]
  value={'id':p['id'],'surface':p['surface'],'mode':mode,'expected_lemmas':p['proposed_lemmas'],'expected_morphemes':p['proposed_morphemes'],'after':after,'added_paths':added,'intended_indices':intended,'complete_original_group':p['complete_original_group'],'source_tension':p['source_tension']}
  checks.append(value)
  if not intended:
   failures.append(value)
   print('MISSING',p['id'],mode,p['surface'],p['proposed_lemmas'],p['proposed_morphemes'],flush=True)
assert all(hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()==digest for p,digest in frozen.items())
value={'state':'passed' if not failures else 'failed','checks':checks,'failures':failures,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':frozen[str(Path(__file__))]},'scope':'Exact51authored source targets across three modes and NFC/NFD, preserving every baseline path/order/assessment. This diagnostic does not certify contextual readings or full distributions.'}
(OUT/'initial-source-diagnostic.json.gz').write_bytes(gzip.compress((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Source targets',len(proposals),'mode checks',len(checks),'missing',len(failures),flush=True)
raise SystemExit(bool(failures))
