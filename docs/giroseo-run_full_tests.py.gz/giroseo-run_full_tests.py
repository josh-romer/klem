"""Run the complete Rust suite with every selected source file frozen."""
import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
PREP=Path(__file__).resolve().parent;PROTO=PREP.parent/'giroseo-prototype'
LOG=PREP/'full-rust.log';OUT=PREP/'full-rust.json';assert not LOG.exists() and not OUT.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
paths=[PROTO/n for n in ['Cargo.toml','Cargo.lock']]
for folder in ['src','tests','tools','examples']:
 paths.extend(p for p in (PROTO/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
frozen={str(p.relative_to(PROTO)):sha(p) for p in paths}
command=['cargo','test','--locked','--offline','--features','web'];env={**os.environ,'CARGO_TARGET_DIR':str(PREP.parent/'giroseo-target'),'CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_INCREMENTAL':'0'}
r={'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'frozen_source_files':frozen,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Actual entire private Rust suite after48independently authored concessive cases appended; all prior35347cases and full34Native owners preserved. Source/tools/tests/examples/manifests frozen. Debug symbols and incremental output disabled; this is correctness evidence. Nix/installed/integration/contextual review separate.'}
OUT.write_text(json.dumps(r,indent=2)+'\n')
with LOG.open('xb') as stream:job=subprocess.run(command,cwd=PROTO,env=env,stdout=stream,stderr=subprocess.STDOUT)
batches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',LOG.read_text());totals={k:sum(int(b[i+1]) for b in batches) for i,k in enumerate(['passed','failed','ignored'])}
unchanged=all(sha(PROTO/name)==value for name,value in frozen.items())
r.update(state='passed' if job.returncode==0 and totals['failed']==0 and unchanged else 'failed',exit_code=job.returncode,totals=totals,batches=len(batches),inputs_unchanged=unchanged,log_sha256=sha(LOG),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
OUT.write_text(json.dumps(r,indent=2)+'\n');print({k:r[k] for k in ['state','exit_code','totals','batches','inputs_unchanged']},flush=True)
assert unchanged;raise SystemExit(job.returncode)
