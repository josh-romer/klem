import datetime,hashlib,json,re,subprocess
from pathlib import Path
W=Path('/home/josh/projects/klem/.direnv/friendly-command-gena');P=Path(__file__).resolve().parent
O=P/'friendly-command-gena-revision-adapters.json';L=P/'friendly-command-gena-revision-adapters.log';assert not O.exists() and not L.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=W)
names=git('ls-files','--cached','--others','--exclude-standard','-z').decode().split('\0')[:-1]
frozen={str(W/n):sha((W/n).read_bytes()) for n in names};frozen[str(Path(__file__))]=sha(Path(__file__).read_bytes());head=git('rev-parse','HEAD').decode().strip();index=sha(git('ls-files','--stage','-z'))
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),results=[],started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Strict named Source44/five-change and frontend18 adapters. All original historical assertions/captures preserved; unknown edits, missingcompiledJSON/publicassets/borrowedroots rejected. Current Gena source22/runtime48/browser18 and four historical runtime/installed control suites; full current Git-selected Nix/installed/main and shared24 promotion remain separately pending.')
def save():O.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save();patterns=['test_friendly_command_gena_source_audit.py','test_friendly_command_gena_runtime_audit.py','test_friendly_command_gena_browser_audit.py','test_gentle_command_long_runtime_audit.py','test_gentle_command_runtime_audit.py','test_gentle_command_installed_audit.py','test_gentle_command_long_installed_audit.py']
commands=[['python3','-m','unittest','discover','-s','tools','-p',p] for p in patterns]+[['python3','tools/review_inventory.py','--verify'],['git','diff','--check']]
with L.open('xb') as log:
 for c in commands:
  log.write(('COMMAND '+json.dumps(c)+'\n').encode());log.flush();job=subprocess.run(c,cwd=W,capture_output=True);log.write(job.stdout+job.stderr);log.flush();output=(job.stdout+job.stderr).decode();match=re.search(r'Ran (\d+) tests',output);r['results'].append(dict(command=c,exit_code=job.returncode,output=output,controls=int(match.group(1)) if match else 0));save();print(c[-1],job.returncode,r['results'][-1]['controls'],flush=True)
  if job.returncode:break
r.update(inputs_unchanged=all(Path(n).exists() and sha(Path(n).read_bytes())==d for n,d in frozen.items()),head_unchanged=git('rev-parse','HEAD').decode().strip()==head,index_unchanged=sha(git('ls-files','--stage','-z'))==index,controls=sum(x['controls'] for x in r['results']),log_sha256=sha(L.read_bytes()),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());r['state']='passed' if len(r['results'])==len(commands) and all(x['exit_code']==0 for x in r['results']) and all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged']) else 'failed';save();print(r['state'],r['controls'],'actual controls',flush=True);raise SystemExit(0 if r['state']=='passed' else 1)
