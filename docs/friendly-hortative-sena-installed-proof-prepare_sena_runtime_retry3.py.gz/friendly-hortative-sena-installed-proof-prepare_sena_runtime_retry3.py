"""Preserve actual recorder race and serialize recorder writes for parallel fallbacks."""
import ast,gzip,hashlib,json,re
from pathlib import Path
P=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=P/'friendly-hortative-sena-runtime-retry3-preparation.json';assert not manifest.exists()
failed=json.loads(gzip.decompress((P/'friendly-hortative-sena-installed-runtime-retry2.json.gz').read_bytes()));assert failed['state']=='failed'
assert all(failed[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged'])
files={}
def preserve(name):
 raw=(P/name).read_bytes();dest=P/('friendly-hortative-sena-runtime-retry3-original-'+name+'.gz');assert not dest.exists();dest.write_bytes(gzip.compress(raw,mtime=0));files[name]=dict(path=dest.name,source_sha256=sha(raw),archive_sha256=sha(dest.read_bytes()));return raw
names=['capture_friendly_hortative_sena_installed_runtime_retry2.py','run_friendly_hortative_sena_installed_browser_retry2.py','validate_friendly_hortative_sena_installed_audit_retry2.py','friendly_hortative_sena_installed_audit_retry2.py','test_friendly_hortative_sena_installed_audit_retry2.py','continue_sena_installed_validation_retry2.py']
for name in ['friendly-hortative-sena-installed-runtime-retry2.json.gz','friendly-hortative-sena-installed-runtime-progress-retry2.json','friendly-hortative-sena-installed-continuation-retry2.json','friendly-hortative-sena-installed-continuation-retry2.log']+[p.name for p in sorted(P.glob('friendly-hortative-sena-installed-retry2-command-*.gz'))]:preserve(name)
mapping={n:n.replace('_retry2.py','_retry3.py') for n in names};tokens={**mapping,**{n[:-3]:v[:-3] for n,v in mapping.items()}}
pattern=re.compile(r'\b(?:'+'|'.join(re.escape(n) for n in sorted(tokens,key=len,reverse=True))+r')\b');new={}
for name in names:
 raw=preserve(name);text=pattern.sub(lambda m:tokens[m.group()],raw.decode()).replace('installed-runtime-retry2','installed-runtime-retry3').replace('installed-runtime-progress-retry2','installed-runtime-progress-retry3').replace('installed-continuation-retry2','installed-continuation-retry3').replace('installed-retry2-command-','installed-retry3-command-')
 if name=='capture_friendly_hortative_sena_installed_runtime_retry2.py':
  text=text.replace('import datetime,gzip,hashlib,json,os,re,subprocess,sys','import datetime,gzip,hashlib,json,os,re,subprocess,sys,threading')
  assert text.count('def _recorded_run(*args,**kwargs):')==1;text=text.replace('def _recorded_run(*args,**kwargs):','def _recorded_run_inner(*args,**kwargs):')
  needle='subprocess.run=_recorded_run\n';assert text.count(needle)==1
  text=text.replace(needle,'_capture_lock=threading.RLock()\ndef _recorded_run(*args,**kwargs):\n with _capture_lock:return _recorded_run_inner(*args,**kwargs)\n'+needle)
 if name=='test_friendly_hortative_sena_installed_audit_retry2.py':
  assert {n.name:ast.dump(n) for n in ast.walk(ast.parse(raw)) if isinstance(n,ast.FunctionDef)}=={n.name:ast.dump(n) for n in ast.walk(ast.parse(text)) if isinstance(n,ast.FunctionDef)},'all original40 test bodies retained'
 ast.parse(text);dest=P/mapping[name];assert not dest.exists();dest.write_text(text);new[dest.name]=dict(sha256=sha(dest.read_bytes()),bytes=len(dest.read_bytes()))
manifest.write_text(json.dumps(dict(state='prepared-not-executed',originals=files,new_producers=new,source_or_original_captures_mutated=False,full_original40_test_bodies_retained=True,scope='Recorder serializes its own subprocess recording and writes during parallel punctuation fallback. Every actual input/stdout/stderr still preserved. This changes validation orchestration only; no throughput claim.'),indent=2)+'\n')
print('Preserved',len(files),'full originals including partial streams; recorder synchronization added to six new programs.')
