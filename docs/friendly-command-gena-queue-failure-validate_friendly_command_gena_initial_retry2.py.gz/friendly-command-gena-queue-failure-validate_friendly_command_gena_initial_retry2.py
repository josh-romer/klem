import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
PREP=Path(__file__).resolve().parent
WORK=Path('/home/josh/projects/klem/.direnv/friendly-command-gena')
OUT=PREP/'friendly-command-gena-initial-validation-retry2.json';LOG=PREP/'friendly-command-gena-initial-validation-retry2.log'
assert not OUT.exists() and not LOG.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=WORK).decode().split('\0')[:-1]
frozen={n:sha((WORK/n).read_bytes()) for n in names}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip();index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK))
commands=[['cargo','fmt','--all','--','--check'],['cargo','test','--locked','--offline','--features','web'],['cargo','clippy','--locked','--offline','--features','web','--test','friendly_command_gena','--bin','klem-web','--','-D','warnings'],['python3','tools/friendly_command_gena_source_audit.py'],['python3','-m','unittest','discover','-s','tools','-p','test_friendly_command_gena_source_audit.py'],['python3','tools/review_inventory.py','--verify'],['git','diff','--check']]
env=dict(os.environ,CARGO_TARGET_DIR='/home/josh/projects/klem/.direnv/friendly-command-gena-target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',PYTHONDONTWRITEBYTECODE='1')
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),results=[],scope='Actual new independently authored -게나 implementation: full current Rust suite, focusedClippy, source/Native/baseline audit22controls and full715queue. Source/privatejudgments/native fixtures/head/index frozen. Parent35740sharedcasebytes519reviews and alloldfixturesunchanged. CLI/broad/corpus/browser/installed/Nix/main/quiet/context/register/independent review remain separately required; no shared promotion.')
def save():OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
with LOG.open('xb') as stream:
 for command in commands:
  stream.write(('COMMAND '+json.dumps(command)+'\n').encode());stream.flush()
  job=subprocess.run(command,cwd=WORK,env=env,stdout=stream,stderr=subprocess.STDOUT)
  r['results'].append(dict(command=command,exit_code=job.returncode));save();print(command[0],command[1],'exit',job.returncode,flush=True)
  if job.returncode:break
r.update(inputs_unchanged=all(sha((WORK/n).read_bytes())==digest for n,digest in frozen.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK))==index,log_sha256=sha(LOG.read_bytes()),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
batches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',LOG.read_text());r['rust_totals']={key:sum(int(b[i+1]) for b in batches) for i,key in enumerate(['passed','failed','ignored'])};r['rust_batches']=len(batches)
r['controls']=sum(map(int,re.findall(r'Ran (\d+) tests? in',LOG.read_text())))
r['state']='passed' if len(r['results'])==len(commands) and all(x['exit_code']==0 for x in r['results']) and all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged']) and r['rust_totals']==dict(passed=1200,failed=0,ignored=1) and r['controls']==22 else 'failed';save();print(r['state'],r['rust_totals'],r['rust_batches'],'batches;',r['controls'],'controls;',len(frozen),'frozen sources',flush=True);raise SystemExit(0 if r['state']=='passed' else 1)
