import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=Path('/home/josh/projects/klem/.direnv/friendly-command-gena');B=Path('/var/tmp/klem-friendly-command-gena-nix-packages-build')
O=P/'friendly-command-gena-selected-source.json';L=P/'friendly-command-gena-selected-source.log';assert not O.exists() and not L.exists();assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
B.mkdir(exist_ok=True);B.chmod(0o1777);sha=lambda b:hashlib.sha256(b).hexdigest()
files=subprocess.check_output(['git','ls-files','-z'],cwd=W).decode().split('\0')[:-1];frozen={n:sha((W/n).read_bytes()) for n in files};head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))
flake='git+file://'+str(W);env=dict(os.environ,TMPDIR=str(B));source=Path(subprocess.check_output(['nix','eval','--offline','--raw',flake+'#checks.x86_64-linux.inventory-review.src'],cwd=W,env=env,text=True).strip());selected={}
for p in source.rglob('*'):
 assert not p.is_symlink()
 if p.is_file():
  name=str(p.relative_to(source));digest=sha(p.read_bytes());assert digest==frozen[name];selected[name]=digest
profiles={}
for attr,prefix in [('klem',''),('corpus-adapter',''),('web-assets','web/')]:
 src=Path(subprocess.check_output(['nix','eval','--offline','--raw',flake+'#packages.x86_64-linux.'+attr+'.src'],cwd=W,env=env,text=True).strip());values={}
 for p in src.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():
   name=str(p.relative_to(src));digest=sha(p.read_bytes());assert frozen[prefix+name]==digest;values[name]=digest
 profiles[attr]=dict(source=str(src),files=values)
production=json.loads((P/'friendly-command-gena-complete-runtime-binding.json').read_bytes())['production_inputs']
for attr in ['klem','corpus-adapter']:
 assert all(profiles[attr]['files'][p]==d for p,d in production.items()),'all44 current compiled inputs'
assert len(profiles['web-assets']['files'])==18
patterns=['test_friendly_command_gena_source_audit.py','test_friendly_command_gena_runtime_audit.py','test_friendly_command_gena_browser_audit.py','test_gentle_command_long_runtime_audit.py','test_gentle_command_runtime_audit.py','test_gentle_command_installed_audit.py','test_gentle_command_long_installed_audit.py']
commands=[['python3','-m','unittest','discover','-s','tools','-p',p] for p in patterns]+[['python3','tools/review_inventory.py','--verify']]
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,selected_source=str(source),selected_files=selected,profiles=profiles,results=[],producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),scope='Actual Git-backed Nix-selected current Gena sources; every selected input byte plus44 compiled inputs and18 frontend inputs verified; seven current/historical independent audit/control suites run from actual selected store source. No package/installed/main/performance/contextual completion claim.')
def save():O.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
with L.open('xb') as log:
 for c in commands:
  log.write(('COMMAND '+json.dumps(c)+'\n').encode());log.flush();job=subprocess.run(c,cwd=source,capture_output=True);raw=job.stdout+job.stderr;log.write(raw);log.flush();match=re.search(rb'Ran (\d+) tests',raw);r['results'].append(dict(command=c,exit_code=job.returncode,controls=int(match.group(1)) if match else 0));save();print(c[-1],job.returncode,r['results'][-1]['controls'],flush=True)
  if job.returncode:break
r.update(inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==head,index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))==index,controls=sum(x['controls'] for x in r['results']),log_sha256=sha(L.read_bytes()),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());r['state']='passed' if len(r['results'])==len(commands) and all(x['exit_code']==0 for x in r['results']) and all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged']) else 'failed';save();print(r['state'],r['controls'],'actual selected controls',flush=True);raise SystemExit(0 if r['state']=='passed' else 1)
