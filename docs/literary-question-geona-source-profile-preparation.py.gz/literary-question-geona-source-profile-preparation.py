"""Verify complete current source deltas and actual immutable source NARs while installation is pending."""
import datetime,gzip,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from literary_future_kko_sources import package_source_texts
from reported_dana_sources import nar_contents
from reported_deoni_complete_sources import source_store_path
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes());OUT=Path('/tmp/klem-literary-question-geona-source-profile-preparation.json.gz');assert not OUT.exists()
first=ROOT/'docs/literary-question-geona-package-first.json.gz';receipt=read(first);assert receipt['state']=='failed' and receipt['snapshot_unchanged'] is True;baseline_receipt=ROOT/'docs/literary-future-kko-package-nix.json';baseline=package_source_texts(read(baseline_receipt));assert len(baseline)==947;snapshot=receipt['snapshot']['files'];assert len(snapshot)==957;updates={}
for n,v in snapshot.items():
 raw=(ROOT/n).read_bytes();assert sha(raw)==v['sha256'] and len(raw)==v['bytes'],n
 if n not in baseline or baseline[n].encode()!=raw:updates[n]={'before_sha256':sha(baseline[n].encode()) if n in baseline else None,'after_text':raw.decode(),'after_sha256':sha(raw)}
assert len(updates)==17 and sum(n not in baseline for n in updates)==10
current={**baseline,**{n:v['after_text'] for n,v in updates.items()}};assert set(current)==set(snapshot);profiles={};covered=set()
for label in ['klem','web-assets','corpus-adapter']:
 source=Path(receipt['source_profiles'][label]);files={};directories=[];texts={}
 for p in source.rglob('*'):
  assert not p.is_symlink();rel=str(p.relative_to(source))
  if p.is_dir():directories.append(rel);continue
  n='web/'+rel if label=='web-assets' else rel;raw=p.read_bytes();assert raw==current[n].encode() and sha(raw)==snapshot[n]['sha256'];files[rel]={**snapshot[n],'snapshot_path':n,'executable':bool(p.stat().st_mode&0o111)};texts[rel]=current[n];covered.add(n)
 assert len(files)==(18 if label=='web-assets' else 940)
 expected,count=nar_contents(files,sorted(directories),texts);job=subprocess.Popen(['nix-store','--dump',str(source)],stdout=subprocess.PIPE);h=hashlib.sha256();actual_count=0
 while chunk:=job.stdout.read(1024*1024):h.update(chunk);actual_count+=len(chunk)
 assert job.wait()==0 and h.hexdigest()==expected and actual_count==count and source_store_path(expected)==str(source)
 profiles[label]={'source':str(source),'files':files,'directories':sorted(directories),'nar_sha256':expected,'nar_bytes':count,'actual_dump_verified':True};print(label,len(files),'complete source inputs;',count,'independently reconstructed actualNAR bytes.',flush=True)
assert covered==set(snapshot) and all(sha((ROOT/n).read_bytes())==v['sha256'] for n,v in snapshot.items());assert profiles['klem']==profiles['corpus-adapter'];p=Path(__file__);report={'state':'source-preparation-passed-installation-pending','snapshot_files':snapshot,'updates':updates,'profiles':profiles,'parent_inputs':947,'new_inputs':10,'changed_existing_inputs':7,'frozen_reference_sha256':sha(first.read_bytes()),'baseline_receipt_sha256':sha(baseline_receipt.read_bytes()),'current_inputs_unchanged':True,'producer':{'text':p.read_text(),'sha256':sha(p.read_bytes())},'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual complete source-profile preparation only. All957currentinputs reconstruct from the frozen947-input historical release with17exact changes (7updates10newfiles); all3actual source NARs are independently reconstructed and dumped. The first release tests passed but installation failed; retry remains independently running. This does not bind installed binaries, certify package success, or close broad/linguistic/performance coverage.'};OUT.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Complete957-input source preparation passed; installedpackage success remains pending.',flush=True)
