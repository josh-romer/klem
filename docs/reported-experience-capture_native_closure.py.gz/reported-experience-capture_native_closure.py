"""Preserve all complete source and lexical-owner LMF entries without merging homonyms."""
import gzip,hashlib,json,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PROTO=ROOT/'.direnv/reported-experience-prototype'
sys.path.insert(0,str(PROTO/'tools'))
from native_lmf import entry,feature
prepared=json.loads(gzip.decompress((OUT/'source-preparation.json.gz').read_bytes()))
proposals=json.loads(gzip.decompress((OUT/'proposals.json.gz').read_bytes()))['proposals']
heads={l for p in proposals for l in p['proposed_lemmas']}|{'벌다','들이다','좋다','춥다','부르다','학생'}
DB=(ROOT/'data/dictionaries/krdict/krdict.db').resolve()
with sqlite3.connect(DB.as_uri()+'?mode=ro',uri=True) as db:
 expected={ident:json.loads(raw) for ident,raw in db.execute('select id,data from entries where headword in ('+','.join('?' for _ in heads)+')',sorted(heads))}
assert {v['headword'] for v in expected.values()}==heads
expected.update(prepared['complete_imported_entries']);values=dict(prepared['original_native_entries']);needed=set(expected)-set(values);exports={}
for p in sorted((ROOT/'.direnv/dictionary-restoration/2026-09').rglob('*.json')):
 raw=p.read_bytes();selected=[]
 for v in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
  ident='krdict:'+str(v.get('val'))
  if ident not in needed or feature(v,'lexicalUnit') in {'관용구','속담'}:continue
  assert ident not in values and entry(v)==expected[ident]
  values[ident]=v;selected.append(ident)
 if selected:exports[p.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'ids':selected}
assert set(values)==set(expected) and {ident:entry(v) for ident,v in values.items()}==expected
fixture={'LexicalResource':{'Lexicon':{'LexicalEntry':[values[i] for i in sorted(values)]}}}
for name,data in [('reported-experience-native.json',fixture),('reported-experience-native-entries.json',expected)]:
 (PROTO/'tests/fixtures'/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
report={'state':'complete-original-source-and-owner-closure-preserved','entries':expected,'headwords':sorted(heads),'source_exports':exports,'fixture_sha256':hashlib.sha256((PROTO/'tests/fixtures/reported-experience-native.json').read_bytes()).hexdigest(),'producer':{'text':Path(__file__).read_text(),'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},'scope':'All51original source targets and finite novel/allomorph controls retain all exact Native lexical homonyms; ten expression entries remain POS 품사 없음. No contextual sense or lexical POS rewritten.'}
(OUT/'native-closure.json.gz').write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Preserved',len(expected),'complete Native entries across',len(heads),'lexical heads plus ten expression sources',flush=True)
