"""Reconstruct the exact recorded immutable benchmark sources and derivations."""
import datetime
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
PREP = ROOT / '.direnv/reported-experience-prepared'
OUT = PREP / 'paired-package-restoration-retry1.json'
LOG = PREP / 'paired-package-restoration-retry1.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
record = {'state': 'running', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'packages': [], 'initial_benchmark_failure': 'paired-release-performance.log', 'initial_offline_restoration_failure': 'paired-package-restoration.json', 'cached_dependency_substitution_enabled': True,
          'scope': 'Restore the exact recorded formal-to-reported release pair. Historical Git revisions, reconstructed evaluated source files, derivations and output identities must match the original installed bindings before a benchmark retry. No replacement version or narrower workload is permitted.',
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())}}


def save():
    OUT.write_text(json.dumps(record, indent=2) + '\n')


save()
try:
    for family in ['formal-b', 'reported-experience']:
        receipt_path = ROOT / '.direnv' / (family + '-prepared') / 'installed-source-binding.json'
        receipt = json.loads(receipt_path.read_text())
        assert receipt['state'] == 'passed' and receipt['inputs_unchanged'] and receipt['exit_code'] == 0
        profile = receipt['profiles']['klem']
        worktree = ROOT / '.direnv' / (family + '-integration')
        uri = 'git+file://' + str(worktree) + '?rev=' + receipt['head']
        drv_command = ['nix', 'eval', '--offline', '--raw', uri + '#packages.x86_64-linux.klem.drvPath']
        source_command = ['nix', 'eval', '--offline', '--raw', uri + '#packages.x86_64-linux.klem.src']
        derivation = subprocess.check_output(drv_command, text=True, cwd=worktree).strip()
        source = subprocess.check_output(source_command, text=True, cwd=worktree).strip()
        assert derivation == profile['derivation'], ('exact recorded derivation', family, derivation, profile['derivation'])
        assert source == profile['source'], ('exact recorded source', family, source, profile['source'])
        actual_files = {str(p.relative_to(source)): p for p in Path(source).rglob('*') if p.is_file()}
        assert set(actual_files) == set(profile['files']), ('complete recorded source inventory', family)
        for relative, metadata in profile['files'].items():
            raw = actual_files[relative].read_bytes()
            assert len(raw) == metadata['bytes'] and sha(raw) == metadata['sha256'], (family, relative)
        build_dir = Path('/tmp/klem-paired-release-restoration-' + family)
        build_dir.mkdir(exist_ok=True)
        # Keep restored baseline outputs reachable until all measurements finish.
        link = PREP / ('paired-release-' + family)
        command = ['nix', 'build', '--option', 'build-dir', str(build_dir),
                   '--cores', '4', '--max-jobs', '1', '--out-link', str(link), '--print-out-paths', '-L',
                   uri + '#packages.x86_64-linux.klem']
        item = {'family': family, 'head': receipt['head'], 'binding_sha256': sha(receipt_path.read_bytes()),
                'derivation': derivation, 'source': source, 'source_files': len(actual_files),
                'all_original_source_files_exact': True, 'drv_command': drv_command,
                'source_command': source_command, 'build_command': command, 'output': profile['package']}
        record['packages'].append(item)
        save()
        with LOG.open('ab') as log:
            log.write(('Restoring ' + family + '\n').encode())
            result = subprocess.run(command, cwd=worktree, env={**os.environ, 'TMPDIR': str(build_dir)},
                                    stdout=log, stderr=subprocess.STDOUT)
        item['exit_code'] = result.returncode
        save()
        assert result.returncode == 0, ('exact recorded package restoration', family)
        assert link.resolve() == Path(profile['package']) and (link / 'bin/klem').is_file()
        item['cli_sha256'] = sha((link / 'bin/klem').read_bytes())
    record.update(state='passed', exit_code=0, all_original_identities_exact=True)
except BaseException as error:
    record.update(state='failed', error=repr(error))
    raise
finally:
    record['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
print('Restored exact recorded paired release packages and every selected source byte', flush=True)
