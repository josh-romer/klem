"""Run the actual append, old ledger controls, new guards and Rust regressions."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent/'friendly-command-gena'
OUT = P/'friendly-command-gena-promotion-validation.json'
LOG = P/'friendly-command-gena-promotion-validation.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *a: subprocess.check_output(['git',*a],cwd=W)
names = git('ls-files','--cached','--others','--exclude-standard','-z').decode().split('\0')[:-1]
source = {n:sha((W/n).read_bytes()) for n in names}
head = git('rev-parse','HEAD').decode().strip()
index = sha(git('ls-files','--stage','-z'))
binding = json.loads((P.parent/'friendly-hortative-sena-prepared/friendly-hortative-sena-complete-runtime-binding.json').read_bytes())
protected = {b['path']:b['sha256'] for b in binding['binaries'].values()} | binding['protected_parent_binaries']
assert len(protected) == 6 and all(sha(Path(p).read_bytes()) == d for p,d in protected.items())
assert len(json.loads((W/'tests/fixtures/validity.json').read_bytes())['cases']) == 35764
target = P.parent/'friendly-command-gena-promotion-target'
temp = P.parent/'friendly-command-gena-promotion-tmp'
target.mkdir(exist_ok=True);temp.mkdir(exist_ok=True)
env = dict(os.environ,CARGO_TARGET_DIR=str(target),TMPDIR=str(temp),PYTHONDONTWRITEBYTECODE='1')
env.pop('KLEM_GENA_PROMOTION_DRAFT',None);env.pop('KLEM_LONG_PROMOTION_DRAFT',None)
commands = [['cargo','fmt','--all','--','--check'],
            ['cargo','test','--locked','--offline','--features','web','--test','validity','--test','friendly_command_gena'],
            ['cargo','clippy','--locked','--offline','--features','web','--test','validity','--','-D','warnings'],
            ['python3','tools/friendly_command_gena_ledger_audit.py']]
for pattern in ['test_gentle_command_ledger_audit.py','test_gentle_command_long_ledger_audit.py',
                'test_friendly_command_gena_ledger_audit.py','test_friendly_command_gena_ledger_descendant.py']:
    commands.append(['python3','-m','unittest','discover','-s','tools','-p',pattern,'-v'])
commands += [['python3','tools/gentle_command_ledger_audit.py'],['python3','tools/gentle_command_long_ledger_audit.py'],
             ['python3','tools/review_inventory.py','--verify'],['git','diff','--check']]
r = dict(state='running',head=head,index_sha256=index,source_inputs=source,protected_binaries=protected,
         results=[],producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Actual shared35764-case Gena append and520 scoped reviews; original35740 serialized case bytes and519 review fields preserved. Four original/new ledger test suites plus focused Rust validity/privateGena regressions, formatting, warning-denied focused Clippy,715queue anddiff. Allsource/head/index/sixprotecteddebugbinaries frozen. Full Rust/updated compile profiles/full current Nix/installed/main/contextregisterindependent review remain separate.')
def save():
    OUT.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
    with LOG.open('xb') as log:
        for command in commands:
            log.write(('COMMAND '+json.dumps(command)+'\n').encode());log.flush()
            job = subprocess.run(command,cwd=W,env=env,capture_output=True)
            raw = job.stdout+job.stderr;log.write(raw);log.flush()
            count = re.search(rb'Ran (\d+) tests',raw)
            batches = re.findall(rb'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)
            r['results'].append(dict(command=command,exit_code=job.returncode,controls=int(count.group(1)) if count else 0,
                                    rust_passed=sum(int(b[1]) for b in batches),rust_failed=sum(int(b[2]) for b in batches)))
            save()
            assert job.returncode == 0
    r.update(state='passed',controls=sum(row['controls'] for row in r['results']),
             rust_passed=sum(row['rust_passed'] for row in r['results']))
    assert r['controls'] == 94 and r['rust_passed'] == 15 and len(r['results']) == 12
except BaseException as error:
    r.update(state='failed',error=repr(error))
    raise
finally:
    r.update(inputs_unchanged=all(sha((W/p).read_bytes()) == d for p,d in source.items()),
             head_unchanged=git('rev-parse','HEAD').decode().strip() == head,
             index_unchanged=sha(git('ls-files','--stage','-z')) == index,
             protected_binaries_unchanged=all(sha(Path(p).read_bytes()) == d for p,d in protected.items()),
             log_sha256=sha(LOG.read_bytes()) if LOG.exists() else None,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged']):
        r['state'] = 'failed'
    save()
assert r['state'] == 'passed'
print('Passed actual Gena promotion:15 Rust regressions,94 ledger controls,fmt/Clippy/715queue/diff; all protected source/binaries unchanged.',flush=True)
