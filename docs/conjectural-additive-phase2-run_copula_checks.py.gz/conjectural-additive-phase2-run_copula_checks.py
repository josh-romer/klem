"""Check formatting and Clippy for the prototype library, both CLIs and regression."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
PROTO = PREP.parent / 'conjectural-additive-copula-prototype'
OUT = PREP / 'copula-checks.json'
assert not OUT.exists()
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
frozen = {str(p.relative_to(PROTO)): sha(p) for p in PROTO.rglob('*') if p.is_file()}
env = {**os.environ, 'CARGO_TARGET_DIR': '/tmp/klem-conjectural-additive-copula-target',
       'CARGO_BUILD_JOBS': '4', 'CARGO_PROFILE_DEV_DEBUG': '0',
       'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_INCREMENTAL': '0'}
commands = [
    ['cargo', 'fmt', '--all', '--', '--check'],
    ['cargo', 'clippy', '--locked', '--offline', '--features', 'web',
     '--bin', 'klem', '--bin', 'klem-web', '--test', 'conjectural_additive', '--test', 'conjectural_additive_copula', '--', '-D', 'warnings'],
]
runs = []
for number, command in enumerate(commands):
    log = PREP / f'copula-check-{number}.log'
    assert not log.exists()
    with log.open('xb') as stream:
        job = subprocess.run(command, cwd=PROTO, env=env, stdout=stream, stderr=subprocess.STDOUT)
    runs.append({'command': command, 'exit_code': job.returncode, 'log': log.read_text(), 'log_sha256': sha(log)})
unchanged = all(sha(PROTO / name) == digest for name, digest in frozen.items())
receipt = {'state': 'passed' if all(r['exit_code'] == 0 for r in runs) and unchanged else 'failed',
           'runs': runs, 'frozen_files': frozen, 'inputs_unchanged': unchanged,
           'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
           'scope': 'Formatting of the entire minimal prototype and focused library/both CLI/regression Clippy with warnings denied. This is not the full inherited Rust or all-target Clippy suite.'}
OUT.write_text(json.dumps(receipt, indent=2) + '\n')
print(receipt['state'], [r['exit_code'] for r in runs], len(frozen), 'inputs unchanged', unchanged, flush=True)
raise SystemExit(0 if receipt['state'] == 'passed' else 1)
