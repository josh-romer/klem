"""Capture merged main format, family/ledger tests and all-target Clippy."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = PREP.parents[1]
OUT = PREP / 'main-focused-validation.json'
assert not OUT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
binding = json.loads((PREP / 'installed-source-binding.json').read_text())
files = {str(ROOT / field['snapshot_path']) for profile in binding['profiles'].values() for field in profile['files'].values()}
files.add(str(ROOT / 'tests/fixtures/formal-volitional-expression-validity.json'))
files.add(str(Path(__file__)))
frozen = {path: sha(path) for path in sorted(files)}
commands = [['cargo', 'fmt', '--all', '--', '--check'],
            ['cargo', 'test', '--locked', '--offline', '--features', 'web', '--test', 'formal_volitional', '--test', 'formal_volitional_novel', '--test', 'validity'],
            ['cargo', 'clippy', '--locked', '--offline', '--all-targets', '--features', 'web', '--', '-D', 'warnings']]
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/klem-apprehensive-main-target',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='4')
report = {'state': 'running', 'pid': os.getpid(), 'frozen_inputs': frozen, 'runs': [],
          'scope': 'Actual prepared main formal merge; every tested Rust/frontend/adapter source plus the retained expression fixture frozen. Formal source/novel and complete ledger tests, whole formatting and all-target warnings-denied Clippy; whole mainRust/Nix/source/inventory/timing remain separate.'}
OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
for ordinal, command in enumerate(commands):
    log = PREP / f'main-focused-validation-{ordinal}.log'
    assert not log.exists()
    with log.open('wb') as handle:
        code = subprocess.run(command, cwd=ROOT, env=env, stdout=handle, stderr=subprocess.STDOUT).returncode
    report['runs'].append({'command': command, 'exit_code': code, 'log_sha256': sha(log)})
    report['inputs_unchanged'] = all(sha(path) == digest for path, digest in frozen.items())
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(command, code, 'source unchanged', report['inputs_unchanged'], flush=True)
    if code or not report['inputs_unchanged']:
        report['state'] = 'failed'
        OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
        raise SystemExit(code or 1)
report['state'] = 'passed'
report['producer'] = {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))}
OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
