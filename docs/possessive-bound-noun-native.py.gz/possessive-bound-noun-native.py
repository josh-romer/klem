"""Retain original source groups and complete same-head owners for nominal boundaries."""
import copy,gzip,hashlib,json,sqlite3,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from native_lmf import array,entry,feature,verify_native_lmf
previous_path=ROOT/'docs/bound-noun-spacing-native-closure.json.gz';previous=json.load(gzip.open(previous_path,'rt'));db=ROOT/'data/dictionaries/krdict/krdict.db';con=sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True)
heads=['것','때문','나','너','저','내','네','제','누구','우리','언니','친구','동생','할머니','선생님','박','건강','날씨','아이','학교','아버지','가족','학생','지식인','사람','공부','이것','그것','저것','이','그','집','돈'];native=copy.deepcopy(previous['complete_native_entries'])
for head in heads:
 for ident,raw in con.execute('select id,data from entries where headword=?',(head,)):native[ident]=json.loads(raw)
original={};exports={};ids={i.split(':')[1] for i in native};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p in sorted((ROOT/'data/dictionaries/krdict/json').glob('*.json')):
 exports[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
 for value in array(json.loads(p.read_bytes())['LexicalResource']['Lexicon'].get('LexicalEntry')):
  if value.get('val') not in ids:continue
  projected=entry(value);ident=projected['id']
  if ident not in native:continue
  assert projected==native[ident] and ident not in original;original[ident]=value
assert set(original)==set(native)
assert all(native[i]==e and original[i]==previous['original_lmf'][i] for i,e in previous['complete_native_entries'].items())
projection=copy.deepcopy(list(original.values()))
for value in projection:
 for sense in array(value.get('Sense')):sense['Equivalent']=[v for v in array(sense.get('Equivalent')) if feature(v,'language')=='영어']
lmf={'LexicalResource':{'Lexicon':{'LexicalEntry':projection}}};verify_native_lmf(lmf,native)
source_groups=[]
for ident,senses in [('krdict:62835',['3']),('krdict:64555',['1'])]:
 e=native[ident]
 for sense in e['senses']:
  if sense['id'] in senses:source_groups.append({'entry_id':ident,'headword':e['headword'],'sense':copy.deepcopy(sense),'source_url':e['url'],'independent_review':'pending','scope':'Complete original groups, including multi-turn and multiword owner phrases. Authored transformations and runtime proposals remain separate.'})
r={'state':'preparation-source-closure-passed','heads':heads,'previous_entries':135,'complete_native_entries':native,'original_lmf':original,'english_projection':lmf,'source_groups':source_groups,'source_exports':exports,'dictionary_sha256':sha(db),'previous_closure_sha256':sha(previous_path),'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Complete nominal/possessive owner closure, all old135entries unchanged. All original possession/cause groups retained without clipping examples. Runtime/library/main/Nix/contextual correctness remain separate.'}
p=Path('/tmp/klem-possessive-bound-noun-native.json.gz');assert not p.exists();p.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));p=Path('/tmp/klem-possessive-bound-noun-prototype/tests/fixtures/possessive-bound-noun-native.json');assert not p.exists();p.write_text(json.dumps(lmf,ensure_ascii=False,indent=2)+'\n');print('Retained',len(native),'complete entries and',len(source_groups),'unabridged source groups.')
