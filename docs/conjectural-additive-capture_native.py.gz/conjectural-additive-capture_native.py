"""Retain original Native owners for all source predicates, auxiliaries and copula homonyms."""
import gzip
import hashlib
import json
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
SOURCE = OUT / 'complete-source-preparation.json'
RESULT = OUT / 'original-native-closure.json.gz'
assert not RESULT.exists()
sys.path.insert(0, str(ROOT / 'tools'))
from native_lmf import entry, feature

sha = lambda raw: hashlib.sha256(raw).hexdigest()
packet = json.loads(SOURCE.read_bytes())
expected = dict(packet['source_entries'])
for owners in packet['complete_lexical_entries'].values():
    for owner in owners:
        if owner['lexical_unit'] == '단어':
            expected[owner['id']] = owner
originals = {}
exports = {}
for path in sorted((ROOT / '.direnv/dictionary-restoration/2026-09').glob('*.json')):
    raw = path.read_bytes()
    selected = []
    for value in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
        ident = 'krdict:' + value['val']
        if ident not in expected or feature(value, 'lexicalUnit') in {'관용구', '속담'}:
            continue
        assert ident not in originals and entry(value) == expected[ident], ident
        originals[ident] = value
        selected.append(ident)
    exports[path.name] = {'bytes': len(raw), 'sha256': sha(raw), 'ids': selected}
    print(path.name, len(selected), 'complete original owners selected', flush=True)
assert len(exports) == 11 and set(originals) == set(expected)
assert {ident: entry(value) for ident, value in originals.items()} == expected
for name, value in [('native.json', {'LexicalResource': {'Lexicon': {'LexicalEntry': list(originals.values())}}}),
                    ('native-entries.json', expected)]:
    path = OUT / name
    assert not path.exists()
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
result = {'state': 'complete-original-native-owner-closure-preserved',
          'source_preparation_sha256': sha(SOURCE.read_bytes()),
          'original_native_entries': originals, 'complete_imported_entries': expected,
          'original_exports': exports, 'owners': len(originals),
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())},
          'scope': 'Original Native fields for two conjectural/intention ending owners and every word homonym of independently proposed lexical targets. All11original exports hashed; idiom/proverb records with reused baseIDs are excluded without dropping any word homonym. Every Python projection equals the pinned original dictionary entry. Rust Native importer/library/browser/typed-path integration and linguistic review remain pending.'}
RESULT.write_bytes(gzip.compress((json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
print('Preserved', len(originals), 'complete original Native owners and exact fixture/projection.')
