"""Run source-backed focused Sena regressions without touching frozen parents."""
import datetime,gzip,hashlib,json,os,re,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=Path('/home/josh/projects/klem');W=ROOT/'.direnv/friendly-hortative-sena';G=ROOT/'.direnv/friendly-command-gena'
O=P/'friendly-hortative-sena-focused-validation.json';L=P/'friendly-hortative-sena-focused-validation.log';assert not O.exists() and not L.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
parent=json.loads((ROOT/'.direnv/willingness-question-prepared/friendly-command-gena-nix-packages.json').read_bytes());assert parent['state']=='passed'
changes={'src/grammar.rs','src/engine.rs','src/dictionary/attachment.rs','src/bin/klem-web/grammar_labels.rs','web/src/grammar-labels.json'}
assert set(subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True).splitlines())==changes
assert all(sha((W/name).read_bytes())==digest for name,digest in parent['frozen_inputs'].items() if name not in changes)
assert all(sha((G/name).read_bytes())==digest for name,digest in parent['frozen_inputs'].items())
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=W).decode().split('\0')[:-1];frozen={name:sha((W/name).read_bytes()) for name in names}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W));assert head==parent['head']
binding=json.loads((ROOT/'.direnv/willingness-question-prepared/friendly-command-gena-complete-runtime-binding.json').read_bytes())
protected={v['path']:v['sha256'] for v in binding['binaries'].values()};assert all(sha(Path(path).read_bytes())==digest for path,digest in protected.items())
external={str(Path(__file__)):sha(Path(__file__).read_bytes())}
env=dict(os.environ,CARGO_TARGET_DIR=str(ROOT/'.direnv/friendly-hortative-sena-target'),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4')
commands=[['cargo','fmt','--all','--','--check'],['cargo','test','--locked','--offline','--features','web','--test','friendly_hortative_sena','--test','friendly_command_gena'],['cargo','test','--locked','--offline','--features','web','--bin','klem-web','grammar_labels'],['cargo','clippy','--locked','--offline','--features','web','--test','friendly_hortative_sena','--bin','klem-web','--','-D','warnings'],['git','diff','--check']]
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,external_inputs=external,protected_parent_binaries=protected,unchanged_parent_inputs=parent['frozen_inputs'],declared_production_changes=sorted(changes),producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),results=[],scope='Actual isolatedSena focused25preauthoredcases/36completeNative owners/63ordered old word records/Rieul restoration ambiguity/ownadjectivehomonyms andUnknownprefinals, plus all8parentGena regressions/backendSourcegrammarlabels/fmt/Clippy. Independentcurrentinstalled baseline36policies1608frames/zero canonical andrequiredlexical matches preserved. All6985Gena parentSource remainsfrozen and unchanged whileownSource snapshots freeze. No changes to shared35740cases/519reviews/gold; fullRust/history/broad/corpora/browser/installed/Nix/main/quiet/contextregister/independentreview required separately.')
def save():O.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
with L.open('xb') as log:
 for command in commands:
  log.write(('COMMAND '+json.dumps(command)+'\n').encode());log.flush();job=subprocess.run(command,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT);r['results'].append(dict(command=command,exit_code=job.returncode));save();print(command[0],command[1],'exit',job.returncode,flush=True)
  if job.returncode:break
r.update(inputs_unchanged=all(sha((W/name).read_bytes())==digest for name,digest in frozen.items()),external_inputs_unchanged=all(sha(Path(path).read_bytes())==digest for path,digest in external.items()),protected_parent_binaries_unchanged=all(sha(Path(path).read_bytes())==digest for path,digest in protected.items()),gena_parent_inputs_unchanged=all(sha((G/name).read_bytes())==digest for name,digest in parent['frozen_inputs'].items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==head,index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))==index,log_sha256=sha(L.read_bytes()),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
batches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',L.read_text());r['rust_totals']={key:sum(int(b[i+1]) for b in batches) for i,key in enumerate(['passed','failed','ignored'])};r['rust_batches']=len(batches)
r['state']='passed' if len(r['results'])==len(commands) and all(x['exit_code']==0 for x in r['results']) and r['rust_totals']['failed']==0 and all(r[k] for k in ['inputs_unchanged','external_inputs_unchanged','protected_parent_binaries_unchanged','gena_parent_inputs_unchanged','head_unchanged','index_unchanged']) else 'failed';save();print(r['state'],r['rust_totals'],'focusedonly;',len(frozen),'frozenSourcefiles',flush=True);raise SystemExit(0 if r['state']=='passed' else 1)
