import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {gunzipSync} from 'node:zlib';
const root='/home/josh/projects/klem',proto='/tmp/klem-literary-future-kko-prototype';
const url=process.env.KLEM_WEB_URL,cli=process.env.KLEM_BIN,prefix=process.env.KLEM_CAPTURE_PREFIX;
assert.ok(url&&cli&&prefix);
const json=async p=>JSON.parse(await readFile(p));
const gz=async p=>JSON.parse(gunzipSync(await readFile(p)));
const hash=async p=>createHash('sha256').update(await readFile(p)).digest('hex');
const cases=await json(proto+'/tests/fixtures/literary-future-kko-original-cases.json');
const boundaries=(await json(proto+'/tests/fixtures/literary-future-kko-authored-boundaries.json')).cases;
const source=await gz('/tmp/klem-literary-future-kko-source-discovery.json.gz');
const replay=await gz('/tmp/klem-literary-future-kko-prototype-source-replay.json.gz');
const owners=(await gz('/tmp/klem-literary-future-kko-boundary-owner-preparation.json.gz')).complete_native_entries;
const catalog=await json(proto+'/web/src/grammar-labels.json');
const match=(a,c)=>JSON.stringify(a.lemmas.map(l=>l.text))===JSON.stringify(c.lemmas)
 &&JSON.stringify(a.lemmas.map(l=>l.kind))===JSON.stringify(c.lemma_kinds)
 &&JSON.stringify(a.morphemes.map(m=>m.form))===JSON.stringify(c.morphemes)
 &&JSON.stringify(a.morphemes.map(m=>m.kind))===JSON.stringify(c.morpheme_kinds)
 &&c.required_rules.every(r=>a.rules.includes(r));
const {chromium}=createRequire(root+'/web/package.json')('playwright');
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH,args:['--no-sandbox']});
try {
 const page=await browser.newPage({viewport:{width:1440,height:1000}});await page.goto(url);
 const words=['누구일꼬','뜰꼬','먹을꼬','갔을꼬'];
 await page.getByLabel('Your sentence',{exact:true}).fill(words.join(' '));
 const wait=page.waitForResponse(r=>r.url().endsWith('/api/analyze'));
 await page.getByRole('button',{name:'Analyze sentence',exact:true}).click();
 const response=await wait;assert.equal(response.status(),200);const api=await response.json();
 await page.waitForFunction(()=>document.querySelectorAll('.breakdown-word').length===4);
 for(const word of words) {
  const c=cases.find(c=>c.surface===word),r=api.records.find(r=>r.analysis?.normalized===word),at=r.analysis.analyses.findIndex(a=>match(a,c.expected));assert.ok(at>=0);
  const card=page.getByRole('region',{name:'Sentence breakdown',exact:true}).locator('.breakdown-word').filter({has:page.locator('.breakdown-surface > span',{hasText:new RegExp('^'+word+'$')})});await card.locator('select').selectOption(String(at));
  assert.ok((await card.locator('.part-gloss').allTextContents()).includes('Literary future question'));
 }
 const region=page.getByRole('region',{name:'Sentence breakdown',exact:true});
 await page.evaluate(async()=>{await document.fonts.ready;});await region.evaluate(el=>el.scrollIntoView({behavior:'instant',block:'start'}));
 assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:prefix+'-desktop.png'});
 await page.setViewportSize({width:390,height:844});await region.evaluate(el=>el.scrollIntoView({behavior:'instant',block:'start'}));
 assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:prefix+'-mobile.png'});
 await writeFile(prefix+'-browser.json',JSON.stringify({scope:'Readable viewport follow-up only, separate from the completed38-diagram/396-mode full browser proof. Both viewport widths fit; four source readings selected and labelled. Dictionary glosses remain ambiguous hints, with no semantic sense selection.',api,cli_sha256:await hash(cli),producer_sha256:await hash(new URL(import.meta.url)),catalog_sha256:await hash(proto+'/web/src/grammar-labels.json')},null,2)+'\n');
 console.log('Readable desktop/mobile viewport checks passed.');
} finally { await browser.close(); }
