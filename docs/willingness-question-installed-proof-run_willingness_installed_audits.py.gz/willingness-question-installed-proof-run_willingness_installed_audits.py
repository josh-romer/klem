"""Capture independent installed audit and corruption controls without refreshing references."""
import argparse
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
out = args.output
assert not out.exists()
prep = Path(__file__).resolve().parent
root = Path('/tmp/klem-willingness-question-prototype')
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')[:-1]
files = [root / name for name in tracked]
files += [p for p in prep.iterdir() if p.is_file() and not p.name.startswith('willingness-installed-pipeline') and (p.name.startswith('willingness-installed-') or p.name.startswith('willingness-selected-inventory-'))]
files += [prep / name for name in ['willingness_question_installed_audit.py', 'test_willingness_question_installed_audit.py', 'run_willingness_installed_browser.py', 'replay_willingness_installed.py', Path(__file__).name]]
frozen = {str(p): sha(p) for p in files}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
index = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=root)).hexdigest()
env = dict(os.environ, PYTHONPATH=str(prep) + ':' + str(root / 'tools'), KLEM_WILLINGNESS_INSTALLED_PROOFS=str(prep))
r = {'state': 'running', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'head': head, 'index_sha256': index, 'frozen_inputs': frozen, 'runs': [],
     'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)},
     'scope': 'Independent installed binding/workload/importer/browser checks and deliberate evidence corruptions. Original baselines and all source bytes remain unchanged; contextual precision, full Nix and current-main review stay separate.'}
out.write_text(json.dumps(r, indent=2) + '\n')
try:
    commands = [['python3', str(prep / 'willingness_question_installed_audit.py'), '--prepared', str(prep)],
                ['python3', '-m', 'unittest', 'discover', '-s', str(prep), '-p', 'test_willingness_question_installed_audit.py']]
    for i, command in enumerate(commands):
        log = Path(str(out.with_suffix('')) + '-' + str(i) + '.log')
        assert not log.exists()
        with log.open('xb') as stream:
            job = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
        raw = log.read_bytes()
        controls = None
        if i == 1 and job.returncode == 0:
            counts = re.findall(rb'Ran (\d+) tests? in ', raw)
            assert len(counts) == 1 and raw.rstrip().endswith(b'OK')
            controls = int(counts[0]); assert controls == 44
        r['runs'].append({'command': command, 'exit_code': job.returncode, 'log': str(log), 'log_sha256': sha(log), 'controls': controls})
        out.write_text(json.dumps(r, indent=2) + '\n')
        assert job.returncode == 0, ('installed audit failed', i, str(log))
    r.update(state='passed', exit_code=0, controls=44)
except Exception as error:
    r.update(state='failed', error=str(error))
    raise
finally:
    r.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             inputs_unchanged=all(sha(p) == digest for p, digest in frozen.items()),
             head_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == head,
             index_unchanged=hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=root)).hexdigest() == index)
    out.write_text(json.dumps(r, indent=2) + '\n')
assert r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged']
print('Complete installed willingness audit and 44 controls passed; every captured input unchanged', flush=True)
