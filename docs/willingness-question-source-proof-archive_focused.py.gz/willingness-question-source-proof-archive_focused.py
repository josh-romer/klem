"""Preserve source authoring, baseline, importer and focused prototype evidence."""
import gzip
import hashlib
import json
import re
from pathlib import Path

prep = Path(__file__).resolve().parent
work = Path('/tmp/klem-willingness-question-prototype')
out = prep / 'prototype-source-focused-archive.json'
assert not out.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
receipt = json.loads((prep / 'prototype-focused-retry1.json').read_bytes())
assert receipt['state'] == 'passed' and receipt['inputs_unchanged']
assert all(sha(Path(path).read_bytes()) == digest for path, digest in receipt['frozen_inputs'].items())
passed = 0
for command in receipt['commands']:
    log = Path(command['log']).read_bytes()
    assert command['exit_code'] == 0 and sha(log) == command['log_sha256']
    batches = re.findall(rb'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    assert all(b[0] == b'ok' and b[2] == b'0' for b in batches)
    passed += sum(int(b[1]) for b in batches)
assert passed == 46 and len(receipt['commands']) == 5
names = [
    'independent-source-authoring.json', 'author_original_targets.py',
    'initial-preparation-failures.json', 'original-installed-baseline.json.gz',
    'probe_baseline.py', 'original-native-closure.json.gz', 'capture_native.py',
    'native-import-verification.json', 'verify_native_import.py',
    'supplemental-pos-native-closure.json.gz', 'capture_pos_boundary.py',
    'prototype-preparation.json', 'prepare_prototype.py',
    'prototype-initial-suite-schema.json', 'prototype-suite-schema-correction.json',
    'initial-raw-class-assumption-test.rs', 'initial-raw-class-assumption-failure.json',
    'expanded-verification-corrections.json', 'prototype-focused.json',
    'prototype-focused-retry1.json', 'run_focused.py', 'run_focused_retry1.py',
    Path(__file__).name,
]
names += ['prototype-focused-' + str(i) + '.log' for i in range(4)]
names += ['prototype-focused-retry1-' + str(i) + '.log' for i in range(5)]
artifacts = []
for name in names:
    raw = (prep / name).read_bytes()
    target = work / 'docs' / ('willingness-question-source-proof-' + name + ('' if name.endswith('.gz') else '.gz'))
    assert not target.exists()
    target.write_bytes(raw if name.endswith('.gz') else gzip.compress(raw, mtime=0))
    artifacts.append({'path': str(target.relative_to(work)), 'original_sha256': sha(raw),
                      'archive_sha256': sha(target.read_bytes())})
summary = {'state': 'bounded-source-implementation-and-focused-proof-preserved',
           'artifacts': artifacts, 'focused_tests_passed': passed,
           'all_target_clippy_passed': True, 'format_passed': True,
           'original_source_owners': 4, 'original_groups': 18,
           'required_ending_cases': 10, 'boundary_cases': 12,
           'complete_original_native_owners': 29, 'supplemental_pos_owners': 1,
           'baseline_streams': 24, 'baseline_lexical_targets_present': 18,
           'baseline_exact_ending_targets_present': 0,
           'full_coverage_complete': False,
           'scope': 'Isolated source implementation. Original lexical hypotheses and complete groups/owners remain intact. Original source/schema/raw-class/expanded-test/Clippy issues are retained. Catalog test retry fixes a zero-match filter; that first filter proves no inventory coverage. Ledger and inventory integration, broader interactions, corpus/novel/full Rust/Nix/installed/browser/performance/main and independent/contextual review remain open.'}
out.write_text(json.dumps(summary, indent=2) + '\n')
(work / 'docs/willingness-question-source-focused-archive.json.gz').write_bytes(gzip.compress(out.read_bytes(), mtime=0))
print('Preserved', len(artifacts), 'proof artifacts;', passed, 'focused tests')
