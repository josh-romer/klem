"""Preserve complete original entries and author lexical targets before baseline probes."""
import gzip
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
PREP = BASE / 'formal-volitional-prepared'
sys.path.insert(0, '/home/josh/projects/klem/tools')
from native_lmf import entry, feature

sha = lambda raw: hashlib.sha256(raw).hexdigest()
database = BASE / 'dictionary-restoration/krdict.db'
db = sqlite3.connect(database.resolve().as_uri() + '?mode=ro', uri=True)
source_ids = ['krdict:86548', 'krdict:86549', 'krdict:86604', 'krdict:86605']
owners = {ident: json.loads(db.execute('select data from entries where id=?', (ident,)).fetchone()[0]) for ident in source_ids}
# Every target is manually selected from the complete original source groups.
# No engine output is read while constructing this proposal.
targets = [
    ('가져가시렵니까', '가져가다', ['시']), ('하렵니까', '하다', []),
    ('않으시렵니까', '않다', ['시']), ('보시렵니까', '보다', ['시']),
    ('떠나렵니다', '떠나다', []), ('주렵니다', '주다', []), ('보렵니다', '보다', []),
    ('살렵니다', '살다', []), ('모시렵니다', '모시다', []),
    ('받으렵니까', '받다', []), ('읽으렵니까', '읽다', []),
    ('찍으렵니까', '찍다', []), ('씻으렵니까', '씻다', []),
    ('찾으렵니다', '찾다', []), ('받으렵니다', '받다', []),
    ('않으렵니다', '않다', []), ('지으렵니다', '짓다', []),
]
groups = []
for ident, owner in owners.items():
    assert owner['id'] == ident and owner['pos'] == '어미'
    for sense in owner['senses']:
        for ordinal, lines in enumerate(sense['examples'], 1):
            groups.append({'id': f'formal-volitional-{ident.split(":")[1]}-sense-{sense["id"]}-group-{ordinal}',
                           'source_entry_id': ident, 'source_headword': owner['headword'], 'sense_id': sense['id'],
                           'group_ordinal': ordinal - 1, 'complete_original_group': lines,
                           'source_notes': owner['notes'], 'sense_notes': sense['notes'], 'definition': sense['definition']})
assert len(groups) == len(targets) == 17
proposals = []
for group, (surface, lemma, prefinals) in zip(groups, targets, strict=True):
    raw = '\n'.join(group['complete_original_group']).encode()
    assert raw.count(surface.encode()) == 1, group['id']
    proposals.append({'id': group['id'], 'surface': surface, 'surface_byte_offset': raw.index(surface.encode()),
                      'source_entry_id': group['source_entry_id'], 'sense_id': group['sense_id'],
                      'complete_original_group': group['complete_original_group'], 'proposed_lemmas': [lemma],
                      'proposed_lemma_kinds': ['predicate'], 'proposed_morphemes': [*prefinals, '으렵니까' if group['source_headword'].endswith('니까') else '으렵니다'],
                      'proposed_morpheme_kinds': ['prefinal'] * len(prefinals) + ['ending'],
                      'proposed_required_rules': ['ending.formal_volitional'],
                      'scope': 'Independent structural target in complete original context; Original statement/question owners and their short/full attachment notes remain separate. Canonical 으렵니다/으렵니까 represent their respective allomorph pairs. No candidate or contextual homonym sense is certified.'})
needed = set(owners)
lexical_heads = {lemma for _, lemma, _ in targets} | {'이다', '아니다'}
for headword in lexical_heads:
    for ident, raw in db.execute('select id,data from entries where headword=?', (headword,)):
        value = json.loads(raw)
        if value['lexical_unit'] == '단어':
            needed.add(ident)
expected = {ident: json.loads(db.execute('select data from entries where id=?', (ident,)).fetchone()[0]) for ident in sorted(needed)}
originals, exports = {}, {}
for path in sorted((BASE / 'dictionary-restoration/2026-09').glob('*.json')):
    raw = path.read_bytes()
    selected = []
    for value in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
        ident = 'krdict:' + value['val']
        if ident not in needed or feature(value, 'lexicalUnit') in {'관용구', '속담'}:
            continue
        assert ident not in originals and entry(value) == expected[ident], ident
        originals[ident] = value
        selected.append(ident)
    if selected:
        exports[path.name] = {'bytes': len(raw), 'sha256': sha(raw), 'ids': selected}
assert set(originals) == needed and all(entry(value) == expected[ident] for ident, value in originals.items())
producer = {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())}
prepared = {'state': 'complete-original-sources-and-independent-proposals-before-baseline',
            'expression_entries': owners, 'complete_groups': groups,
            'complete_source_text': '\n'.join(line for group in groups for line in group['complete_original_group']),
            'complete_imported_entries': expected, 'original_native_entries': originals,
            'original_exports': exports, 'dictionary_metadata': dict(db.execute('select key,value from metadata')),
            'independent_proposals': proposals, 'producer': producer,
            'scope': 'All four original ending entries, every sense, all 17 complete groups, original attachment notes and full Native lexical homonyms preserved before any baseline probe or implementation. Wider examples, boundary judgments, implementation/corpus/browser/Nix/performance/integration and independent linguistic review remain.'}
path = PREP / 'source-preparation.json.gz'
assert not path.exists()
path.write_bytes(gzip.compress((json.dumps(prepared, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
(PREP / 'independent-source-proposals.json').write_text(json.dumps({'state': 'authored-before-baseline-and-implementation',
            'source_preparation_sha256': sha(path.read_bytes()), 'proposals': proposals, 'producer': producer}, ensure_ascii=False, indent=2) + '\n')
print('Preserved four ending identities, 17 complete groups, 17 independent targets and', len(originals), 'full Native owners before baseline observation', flush=True)
