"""Run the complete Rust suite with every selected source file frozen."""
import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
PREP=Path(__file__).resolve().parent;PROTO=PREP.parent/'formal-volitional-expression-integration'
LOG=PREP/'full-rust.log';OUT=PREP/'full-rust.json';assert not LOG.exists() and not OUT.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
paths=[PROTO/n for n in ['Cargo.toml','Cargo.lock','web/src/grammar-labels.json']]
for folder in ['src','tests','tools','examples']:
 for source in (PROTO/folder).rglob('*.rs'):
  for relative in re.findall(r'include_(?:str|bytes)!\(\s*"([^"]+)"',source.read_text()):
   selected=(source.parent/relative).resolve()
   if selected not in paths:paths.append(selected)
for folder in ['src','tests','tools','examples']:
 paths.extend(p for p in (PROTO/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
frozen={str(p.relative_to(PROTO)):sha(p) for p in paths}
command=['cargo','test','--locked','--offline','--features','web'];env={**os.environ,'CARGO_TARGET_DIR':'/tmp/klem-formal-expression-target','CARGO_BUILD_JOBS':'4','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_INCREMENTAL':'0'}
r={'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'frozen_source_files':frozen,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Actual complete1150parent Rust suite plus three original-expression regressions after only eight independently authored cases append to exact35587prefix. Original59ending judgments, raw53/fournovel cases and all16Native owners preserved. Seven focusedRust/Clippy and48browser decisions/diagrams/sixexports/16Native plus88historical/6parent-ledger/8expression-ledger/11Source/6streams/19browser/10inventorycontrols pass. Application/label/attachment code unchanged. Four expression audits wired into Nix. Allmanifest/source/test/tool/example/literal include inputs frozen; dedicated/tmp target, no prior referenceCLI or gateworktree rebuilt. All expression runtime/browser captures terminal/passed before starting. Nix/installed/main/distribution/timing/contextual/independentreview and separate expression dispositions remain required.'}
OUT.write_text(json.dumps(r,indent=2)+'\n')
with LOG.open('xb') as stream:job=subprocess.run(command,cwd=PROTO,env=env,stdout=stream,stderr=subprocess.STDOUT)
batches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',LOG.read_text());totals={k:sum(int(b[i+1]) for b in batches) for i,k in enumerate(['passed','failed','ignored'])}
unchanged=all(sha(PROTO/name)==value for name,value in frozen.items())
r.update(state='passed' if job.returncode==0 and totals['failed']==0 and unchanged else 'failed',exit_code=job.returncode,totals=totals,batches=len(batches),inputs_unchanged=unchanged,log_sha256=sha(LOG),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
OUT.write_text(json.dumps(r,indent=2)+'\n');print({k:r[k] for k in ['state','exit_code','totals','batches','inputs_unchanged']},flush=True)
assert unchanged;raise SystemExit(job.returncode)
