let
  flake = builtins.getFlake "git+file:///home/josh/projects/klem/.direnv/friendly-command-gena";
  pkgs = flake.inputs.nixpkgs.legacyPackages.x86_64-linux;
in pkgs.runCommand "klem-gena-completed-evidence-sandbox" {
  src = flake.checks.x86_64-linux.inventory-review.src;
  nativeBuildInputs = [ pkgs.python3 ];
} ''
  cp -r $src/. .
  export PYTHONDONTWRITEBYTECODE=1
  export KLEM_GENA_PROMOTION_DRAFT=1
  python - <<'PY'
  import sys
  from pathlib import Path
  sys.path.insert(0,'tools')
  import friendly_command_gena_performance_audit as audit
  v = audit.inputs()
  paths = {str(Path(p) if Path(p).is_absolute() else audit.CAPTURE_ROOT/p)
           for p in v['report']['frozen_inputs']}
  paths.update(row['path'] for row in v['values']['friendly-command-gena-installed-runtime.json.gz']['binaries'].values())
  paths.update(row['path'] for row in v['values']['friendly-command-gena-complete-runtime-binding.json']['binaries'].values())
  assert len(paths) == 19 and all(not Path(p).exists() for p in paths), 'actual Nix sandbox must not expose captured host executables, dictionary, book or prepared receipts'
  assert v['binary_evidence']['live_executable_files_verified'] is False
  assert v['original_input_evidence'] == dict(mode='archived',live_non_executable_files_verified=False)
  print('Confirmed actual Nix sandbox: all19 captured host paths absent; archive evidence only.')
  PY
  python tools/friendly_command_gena_installed_audit.py
  python -m unittest discover -s tools -p 'test_friendly_command_gena_installed_audit.py'
  python tools/friendly_command_gena_performance_audit.py
  python -m unittest discover -s tools -p 'test_friendly_command_gena_performance_audit.py'
  python tools/friendly_command_gena_ledger_audit.py --draft
  python -m unittest discover -s tools -p 'test_friendly_command_gena_ledger_audit.py'
  python tools/review_inventory.py --verify
  mkdir -p $out
  printf '%s\n' 'Actual Nix sandbox: installed28/timing29/draft24 controls and715queue passed; all19 captured host paths absent. Original captured release/CLI/browser/timing evidence retained. Current shared35740cases519reviews unchanged. Main/shared promotion/context/register/independent review and full checklist completion remain separate.' > $out/scope.txt
''
