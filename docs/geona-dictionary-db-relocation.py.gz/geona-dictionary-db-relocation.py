import hashlib,json,os,shutil,sqlite3
from pathlib import Path
source=Path('/home/josh/projects/klem/data/dictionaries/krdict/krdict.db');target=Path('/tmp/klem-geona-retained-dictionary.db');old=source.with_name('krdict.db.klem-geona-retained-original');out=Path('/tmp/klem-geona-dictionary-db-relocation.json');assert source.is_file() and not source.is_symlink() and not target.exists() and not old.exists() and not out.exists()
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();digest=sha(source);size=source.stat().st_size;assert not source.with_name(source.name+'-wal').exists();shutil.copy2(source,target);assert sha(target)==sha(source)==digest
with sqlite3.connect(target.as_uri()+'?mode=ro',uri=True) as db:
 assert db.execute('PRAGMA quick_check').fetchone()[0]=='ok';entries=db.execute('SELECT COUNT(*) FROM entries').fetchone()[0];assert entries==56555
os.rename(source,old)
try:os.symlink(target,source)
except BaseException:os.rename(old,source);raise
assert sha(source)==digest;old.unlink();out.write_text(json.dumps({'state':'passed','scope':'Relocate only the ignored downloaded dictionary SQLite cache after every owned job is terminal. Every original path remains readable through a symlink; rawSHA256 and56555entry count are unchanged and SQLitequick_check passes. No tracked sources, outputs or Git objects are moved.','source':str(source),'target':str(target),'sha256':digest,'bytes_freed':size,'entries':entries},indent=2)+'\n');print('Retained complete SQLite cache at its old path; freed',size,'Root bytes.')
