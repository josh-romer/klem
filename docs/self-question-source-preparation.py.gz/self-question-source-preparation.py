"""Preserve complete native self-question sources and actual unmodified CLI observations."""
import gzip,hashlib,json,re,sqlite3,subprocess,zipfile
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');DB=ROOT/'data/dictionaries/krdict/krdict.db';ZIP=ROOT/'data/dictionaries/krdict/2026-09.zip';CLI=Path('/nix/store/j4in370si6hf8dv52x2vsxj95grmsnvi-klem-0.1.0/bin/klem');OUT=Path('/tmp/klem-self-question-source-preparation.json.gz');assert not OUT.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
ids={'73881','73882','73883','73891','91482','88906'};original={};files={}
with zipfile.ZipFile(ZIP) as archive:
 for name in archive.namelist():
  if not name.endswith('.json'):continue
  raw=archive.read(name)
  entries=json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']
  selected=[e for e in entries if str(e.get('val')) in ids]
  if selected:files[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
  for e in selected:
   ident='krdict:'+str(e['val']);assert ident not in original;original[ident]=e
assert set(original)=={'krdict:'+i for i in ids}
with sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True) as db:
 complete={id:json.loads(raw) for id,raw in db.execute("select id,data from entries where headword in ('-ㄴ담','-는담','-담','-남')")};metadata=dict(db.execute('select key,value from metadata'))
assert set(complete)==set(original)
lemmas={'간담':'가다','온담':'오다','안담':'알다','정한담':'정하다','나간담':'나가다','천재였남':'천재','되었남':'되다','주남':'주다','있었남':'있다','혼내시남':'혼내다','않는담':'않다','읽는담':'읽다','찾는담':'찾다','잡는담':'잡다','먹는담':'먹다','곱담':'곱다','심하담':'심하다','웃기담':'웃기다','있담':'있다','여리담':'여리다','먹었담':'먹다'}
text='';groups=[]
for ident in ['krdict:73881','krdict:73882','krdict:73883','krdict:73891']:
 for sense in complete[ident]['senses']:
  for i,examples in enumerate(sense['examples'],1):
   original_text='\n'.join(examples);start=len(text.encode());text+=original_text+'\n'
   groups.append({'id':f"self-question-source-{ident.split(':')[1]}-{sense['id']}-{i}",'entry_id':ident,'sense_id':sense['id'],'group':i,'complete_original_examples':examples,'span':{'start':start,'end':start+len(original_text.encode())}})
assert len(groups)==21
runs={}
for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
 command=[str(CLI),'text','-','--dictionary',str(DB),*flags];job=subprocess.run(command,input=text.encode(),capture_output=True,check=True);assert not job.stderr
 runs[mode]={'command':command,'exit_code':job.returncode,'records':[json.loads(line) for line in job.stdout.splitlines()],'stdout_sha256':hashlib.sha256(job.stdout).hexdigest()}
proposals=[]
for ordinal,record in enumerate(runs['raw']['records']):
 if record['kind']!='word':continue
 word=record['analysis']['normalized']
 if not word.endswith(('담','남')):continue
 assert word in lemmas,word
 group=next(g for g in groups if g['span']['start']<=record['span']['start']<record['span']['end']<=g['span']['end'])
 proposals.append({'id':group['id']+'-'+str(record['span']['start']-group['span']['start']),'source_group_id':group['id'],'surface':word,'proposed_lemma':lemmas[word],'complete_original_group':group['complete_original_examples'],'baseline_records':{mode:run['records'][ordinal] for mode,run in runs.items()},'judgment':'proposed-unreviewed','basis':'Authored source-example analysis, not annotated gold; nominal copula/prefinal and immediate-owner licenses require review.'})
assert len(proposals)==21 and {p['source_group_id'] for p in proposals}=={g['id'] for g in groups}
frozen={str(p):sha(p) for p in [DB,ZIP,CLI,Path(__file__)]}
r={'state':'complete-native-source-and-baseline-preparation-passed','dictionary_metadata':metadata,'original_native_entries':original,'complete_imported_entries':complete,'original_source_files':files,'complete_groups':groups,'complete_source_text':text,'baseline_runs':runs,'proposals':proposals,'frozen_inputs':frozen,'inputs_unchanged':all(sha(p)==h for p,h in frozen.items()),'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Four unreviewed ending identities, all21complete example groups and21authored proposals; two unrelated suffix homonyms retained separately. Actual unchanged installed CLI in all three dictionary modes. No implementation or linguistic verdict is claimed.'}
assert r['inputs_unchanged'];OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Preserved six native identities, 21 complete groups and 21 unreviewed source proposals in all three CLI modes.')
