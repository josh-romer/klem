"""Archive original regression failure, actual retry and complete case/dictionary output."""
import gzip
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
D = W / 'docs'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
retry = json.loads((P / 'friendly-hortative-sena-corpus-regression-retry-receipt.json').read_bytes())
first = json.loads((P / 'friendly-hortative-sena-corpus-regression-receipt.json').read_bytes())
assert retry['state']=='passed' and retry['runs']==12 and retry['frames']==336 and retry['native_owners']==1
assert first['state']=='failed' and first['error']=='AssertionError()'
for r in [first,retry]:
    assert all(r[k] for k in ['inputs_unchanged','external_inputs_unchanged','head_unchanged','index_unchanged'])
    assert all(sha((W/n).read_bytes())==d for n,d in r['frozen_inputs'].items())
assert sha((P/'friendly-hortative-sena-corpus-regression-retry.json.gz').read_bytes())==retry['record_sha256']
assert sha((P/'friendly-hortative-sena-corpus-regression-retry.log').read_bytes())==retry['log_sha256']
files={}
for path in [P/name for name in [
    'capture_friendly_hortative_sena_corpus_regression.py',
    'friendly-hortative-sena-corpus-regression-original-producer.py.gz',
    'friendly-hortative-sena-corpus-regression-original-terminal-observation.json',
    'friendly-hortative-sena-corpus-regression-receipt.json',
    'friendly-hortative-sena-corpus-regression.log',
    'friendly-hortative-sena-corpus-regression-partial.json.gz',
    'friendly-hortative-sena-corpus-regression-status-diagnostic.json',
    'capture_friendly_hortative_sena_corpus_regression_retry.py',
    'friendly-hortative-sena-corpus-regression-retry-receipt.json',
    'friendly-hortative-sena-corpus-regression-retry.log',
    'friendly-hortative-sena-corpus-regression-retry.json.gz']]+[Path(__file__)]:
    raw=path.read_bytes();name='friendly-hortative-sena-corpus-regression-proof-'+path.name+'.gz'
    output=D/name;assert not output.exists();packed=gzip.compress(raw,mtime=0);output.write_bytes(packed)
    files[path.name]=dict(path=name,source_sha256=sha(raw),archive_sha256=sha(packed))
out=D/'friendly-hortative-sena-corpus-regression-proof-archive.json';assert not out.exists()
out.write_text(json.dumps(dict(state='actual-whole-original-KAIST-sentence12regression-policies-passed',files=files,
    stable_case_id='friendly-hortative-sena-kaist-MH2_0180-s63-5',original_gold_lemma='중세',
    new_raw_hypothesis=dict(lemma='중다',morphemes=['세나'],compatibility='unknown',headword_matches=0,contextual_verdict='unjudged'),
    headword_and_compatible_filters_exclude_unmatched_hypothesis=True,
    original_nominal_reading_and_all_prior_candidates_assessments_order_retained=True,
    complete_original_sentence_token_and_gold_retained=True,actual_policy_runs=12,frames=336,complete_Native_owners=1,
    original_failed_test_and_separate_diagnostic_and_retry_retained=True,
    historical_allowances_assigned=False,shared_cases_reviews_changed=False,full_coverage_complete=False),ensure_ascii=False,indent=2)+'\n')
print('Archived12fulloriginals for actual12whole-sentence policies and preserved original test expectation failure.',flush=True)
