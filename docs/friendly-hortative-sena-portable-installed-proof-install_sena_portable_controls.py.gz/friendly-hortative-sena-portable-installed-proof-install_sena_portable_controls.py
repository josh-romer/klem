"""Keep all43 original test bodies, add whole-stream archive rejection controls."""
import ast
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent/'friendly-hortative-sena'
t=(P/'test_friendly_hortative_sena_installed_audit_retry6.py').read_text()
def methods(source):return {n.name:ast.dump(n,include_attributes=False) for c in ast.parse(source).body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
old=methods(t);assert len(old)==43
t=t.replace('import friendly_hortative_sena_installed_audit_retry6 as audit','import friendly_hortative_sena_installed_audit as audit')
extra='''
    def test_whole_installed_stream_omitted(self):
        v=self.values.copy();v['originals']=v['originals'].copy()
        name=next(n for n in v['originals'] if n.endswith('retry3-command-0000-stdout.gz'))
        del v['originals'][name]
        with self.assertRaisesRegex(AssertionError,'all complete unique original stream archives'):
            audit.inspect_streams(v)

    def test_whole_installed_stream_corrupted(self):
        v=self.values.copy();v['originals']=v['originals'].copy()
        name=next(n for n in v['originals'] if n.endswith('retry3-command-0000-stdout.gz'))
        v['originals'][name]=b'changed stream'
        with self.assertRaisesRegex(AssertionError,'original packed installed stream bytes'):
            audit.inspect_streams(v)

    def test_original_failed_wrapper_cannot_be_promoted(self):
        import gzip
        v=self.values.copy();v['originals']=v['originals'].copy()
        name=audit.PREFIX+'installed-runtime-retry3.json.gz'
        original=json.loads(gzip.decompress(v['originals'][name]));original['state']='passed'
        v['originals'][name]=gzip.compress(json.dumps(original).encode(),mtime=0)
        with self.assertRaisesRegex(AssertionError,'original failed wrapper retained separately'):
            audit.inspect_streams(v)

'''
anchor="if __name__=='__main__':";assert anchor in t;t=t.replace(anchor,extra+'\n'+anchor);new=methods(t);assert len(new)==46 and all(new[n]==v for n,v in old.items())
(W/'tools/test_friendly_hortative_sena_installed_audit.py').write_text(t)
f=W/'flake.nix';s=f.read_text();needle='                ./tools/friendly_hortative_sena_revision.py\n';assert needle in s;s=s.replace(needle,needle+'                ./tools/friendly_hortative_sena_installed_audit.py\n                ./tools/test_friendly_hortative_sena_installed_audit.py\n');needle="            python -m unittest discover -s tools -p 'test_friendly_hortative_sena_revision.py'\n";assert needle in s;s=s.replace(needle,needle+"            KLEM_SENA_BINARY_EVIDENCE=captured python tools/friendly_hortative_sena_installed_audit.py\n            KLEM_SENA_BINARY_EVIDENCE=captured python -m unittest discover -s tools -p 'test_friendly_hortative_sena_installed_audit.py'\n");f.write_text(s)
print('All43 original controls preserved exactly;3 meaningful stream/failure controls added;flake wired.',flush=True)
