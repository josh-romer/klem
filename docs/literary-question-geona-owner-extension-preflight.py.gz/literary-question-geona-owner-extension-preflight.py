"""Track authored future-question boundaries against the isolated candidate; inherited spelling and immediate-owner expectations are authored."""
import gzip
import hashlib
import json
import subprocess
import unicodedata
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
before = Path('/nix/store/jmk0c772h8z0frp6f0x14v6siz0w8zhl-klem-0.1.0/bin/klem')
after = Path('/tmp/klem-literary-question-geona-cli')
dictionary = ROOT/'data/dictionaries/krdict/krdict.db'
output = Path('/tmp/klem-literary-question-geona-owner-extension-preflight.json.gz')
assert not output.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
producer = Path(__file__)
frozen = {str(p):sha(p.read_bytes()) for p in [before,after,dictionary,producer]}
specs = [
    ('derived-dap-vowel','학생다울거나',['학생'],['답다']),
    ('derived-dap-honorific','학생다우실거나',['학생'],['답다','시']),
    ('derived-dap-past','학생다웠을거나',['학생'],['답다','었']),
    ('derived-dap-modal-listed','학생답겠을거나',['학생'],['답다','겠']),
    ('derived-hada','행복할거나',['행복'],['하다']),
    ('derived-hada-past','행복했을거나',['행복'],['하다','었']),
    ('aux-benefactive','먹어줄거나',['먹다','주다'],['어']),
    ('aux-change','행복해질거나',['행복하다','지다'],['어']),
    ('aux-result','먹게될거나',['먹다','되다'],['게']),
    ('aux-benefactive-si','먹어주실거나',['먹다','주다'],['어','시']),
    ('aux-benefactive-past','먹어주었을거나',['먹다','주다'],['어','었']),
    ('aux-result-modal-listed','먹게되겠을거나',['먹다','되다'],['게','겠']),
    ('stack-negative-existential','먹지않고있을거나',['먹다','않다','있다'],['지','고']),
    ('stack-try-negative','읽어보지않을거나',['읽다','보다','않다'],['어','지']),
    ('adjective-past-listed','좋았을거나',['좋다'],['었']),
    ('adjective-modal-listed','좋겠을거나',['좋다'],['겠']),
    ('aux-desire-past-listed','먹고싶었을거나',['먹다','싶다'],['고','었']),
    ('copula-honorific-conditional','학생이실거나',['학생','이다'],['시']),
    ('copula-modal-listed','학생이겠을거나',['학생','이다'],['겠']),
]
forbidden = [
    ('derived-dap-unrecovered','학생답을거나',['학생'],['답다']),
    ('derived-dap-wrong-honorific','학생답으실거나',['학생'],['답다','시']),
    ('derived-dap-wrong-past','학생답았을거나',['학생'],['답다','었']),
    ('aux-vowel-full','먹어주을거나',['먹다','주다'],['어']),
    ('aux-coda-short','먹지않거나',['먹다','않다'],['지']),
    ('aux-rieul-full','먹게될을거나',['먹다','되다'],['게']),
]
all_cases = [{'id':'literary-question-geona-owner-extension-'+name,'surface':word,'lemmas':heads,
              'morphemes':prefix+['을거나'],'proposal':'required',
              'contextual_verdict':'unjudged','independent_review':'pending'}
             for name,word,heads,prefix in specs]
all_cases += [{'id':'literary-question-geona-owner-extension-'+name,'surface':word,'lemmas':heads,
               'morphemes':prefix+['을거나'],'proposal':'forbidden',
               'contextual_verdict':'unjudged','independent_review':'pending'}
              for name,word,heads,prefix in forbidden]
assert len({c['id'] for c in all_cases}) == len(all_cases) == 25
for case in all_cases:
    if case['id'].endswith(('derived-dap-vowel','derived-dap-honorific','derived-hada','copula-honorific-conditional')):
        case['proposal']='conditional'
        case['expected_status']='unknown'
text = ' '.join(dict.fromkeys(c['surface'] for c in all_cases))
runs, observations = [], []
for encoding in ['NFC','NFD']:
    encoded = unicodedata.normalize(encoding,text).encode()
    for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
        command = [str(after),'text','-','--dictionary',str(dictionary),*flags]
        result = subprocess.run(command,input=encoded,capture_output=True,check=True)
        rows = {r['analysis']['normalized']:r for r in map(json.loads,result.stdout.splitlines()) if r.get('analysis')}
        for case in all_cases:
            row = rows[case['surface']]
            hits = [i for i,a in enumerate(row['analysis']['analyses'])
                    if [l['text'] for l in a['lemmas']] == case['lemmas']
                    and [m['form'] for m in a['morphemes']] == case['morphemes']
                    and 'ending.literary_question_geona' in a['rules']]
            observations.append({'encoding':encoding,'mode':mode,'case_id':case['id'],
                                 'expected_present':case['proposal'] in ['required','conditional'],'present':bool(hits),
                                 'paths':[row['analysis']['analyses'][i] for i in hits],
                                 'assessments':[row['dictionary']['readings'][i] for i in hits]})
        runs.append({'encoding':encoding,'mode':mode,'command':command,'input_sha256':sha(encoded),
                     'jsonl':result.stdout.decode(),'sha256':sha(result.stdout),'exit_code':0})
# Proposals stay visible even when a spelling policy or inherited owner needs review.
violations = [o for o in observations if o['present'] != o['expected_present']]
assert all(sha(Path(p).read_bytes()) == expected for p,expected in frozen.items())
report = {'schema_version':1,'state':'passed' if not violations else 'review-required',
          'cases':all_cases,'input':text,'runs':runs,'observations':observations,'violations':violations,
          'frozen_inputs':frozen,'inputs_unchanged':True,
          'producer':{'text':producer.read_text(),'sha256':frozen[str(producer)]},
          'scope':'Twenty-five authored immediate-owner, derivation, auxiliary-stack and listed-marker proposals, separate from the eight original source occurrences. Four bare adjective/derivation/honorific-copula extensions stay conditional; their emitted structure is not a raw required judgment. Actual candidate output in six Unicode/filter modes, with every target and Native assessment retained. Unreviewed marker/omission/negative owner distributions are tracked independently. This preflight does not promote proposals into corpus gold or global ledger judgments; regular/irregular and sense-specific conflicts require individual review.'}
assert len(observations)==150
output.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Authored proposals:',len(all_cases),'mode observations:',len(observations),'mismatches:',len(violations),flush=True)
for violation in violations: print(violation['encoding'],violation['mode'],violation['case_id'],violation['present'],flush=True)
