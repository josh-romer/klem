"""Validate the new runtime auditor with every current source byte frozen."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-gentle-command')
OUT = PREP / 'gentle-command-runtime-audit-validation.json'
LOG = PREP / 'gentle-command-runtime-audit-validation.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=WORK).decode().split('\0')[:-1]
frozen = {str(p): sha(p) for p in [WORK / n for n in names]+[Path(__file__)]}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
index = sha(WORK / '.git') if (WORK / '.git').is_dir() else hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest()
commands = [
    ['python3', 'tools/gentle_command_runtime_audit.py'],
    ['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_gentle_command_runtime_audit.py'],
    ['python3', 'tools/gentle_command_source_audit.py'],
    ['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_gentle_command_source_audit.py'],
    ['python3', 'tools/gentle_command_history_audit.py'],
    ['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_gentle_command_history_audit.py'],
    ['python3', 'tools/review_inventory.py', '--verify'],
    ['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_review_inventory.py'],
    ['git', 'diff', '--check'],
]
r = dict(state='running', head=head, index_sha256=index, frozen_inputs=frozen, results=[],
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         producer=dict(text=Path(__file__).read_text(), sha256=sha(__file__)),
         scope='Complete archived actual runtime proof, independent audits and corruption controls; production code and original judgments unchanged. Nix selection/installed browser/main/quiet performance and contextual independent review remain separate.')
save = lambda: OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2)+'\n')
save()
with LOG.open('xb') as stream:
    for command in commands:
        job = subprocess.run(command, cwd=WORK, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        stream.write(job.stdout); stream.flush()
        output = job.stdout.decode()
        tests = sum(map(int, re.findall(r'Ran (\d+) tests? in', output)))
        r['results'].append(dict(command=command, exit_code=job.returncode, output=output, controls=tests))
        save()
        print(command[-1], 'exit', job.returncode, 'controls', tests, flush=True)
        if job.returncode:
            break
r.update(inputs_unchanged=all(sha(p) == digest for p, digest in frozen.items()),
         head_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == head,
         index_unchanged=hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest() == index,
         controls=sum(row['controls'] for row in r['results']), log_sha256=sha(LOG),
         finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
r['state'] = 'passed' if len(r['results']) == len(commands) and all(row['exit_code'] == 0 for row in r['results']) and r['controls'] == 77 and r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged'] else 'failed'
save()
print(r['state'], r['controls'], 'controls;', len(frozen), 'frozen sources', flush=True)
raise SystemExit(0 if r['state'] == 'passed' else 1)
