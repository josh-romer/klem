"""Actual complete four-check gate with durable preflight failures and source freeze."""
import datetime,hashlib,json,os,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent/'friendly-hortative-sena'
O=P/'friendly-hortative-sena-portable-complete-nix-gate.json';L=P/'friendly-hortative-sena-portable-complete-nix-gate.log'
B=Path('/var/tmp/klem-friendly-hortative-sena-portable-complete-nix-build')
assert not O.exists() and not L.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest();git=lambda *args:subprocess.check_output(['git',*args],cwd=W)
assert not git('status','--porcelain')
frozen={n:sha((W/n).read_bytes()) for n in git('ls-files','-z').decode().split('\0')[:-1]}
head,index=git('rev-parse','HEAD').decode().strip(),sha(git('ls-files','--stage','-z'))
B.mkdir(exist_ok=True);B.chmod(0o1777)
env=dict(os.environ,TMPDIR=str(B),PYTHONDONTWRITEBYTECODE='1')
flake='git+file://'+str(W)
command=['nix','build','--option','auto-optimise-store','true','--option','build-dir',str(B),'--cores','4','--max-jobs','1','--no-link','--print-out-paths','-L']+[flake+'#checks.x86_64-linux.'+n for n in ['klem','web-assets','corpus-adapter','inventory-review']]
binding=json.loads((P/'friendly-hortative-sena-complete-runtime-binding.json').read_bytes())
protected={row['path']:row['sha256'] for row in binding['binaries'].values()}|binding['protected_parent_binaries']
assert all(sha(Path(p).read_bytes())==d for p,d in protected.items())
r=dict(state='running',phase='preflight',head=head,index_sha256=index,frozen_inputs=frozen,protected_binaries=protected,command=command,results=[],
 producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 scope='Actual complete current Git-selected Sena four Nix checks: Rust CLI/server library, frontend, corpus adapter, and entire historical inventory with strict named44/18/1158 source guard. Source/head/index/six debug binaries frozen. This does not itself prove installed runtime/browser, shared25promotion/main, quiet timing/context/register/Korean review completion.')
def save():O.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 with L.open('xb') as log:
  def source(attr):
   args=['nix','eval','--offline','--raw',flake+'#'+attr]
   log.write(('SOURCE '+json.dumps(args)+'\n').encode());log.flush()
   job=subprocess.run(args,cwd=W,env=env,stdout=subprocess.PIPE,stderr=log)
   r['results'].append(dict(command=args,exit_code=job.returncode));save();assert job.returncode==0
   return Path(job.stdout.decode().strip())
  def files(root,prefix=''):
   values={}
   for path in root.rglob('*'):
    assert not path.is_symlink()
    if path.is_file():
     n=str(path.relative_to(root));digest=sha(path.read_bytes());assert frozen[prefix+n]==digest;values[n]=digest
   return values
  selected=source('checks.x86_64-linux.inventory-review.src');r['inventory_source']=str(selected);r['inventory_source_files']=files(selected)
  for n in ['tools/friendly_hortative_sena_revision.py','tools/test_friendly_hortative_sena_revision.py','tools/friendly_command_gena_revision.py','tools/friendly_command_gena_browser_audit.py','tools/friendly_hortative_sena_browser_audit.py','docs/friendly-hortative-sena-browser-proof-archive.json','tools/friendly_hortative_sena_installed_audit.py','tools/test_friendly_hortative_sena_installed_audit.py','docs/friendly-hortative-sena-installed-proof-archive.json','docs/friendly-hortative-sena-portable-installed-proof-archive.json']:
   assert n in r['inventory_source_files'], 'all new named guards and immutable proofs must be selected'
  prior=json.loads((P/'friendly-hortative-sena-wide-selected-source.json').read_bytes());r['profiles']={}
  for attr,prefix in [('klem',''),('corpus-adapter',''),('web-assets','web/')]:
   root=source('packages.x86_64-linux.'+attr+'.src');current=files(root,prefix)
   assert current==prior['profiles'][attr]['files'], 'every prior1158/1158/18 passed Rust/frontend input unchanged'
   r['profiles'][attr]=dict(source=str(root),files=current)
  save()
  preflight=['python3','-m','unittest','discover','-s','tools','-p','test_friendly_hortative_sena_revision.py']
  log.write(('SELECTED PREFLIGHT '+json.dumps(preflight)+'\n').encode());log.flush()
  job=subprocess.run(preflight,cwd=selected,env=dict(env,KLEM_SENA_BINARY_EVIDENCE='captured'),stdout=log,stderr=subprocess.STDOUT)
  r['results'].append(dict(command=preflight,exit_code=job.returncode));r['selected_preflight_passed']=job.returncode==0;save();assert job.returncode==0
  portable=['python3','-m','unittest','discover','-s','tools','-p','test_friendly_hortative_sena_installed_audit.py']
  log.write(('PORTABLE SELECTED '+json.dumps(portable)+'\n').encode());log.flush()
  job=subprocess.run(portable,cwd=selected,env=dict(env,KLEM_SENA_BINARY_EVIDENCE='captured'),stdout=log,stderr=subprocess.STDOUT)
  r['results'].append(dict(command=portable,exit_code=job.returncode));r['portable_selected_preflight_passed']=job.returncode==0;save();assert job.returncode==0
  r['phase']='complete-four-check-build';save()
  log.write(('COMPLETE NIX '+json.dumps(command)+'\n').encode());log.flush()
  job=subprocess.run(command,cwd=W,env=env,stdout=subprocess.PIPE,stderr=log)
  r.update(exit_code=job.returncode,stdout=job.stdout.decode(),outputs=job.stdout.decode().splitlines());r['results'].append(dict(command=command,exit_code=job.returncode))
  assert job.returncode==0 and len(r['outputs'])==4 and all(line.startswith('/nix/store/') for line in r['outputs'])
 r['state']='passed';r['phase']='complete'
except BaseException as error:r.update(state='failed',error=repr(error));raise
finally:
 r.update(inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),protected_binaries_unchanged=all(sha(Path(p).read_bytes())==d for p,d in protected.items()),head_unchanged=git('rev-parse','HEAD').decode().strip()==head,index_unchanged=sha(git('ls-files','--stage','-z'))==index,log_sha256=sha(L.read_bytes()) if L.exists() else None,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 if not all(r[k] for k in ['inputs_unchanged','protected_binaries_unchanged','head_unchanged','index_unchanged']):r['state']='failed'
 save()
assert r['state']=='passed'
print('Passed actual complete Sena four-check Nix gate; allsource/head/index/sixbinaries unchanged.',flush=True)
