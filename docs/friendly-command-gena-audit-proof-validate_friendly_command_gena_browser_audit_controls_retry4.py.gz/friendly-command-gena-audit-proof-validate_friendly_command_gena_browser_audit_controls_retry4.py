import datetime,hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=Path('/home/josh/projects/klem/.direnv/friendly-command-gena')
O=P/'friendly-command-gena-browser-audit-controls-retry4.json';L=P/'friendly-command-gena-browser-audit-controls-retry4.log';assert not O.exists() and not L.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
frozen={str(p.relative_to(W)):sha(p.read_bytes()) for p in (W/'tools').glob('*friendly_command_gena*.py')}
command=['python3','-m','unittest','discover','-s','tools','-p','test_friendly_command_gena_browser_audit.py','-v']
with L.open('xb') as log:r=subprocess.run(command,cwd=W,stdout=log,stderr=subprocess.STDOUT)
O.write_text(json.dumps(dict(state='passed' if r.returncode==0 else 'failed',exit_code=r.returncode,command=command,frozen_inputs=frozen,inputs_unchanged=all(sha((W/p).read_bytes())==d for p,d in frozen.items()),log_sha256=sha(L.read_bytes()),producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
print(L.read_text(),flush=True);raise SystemExit(r.returncode)
