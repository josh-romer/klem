"""Retain every original corpus occurrence of new raw-word hypotheses."""
import gzip
import hashlib
import json
from pathlib import Path

prep = Path(__file__).resolve().parent
root = Path('/home/josh/projects/klem')
out = prep / 'distribution-contexts.json.gz'
assert not out.exists()
read = lambda p: json.loads(gzip.decompress(p.read_bytes()))
cohorts = read(prep / 'willingness-cohorts.json.gz')
corpora = read(prep / 'willingness-corpora.json.gz')
broad = read(prep / 'willingness-broad.json.gz')
changed = {item['surface']: item for item in cohorts['individual_changed_words']}
assert set(changed) == {'구소련', '대련', '마련', '소련'}
occurrences, sources = [], {}
for run in corpora['runs']:
    source = root / run['source']
    raw = source.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == run['source_sha256']
    sources[run['source']] = {'sha256': run['source_sha256'], 'bytes': len(raw)}
    for ordinal, sentence in enumerate(raw.split(b'\n\n')):
        for row in sentence.splitlines():
            if not row or row.startswith(b'#'):
                continue
            fields = row.decode().split('\t')
            if len(fields) != 10 or fields[1] not in changed:
                continue
            occurrences.append({'id': 'willingness-question-observed-' + run['corpus'] + '-' + run['partition'] + '-' + str(ordinal) + '-' + fields[0],
                                'corpus': run['corpus'], 'partition': run['partition'],
                                'source': run['source'], 'surface': fields[1],
                                'original_annotation_fields': fields,
                                'complete_original_sentence': sentence.decode(),
                                'observation': changed[fields[1]],
                                'contextual_verdict': 'unjudged; original annotations are preserved without forbidding every alternative'})
assert {item['surface'] for item in occurrences} == set(changed)
novel = [item for run in broad['runs'] for item in run['changed_frames']]
assert len(novel) == 1 and novel[0]['after']['surface'] == '궐련'
report = {'state': 'all-original-distribution-contexts-preserved',
          'corpus_occurrences': occurrences, 'corpus_sources': sources,
          'complete_novel_observation': novel[0],
          'changed_word_observations': list(changed.values()),
          'producer': {'text': Path(__file__).read_text(), 'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
          'scope': 'Every original annotated occurrence of four raw changed corpus words and the complete original novel line for the single changed broad record. No observed hypothesis becomes gold, no source expected lemmas are rewritten and no contextual precision claim is made.'}
out.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
print(len(occurrences), 'complete original annotated occurrences;', len(novel), 'complete original novel observation')
