"""Retain all original corpus/history words and individually record every candidate addition."""
import datetime,gzip,hashlib,json,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from doeda_native_corpora import words_from_cli
CLI=Path('/tmp/klem-additive-ppundeoreo-current-cli')
OUT=Path('/tmp/klem-additive-ppundeoreo-corpus-history.json.gz');assert not OUT.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
frozen={str(CLI):sha(CLI.read_bytes())};cohorts=[];changes=[]
for family,suffix,count in [('corpus','prototype-corpora',32096),('history','prototype-legacy-history',21406)]:
    path=ROOT/'docs'/('literary-question-geona-'+suffix+'.json.gz');frozen[str(path)]=sha(path.read_bytes())
    prior=json.loads(gzip.decompress(path.read_bytes()));before=prior['after_words'];assert len(before)==count
    after=words_from_cli(CLI,sorted(before));assert set(after)==set(before)
    for surface,old in before.items():
        new=after[surface]
        if old==new:continue
        assert {k:v for k,v in old.items() if k!='analyses'}=={k:v for k,v in new.items() if k!='analyses'}
        assert [p for p in new['analyses'] if p in old['analyses']]==old['analyses']
        additions=[p for p in new['analyses'] if p not in old['analyses']]
        assert additions and all('ending.additive_ppundeoreo' in p['rules'] for p in additions)
        for candidate in additions:
            ident=sha(json.dumps([family,surface,candidate],ensure_ascii=False,sort_keys=True).encode())[:24]
            changes.append({'id':'additive-ppundeoreo-'+family+'-'+ident,'family':family,'surface':surface,
                            'analysis':candidate,'before':old,'after':new,'contextual_verdict':'unjudged','independent_review':'pending'})
    digest=sha(json.dumps(after,ensure_ascii=False,sort_keys=True).encode())
    cohorts.append({'family':family,'surfaces':count,'baseline_capture':str(path),'baseline_sha256':frozen[str(path)],
                    'before_word_sha256':prior['after_words_sha256'],'after_word_sha256':digest,
                    'all_prior_candidates_retained':True,'exact_prior_words':after==before,'before_words':before,'after_words':after})
    print(family,count,'complete words;',sum(c['family']==family for c in changes),'individually retained additions.',flush=True)
assert all(sha(Path(p).read_bytes())==v for p,v in frozen.items())
producer=Path(__file__)
report={'state':'passed','preparation_only':True,'cli':str(CLI),'cli_sha256':frozen[str(CLI)],'cohorts':cohorts,
        'individual_additions':changes,'frozen_inputs':frozen,'inputs_unchanged':True,
        'producer':{'text':producer.read_text(),'sha256':sha(producer.read_bytes())},
        'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope':'All32096original corpus and21406history words, exact candidate preservation and individual additive-ending changes. Original gold-row outcomes, adapter execution, browser, full Rust and Root/package integration remain separate.'}
OUT.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Complete original corpus/history cohorts retained with',len(changes),'individually scoped additions.',flush=True)
