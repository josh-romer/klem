"""Validate complete original inventory source and actual captured streams."""
import gzip,hashlib,json,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from native_lmf import entry,array,verify_native_lmf
from review_inventory import source_entry,digest
PREFIX=Path('/tmp/klem-unreviewed-inventory')
read=lambda p:json.load(gzip.open(p,'rt'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def verify(closure,runtime,discovery):
 rows=closure['review_entries'];assert len(rows)==237 and len({r['source']['id'] for r in rows})==237
 native=closure['complete_native_entries'];assert len(native)==306 and closure['original_lmf'].keys()==native.keys()
 verify_native_lmf(closure['english_projection'],native)
 for ident,raw in closure['original_lmf'].items():assert entry(raw)==native[ident]
 expected=[];text='';cursor=0
 for row in rows:
  source=row['source'];assert row['review']['status']=='unreviewed' and source_entry(native[source['id']])==source and digest(source)==row['source_sha256']
  for sense in native[source['id']]['senses']:
   for ordinal,examples in enumerate(sense['examples'],1):
    complete='\n'.join(examples);start=cursor;text+=complete+'\n';cursor+=len((complete+'\n').encode())
    expected.append(dict(id=f"unreviewed-source-{source['id'].split(':')[1]}-{sense['id']}-{ordinal}",entry_id=source['id'],sense_id=sense['id'],example_group=ordinal,complete_original_examples=examples,text=complete,span={'start':start,'end':cursor-1},source_url=source['url'],linguistic_verdict='unjudged',attachment_verdict='unjudged',independent_review='pending'))
 assert closure['groups']==expected and len(expected)==1621
 assert text==Path(str(PREFIX)+'-source-text.txt').read_text()
 assert runtime['state']=='complete-unreviewed-source-runtime-preparation-passed' and runtime['inputs_unchanged'] and not runtime['full_coverage_complete']
 assert runtime['entries']==237 and runtime['same_head_entries']==306 and runtime['original_groups']==1621
 captures=runtime['captures'];assert len(captures)==6 and {(c['mode'],c['cache_bytes']) for c in captures}=={(m,b) for m in ['raw','headword','compatible'] for b in [0,4096]}
 for capture in captures:
  assert capture['exit_code']==0 and sha(capture['artifact'])==capture['artifact_sha256']
  h=hashlib.sha256();cursor=0;frames=0;empty=[];ambiguous=0
  with gzip.open(capture['artifact'],'rb') as stream:
   for line in stream:
    h.update(line);r=json.loads(line);frames+=1;span=r['span'];assert span['start']==cursor and text.encode()[cursor:span['end']].decode()==r['surface'];cursor=span['end']
    if r.get('analysis'):
     analyses=r['analysis']['analyses'];ambiguous+=len(analyses)>1
     if not analyses:empty.append(dict(record=frames,surface=r['surface'],span=span,status='unjudged-dictionary-filter-empty'))
  assert cursor==len(text.encode()) and frames==capture['records']==27548 and h.hexdigest()==capture['stdout_sha256']
  assert empty==capture['empty_filtered_records'] and ambiguous==capture['ambiguous_records']
 for mode in ['raw','headword','compatible']:
  assert len({c['stdout_sha256'] for c in captures if c['mode']==mode})==1
 assert len(discovery['summary'])==237 and all(r['disposition']=='unreviewed' for r in discovery['summary'])
 assert {r['entry_id'] for r in discovery['summary']}=={r['source']['id'] for r in rows}
 observations=discovery['direct_source_observations'];assert len(observations)==len({o['id'] for o in observations})==1631
 indexed={g['id']:g for g in expected}
 for o in observations:
  g=indexed[o['source_group_id']];assert o['complete_original_group']==g['complete_original_examples'] and o['entry_id']==g['entry_id'] and o['linguistic_verdict']=='unjudged'
  assert text.encode()[o['span']['start']:o['span']['end']].decode()==o['surface']
  for mode,record in o['records'].items():
   assert record['surface']==o['surface'] and record['span']==o['span']
   assert all(0<=i<len(record['analysis']['analyses']) for i in o['matching_analysis_ordinals'][mode])
 return dict(unreviewed_entries=237,complete_native_entries=306,original_groups=1621,streams=6,frames=6*27548,discovery_observations=1631,linguistic_review_complete=False)
if __name__=='__main__':
 result=verify(read(str(PREFIX)+'-source-closure.json.gz'),read(str(PREFIX)+'-preflight.json.gz'),read(str(PREFIX)+'-discovery.json.gz'));print(result)
