"""Preserve every newly exposed complete lexical owner from the full source streams."""
import gzip,hashlib,json,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;PROTO=ROOT/'.direnv/familiar-geurae-prototype'
sys.path.insert(0,str(PROTO/'tools'))
from native_lmf import entry,feature
read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
prepared=read(OUT/'full-native-preparation.json.gz');streams=read(OUT/'source-streams.json.gz');needed=set(prepared['complete_imported_entries']);observations=[]
for run in streams['runs']:
 rows=run['captures'][1]['records']
 for observation in run['individual_additions']:
  row=rows[observation['record']-1];owners=[next(v for v in row['dictionary']['lemmas'] if v['lemma']==lemma) for lemma in observation['analysis']['lemmas']]
  needed.update(e['id'] for v in owners for e in v['entries']);observations.append({'id':observation['id'],'dictionary_owners':owners})
with sqlite3.connect((ROOT/'data/dictionaries/krdict/krdict.db').resolve().as_uri()+'?mode=ro',uri=True) as db:
 expected={ident:json.loads(db.execute('select data from entries where id=?',(ident,)).fetchone()[0]) for ident in sorted(needed)}
original=dict(prepared['original_native_entries']);exports={}
for path in sorted((ROOT/'.direnv/dictionary-restoration/2026-09').rglob('*.json')):
 raw=path.read_bytes();selected=[]
 for value in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
  ident='krdict:'+value['val']
  if ident not in needed or ident in original or feature(value,'lexicalUnit') in {'관용구','속담'}:continue
  assert entry(value)==expected[ident];original[ident]=value;selected.append(ident)
 if selected:exports[path.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'ids':selected}
assert set(original)==needed and {ident:entry(value) for ident,value in original.items()}==expected
report={'state':'complete-added-source-native-owner-closure-preserved','entries':expected,'original_native_entries':original,'additional_exports':exports,'individual_owner_observations':observations,'source_streams_sha256':hashlib.sha256((OUT/'source-streams.json.gz').read_bytes()).hexdigest(),'producer':{'text':Path(__file__).read_text(),'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},'scope':'Initial45fullNative source/control identities plus every actual new path owner across12complete source streams. Unknown/unmatched paths stay visible, homonyms remain separate and no lexical POS or sense rewritten. Contextual/independent review pending.'}
(OUT/'native-closure.json.gz').write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
(PROTO/'docs/familiar-geurae-native-closure.json.gz').write_bytes((OUT/'native-closure.json.gz').read_bytes())
for name,value in [('familiar-geurae-additional-native.json',{'LexicalResource':{'Lexicon':{'LexicalEntry':[original[i] for i in sorted(needed)]}}}),('familiar-geurae-additional-native-entries.json',expected)]:
 (PROTO/'tests/fixtures'/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
print('Complete source Native owner closure',len(needed),'entries;',len(observations),'individually owned source paths',flush=True)
