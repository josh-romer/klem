"""Freeze original Sena production and ledger bytes before integrating main."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path
P = Path(__file__).resolve().parent
ROOT = P.parents[1]
W = ROOT / '.direnv/friendly-hortative-sena'
OUT = P / 'friendly-hortative-sena-before-gena-parent-merge.json'
assert not OUT.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda tree, *a: subprocess.check_output(['git', *a], cwd=tree)
assert not git(ROOT, 'status', '--porcelain') and not git(W, 'status', '--porcelain')
gate = json.loads((P / 'friendly-hortative-sena-portable-complete-nix-gate.json').read_bytes())
assert gate['state'] == 'passed' and gate['phase'] == 'complete'
main_validation = json.loads((ROOT / '.direnv/willingness-question-prepared/friendly-command-gena-main-validation.json').read_bytes())
assert main_validation['state'] == 'passed' and main_validation['python_controls'] == 260
files = {}
for label, tree in [('main', ROOT), ('sena', W)]:
    for name in ['tests/fixtures/validity.json', 'tests/validity.rs', 'docs/inventory-reviews.json',
                 'docs/inventory-review-queue.json', 'docs/coverage-checklist.md', 'flake.nix']:
        raw = (tree / name).read_bytes(); packed = gzip.compress(raw, mtime=0)
        path = P / ('sena-before-gena-parent-' + label + '-' + name.replace('/', '-') + '.gz')
        path.write_bytes(packed)
        files[label + ':' + name] = dict(path=str(path), source_sha256=sha(raw), archive_sha256=sha(packed), bytes=len(raw))
old = json.loads((W / 'tests/fixtures/validity.json').read_bytes())
current = json.loads((ROOT / 'tests/fixtures/validity.json').read_bytes())
assert len(old['cases']) == 35740 and len(current['cases']) == 35764 and current['cases'][:35740] == old['cases']
binding = json.loads((P / 'friendly-hortative-sena-complete-runtime-binding.json').read_bytes())
production = binding['production_inputs']
assert len(production) == 44 and all(sha((W / name).read_bytes()) == digest for name, digest in production.items())
OUT.write_text(json.dumps(dict(state='complete-before-parent-merge-preserved', files=files,
                              main_head=git(ROOT, 'rev-parse', 'HEAD').decode().strip(),
                              sena_head=git(W, 'rev-parse', 'HEAD').decode().strip(),
                              main_index_sha256=sha(git(ROOT, 'ls-files', '--stage', '-z')),
                              sena_index_sha256=sha(git(W, 'ls-files', '--stage', '-z')),
                              production_inputs=production,
                              producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes()))), indent=2) + '\n')
print('Preserved12 original main/Sena inputs and all44 passed Sena production hashes.')
