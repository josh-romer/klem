"""Replay predeclared spacing cases against actual old/new CLIs and complete dictionary."""
import gzip,hashlib,json,subprocess,unicodedata
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');P=Path('/tmp/klem-predicate-auxiliary-spacing-prototype');OUT=Path('/tmp/klem-predicate-auxiliary-spacing-preflight.json.gz');assert not OUT.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
cli='/tmp/klem-predicate-auxiliary-spacing-cli';old='/tmp/klem-additive-ppundeoreo-main-cli';db=str(ROOT/'data/dictionaries/krdict/krdict.db');fixture=P/'tests/fixtures/predicate-auxiliary-spacing-cases.json';cases=json.loads(fixture.read_text())['cases']
frozen={str(p):sha(Path(p).read_bytes()) for p in [cli,old,db,fixture]};observations=[];mismatches=[]
for case in cases:
 for encoding in ['NFC','NFD']:
  word=unicodedata.normalize(encoding,case['surface'])
  for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
   outputs=[]
   for binary in [old,cli]:
    command=[binary,'word',word,'--dictionary',db,'--suggest-spacing',*flags]
    job=subprocess.run(command,capture_output=True,text=True);assert job.returncode==0,job.stderr
    outputs.append(json.loads(job.stdout))
   before,after=outputs;assert before['analyses']==after['analyses'] and before['dictionary']==after['dictionary']
   assert all(a in after['spacing']['alternatives'] for a in before['spacing']['alternatives'])
   actual=[a for a in after['spacing']['alternatives'] if a.get('rule')=='spacing.predicate_auxiliary']
   spaces={unicodedata.normalize('NFC',a['spaced']) for a in actual}
   missing=set(case['required_spaces'])-spaces
   if missing or (not case['required_spaces'] and spaces):mismatches.append({'case':case['id'],'encoding':encoding,'mode':mode,'missing':sorted(missing),'unexpected':sorted(spaces) if not case['required_spaces'] else []})
   observations.append({'case_id':case['id'],'encoding':encoding,'mode':mode,'before':before,'after':after})
assert all(sha(Path(p).read_bytes())==v for p,v in frozen.items())
r={'state':'passed' if not mismatches else 'failed','cases':cases,'observations':observations,'mismatches':mismatches,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'scope':'Every finite Unicode/filter case preserves raw candidates, dictionary readings and all prior spacing options. Required spaces declared before execution; arbitrary contextual spacing and broad/main/Nix validation remain unproven.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Finite spacing preflight',r['state'],len(observations),'observations',len(mismatches),'mismatches',flush=True)
if mismatches:print(mismatches)
