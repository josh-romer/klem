"""Preserve partial actual runtime; compare complete lookup JSON and retain every stream."""
import ast,gzip,hashlib,json,re
from pathlib import Path
P=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=P/'friendly-hortative-sena-runtime-retry2-preparation.json';assert not manifest.exists()
failed=json.loads(gzip.decompress((P/'friendly-hortative-sena-installed-runtime.json.gz').read_bytes()))
assert failed['state']=='failed' and failed['error']=="'response'"
package=json.loads((P/'friendly-hortative-sena-nix-packages-retry1.json').read_bytes());assert package['state']=='passed'
files={}
def preserve(name):
 raw=(P/name).read_bytes();dest=P/('friendly-hortative-sena-runtime-retry2-original-'+name+'.gz');assert not dest.exists();dest.write_bytes(gzip.compress(raw,mtime=0));files[name]=dict(path=dest.name,source_sha256=sha(raw),archive_sha256=sha(dest.read_bytes()));return raw.decode() if name.endswith('.py') else raw
for name in ['friendly-hortative-sena-installed-runtime.json.gz','friendly-hortative-sena-installed-runtime-progress.json','friendly-hortative-sena-installed-continuation-retry1.json','friendly-hortative-sena-installed-continuation-retry1.log']:
 preserve(name)
names=['capture_friendly_hortative_sena_installed_runtime_retry1.py','run_friendly_hortative_sena_installed_browser_retry1.py','validate_friendly_hortative_sena_installed_audit_retry1.py','friendly_hortative_sena_installed_audit_retry1.py','test_friendly_hortative_sena_installed_audit_retry1.py','continue_sena_installed_validation_retry1.py']
mapping={name:name.replace('_retry1.py','_retry2.py') for name in names}
tokens={**mapping,**{n[:-3]:v[:-3] for n,v in mapping.items()}}
pattern=re.compile(r'\b(?:'+'|'.join(re.escape(n) for n in sorted(tokens,key=len,reverse=True))+r')\b')
new={}
for name in names:
 old=preserve(name);text=pattern.sub(lambda m:tokens[m.group()],old)
 text=text.replace('friendly-hortative-sena-installed-runtime.json.gz','friendly-hortative-sena-installed-runtime-retry2.json.gz').replace('friendly-hortative-sena-installed-runtime-progress.json','friendly-hortative-sena-installed-runtime-progress-retry2.json')
 if name=='capture_friendly_hortative_sena_installed_runtime_retry1.py':
  needle="if head in lookups:assert row['stdout']==lookups[head]['stdout'] and row['response']==lookups[head]['response']"
  replacement="if head in lookups:assert row['stdout']==lookups[head]['stdout'] and json.loads(row['stdout'])==json.loads(lookups[head]['stdout'])"
  assert text.count(needle)==1;text=text.replace(needle,replacement)
  needle='def call(command,text=None):\n';assert text.count(needle)==1
  recording='''# Preserve full stdout/stderr of every actual replay, including cohort fallback calls.
_original_run=subprocess.run
r['command_attempts']=[]
def _recorded_run(*args,**kwargs):
 command=[str(value) for value in (args[0] if args else kwargs['args'])]
 job=_original_run(*args,**kwargs)
 ordinal=len(r['command_attempts'])
 supplied=kwargs.get('input')
 raw_input=supplied.encode() if isinstance(supplied,str) else supplied
 row=dict(command=command,exit_code=job.returncode,input=None if raw_input is None else raw_input.decode(),input_sha256=None if raw_input is None else sha(raw_input),streams={})
 for stream in ['stdout','stderr']:
  value=getattr(job,stream)
  assert value is not None, 'every actual command stream captured'
  raw=value.encode() if isinstance(value,str) else value
  path=P/('friendly-hortative-sena-installed-retry2-command-'+str(ordinal).zfill(4)+'-'+stream+'.gz')
  assert not path.exists();path.write_bytes(gzip.compress(raw,mtime=0))
  row['streams'][stream]=dict(path=str(path),sha256=sha(raw),archive_sha256=sha(path.read_bytes()),bytes=len(raw))
 r['command_attempts'].append(row);save()
 return job
subprocess.run=_recorded_run
'''
  text=text.replace(needle,recording+needle)
  text+='''
finally:
 subprocess.run=_original_run
 r.update(inputs_unchanged=all(sha(Path(p).read_bytes())==d for p,d in frozen.items()),source_unchanged=all(sha((W/p).read_bytes())==d for p,d in pkg['frozen_inputs'].items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==pkg['head'],index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))==index,protected_binaries_unchanged=all(sha(Path(p).read_bytes())==d for p,d in pkg['protected_binaries'].items()))
 if not all(r[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged']):r['state']='failed'
 save()
'''
 if name=='friendly_hortative_sena_installed_audit_retry1.py':
  text=text.replace("PREFIX+'installed-runtime.json.gz'","PREFIX+'installed-runtime-retry2.json.gz'")
 if name=='validate_friendly_hortative_sena_installed_audit_retry1.py':
  text=text.replace("'installed-runtime.json.gz'","'installed-runtime-retry2.json.gz'")
 if name=='test_friendly_hortative_sena_installed_audit_retry1.py':
  assert {n.name:ast.dump(n) for n in ast.walk(ast.parse(old)) if isinstance(n,ast.FunctionDef)}=={n.name:ast.dump(n) for n in ast.walk(ast.parse(text)) if isinstance(n,ast.FunctionDef)},'all original40 test bodies retained'
 if name=='continue_sena_installed_validation_retry1.py':
  needle="            ('packages', 'build_friendly_hortative_sena_nix_packages_retry1.py', prefix + 'nix-packages-retry1.json'),\n";assert text.count(needle)==1;text=text.replace(needle,'')
  text=text.replace("prefix + 'installed-runtime.json.gz'","prefix + 'installed-runtime-retry2.json.gz'")
  text=text.replace("prefix + 'installed-continuation-retry1.json'","prefix + 'installed-continuation-retry2.json'").replace("prefix + 'installed-continuation-retry1.log'","prefix + 'installed-continuation-retry2.log'")
  text=text.replace("'all-four-installed-stages-passed'","'all-three-replay-browser-audit-stages-passed'")
  text=text.replace("four actual installed stages passed","three actual remaining installed stages passed")
 ast.parse(text);dest=P/mapping[name];assert not dest.exists();dest.write_text(text);new[dest.name]=dict(sha256=sha(dest.read_bytes()),bytes=len(dest.read_bytes()))
manifest.write_text(json.dumps(dict(state='prepared-not-executed',originals=files,new_producers=new,source_head=package['head'],already_passed_packages_sha256=sha((P/'friendly-hortative-sena-nix-packages-retry1.json').read_bytes()),full_original40_test_bodies_retained=True,full_replay_stream_capture_added=True,source_or_original_capture_mutated=False),indent=2)+'\n')
print('Preserved',len(files),'full originals; six new programs use passed packages; exact lookup bytes and parsed JSON compared; every replay stream retained.')
