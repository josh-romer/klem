"""Preserve full original dictionary identities for corpus, novel and spacing owners."""
import gzip
import hashlib
import json
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
PROTO = BASE / 'explanatory-se-prototype'
sys.path.insert(0, str(PROTO / 'tools'))
from native_lmf import entry, feature

read = lambda p: json.loads(gzip.decompress(p.read_bytes()) if p.suffix == '.gz' else p.read_bytes())
source = read(OUT / 'native-closure.json.gz')
cohorts = read(OUT / 'cohorts.json.gz')
broad = read(OUT / 'broad.json.gz')
expected = {}
for projection in [source['entries'], cohorts['complete_native_entries'], broad['complete_native_entries']]:
    for ident, value in projection.items():
        if ident in expected:
            assert expected[ident] == value, ('inconsistent full owner', ident)
        expected[ident] = value
needed = set(expected)
spacing_owners = []
for observation in broad['individual_spacing_additions']:
    for segment in observation['hypothesis']['records'] + observation['hypothesis'].get('joined_contexts', []):
        for owner in segment['dictionary']['lemmas']:
            for summary in owner['entries']:
                needed.add(summary['id'])
                spacing_owners.append(summary)
originals = {}
exports = {}
for path in sorted((BASE / 'dictionary-restoration/2026-09').rglob('*.json')):
    raw = path.read_bytes()
    selected = []
    for value in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
        ident = 'krdict:' + value['val']
        if ident not in needed or ident in originals or feature(value, 'lexicalUnit') in {'관용구', '속담'}:
            continue
        projected = entry(value)
        if ident in expected:
            assert projected == expected[ident], ('original full Native fields differ', ident)
        originals[ident] = value
        selected.append(ident)
    if selected:
        exports[path.name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw), 'ids': selected}
assert set(originals) == needed
entries = {i: entry(originals[i]) for i in sorted(needed)}
for summary in spacing_owners:
    assert all(summary[k] == entries[summary['id']][k] for k in ['id', 'headword', 'homonym', 'pos'])
assert all(originals[i] == value for i, value in source['original_native_entries'].items())
report = {'state': 'complete-distribution-native-closure-preserved', 'entries': entries,
          'original_native_entries': originals, 'original_exports': exports,
          'capture_sha256': {name: hashlib.sha256((OUT / name).read_bytes()).hexdigest()
                             for name in ['native-closure.json.gz', 'cohorts.json.gz', 'broad.json.gz']},
          'producer': {'text': Path(__file__).read_text(), 'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
          'scope': 'Every complete original source, corpus, novel and independently replayed spacing owner. Exact original LMF fields and full projections preserved; observed candidates do not define grammatical or contextual gold.'}
for name, value in [('explanatory-se-distribution-native.json', {'LexicalResource': {'Lexicon': {'LexicalEntry': [originals[i] for i in sorted(needed)]}}}),
                    ('explanatory-se-distribution-entries.json', entries)]:
    destination = PROTO / 'tests/fixtures' / name
    assert not destination.exists()
    destination.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
destination = OUT / 'distribution-native-closure.json.gz'
assert not destination.exists()
destination.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
(PROTO / 'docs/explanatory-se-distribution-native-closure.json.gz').write_bytes(destination.read_bytes())
print('Preserved complete distribution Native closure:', len(entries), 'original identities.', flush=True)
