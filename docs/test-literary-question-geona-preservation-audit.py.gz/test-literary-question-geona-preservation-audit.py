"""Reject missing contexts/rows and fabricated candidate preservation claims."""
import copy,importlib.util,unittest
from functools import lru_cache
spec=importlib.util.spec_from_file_location('audit','/tmp/klem-literary-question-geona-preservation-audit.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);a.read=lru_cache(maxsize=None)(a.read);R=a.inputs()
def replace(value,path,fn):
 if not path:return fn(copy.deepcopy(value))
 result=value.copy();result[path[0]]=replace(value[path[0]],path[1:],fn);return result
class Controls(unittest.TestCase):
 def reject(self,index,path,fn):
  reports=list(R);reports[index]=replace(reports[index],path,fn)
  with self.assertRaises((AssertionError,KeyError,ValueError,TypeError,StopIteration)):a.inspect(*reports)
 def test_actual_complete_captures(self):self.assertEqual(a.inspect(*R)['individual_unjudged_additions'],44)
 def test_missing_full_mode(self):self.reject(0,['comparisons'],lambda r:r[:-1])
 def test_unchanged_stream_cannot_drift(self):self.reject(0,['comparisons',1,'after_jsonl_sha256'],lambda _:'0'*64)
 def test_individual_id_is_derived(self):self.reject(0,['individual_additions',0,'id'],lambda x:x+'invented')
 def test_original_context_is_bound(self):self.reject(0,['individual_additions',0,'complete_original_line'],lambda x:x+' invented')
 def test_original_utf8_span(self):self.reject(0,['comparisons',0,'changed_frames',0,'after','span','start'],lambda n:n+1)
 def test_structural_candidate_is_not_context_gold(self):self.reject(0,['individual_additions',0,'contextual_verdict'],lambda _:'correct')
 def test_prior_native_assessment_is_retained(self):self.reject(0,['comparisons',0,'changed_frames',0,'before','dictionary','readings',0,'status'],lambda _:'fabricated')
 def test_original_gold_row(self):self.reject(1,['corpora',0,'original_converted_rows',0,'surface'],lambda x:x+'거나')
 def test_original_recovered_lemma_groups(self):self.reject(1,['corpora',0,'comparisons',0,'after','recovered'],lambda n:n+1)
 def test_candidate_summary_cannot_hide_errors(self):self.reject(1,['corpora',0,'after_summary','candidate_count_sum'],lambda n:n+1)
 def test_complete_partition(self):self.reject(1,['corpora'],lambda rows:rows[:-1])
 def test_historical_source_cannot_disappear(self):self.reject(2,['source_files_sha256'],lambda d:{k:v for i,(k,v) in enumerate(d.items()) if i})
 def test_historical_origin_is_bound(self):
  word=next(iter(R[2]['origins']));self.reject(2,['origins',word,0,'source_sha256'],lambda _:'0'*64)
if __name__=='__main__':unittest.main()
