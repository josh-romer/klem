"""Validate the exact original ledger and every reviewed later append."""
import datetime,hashlib,json,re,subprocess
from pathlib import Path
prep=Path(__file__).resolve().parent;work=Path('/tmp/klem-expression-conjectural-main');out=prep/'combined-historical-ledger-repair.json';assert not out.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
files=[work/n for n in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=work).decode().split('\0')[:-1]]+[Path(__file__)];frozen={str(p):sha(p) for p in files}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip();index=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=work)).hexdigest()
r=dict(state='running',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),frozen_inputs=frozen,head=head,index_sha256=index,runs=[],producer=dict(text=Path(__file__).read_text(),sha256=sha(__file__)))
save=lambda:out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');save()
commands=[(['python3','tools/formal_volitional_ledger_audit.py'],None),(['python3','-m','unittest','discover','-s','tools','-p','test_formal_volitional_ledger_audit.py'],11),(['python3','-m','unittest','discover','-s','tools','-p','test_literary_question_geona_runtime.py'],94),(['python3','tools/review_inventory.py','--verify'],None),(['python3','-m','unittest','discover','-s','tools','-p','test_review_inventory.py'],10)]
try:
 for i,(command,count) in enumerate(commands):
  log=prep/f'combined-historical-ledger-repair-{i}.log';assert not log.exists()
  with log.open('xb') as stream:job=subprocess.run(command,cwd=work,stdout=stream,stderr=subprocess.STDOUT)
  r['runs'].append(dict(command=command,exit_code=job.returncode,log_sha256=sha(log)));save();assert job.returncode==0,(i,str(log))
  if count is not None:
   raw=log.read_bytes();matches=re.findall(rb'Ran (\d+) tests? in ',raw);assert len(matches)==1 and int(matches[0])==count and raw.rstrip().endswith(b'OK');r['runs'][-1]['tests']=count;save()
  print('passed',i,count,flush=True)
 r.update(state='passed',controls=115,exit_code=0)
except Exception as error:r.update(state='failed',error=str(error));raise
finally:
 r.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),inputs_unchanged=all(sha(p)==h for p,h in frozen.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==head,index_unchanged=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=work)).hexdigest()==index);save()
assert r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged']
