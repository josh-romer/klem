"""Preserve and extend the strict historical ledger verifier with reviewed Gena24."""
import ast, gzip, hashlib, json, subprocess
from pathlib import Path
P=Path(__file__).resolve().parent
W=P.parent/'friendly-command-gena'
sha=lambda b:hashlib.sha256(b).hexdigest()
names=['tools/literary_question_geona_runtime.py','tools/test_literary_question_geona_runtime.py','flake.nix']
manifest=P/'friendly-command-gena-historical-ledger-originals.json'
assert not manifest.exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
failed=json.loads((P/'friendly-command-gena-promoted-complete-nix-gate-retry1.json').read_bytes())
assert failed['state']=='failed' and all(failed[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged'])
proof={}
for name in names:
 raw=(W/name).read_bytes(); dest=P/('friendly-command-gena-historical-ledger-original-'+name.replace('/','-')+'.gz')
 assert not dest.exists(); dest.write_bytes(gzip.compress(raw,mtime=0))
 proof[name]=dict(path=str(dest),source_sha256=sha(raw),archive_sha256=sha(dest.read_bytes()))
manifest.write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip(),files=proof),indent=2)+'\n')
path=W/names[0]; raw=path.read_text(); needle="    ('gentle-command-class-interaction-validity.json',3,'655f08927753cc454373a47dff559e77b08b1afc80cc46c84bdf2abbd8bd5026','gentle-command actual derived class'),\n"
assert raw.count(needle)==1
suite=W/'tests/fixtures/friendly-command-gena-validity.json'
assert sha(suite.read_bytes())=='52dc5dae1dd3218c049be2a5f7f89e741fd9b166177102bf361892584188ed3b'
added="    ('friendly-command-gena-validity.json',24,'52dc5dae1dd3218c049be2a5f7f89e741fd9b166177102bf361892584188ed3b','friendly-command Gena preauthored'),\n"
new=raw.replace(needle,needle+added)
assert [ast.dump(n) for n in ast.walk(ast.parse(raw)) if isinstance(n,ast.Assert)]==[ast.dump(n) for n in ast.walk(ast.parse(new)) if isinstance(n,ast.Assert)]
path.write_text(new)
path=W/names[1]; old=path.read_text(); needle="'gentle-command-class-interaction-validity.json']:\n"
assert old.count(needle)==2
new=old.replace(needle,"'gentle-command-class-interaction-validity.json','friendly-command-gena-validity.json']:\n")
extra=''' def test_exact_current_gena_tail_and_parent_pass(self):
  suite=audit.read(audit.ROOT/'tests/fixtures/friendly-command-gena-validity.json')
  self.assertEqual(len(self.current['cases']),35764)
  self.assertEqual(self.current['cases'][35740:],suite['cases'])
  parent=audit.read(audit.ROOT/'docs/friendly-command-gena-parent-validity.json.gz')
  self.assertEqual(self.ledger_through(35740),parent)
  for ledger in [self.current,parent]:
   self.assertEqual(audit.verify_ledger(ledger,self.proposal)['preserved_cases'],34920)
 def test_each_gena_judgment_change_cannot_pass(self):
  for index in range(35740,35764):
   with self.subTest(case=self.current['cases'][index]['id']):
    c=copy.deepcopy(self.current);c['cases'][index]['judgments'][0]['reason']='changed original Gena rationale'
    with self.assertRaisesRegex(AssertionError,'complete append-only ledger'):audit.verify_ledger(c,self.proposal)
 def test_gena_case_order_change_cannot_pass(self):
  c=copy.deepcopy(self.current);c['cases'][35740:]=c['cases'][35740:][::-1]
  with self.assertRaisesRegex(AssertionError,'complete append-only ledger'):audit.verify_ledger(c,self.proposal)
 def test_missing_gena_case_cannot_pass(self):
  c=copy.deepcopy(self.current);c['cases'].pop()
  with self.assertRaisesRegex(AssertionError,'complete append-only ledger'):audit.verify_ledger(c,self.proposal)
 def test_gena_unreviewed_extra_case_cannot_pass(self):
  c=copy.deepcopy(self.current);extra=copy.deepcopy(c['cases'][-1]);extra['id']='unreviewed-gena-extra';c['cases'].append(extra)
  with self.assertRaisesRegex(AssertionError,'complete append-only ledger'):audit.verify_ledger(c,self.proposal)
 def test_gena_source_identity_change_cannot_pass(self):
  c=copy.deepcopy(self.current);c['sources']['friendly-command-gena-66968']='https://invalid.example/owner'
  with self.assertRaisesRegex(AssertionError,'complete append-only ledger'):audit.verify_ledger(c,self.proposal)
 def test_gena_source_omission_cannot_pass(self):
  c=copy.deepcopy(self.current);c['sources'].pop('friendly-command-gena-66968')
  with self.assertRaisesRegex(AssertionError,'complete append-only ledger'):audit.verify_ledger(c,self.proposal)
 def test_gena_unused_source_addition_cannot_pass(self):
  c=copy.deepcopy(self.current);c['sources']['unreviewed-gena-source']='https://invalid.example/owner'
  with self.assertRaisesRegex(AssertionError,'complete append-only ledger'):audit.verify_ledger(c,self.proposal)
 def test_gena_ledger_metadata_change_cannot_pass(self):
  c=copy.deepcopy(self.current);c['invented_metadata']='changed'
  with self.assertRaisesRegex(AssertionError,'complete append-only ledger'):audit.verify_ledger(c,self.proposal)
 def test_gena_forbidden_promotion_cannot_pass(self):
  c=copy.deepcopy(self.current);case=next(case for case in c['cases'][35740:] if case['judgments'][0]['verdict']=='forbidden');case['judgments'][0]['verdict']='required'
  with self.assertRaisesRegex(AssertionError,'complete append-only ledger'):audit.verify_ledger(c,self.proposal)
 def test_coordinated_gena_fixture_rewrite_cannot_pass(self):
  import ast
  c=copy.deepcopy(self.current);suite=audit.read(audit.ROOT/'tests/fixtures/friendly-command-gena-validity.json');later=audit.read(audit.ROOT/'docs/additive-ppundeoreo-proposed-ledger.json.gz')
  c['cases'][-1]['judgments'][0]['reason']='coordinated changed Gena rationale';suite['cases'][-1]=copy.deepcopy(c['cases'][-1])
  tree=ast.parse((audit.ROOT/'tools/literary_question_geona_runtime.py').read_text())
  reviewed=next(ast.literal_eval(node.value) for node in ast.walk(tree) if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='reviewed_appends' for t in node.targets))
  with tempfile.TemporaryDirectory() as directory:
   root=Path(directory);fixtures=root/'tests/fixtures';fixtures.mkdir(parents=True)
   for name,_,_,_ in reviewed:(fixtures/name).write_bytes((audit.ROOT/'tests/fixtures'/name).read_bytes())
   (fixtures/'friendly-command-gena-validity.json').write_text(audit.json.dumps(suite))
   with patch.object(audit,'ROOT',root):
    with self.assertRaisesRegex(AssertionError,'reviewed friendly-command Gena preauthored fixture bytes'):audit.verify_ledger(c,self.proposal,later)
'''
needle="if __name__=='__main__':unittest.main()\n";assert new.count(needle)==1
new=new.replace(needle,extra+needle)
old_methods={n.name:ast.dump(n) for n in ast.walk(ast.parse(old)) if isinstance(n,ast.FunctionDef)}
new_methods={n.name:ast.dump(n) for n in ast.walk(ast.parse(new)) if isinstance(n,ast.FunctionDef)}
assert all(new_methods[name]==body for name,body in old_methods.items() if name!='ledger_through')
assert [ast.dump(n) for n in ast.walk(ast.parse(old_methods and old)) if isinstance(n,ast.Assert)]==[ast.dump(n) for n in ast.walk(ast.parse(new.split(extra)[0]+needle)) if isinstance(n,ast.Assert)]
path.write_text(new)
print('Preserved three originals; retained every old assertion/test; exact Gena24 tuple and 11 controls added.')
