"""Archive complete installed proof and all original wrapper failures without rewriting them."""
import gzip,hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent/'friendly-hortative-sena';D=W/'docs'
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=D/'friendly-hortative-sena-installed-proof-archive.json';assert not manifest.exists()
controls=json.loads((P/'friendly-hortative-sena-installed-audit-validation-retry6.json').read_bytes());assert controls['state']=='passed' and controls['tests_run']==43 and not controls['errors'] and not controls['failures']
assert all(controls[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged'])
package=json.loads((P/'friendly-hortative-sena-nix-packages-retry1.json').read_bytes());assert package['state']=='passed'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
assert all(sha((W/n).read_bytes())==digest for n,digest in package['frozen_inputs'].items())
installed=json.loads(gzip.decompress((P/'friendly-hortative-sena-installed-runtime-completion-audit.json.gz').read_bytes()));assert installed['state']=='passed' and installed['original_attempt_state']=='failed' and installed['supplementary_audit_executed_cli_commands']==0
names=set([
 'friendly-hortative-sena-complete-nix-gate.json','friendly-hortative-sena-complete-nix-gate.log','run_complete_friendly_hortative_sena_nix_gate.py',
 'friendly-hortative-sena-nix-packages.json','friendly-hortative-sena-nix-packages.log','friendly-hortative-sena-release-rust.log',
 'friendly-hortative-sena-nix-packages-retry1.json','friendly-hortative-sena-nix-packages-retry1.log','friendly-hortative-sena-release-rust-retry1.log','build_friendly_hortative_sena_nix_packages.py','build_friendly_hortative_sena_nix_packages_retry1.py',
 'friendly-hortative-sena-documentation-scope.json','friendly-hortative-sena-documentation-scope.log','run_friendly_hortative_sena_documentation_scope.py',
 'friendly-hortative-sena-installed-runtime.json.gz','friendly-hortative-sena-installed-runtime-progress.json',
 'friendly-hortative-sena-installed-runtime-retry2.json.gz','friendly-hortative-sena-installed-runtime-progress-retry2.json',
 'friendly-hortative-sena-installed-runtime-retry3.json.gz','friendly-hortative-sena-installed-runtime-progress-retry3.json',
 'friendly-hortative-sena-installed-runtime-completion-audit.json.gz','audit_completed_sena_runtime.py',
 'friendly-hortative-sena-installed-browser.json','friendly-hortative-sena-installed-browser-runtime.json','friendly-hortative-sena-installed-browser-runtime.log','friendly-hortative-sena-browser.mjs',
 'friendly-hortative-sena-installed-browser-desktop.png','friendly-hortative-sena-installed-browser-mobile.png','friendly-hortative-sena-installed-visual-review.json',
 'friendly-hortative-sena-installed-audit-validation.json','friendly-hortative-sena-installed-audit-validation.log',
 'friendly-hortative-sena-installed-audit-validation-retry5.json','friendly-hortative-sena-installed-audit-validation-retry5.log',
 'friendly-hortative-sena-installed-audit-validation-retry6.json','friendly-hortative-sena-installed-audit-validation-retry6.log',
 'friendly-hortative-sena-latency-retry5-preparation-failure.json','friendly-hortative-sena-latency-retry5-preparation-failure-producer.py.gz',
])
for pattern in ['*installed*retry*.py','continue_sena_installed_validation_retry*.py','friendly-hortative-sena-installed-continuation*.json','friendly-hortative-sena-installed-continuation*.log','friendly-hortative-sena-installed-retry2-command-*.gz','friendly-hortative-sena-installed-retry3-command-*.gz','prepare_sena*.py','friendly-hortative-sena-*preparation.json']:
 names.update(p.name for p in P.glob(pattern) if p.is_file())
# Preserve the exact original shared continuation that failed before creating new versions.
shared=json.loads((P/'friendly-hortative-sena-installed-retry1-preparation.json').read_bytes())
old_shared=shared['originals']['continue_friendly_installed_validation.py'];packed=(P/old_shared['path']).read_bytes();assert sha(packed)==old_shared['archive_sha256'];old_body=gzip.decompress(packed);assert sha(old_body)==old_shared['source_sha256']
files={}
def add(name,raw):
 output=D/('friendly-hortative-sena-installed-proof-'+name+'.gz');assert not output.exists();output.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(output.read_bytes())==raw
 files[name]=dict(path=output.name,source_sha256=sha(raw),archive_sha256=sha(output.read_bytes()),bytes=len(raw))
for name in sorted(names):add(name,(P/name).read_bytes())
add('continue_friendly_installed_validation.py',old_body)
manifest.write_text(json.dumps(dict(state='actual-complete-installed-Sena-proof-preserved',files=files,source_head=package['head'],source_files=len(package['frozen_inputs']),actual_release_rust=dict(passed=1212,failed=0,ignored=1,batches=257),full_actual_replay_commands=253,full_completed_replay_streams=506,browser_decisions=150,browser_diagrams=114,browser_exports=12,browser_native_entries=37,controls_passed=43,visual_review_passed=True,original_failed_receipts_producers_logs_partial_streams_retained=True,supplementary_completed_output_audit_runs_no_replay=True,shared_promotion=False,main_integration=False,quiet_performance_and_contextual_review='pending'),indent=2)+'\n')
print('Archived',len(files),'complete original artifacts; manifest',sha(manifest.read_bytes()),flush=True)
