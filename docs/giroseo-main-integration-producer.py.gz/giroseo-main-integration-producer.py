"""Verify the actual merge, retained evidence trees and all installed runtime inputs."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
PREP = ROOT / '.direnv/giroseo-prepared'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def tree(revision):
    result = {}
    for record in git('ls-tree', '-r', '-z', revision).split(b'\0'):
        if not record:
            continue
        metadata, name = record.split(b'\t', 1)
        result[name.decode()] = metadata.decode()
    return result


assert not git('status', '--porcelain'), 'clean actual main merge'
head = git('rev-parse', 'HEAD').decode().strip()
preparation = json.loads((PREP / 'main-merge-preparation.json').read_bytes())
parents = git('show', '-s', '--format=%P', head).decode().split()
assert parents == [preparation['previous_main'], preparation['integration_parent']]
current = tree(head)
previous = tree(parents[0])
integration = tree(parents[1])
documentation = {'docs/coverage-checklist.md', 'docs/inventory-reviews.json',
                 'docs/inventory-review-queue.json', 'docs/formal-b-draft.md',
                 'docs/reported-experience-draft.md', 'docs/giroseo-draft.md'}
normalization = {'tools/test_giroseo_installed_audit.py'}
integration_changes = set(git('diff', '--name-only', preparation['merge_base'], parents[1]).decode().splitlines())
for path, value in previous.items():
    assert path in current, ('prior main evidence removed', path)
    if path not in integration_changes | documentation | normalization:
        assert current[path] == value, ('prior main evidence changed', path)
for path, value in integration.items():
    if path not in documentation | normalization:
        assert current[path] == value, ('validated integration byte changed', path)
old = json.loads(git('show', parents[0] + ':tests/fixtures/validity.json'))
ledger = json.loads((ROOT / 'tests/fixtures/validity.json').read_bytes())
assert ledger['cases'][:len(old['cases'])] == old['cases']
assert ledger == json.loads(git('show', parents[1] + ':tests/fixtures/validity.json'))
binding = json.loads((PREP / 'installed-source-binding.json').read_bytes())
profiles = {}
for name, profile in binding['profiles'].items():
    local = ROOT / 'web' if name == 'web-assets' else ROOT
    source = Path(profile['source'])
    for relative, expected in profile['files'].items():
        raw = (local / relative).read_bytes()
        assert raw == (source / relative).read_bytes(), relative
        assert sha(raw) == expected['sha256'] and len(raw) == expected['bytes'], relative
    profiles[name] = profile
assert {name:len(p['files']) for name,p in profiles.items()} == {'klem':1024, 'web-assets':18, 'corpus-adapter':1024}
queue = json.loads((ROOT / 'docs/inventory-review-queue.json').read_bytes())
assert queue['counts']['by_review'] == {'scoped':501, 'unreviewed':214}
proof = {'state':'actual-main-integration-passed', 'head':head, 'parents':parents,
         'tree':git('rev-parse', head + '^{tree}').decode().strip(),
         'retained_previous_main_files':len(previous), 'validated_integration_files':len(integration),
         'unchanged_integration_files':len(set(integration) - documentation - normalization),
         'intentional_document_updates':sorted(documentation),
         'syntax_preserving_whitespace_adjustment':sorted(normalization),
         'actual_installed_profiles':profiles, 'previous_main_cases':len(old['cases']),
         'main_cases':len(ledger['cases']), 'exact_previous_main_ledger_prefix':True,
         'actual_main_ledger_equals_validated_integration':True, 'queue_counts':queue['counts'],
         'scope':'Actual local merge with prior-main evidence retained and exact validated runtime inputs. '
                 'Combined Nix gate passed at e910d4d before the merge; every1024Rust/18frontend/1024adapter '
                 'selected input matches actual installed sources. Quiet performance and wider/contextual/independent review remain open.',
         'producer':{'text':Path(__file__).read_text(), 'sha256':sha(Path(__file__).read_bytes())}}
docs = ROOT / 'docs'
(docs / 'giroseo-main-integration.json.gz').write_bytes(gzip.compress((json.dumps(proof, indent=2)+'\n').encode(), mtime=0))
(docs / 'giroseo-main-integration-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
tracker = docs / 'coverage-checklist.md'
text = tracker.read_text().replace('The [main runtime parity proof](giroseo-main-integration-preparation.json.gz)',
                                  'The [actual main integration proof](giroseo-main-integration.json.gz)')
tracker.write_text(text)
p = docs / 'giroseo-draft.md'
text = p.read_text()
text += '\nActual local main integration is complete at `' + head[:7] + '`. The [merge proof](giroseo-main-integration.json.gz) retains both parent trees and every selected installed source byte.\n'
p.write_text(text)
p = docs / 'inventory-reviews.json'
reviews = json.loads(p.read_text())
changed = 0
for review in reviews['entries']:
    if any(e['path'] == 'docs/giroseo-draft.md' for e in review['evidence']):
        review['evidence'].append({'path':'docs/giroseo-main-integration.json.gz'})
        changed += 1
assert changed == 2
p.write_text(json.dumps(reviews, ensure_ascii=False, indent=2)+'\n')
print('Actual merge', head[:7], 'verified; runtime1024/18/1024 exact; prior ledger', len(old['cases']), '→', len(ledger['cases']), '; regenerate queue last')
