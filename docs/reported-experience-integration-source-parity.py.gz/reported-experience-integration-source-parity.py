"""Compare actual evaluated integration sources to the unchanged private prototype."""
import hashlib,json,subprocess
from pathlib import Path
PREP=Path(__file__).resolve().parent;ROOT=PREP.parent/'reported-experience-integration';PROTO=PREP.parent/'reported-experience-prototype'
sha=lambda data:hashlib.sha256(data).hexdigest()
profiles={}
for name in ['klem','web-assets','corpus-adapter']:
 source=Path(subprocess.check_output(['nix','eval','--offline','--raw','.#packages.x86_64-linux.'+name+'.src'],cwd=ROOT,text=True).strip())
 files={};base=ROOT/'web' if name=='web-assets' else ROOT;private=PROTO/'web' if name=='web-assets' else PROTO
 for path in source.rglob('*'):
  assert not path.is_symlink()
  if not path.is_file():continue
  namepath=str(path.relative_to(source));data=path.read_bytes()
  assert data==(base/namepath).read_bytes()==(private/namepath).read_bytes(),namepath
  files[namepath]={'bytes':len(data),'sha256':sha(data)}
 profiles[name]={'source':str(source),'files':files}
assert profiles['klem']['files']==profiles['corpus-adapter']['files']
# Every source selected by inventory evaluation must match the worktree, too.
source=Path(subprocess.check_output(['nix','eval','--offline','--raw','.#checks.x86_64-linux.inventory-review.src'],cwd=ROOT,text=True).strip());inventory={}
for path in source.rglob('*'):
 assert not path.is_symlink()
 if not path.is_file():continue
 name=str(path.relative_to(source));data=path.read_bytes();assert data==(ROOT/name).read_bytes(),name;inventory[name]={'bytes':len(data),'sha256':sha(data)}
assert all('tools/'+n in inventory for family in ['source','cohort','broad','corpora'] for n in [f'reported_experience_{family}_audit.py',f'test_reported_experience_{family}_audit.py'])
r={'state':'passed','profiles':profiles,'inventory_source':str(source),'inventory_files':inventory,'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'scope':'Actual staged Git-backed Nix source evaluation: every Rust/frontend/adapter selected source byte equals private prototype and integration. All complete inventory-source files also equal currentintegration. Private complete Rust still active; actual package and inventory builds/installed/current-source parity remain separate.'}
(PREP/'integration-source-parity.json').write_text(json.dumps(r,indent=2)+'\n');print('All actual package source profiles equal private prototype:',{k:len(v['files']) for k,v in profiles.items()},'inventoryfiles',len(inventory),flush=True)
