"""Append only the eight unchanged preauthored interaction judgments."""
import gzip
import hashlib
import json
from pathlib import Path

prep = Path(__file__).resolve().parent
root = Path('/tmp/klem-willingness-interactions')
out = prep / 'willingness-interaction-ledger-append.json'
assert not out.exists()
path = root / 'tests/fixtures/validity.json'
fixture = root / 'tests/fixtures/willingness-question-interaction-validity.json'
raw = path.read_bytes()
sha = lambda value: hashlib.sha256(value).hexdigest()
assert sha(raw) == '5f695ecf212ef16b5d932c1a43bdf0df3d570e3eea6d46f191953ddc8ea0f799'
parent = json.loads(raw)
suite = json.loads(fixture.read_bytes())
assert len(parent['cases']) == 35673 and len(suite['cases']) == 8
authored = json.loads(gzip.decompress((root / 'docs/willingness-question-interaction-proof-willingness-interaction-authored.json.gz').read_bytes()))
assert suite['cases'] == authored['cases'] and suite['sources'] == authored['sources']
assert len({c['id'] for c in suite['cases']}) == 8
assert not {c['id'] for c in suite['cases']} & {c['id'] for c in parent['cases']}
archive = root / 'docs/willingness-question-interaction-parent-validity.json.gz'
assert not archive.exists()
archive.write_bytes(gzip.compress(raw, mtime=0))
current = json.loads(raw)
for key, value in suite['sources'].items():
    assert key not in current['sources'] or current['sources'][key] == value
    current['sources'][key] = value
current['cases'].extend(suite['cases'])
updated = (json.dumps(current, ensure_ascii=False, indent=2) + '\n').encode()
prefix = raw.split(b'"cases": [', 1)[1].rsplit(b'\n  ]\n}', 1)[0]
assert updated.split(b'"cases": [', 1)[1].startswith(prefix)
assert current['cases'][:35673] == parent['cases']
assert {k: v for k, v in current.items() if k not in ['cases', 'sources']} == {k: v for k, v in parent.items() if k not in ['cases', 'sources']}
counts = {kind: sum(j['verdict'] == kind for c in current['cases'] for j in c['judgments']) for kind in ['required', 'forbidden']}
assert counts == {'required': 31412, 'forbidden': 4286}
path.write_bytes(updated)
r = {'state': 'eight-unchanged-interactions-appended', 'parent_sha256': sha(raw), 'current_sha256': sha(updated),
     'parent_case_prefix_sha256': sha(prefix), 'parent_case_prefix_bytes': len(prefix),
     'fixture_sha256': sha(fixture.read_bytes()), 'original_cases': 35673, 'added_cases': 8,
     'added_required': 4, 'added_forbidden': 4, 'counts': counts,
     'every_original_case_byte_and_metadata_retained': True, 'unjudged_policy_proposals_promoted': False,
     'inventory_dispositions_changed': False, 'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())}}
out.write_text(json.dumps(r, indent=2) + '\n')
print('Appended8unchanged interaction cases;', len(prefix), sha(prefix), 'original case prefix;', counts, flush=True)
