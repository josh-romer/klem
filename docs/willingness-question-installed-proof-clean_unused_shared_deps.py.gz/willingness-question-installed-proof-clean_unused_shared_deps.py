"""Remove only unused dependency cache files, preserving executable artifacts."""
from pathlib import Path
import hashlib
import json
import os
import shutil

base = Path('/tmp/klem-expression-conjectural-main-target/debug')
deps = base / 'deps'
out = Path('/home/josh/projects/klem/.direnv/willingness-question-prepared/unused-shared-compiler-cache-cleanup.json')
assert not out.exists()
digest = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
protected = {str(p): digest(p) for folder in [base, base / 'examples']
             for p in folder.iterdir() if p.is_file() and os.access(p, os.X_OK)}
assert protected
referencing = []
other_user_processes = []
restricted_maps = []
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit() or int(proc.name) == os.getpid():
        continue
    if proc.stat().st_uid != os.getuid():
        try:
            command = (proc / 'cmdline').read_bytes()
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            command = b''
        assert str(base).encode() not in command, ('other-user target command', proc.name)
        other_user_processes.append(proc.name)
        continue
    try:
        raw = (proc / 'cmdline').read_bytes()
        try:
            raw += (proc / 'maps').read_bytes()
        except PermissionError:
            restricted_maps.append({'pid': proc.name, 'cmdline': raw.decode(errors='replace').replace(chr(0), ' ')})
        links = [proc / 'cwd', proc / 'exe']
        try:
            links += list((proc / 'fd').iterdir())
        except PermissionError:
            pass
    except (FileNotFoundError, ProcessLookupError):
        continue
    for link in links:
        try:
            raw += os.readlink(link).encode()
        except (OSError, ProcessLookupError):
            continue
    if str(base).encode() in raw:
        referencing.append(proc.name)
assert not referencing, ('compiler cache is in use', referencing)
files = [p for p in deps.iterdir() if p.is_file() and not p.is_symlink()]
receipt = {'state': 'prepared', 'scope': 'Only unused debug/deps regular files; all top-level and example executables preserved.',
           'files': len(files), 'regular_bytes': sum(p.stat().st_size for p in files),
           'protected_top_binaries': protected, 'process_references': referencing, 'other_user_cmdline_only': other_user_processes, 'restricted_maps': restricted_maps}
out.write_text(json.dumps(receipt, indent=2) + '\n')
for p in files:
    p.unlink()
assert all(digest(Path(p)) == sha for p, sha in protected.items())
receipt.update(state='passed', protected_binaries_unchanged=True, tmp_available_bytes=shutil.disk_usage('/tmp').free)
out.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ['state', 'files', 'regular_bytes', 'protected_binaries_unchanged', 'tmp_available_bytes']}), flush=True)
