"""Compare the entire novel before/after named-title spacing with full contexts."""
import gzip,hashlib,itertools,json,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');SOURCE=ROOT/'data/books/mujeong.txt';DB=ROOT/'data/dictionaries/krdict/krdict.db';BEFORE=Path('/home/josh/projects/klem/.direnv/surname-runtime-target/debug/klem');AFTER=Path('/home/josh/projects/klem/.direnv/named-title-target/debug/klem');OUT=Path('/tmp/klem-named-title-novel.json.gz');assert not OUT.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest();inputs={str(p):sha(p) for p in [SOURCE,DB,BEFORE,AFTER,Path(__file__)]};original=SOURCE.read_bytes();runs=[];changes=[]
key=lambda h:(h.get('rule'),h['spaced'],tuple(h['inserted_at']))
for mode,flag in [('headword','--dict-only'),('compatible','--dict-compatible')]:
 common=['text',str(SOURCE),'--dictionary',str(DB),'--proper-names','--suggest-spacing',flag];commands=[[str(b),*common] for b in [BEFORE,AFTER]];jobs=[subprocess.Popen(c,stdout=subprocess.PIPE,cwd=ROOT) for c in commands];digests=[hashlib.sha256(),hashlib.sha256()];count=cursor=0;ids=[]
 try:
  for lines in itertools.zip_longest(*(job.stdout for job in jobs)):
   assert all(line is not None for line in lines);count+=1
   for h,line in zip(digests,lines,strict=True):h.update(line)
   if lines[0]==lines[1]:
    record=json.loads(lines[0]);assert record['span']['start']==cursor;cursor=record['span']['end'];continue
   old,new=[json.loads(line) for line in lines];assert {k:v for k,v in old.items() if k!='spacing'}=={k:v for k,v in new.items() if k!='spacing'}
   span=new['span'];assert span['start']==cursor and original[cursor:span['end']].decode()==new['surface'];cursor=span['end']
   assert old.get('spacing') and new.get('spacing');a,b=old['spacing'],new['spacing'];oldkeys=[key(h) for h in a['alternatives']]
   assert [key(h) for h in b['alternatives'] if key(h) in oldkeys]==oldkeys
   assert all(h in b['alternatives'] for h in a['alternatives'])
   added=[h for h in b['alternatives'] if key(h) not in oldkeys];assert all(h.get('rule')=='spacing.proper_name_title' for h in added)
   left=original.rfind(b'\n',0,span['start'])+1;right=original.find(b'\n',span['end']);right=len(original) if right<0 else right
   id='named-title-novel-'+hashlib.sha256(json.dumps([mode,count,new],ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:24]
   changes.append({'id':id,'mode':mode,'record':count,'before':old,'after':new,'additions':added,'complete_original_line':original[left:right].decode(),'contextual_verdict':'unjudged','independent_review':'pending'});ids.append(id)
  codes=[job.wait() for job in jobs];assert codes==[0,0] and count==179112 and cursor==len(original)
 finally:
  for job in jobs:
   if job.poll() is None:job.terminate();job.wait()
 runs.append({'mode':mode,'commands':commands,'records':count,'jsonl_sha256':[h.hexdigest() for h in digests],'observations':ids});print(mode,count,'complete novel frames',len(ids),'changed',flush=True)
assert all(sha(p)==digest for p,digest in inputs.items());r={'state':'complete-novel-named-title-preservation-passed','runs':runs,'individual_observations':changes,'inputs_unchanged':True,'frozen_inputs':inputs,'scope':'All358224paired frames preserve original bytes, word/candidate/dictionary data, old hypotheses/order; additions have complete original context and stable IDs. This is debug novel coverage, not all corpora or contextual/installed certification.'};OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Complete novel comparisons retained all prior hypotheses')
