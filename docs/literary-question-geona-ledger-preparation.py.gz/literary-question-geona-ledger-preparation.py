import collections,gzip,hashlib,json
from pathlib import Path
P=Path('/tmp/klem-literary-question-geona-prototype/tests/fixtures');OUT=Path('/tmp/klem-literary-question-geona-proposed-ledger.json.gz');assert not OUT.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
paths={n:P/n for n in ['validity.json','literary-question-geona-original-cases.json','literary-question-geona-authored-boundaries.json','literary-question-geona-owner-extension-cases.json']}
hashes={n:sha(p.read_bytes()) for n,p in paths.items()};data={n:json.loads(p.read_bytes()) for n,p in paths.items()};before=data['validity.json'];cases=[];excluded=[];origins=[]
for original in data['literary-question-geona-original-cases.json']:
 expected=original['expected'];source=original['source_occurrence']['source'].split(':')[1];judgment={'id':'original-exact-path','source':'literary-question-geona-'+source,'verdict':'required',**expected,'reason':'Exact raw segmentation of the complete original source example, preserving its earlier -(으)ㄹ까 parent and Native homonyms. The original 좋다 example retains its restrictive verb-note tension as Unknown. Context and independent review remain unjudged.'}
 cases.append({'id':original['id'],'surface':original['surface'],'judgments':[judgment]});origins.append({'id':original['id'],'origin':'literary-question-geona-original-cases.json','source_occurrence':original['source_occurrence']})
for filename in ['literary-question-geona-authored-boundaries.json','literary-question-geona-owner-extension-cases.json']:
 for proposal in data[filename]['cases']:
  if proposal['proposal'] not in {'required','forbidden'}:excluded.append({'id':proposal['id'],'proposal':proposal['proposal'],'origin':filename});continue
  source='80970' if proposal['surface'].endswith('을거나') else '80972'
  judgment={'id':'exact-finite-path','source':'literary-question-geona-'+source,'verdict':proposal['proposal'],**{k:proposal[k] for k in ['lemmas','lemma_kinds','morphemes','morpheme_kinds','required_rules']},'reason':'Authored finite structural allomorph or immediate-owner case based on the two original source entries and preserved earlier parent paths. The judgment constrains only this ordered raw path and rule provenance. Headword, Native attachment policy, lexical versus auxiliary role, context and independent review remain separate; all conditional and Native-policy-only proposals are excluded.'}
  cases.append({'id':proposal['id'],'surface':proposal['surface'],'judgments':[judgment]});origins.append({'id':proposal['id'],'origin':filename})
assert len(cases)==61 and len(excluded)==21
counts=collections.Counter(c['judgments'][0]['verdict'] for c in cases);assert counts=={'required':50,'forbidden':11}
all_ids={c['id'] for c in before['cases']};assert len(all_ids)==len(before['cases']) and not all_ids.intersection(c['id'] for c in cases)
after={**before,'sources':{**before['sources'],**{f'literary-question-geona-{i}':f'https://krdict.korean.go.kr/kor/dicSearch/SearchView?ParaWordNo={i}' for i in [80970,80972]}},'cases':before['cases']+cases}
assert after['cases'][:len(before['cases'])]==before['cases'] and all(after['sources'][k]==v for k,v in before['sources'].items())
assert all(sha(p.read_bytes())==hashes[n] for n,p in paths.items())
result={'state':'proposed-not-applied','input_sha256':hashes,'before_case_count':len(before['cases']),'new_cases':cases,'new_counts':dict(counts),'excluded_conditional_native_cases':excluded,'origins':origins,'proposed_ledger':after,'scope':'61 scoped raw structural cases only; preserve the full old case/source prefix; 15 conditional and6 Native-policy-only cases stay in separate fixtures. Original adjective example is explicitly required raw while Native restrictive-source tension remains Unknown. Broad44 novel/candidate path additions stay unjudged. This draft has not been applied or checked by the Rust global ledger evaluator.'}
OUT.write_bytes(gzip.compress((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Prepared append-only61 raw judgments:50required11forbidden; excluded21conditional/Native; old',len(before['cases']),'unchanged.')
