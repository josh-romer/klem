"""Exercise the new audit from the actual Git-backed Nix selected source."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
OUT = PREP / 'gentle-command-selected-runtime-audit.json'
LOG = PREP / 'gentle-command-selected-runtime-audit.log'
binding = json.loads((PREP / 'gentle-command-nix-packages-retry1.json').read_bytes())
SOURCE = Path(binding['inventory_source'])
assert not OUT.exists() and not LOG.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
frozen = binding['inventory_source_files']
assert all(sha((SOURCE/n).read_bytes()) == digest for n, digest in frozen.items())
r = dict(state='running', package_capture_head=binding['head'], selected_source=str(SOURCE),
         source_files=frozen, results=[], producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
         scope='Actual selected source executes complete gentle runtime audit and all35corruption controls. Selection proof alone is not a completed full Nix inventory or installed/browser validation.')
save = lambda: OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2)+'\n')
save()
commands = [['python3', 'tools/gentle_command_runtime_audit.py'],
            ['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_gentle_command_runtime_audit.py']]
with LOG.open('xb') as stream:
    for command in commands:
        job = subprocess.run(command, cwd=SOURCE, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        stream.write(job.stdout); stream.flush()
        r['results'].append(dict(command=command, exit_code=job.returncode, output=job.stdout.decode()))
        save()
        if job.returncode: break
r.update(inputs_unchanged=all(sha((SOURCE/n).read_bytes()) == digest for n, digest in frozen.items()),
         controls=sum(int(n) for row in r['results'] for n in re.findall(r'Ran (\d+) tests? in', row['output'])),
         log_sha256=sha(LOG.read_bytes()), finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
r['state'] = 'passed' if len(r['results']) == 2 and all(row['exit_code'] == 0 for row in r['results']) and r['controls'] == 35 and r['inputs_unchanged'] else 'failed'
save()
print(r['state'], r['controls'], 'controls from actual selected source;', len(frozen), 'unchanged files', flush=True)
raise SystemExit(0 if r['state'] == 'passed' else 1)
