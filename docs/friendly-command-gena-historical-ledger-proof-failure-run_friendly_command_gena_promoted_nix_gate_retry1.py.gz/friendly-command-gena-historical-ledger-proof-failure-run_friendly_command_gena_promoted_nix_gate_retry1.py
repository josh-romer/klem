"""Run all four Nix checks for the committed actual 35764/520 Gena promotion."""
import datetime
import gzip
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-command-gena'
OUT = P / 'friendly-command-gena-promoted-complete-nix-gate-retry1.json'
LOG = P / 'friendly-command-gena-promoted-complete-nix-gate-retry1.log'
BUILD = Path('/var/tmp/klem-friendly-command-gena-promoted-nix-build')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=W)


def main():
    assert not OUT.exists() and not LOG.exists()
    rust_path = P / 'friendly-command-gena-promotion-full-rust-results-audit.json'
    rust = json.loads(rust_path.read_bytes())
    assert rust['state'] == 'passed' and rust['targets'] == 260 and rust['commands'] == 264
    assert rust['totals']['failed'] == 0 and rust['totals']['ignored'] == 1
    assert all(rust[k] for k in ['source_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged'])
    doctest_path = P / 'friendly-command-gena-promotion-doctest.json'
    doctest = json.loads(doctest_path.read_bytes())
    assert doctest['state'] == 'passed' and doctest['exit_code'] == 0
    assert doctest['rust_totals'] == dict(passed=1, failed=0, ignored=0)
    assert doctest['all_target_audit_sha256'] == sha(rust_path.read_bytes())
    assert doctest['current_cargo_inventory_verified'] and doctest['metadata_exit_code'] == 0
    assert doctest['current_metadata_sha256'] == sha(doctest['current_metadata_raw'].encode())
    assert all(doctest[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged'])
    full_rust = json.loads((P / 'friendly-command-gena-promotion-full-rust.json').read_bytes())
    assert sha((P / 'friendly-command-gena-promotion-full-rust.json').read_bytes()) == rust['original_receipt_sha256']
    assert not git('status', '--porcelain'), 'commit the complete promotion and its evidence first'
    frozen = {name: sha((W / name).read_bytes()) for name in git('ls-files', '-z').decode().split('\0')[:-1]}
    for name, digest in full_rust['frozen_inputs'].items():
        if name not in ['docs/coverage-checklist.md', 'docs/inventory-review-queue.json', 'tools/friendly_command_audit.py', 'flake.nix']:
            assert frozen[name] == digest, ('complete tested promotion source retained', name)
    head, index = git('rev-parse', 'HEAD').decode().strip(), sha(git('ls-files', '--stage', '-z'))
    failed_path = P / 'friendly-command-gena-promoted-complete-nix-gate.json'
    failed = json.loads(failed_path.read_bytes())
    assert failed['state'] == 'failed' and failed['results'][-1]['exit_code'] != 0
    prefix_path = W / 'docs/friendly-command-gena-prefix-fix-proof-archive.json'
    assert sha(prefix_path.read_bytes()) == '2406a23b9d2a686d4c4e3e899e7f093e909e9f1adf6f0012fcc1727e2a162fca'
    prefix = json.loads(prefix_path.read_bytes())
    for name in ['tools/friendly_command_audit.py', 'tools/test_friendly_command_historical_gena.py', 'flake.nix']:
        assert frozen[name] == prefix['files']['current-' + name.replace('/', '-')]['source_sha256'], 'only exact reviewed guarded prefix repair'
    protected = full_rust['protected_binaries']
    assert len(protected) == 6 and all(sha(Path(n).read_bytes()) == d for n, d in protected.items())
    fixture = json.loads((W / 'tests/fixtures/validity.json').read_bytes())
    reviews = json.loads((W / 'docs/inventory-reviews.json').read_bytes())
    assert len(fixture['cases']) == 35764 and len(reviews['entries']) == 520
    original_tests = json.loads((P / 'friendly-command-gena-promotion-originals.json').read_bytes())
    for name in ['tools/test_gentle_command_long_ledger_audit.py', 'tools/test_gentle_command_ledger_audit.py', 'tools/test_friendly_command_gena_ledger_audit.py']:
        row = original_tests[name]
        packed = (P.parents[1] / row['path']).read_bytes()
        assert sha(packed) == row['archive_sha256']
        original = gzip.decompress(packed)
        assert sha(original) == row['source_sha256'] == frozen[name]
    previous = json.loads((P / 'friendly-command-gena-complete-nix-gate.json').read_bytes())
    assert previous['state'] == 'passed'
    BUILD.mkdir(exist_ok=True)
    BUILD.chmod(0o1777)
    env = dict(os.environ, TMPDIR=str(BUILD), PYTHONDONTWRITEBYTECODE='1')
    flake = 'git+file://' + str(W)
    command = ['nix', 'build', '--offline', '--option', 'auto-optimise-store', 'true', '--option', 'build-dir', str(BUILD), '--cores', '4', '--max-jobs', '1', '--no-link', '--print-out-paths', '-L'] + [flake + '#checks.x86_64-linux.' + name for name in ['klem', 'web-assets', 'corpus-adapter', 'inventory-review']]
    r = dict(state='running', phase='selection', head=head, index_sha256=index,
             frozen_inputs=frozen, protected_binaries=protected, command=command,
             promoted_cases=35764, scoped_reviews=520, rust_audit_sha256=sha(rust_path.read_bytes()),
             doctest_sha256=sha(doctest_path.read_bytes()), complete_rust_totals=doctest['combined_rust_totals'],
             original_failed_gate_sha256=sha(failed_path.read_bytes()), original_failed_gate_preserved=True, prefix_fix_manifest_sha256=sha(prefix_path.read_bytes()),
             producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
             started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), results=[],
             scope='Complete committed 35764-case/520-review promotion four-check Nix gate. All old32/26/24 controls retained byte for byte; actual selected102 promotion/prefix controls and715 queue, complete source profiles, and all historical inventory checks. Only two tested validity inputs may differ from the original Gena compiled Rust closure; frontend and all production inputs exact. Current installed packages/browser/main/quiet timing/context/register/independent review remain separate.')
    def save():
        OUT.write_text(json.dumps(r, indent=2) + '\n')
    save()
    try:
        with LOG.open('xb') as log:
            def run(args, cwd, capture=False):
                log.write(('COMMAND ' + json.dumps(args) + '\n').encode()); log.flush()
                job = subprocess.run(args, cwd=cwd, env=env, stdout=subprocess.PIPE if capture else log, stderr=log)
                row = dict(command=args, exit_code=job.returncode)
                if capture:
                    row['stdout'] = job.stdout.decode()
                r['results'].append(row); save()
                assert job.returncode == 0
                return job.stdout if capture else None
            def selected(attr):
                root = Path(run(['nix', 'eval', '--offline', '--raw', flake + '#' + attr], W, True).decode().strip())
                files = {}
                prefix = 'web/' if attr.endswith('web-assets.src') else ''
                for file in root.rglob('*'):
                    assert not file.is_symlink()
                    if file.is_file():
                        name = str(file.relative_to(root)); digest = sha(file.read_bytes())
                        assert frozen[prefix + name] == digest
                        files[name] = digest
                return root, files
            source, files = selected('checks.x86_64-linux.inventory-review.src')
            r.update(inventory_source=str(source), inventory_source_files=files, compiled_source_profiles={})
            for name in ['tools/friendly_command_gena_ledger_audit.py', 'tools/test_friendly_command_gena_ledger_descendant.py', 'docs/inventory-reviews.json', 'tests/fixtures/validity.json']:
                assert files[name] == frozen[name]
            for attr, prior_name in [('klem', 'klem'), ('corpus-adapter', 'klem-corpus-adapter'), ('web-assets', 'klem-web-assets')]:
                root, compiled = selected('packages.x86_64-linux.' + attr + '.src')
                prior = previous['compiled_source_profiles'][prior_name]['files']
                changed = {name for name in set(prior) | set(compiled) if prior.get(name) != compiled.get(name)}
                expected = set() if attr == 'web-assets' else {'tests/fixtures/validity.json', 'tests/validity.rs'}
                assert changed == expected, ('only actual tested ledger promotion changes compiled closure', attr, changed)
                assert set(compiled) == set(prior)
                assert compiled == failed['compiled_source_profiles'][prior_name]['files'], 'all first-failed1146/1146/18 compiled inputs retained exactly'
                r['compiled_source_profiles'][prior_name] = dict(source=str(root), files=compiled, changes={name: dict(before=prior[name], after=compiled[name]) for name in sorted(changed)})
            r['phase'] = 'selected-promotion-controls'; save()
            for module in ['test_gentle_command_ledger_audit.py', 'test_gentle_command_long_ledger_audit.py', 'test_friendly_command_gena_ledger_audit.py', 'test_friendly_command_gena_ledger_descendant.py', 'test_friendly_command_historical_gena.py']:
                run(['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', module], source)
            r['selected_controls'] = sum(int(c) for c in re.findall(r'Ran (\d+) tests', LOG.read_text()))
            assert r['selected_controls'] == 102
            run(['python3', 'tools/friendly_command_audit.py'], source)
            run(['python3', 'tools/review_inventory.py', '--verify'], source)
            r['phase'] = 'complete-four-check-build'; save()
            paths = run(command, W, True).decode().splitlines()
            assert len(paths) == 4 and all(path.startswith('/nix/store/') and Path(path).is_dir() for path in paths)
            r.update(state='passed', outputs=paths)
    except BaseException as error:
        r.update(state='failed', error=repr(error))
        raise
    finally:
        current_names = git('ls-files', '-z').decode().split('\0')[:-1]
        r.update(inputs_unchanged=set(current_names) == set(frozen) and all(sha((W / n).read_bytes()) == d for n, d in frozen.items()),
                 head_unchanged=git('rev-parse', 'HEAD').decode().strip() == head,
                 index_unchanged=sha(git('ls-files', '--stage', '-z')) == index,
                 protected_binaries_unchanged=all(sha(Path(n).read_bytes()) == d for n, d in protected.items()),
                 log_sha256=sha(LOG.read_bytes()) if LOG.exists() else None,
                 finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
        if not all(r[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged']):
            r['state'] = 'failed'
        save()
    assert r['state'] == 'passed'
    print('Actual committed Gena promotion: all four Nix checks passed.', flush=True)


if __name__ == '__main__':
    main()
