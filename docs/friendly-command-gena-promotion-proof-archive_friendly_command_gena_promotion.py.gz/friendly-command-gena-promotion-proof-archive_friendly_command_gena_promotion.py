"""Preserve actual shared promotion, complete results, and original count failures."""
import datetime
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-command-gena'
OUT = P / 'friendly-command-gena-promotion-archive.json'
MANIFEST = W / 'docs/friendly-command-gena-promotion-proof-archive.json'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    assert not OUT.exists() and not MANIFEST.exists()
    audit_path = P / 'friendly-command-gena-promotion-full-rust-results-audit.json'
    full_audit = json.loads(audit_path.read_bytes())
    focused = json.loads((P / 'friendly-command-gena-promotion-results-audit.json').read_bytes())
    assert full_audit['state'] == focused['state'] == 'passed'
    assert (full_audit['targets'], full_audit['commands']) == (260, 264)
    assert focused['actual_rust_tests'] == 12 and focused['actual_python_controls'] == 94
    doctest = json.loads((P / 'friendly-command-gena-promotion-doctest.json').read_bytes())
    assert doctest['state'] == 'passed' and doctest['exit_code'] == 0
    assert doctest['rust_totals'] == dict(passed=1, failed=0, ignored=0)
    assert doctest['all_target_audit_sha256'] == sha(audit_path.read_bytes())
    assert doctest['current_cargo_inventory_verified'] and doctest['metadata_exit_code'] == 0
    assert doctest['current_metadata_sha256'] == sha(doctest['current_metadata_raw'].encode())
    assert doctest['log_sha256'] == sha((P / 'friendly-command-gena-promotion-doctest.log').read_bytes())
    assert all(doctest[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged'])
    assert doctest['combined_rust_totals'] == dict(passed=1200, failed=0, ignored=1)
    actual = json.loads((P / 'friendly-command-gena-promotion-full-rust.json').read_bytes())
    assert sha((P / 'friendly-command-gena-promotion-full-rust.json').read_bytes()) == full_audit['original_receipt_sha256']
    assert actual['state'] == 'failed' and actual['error'] == "AssertionError('complete actual255target inventory andfourrequiredcommands')"
    assert all(sha((W / name).read_bytes()) == digest for name, digest in actual['frozen_inputs'].items())
    assert all(sha(Path(name).read_bytes()) == digest for name, digest in actual['protected_binaries'].items())
    git = lambda *args: subprocess.check_output(['git', *args], cwd=W)
    assert git('rev-parse', 'HEAD').decode().strip() == actual['head']
    assert sha(git('ls-files', '--stage', '-z')) == actual['index_sha256']
    files = {name: (P / name).read_bytes() for name in [
        'friendly-command-gena-promotion-originals.json',
        'friendly-command-gena-promotion-count-failure-originals.json',
        'friendly-command-gena-promotion-validation.json',
        'friendly-command-gena-promotion-validation.log',
        'validate_friendly_command_gena_promotion.py',
        'friendly-command-gena-promotion-results-audit.json',
        'audit_friendly_command_gena_promotion_results.py',
        'friendly-command-gena-promotion-full-rust.json',
        'friendly-command-gena-promotion-full-rust.log',
        'run_friendly_command_gena_promotion_full_rust.py',
        'friendly-command-gena-promotion-full-rust-count-observation.json',
        'friendly-command-gena-promotion-full-rust-terminal-originals.json',
        'friendly-command-gena-promotion-full-rust-results-audit.json',
        'audit_friendly_command_gena_promotion_full_rust.py',
        'test_friendly_command_gena_promotion_full_rust_audit.py',
        'friendly-command-gena-promotion-followup-preparation.json',
        'run_friendly_command_gena_promoted_nix_gate.py',
        'friendly-command-gena-promotion-doctest.json',
        'friendly-command-gena-promotion-doctest.log',
        'run_friendly_command_gena_promotion_doctest.py',
        Path(__file__).name,
    ]}
    backups = json.loads(files['friendly-command-gena-promotion-originals.json'])
    assert len(backups) == 11
    for name, row in backups.items():
        packed = (P.parents[1] / row['path']).read_bytes()
        assert sha(packed) == row['archive_sha256']
        original = gzip.decompress(packed)
        assert sha(original) == row['source_sha256']
        files['original-' + name.replace('/', '-')] = original
    for name in [
        'tests/fixtures/validity.json', 'tests/validity.rs',
        'docs/inventory-reviews.json', 'docs/inventory-review-queue.json',
        'tools/friendly_command_gena_ledger_audit.py',
        'tools/gentle_command_long_ledger_audit.py',
        'tools/gentle_command_ledger_audit.py',
        'tools/test_gentle_command_long_ledger_audit.py',
        'tools/test_gentle_command_ledger_audit.py',
        'tools/test_friendly_command_gena_ledger_audit.py',
        'tools/test_friendly_command_gena_ledger_descendant.py',
        'flake.nix',
    ]:
        raw = (W / name).read_bytes()
        assert sha(raw) == actual['frozen_inputs'][name]
        files['promoted-' + name.replace('/', '-')] = raw
    manifest = dict(state='actual-shared-Gena35764-520-promotion-and-complete-original-Rust-results-verified',
                    focused_original_session_id=43725, focused_original_exit_code=1,
                    focused_results_audit_session_id=53655,
                    full_rust_original_session_id=10415, full_rust_original_exit_code=1,
                    original_failed_receipts_preserved=True, all_actual_commands_passed=True,
                    focused_rust_tests=12, python_controls=94,
                    full_rust_targets=260, full_rust_commands=264,
                    all_target_rust_totals=full_audit['totals'], all_target_rust_batches=full_audit['batches'],
                    full_rust_totals=doctest['combined_rust_totals'], full_rust_batches=doctest['combined_rust_batches'],
                    original_doctest_preserved=True, supplemental_doctest_commands=1, complete_commands=doctest['combined_commands'],
                    supplemental_inventory_read_commands=1, all_executed_commands=doctest['combined_commands'] + 1,
                    shared_cases=35764, scoped_reviews=520, unreviewed_owners=195,
                    captured_head=actual['head'], captured_source_files=len(actual['frozen_inputs']),
                    original_test_files_preserved=True,
                    current_promoted_nix_gate=False, main_integration=False, full_coverage_complete=False,
                    files={},
                    scope='Full original failed-count receipts/logs/producers, successful independent result audits, all11 pre-promotion original bodies and actual promoted source retained. Every260 Cargo target and all4 trailing checks executed successfully. Original wrapper failures remain failed; separate audits derive complete command/test totals. Old35740 cases/519 reviews and32/26/24 test files preserved. Current promoted-source Nix/packages/browser/main/context/register/independent review remain open.')
    for name, raw in files.items():
        filename = 'friendly-command-gena-promotion-proof-' + name + '.gz'
        destination = W / 'docs' / filename
        assert not destination.exists()
        packed = gzip.compress(raw, mtime=0)
        destination.write_bytes(packed)
        assert gzip.decompress(destination.read_bytes()) == raw
        manifest['files'][name] = dict(path=filename, source_sha256=sha(raw), archive_sha256=sha(packed), original_bytes=len(raw))
    MANIFEST.write_text(json.dumps(manifest, indent=2) + '\n')
    OUT.write_text(json.dumps(dict(state='passed', originals=len(files), manifest=str(MANIFEST),
                                  manifest_sha256=sha(MANIFEST.read_bytes()),
                                  producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
                                  finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), scope=manifest['scope']), indent=2) + '\n')
    print('Archived complete actual Gena promotion:', len(files), 'original artifacts;', manifest['full_rust_totals'], flush=True)


if __name__ == '__main__':
    main()
