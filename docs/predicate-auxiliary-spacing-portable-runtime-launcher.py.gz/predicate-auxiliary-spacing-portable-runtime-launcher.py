import json,hashlib,socket,subprocess,signal,time,urllib.request
from pathlib import Path
root=Path('/home/josh/projects/klem');prefix=Path('/tmp/klem-predicate-auxiliary-spacing-main-portable-runtime')
out=Path(str(prefix)+'-launcher.json');assert not out.exists()
cli=Path('/tmp/klem-predicate-auxiliary-spacing-main-cli');server=Path('/tmp/klem-predicate-auxiliary-spacing-main-server');assets=root/'web/dist';db=root/'data/dictionaries/krdict/krdict.db';driver=root/'tools/predicate_auxiliary_spacing_runtime.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen={str(p):sha(p) for p in [cli,server,db,driver,Path(__file__)]}
snapshot=json.loads(Path('/tmp/klem-predicate-auxiliary-spacing-main-rust.json').read_text())['snapshot_files']
assert all(sha(root/n)==v['sha256'] for n,v in snapshot.items())
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
url=f'http://127.0.0.1:{port}';command=[str(server),'--port',str(port),'--assets',str(assets),'--dictionary',str(db)]
report={'state':'running','frozen_inputs':frozen,'command':command,'snapshot_files':snapshot,'url':url}
def save():out.write_text(json.dumps(report,indent=2)+'\n')
save();job=None
try:
 with Path(str(prefix)+'-server.log').open('xb') as log:
  job=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT);report['server_pid']=job.pid;save();deadline=time.monotonic()+30
  while True:
   assert job.poll() is None
   try:
    with urllib.request.urlopen(url,timeout=2) as r:r.read()
    break
   except OSError:assert time.monotonic()<deadline;time.sleep(.1)
  replay=['python3',str(driver),'--cli',str(cli),'--dictionary',str(db),'--url',url,'--output',str(prefix)+'.json.gz'];report['replay_command']=replay;save()
  with Path(str(prefix)+'.log').open('xb') as stream:run=subprocess.run(replay,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
  report.update(state='passed' if run.returncode==0 else 'failed',exit_code=run.returncode);assert run.returncode==0
finally:
 if job is not None:
  if job.poll() is None:job.send_signal(signal.SIGINT)
  report.update(server_exit_code=job.wait(timeout=20),server_stopped=True)
 report['inputs_unchanged']=all(sha(Path(p))==h for p,h in frozen.items()) and all(sha(root/n)==v['sha256'] for n,v in snapshot.items());save()
assert report['inputs_unchanged'] and report['server_stopped']
print('Real main CLI/API/Native/cache/Unicode replay passed; server stopped.')
