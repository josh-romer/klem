"""Retain successful unchanged tests after the initial runner's incorrect count assertion."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

prep = Path(__file__).resolve().parent
root = Path('/tmp/klem-willingness-interactions')
prior_path = prep / 'willingness-interaction-focused.json'
out = prep / 'willingness-interaction-focused-complete.json'
log = prep / 'willingness-interaction-focused-complete-clippy.log'
assert not out.exists() and not log.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
prior = json.loads(prior_path.read_text())
assert prior['state'] == 'failed' and all(prior[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged'])
assert len(prior['runs']) == 2 and all(run['exit_code'] == 0 for run in prior['runs'])
assert all(sha(p) == h for p, h in prior['frozen_inputs'].items())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == prior['head']
assert hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=root)).hexdigest() == prior['index_sha256']
for i, run in enumerate(prior['runs']):
    assert sha(prep / ('willingness-interaction-focused-' + str(i) + '.log')) == run['log_sha256']
raw = (prep / 'willingness-interaction-focused-1.log').read_bytes()
batches = re.findall(rb'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', raw)
assert batches == [(b'ok', b'11', b'0', b'0')]
for name in ['independently_authored_irregular_auxiliary_and_class_interactions', 'interaction_targets_keep_native_compatibility_roles_and_unicode']:
    assert ('test ' + name + ' ... ok').encode() in raw
parent = subprocess.check_output(['git', 'show', prior['head'] + ':tests/willingness_question.rs'], cwd=root)
assert (root / 'tests/willingness_question.rs').read_bytes().startswith(parent), 'all nine original tests retained byte-for-byte'
frozen = dict(prior['frozen_inputs'], **{str(prior_path): sha(prior_path), str(Path(__file__)): sha(__file__)})
command = ['cargo', 'clippy', '--locked', '--offline', '--features', 'web', '--test', 'willingness_question', '--', '-D', 'warnings']
r = {'state': 'running', 'pid': os.getpid(), 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'head': prior['head'], 'index_sha256': prior['index_sha256'], 'frozen_inputs': frozen,
     'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)},
     'preserved_initial_failure': {'receipt_sha256': sha(prior_path), 'reason': 'Runner incorrectly required at least12 tests; actual unfiltered target has9 original tests plus2 newtests, all11passed. Source/judgments/runtime output unchanged.'},
     'reused_successful_commands': prior['runs'], 'actual_tests_passed': 11, 'new_tests': 2,
     'scope': 'Actual prior fmt/unfiltered11-test library/Native/Unicode run reused only after checking every input, HEAD/index, log and original-test prefix unchanged. Only remaining focused Clippy runs here. Whole suite, shared-ledger/browser/installed/current-main and independent review remain separate.'}
out.write_text(json.dumps(r, indent=2) + '\n')
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/klem-willingness-interaction-target', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2')
with log.open('xb') as stream:
    job = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
r.update(state='passed' if job.returncode == 0 else 'failed', exit_code=job.returncode, command=command,
         log_sha256=sha(log), finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         inputs_unchanged=all(sha(p) == h for p, h in frozen.items()),
         head_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == prior['head'],
         index_unchanged=hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=root)).hexdigest() == prior['index_sha256'])
out.write_text(json.dumps(r, indent=2) + '\n')
assert r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged']
assert r['state'] == 'passed'
print('Actual11interaction/inherited tests + complete fmt + focused Clippy passed; all inputs unchanged', flush=True)
