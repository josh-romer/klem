import copy,hashlib,importlib.util,json,unittest
from pathlib import Path
p=Path('/tmp/klem-literary-question-geona-ledger-audit.py');spec=importlib.util.spec_from_file_location('audit',p);audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
class Controls(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.good=audit.inputs()
 def run_corruption(self,change,reason):
  args=copy.deepcopy(self.good);change(args)
  args[0]['proposed_ledger']['cases'][len(args[2]['cases']):]=copy.deepcopy(args[0]['new_cases'])
  with self.assertRaisesRegex(AssertionError,reason):audit.verify(*args)
 def test_actual_complete_capture_passes(self):self.assertEqual(audit.verify(*self.good)['individual_observations'],122)
 def test_removed_case(self):self.run_corruption(lambda a:a[0]['new_cases'].pop(),'case count')
 def test_original_surface(self):self.run_corruption(lambda a:a[0]['new_cases'][0].update(surface='wrong'),'original surface')
 def test_changed_lemma_role(self):self.run_corruption(lambda a:a[0]['new_cases'][0]['judgments'][0].update(lemma_kinds=['nominal']),'typed exact path')
 def test_missing_rule(self):self.run_corruption(lambda a:a[0]['new_cases'][0]['judgments'][0].update(required_rules=[]),'typed exact path')
 def test_wrong_source(self):self.run_corruption(lambda a:a[0]['new_cases'][0]['judgments'][0].update(source='literary-question-geona-80972'),'allomorph source')
 def test_old_prefix_changed(self):self.run_corruption(lambda a:a[0]['proposed_ledger']['cases'][0].update(surface='wrong'),'append-only')
 def test_old_source_changed(self):self.run_corruption(lambda a:a[0]['proposed_ledger']['sources'].update(wrong='source'),'exact original source')
 def test_conditional_promoted(self):
  def change(a):a[0]['new_cases'][0]['id']=a[0]['excluded_conditional_native_cases'][0]['id']
  self.run_corruption(change,'finite scope')
 def test_missing_native_exclusion(self):self.run_corruption(lambda a:a[0]['excluded_conditional_native_cases'].pop(),'Native exclusions')
 def test_missing_unicode_run(self):self.run_corruption(lambda a:a[1]['runs'].pop(),'Unicode runs')
 def test_altered_command_input(self):self.run_corruption(lambda a:a[1]['runs'][0].update(stdin='wrong'),'exact command input')
 def test_altered_transcript(self):self.run_corruption(lambda a:a[1]['runs'][0].update(jsonl='wrong'),'stream hash')
 def test_wrong_original_span(self):
  def change(a):
   r=a[1]['runs'][0];rows=list(map(json.loads,r['jsonl'].splitlines()));rows[0]['span']['end']+=1;r['jsonl']='\n'.join(json.dumps(q,ensure_ascii=False) for q in rows)+'\n';r['sha256']=hashlib.sha256(r['jsonl'].encode()).hexdigest()
  self.run_corruption(change,'UTF8 spans')
 def test_missing_individual_observation(self):self.run_corruption(lambda a:a[1]['observations'].pop(),'individual observations')
if __name__=='__main__':unittest.main(verbosity=2)
