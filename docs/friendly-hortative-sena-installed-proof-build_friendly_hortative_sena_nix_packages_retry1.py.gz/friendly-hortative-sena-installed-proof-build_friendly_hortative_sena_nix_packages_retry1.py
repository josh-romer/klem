"""Materialize all four packages after the actual complete current Nix gate passes."""
import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent/'friendly-hortative-sena'
O=P/'friendly-hortative-sena-nix-packages-retry1.json';L=P/'friendly-hortative-sena-nix-packages-retry1.log';R=P/'friendly-hortative-sena-release-rust-retry1.log'
B=Path('/var/tmp/klem-friendly-hortative-sena-complete-nix-build')
assert not O.exists() and not L.exists() and not R.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest();git=lambda *args:subprocess.check_output(['git',*args],cwd=W)
gate_path=P/'friendly-hortative-sena-complete-nix-gate.json';gate=json.loads(gate_path.read_bytes());assert gate['state']=='passed' and gate['exit_code']==0 and len(gate['outputs'])==4
assert all(gate[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged'])
assert not git('status','--porcelain');head=git('rev-parse','HEAD').decode().strip();index=sha(git('ls-files','--stage','-z'))
doc_path=P/'friendly-hortative-sena-documentation-scope.json';doc=json.loads(doc_path.read_bytes());assert doc['state']=='passed' and doc['exit_code']==0
assert doc['head']==head and doc['index_sha256']==index and all(doc[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged','original_receipt_and_log_unchanged'])
frozen={n:sha((W/n).read_bytes()) for n in git('ls-files','-z').decode().split('\0')[:-1]};assert frozen==gate['frozen_inputs'] and head==gate['head'] and index==gate['index_sha256']
B.mkdir(exist_ok=True);B.chmod(0o1777);env=dict(os.environ,TMPDIR=str(B));flake='git+file://'+str(W)
command=['nix','build','--option','auto-optimise-store','true','--option','build-dir',str(B),'--cores','4','--max-jobs','1','--no-link','--print-out-paths','-L']+[flake+'#packages.x86_64-linux.'+n for n in ['klem','web-assets','corpus-adapter','web']]
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,protected_binaries=gate['protected_binaries'],complete_gate_sha256=sha(gate_path.read_bytes()),documentation_scope_sha256=sha(doc_path.read_bytes()),command=command,profiles=gate['profiles'],producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Actual complete currentSource gate prerequisite, then all4packages includinginstalled web launcher. Full original package Rust build log and1212/0/1/257 check results. Source/head/index/sixdebugbinaries unchanged. Installed replay/browser/sharedpromotion/main/timing/context/register/Korean review remain separate.')
def save():O.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 with L.open('xb') as log:
  job=subprocess.run(command,cwd=W,env=env,stdout=subprocess.PIPE,stderr=log);r.update(exit_code=job.returncode,stdout=job.stdout.decode(),outputs=job.stdout.decode().splitlines());save()
  assert job.returncode==0 and len(r['outputs'])==4 and all(s.startswith('/nix/store/') for s in r['outputs'])
  log_command=['nix','log',flake+'#packages.x86_64-linux.klem'];r['release_log_command']=log_command;save()
  capture=subprocess.run(log_command,cwd=W,env=env,stdout=subprocess.PIPE,stderr=log);R.write_bytes(capture.stdout)
  r['release_log_exit_code']=capture.returncode;r['release_log_sha256']=sha(capture.stdout);assert capture.returncode==0
  batches=re.findall(rb'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',capture.stdout)
  totals={k:sum(int(x[i+1]) for x in batches) for i,k in enumerate(['passed','failed','ignored'])}
  assert totals==doc['expected_default_release_totals']==dict(passed=1212,failed=0,ignored=1) and len(batches)==doc['expected_default_release_batches']==257 and all(x[0]==b'ok' for x in batches), 'complete actual current release Rust suite'
  normalized_release=re.sub(rb'\x1b\[[0-?]*[ -/]*[@-~]',b'',capture.stdout)
  assert b'Doc-tests klem' in normalized_release and b'test src/lib.rs - (line 3) ... ok' in normalized_release
  r['release_rust']=dict(totals=totals,batches=len(batches))
 r['state']='passed'
except BaseException as error:r.update(state='failed',error=repr(error));raise
finally:
 r.update(inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),protected_binaries_unchanged=all(sha(Path(p).read_bytes())==d for p,d in r['protected_binaries'].items()),head_unchanged=git('rev-parse','HEAD').decode().strip()==head,index_unchanged=sha(git('ls-files','--stage','-z'))==index,log_sha256=sha(L.read_bytes()) if L.exists() else None,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 if not all(r[k] for k in ['inputs_unchanged','protected_binaries_unchanged','head_unchanged','index_unchanged']):r['state']='failed'
 save()
assert r['state']=='passed';print('Passed actual4currentpackages; captured full releaseRust1212/0/1/257.',flush=True)
