"""Capture the original KAIST sentence across dictionary, Unicode and cache modes."""
import datetime
import gzip
import hashlib
import json
import os
import subprocess
import sys
import unicodedata
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = P.parents[1]
W = P.parent / 'friendly-hortative-sena'
O = P / 'friendly-hortative-sena-corpus-regression.json.gz'
R = P / 'friendly-hortative-sena-corpus-regression-receipt.json'
L = P / 'friendly-hortative-sena-corpus-regression.log'
assert not O.exists() and not R.exists() and not L.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
sys.path.insert(0, str(W / 'tools'))
from native_lmf import array, entry, features
from friendly_hortative_sena_runtime_audit import additions

observation_path = P / 'friendly-hortative-sena-corpus-observations.json'
observation = json.loads(observation_path.read_bytes())
item = observation['items'][0]
sentence = next(line[9:] for line in item['complete_original_conllu_block'].splitlines() if line.startswith('# text = '))
binding_path = P / 'friendly-hortative-sena-complete-runtime-binding.json'
binding = json.loads(binding_path.read_bytes())
parent_path = ROOT / '.direnv/willingness-question-prepared/friendly-command-gena-installed-runtime.json.gz'
parent = json.loads(gzip.decompress(parent_path.read_bytes()))
current, prior = [Path(b['binaries']['klem']['path']) for b in [binding, parent]]
DB = ROOT / '.direnv/dictionary-restoration/krdict.db'
git = lambda *args: subprocess.check_output(['git', *args], cwd=W)
names = git('ls-files', '-z').decode().split('\0')[:-1]
frozen = {n: sha((W / n).read_bytes()) for n in names}
head, index = git('rev-parse', 'HEAD').decode().strip(), sha(git('ls-files', '--stage', '-z'))
protected = {str(p): sha(p.read_bytes()) for p in [Path(__file__), current, prior, DB, binding_path, parent_path, observation_path]}
assert sha(current.read_bytes()) == binding['binaries']['klem']['sha256']
assert sha(prior.read_bytes()) == parent['binaries']['klem']['sha256']
assert all(frozen[p] == d for p, d in binding['production_inputs'].items())
r = dict(state='running', head=head, index_sha256=index, frozen_inputs=frozen, external_inputs=protected,
         producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
def save():
    R.write_text(json.dumps(r, indent=2) + '\n')
save()
captures, raw_lmf, owners, exports = [], {}, {}, {}
try:
    with L.open('x') as log:
        for normalization in ['NFC', 'NFD']:
            text = unicodedata.normalize(normalization, sentence)
            for mode, flags in [('raw', []), ('headword', ['--dict-only']), ('compatible', ['--dict-compatible'])]:
                for cache in [0, 8388608]:
                    outputs = []
                    for binary in [prior, current]:
                        command = [str(binary), 'text', '--dictionary', str(DB), *flags, '--cache-bytes', str(cache)]
                        job = subprocess.run(command, input=text.encode(), capture_output=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
                        assert job.returncode == 0 and not job.stderr
                        outputs.append(dict(command=command,exit_code=0,stdout=job.stdout.decode(),stderr='',frames=[json.loads(line) for line in job.stdout.splitlines()]))
                    before, after = outputs
                    assert len(before['frames']) == len(after['frames'])
                    cursor, new_paths = 0, []
                    for old, new in zip(before['frames'], after['frames'], strict=True):
                        assert new['span']['start'] == cursor and text.encode()[cursor:new['span']['end']].decode() == new['surface']
                        cursor = new['span']['end']
                        added = additions(old, new)
                        new_paths.extend(dict(surface=new['surface'],span=new['span'],analysis=a,assessment=new['dictionary']['readings'][new['analysis']['analyses'].index(a)]) for a in added)
                    assert cursor == len(text.encode())
                    target = next(f for f in after['frames'] if unicodedata.normalize('NFC', f['surface']) == '중세나')
                    paths = target['analysis']['analyses']
                    noun = next(a for a in paths if a['lemmas']==[dict(text='중세',kind='nominal')] and a['morphemes']==[dict(form='나',kind='particle')])
                    assert target['dictionary']['readings'][paths.index(noun)]['status'] == 'compatible'
                    hypotheses = [a for a in paths if 'ending.friendly_hortative.sena' in a['rules']]
                    assert len(hypotheses) == (1 if mode=='raw' else 0)
                    if hypotheses:
                        assert hypotheses == item['new_unjudged_paths']
                        assert target['dictionary']['readings'][paths.index(hypotheses[0])]['status'] == 'incompatible'
                    captures.append(dict(normalization=normalization,mode=mode,cache_bytes=cache,input=text,before=before,after=after,new_paths=new_paths))
                    log.write(json.dumps(dict(normalization=normalization,mode=mode,cache_bytes=cache,frames=len(after['frames']),new_paths=len(new_paths)))+'\n');log.flush()
        for export in sorted((ROOT / '.direnv/dictionary-restoration/2026-09').glob('*.json')):
            raw = export.read_bytes();exports[export.name]=dict(sha256=sha(raw),bytes=len(raw))
            for value in array(json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']):
                heads = {h for lemma in array(value['Lemma']) for h in features(lemma,'writtenForm')}
                if not heads & {'중세','중다'}:
                    continue
                native = entry(value);raw_lmf[native['id']]=value;owners[native['id']]=native
        assert owners and {e['headword'] for e in owners.values()} == {'중세'}
        lookups = {}
        for headword in ['중세', '중다']:
            command = [str(current),'dict','lookup',str(DB),headword]
            job = subprocess.run(command,capture_output=True);assert job.returncode==0 and not job.stderr
            response=json.loads(job.stdout)
            assert response['entries']==[{k:e[k] for k in ['id','headword','homonym','pos']} for n,e in sorted(owners.items()) if e['headword']==headword]
            lookups[headword]=dict(command=command,exit_code=0,stdout=job.stdout.decode(),stderr='',response=response)
        entries = {}
        for ident, native in owners.items():
            command=[str(current),'dict','entry',str(DB),ident]
            job=subprocess.run(command,capture_output=True);assert job.returncode==0 and not job.stderr and json.loads(job.stdout)['entry']==native
            entries[ident]=dict(command=command,exit_code=0,stdout=job.stdout.decode(),stderr='',response=json.loads(job.stdout))
        record = dict(state='original-KAIST-noun-reading-preserved-and-unmatched-Sena-hypothesis-filtered',
                      stable_case_id=item['id'], original_observation=observation, captures=captures,
                      original_lmf=raw_lmf,complete_native_entries=owners,source_exports=exports,
                      actual_headword_queries=lookups,actual_complete_entry_responses=entries,
                      contextual_hypothesis='unjudged',independent_korean_review='pending',
                      shared_cases_reviews_changed=False,historical_allowances_assigned=False)
        O.write_bytes(gzip.compress((json.dumps(record,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
    r.update(state='passed',runs=len(captures),frames=sum(len(c['after']['frames']) for c in captures),native_owners=len(owners),record_sha256=sha(O.read_bytes()))
except BaseException as error:
    r.update(state='failed',error=repr(error))
    (P/'friendly-hortative-sena-corpus-regression-partial.json.gz').write_bytes(gzip.compress(json.dumps(dict(captures=captures,original_lmf=raw_lmf,complete_native_entries=owners),ensure_ascii=False).encode(),mtime=0))
    raise
finally:
    r.update(inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),
             external_inputs_unchanged=all(sha(Path(p).read_bytes())==d for p,d in protected.items()),
             head_unchanged=git('rev-parse','HEAD').decode().strip()==head,
             index_unchanged=sha(git('ls-files','--stage','-z'))==index,
             log_sha256=sha(L.read_bytes()) if L.exists() else None,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['inputs_unchanged','external_inputs_unchanged','head_unchanged','index_unchanged']):
        r['state']='failed'
    save()
assert r['state']=='passed'
print('Passed original whole KAIST sentence across12NFC/NFD/filter/cache policies;',r['frames'],'frames;',r['native_owners'],'complete noun owners.',flush=True)
