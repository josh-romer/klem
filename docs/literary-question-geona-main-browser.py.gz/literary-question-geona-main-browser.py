import datetime,hashlib,json,os,re,signal,socket,subprocess,time,urllib.request
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');P=Path('/home/josh/projects/klem');ASSETS=ROOT/'web/dist';PREFIX=Path('/tmp/klem-literary-question-geona-main');OUT=Path(str(PREFIX)+'-browser-runtime.json');assert not OUT.exists();sha=lambda b:hashlib.sha256(b).hexdigest()
built=json.loads(Path('/tmp/klem-literary-question-geona-main-binaries.json').read_text());frontend=json.loads(Path('/tmp/klem-literary-question-geona-main-frontend-build.json').read_text());snapshot=built['snapshot_files'];cli=Path(built['binaries']['cli']['path']);server=Path(built['binaries']['server']['path']);driver=ROOT/'web/tests/literary-question-geona.mjs';DB=ROOT/'data/dictionaries/krdict/krdict.db'
assert all(sha((P/n).read_bytes())==v['sha256'] for n,v in snapshot.items());assert all(sha((ASSETS/n).read_bytes())==v['sha256'] for n,v in frontend['assets'].items())
source=ROOT/'docs/literary-question-geona-source-discovery.json.gz';replay=Path('/tmp/klem-literary-question-geona-prototype-source-replay.json.gz');owners=Path('/tmp/klem-literary-question-geona-complete-owner-preparation.json.gz');frozen={str(p):sha(p.read_bytes()) for p in [cli,server,driver,DB,source,replay,owners,Path(__file__),Path('/tmp/klem-literary-question-geona-main-binaries.json'),Path('/tmp/klem-literary-question-geona-main-frontend-build.json')]}
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
url=f'http://127.0.0.1:{port}';command=[str(server),'--port',str(port),'--assets',str(ASSETS),'--dictionary',str(DB)]
r={'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'url':url,'snapshot_files':snapshot,'assets':frontend['assets'],'frozen_inputs':frozen,'scope':'Actual integrated main neutral-label server/CLI plus built SolidJS assets. Complete original source API outputs, finite boundary/typed owner exports, diagram labels/entry panes and241 complete Native endpoints; full main Rust suite/package/performance/context/independent review remain separate.'}
def save():OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save();job=None;serverlog=Path(str(PREFIX)+'-browser-server.log');browserlog=Path(str(PREFIX)+'-browser-driver.log')
try:
 with serverlog.open('xb') as out:
  job=subprocess.Popen(command,cwd=P,stdout=out,stderr=subprocess.STDOUT);r['server_pid']=job.pid;save();deadline=time.monotonic()+30
  while True:
   assert job.poll() is None,'owned server exited'
   try:
    with urllib.request.urlopen(url,timeout=2) as response:html=response.read()
    break
   except OSError:assert time.monotonic()<deadline;time.sleep(.1)
  assert html==(ASSETS/'index.html').read_bytes();checks=[]
  for path in re.findall(r'(?:src|href)="(/assets/[^"?#]+\.(?:js|css))"',html.decode()):
   with urllib.request.urlopen(url+path,timeout=20) as response:raw=response.read()
   assert raw==(ASSETS/path.lstrip('/')).read_bytes();checks.append({'path':path,'sha256':sha(raw),'bytes':len(raw)})
  assert len(checks)==2;r['served_asset_checks']=checks
  env=dict(os.environ,KLEM_ROOT=str(P),KLEM_DEPENDENCY_ROOT=str(ROOT),KLEM_WEB_URL=url,KLEM_BIN=str(cli),KLEM_DICTIONARY=str(DB),KLEM_CAPTURE_PREFIX=str(PREFIX),KLEM_GEONA_SOURCE=str(source),KLEM_GEONA_REPLAY=str(replay),KLEM_GEONA_OWNERS=str(owners),CHROMIUM_PATH='/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium');r['browser_command']=['node',str(driver)];save()
  with browserlog.open('xb') as out:completed=subprocess.run(r['browser_command'],cwd=P,env=env,stdout=out,stderr=subprocess.STDOUT)
  assert completed.returncode==0,f'browser exit {completed.returncode}; see {browserlog}'
  report=Path(str(PREFIX)+'-browser.json');r.update(state='passed',exit_code=0,browser_sha256=sha(report.read_bytes()))
except BaseException as error:r.update(state='failed',exit_code=1,error=repr(error));raise
finally:
 if job is not None:
  if job.poll() is None:job.send_signal(signal.SIGINT)
  r.update(server_exit_code=job.wait(timeout=20),server_stopped=True)
 r['inputs_unchanged']=all(sha(Path(p).read_bytes())==v for p,v in frozen.items()) and all(sha((P/n).read_bytes())==v['sha256'] for n,v in snapshot.items()) and all(sha((ASSETS/n).read_bytes())==v['sha256'] for n,v in frontend['assets'].items());r['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();r['server_log_sha256']=sha(serverlog.read_bytes());r['driver_log_sha256']=sha(browserlog.read_bytes()) if browserlog.exists() else None;save()
assert r['inputs_unchanged'] and r['server_stopped'] and r['server_exit_code'] in [-2,130];print('Actual neutral-label isolated browser/CLI/Native endpoints and served assets passed; owned server stopped.',flush=True)
