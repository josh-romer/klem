"""Preserve independently authored boundaries without claiming executable coverage."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
PREP = ROOT / '.direnv/formal-volitional-prepared'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
authored = json.loads((PREP / 'independent-authoring.json').read_text())
suite = json.loads((PREP / 'formal-volitional-validity.json').read_text())
closure = json.loads(gzip.decompress((PREP / 'authored-native-closure.json.gz').read_bytes()))
assert authored['state'] == 'authored-before-implementation'
assert authored['cases'] == len(suite['cases']) == 59
assert authored['required'] == sum(j['verdict'] == 'required' for c in suite['cases'] for j in c['judgments']) == 33
assert authored['forbidden'] == 26
assert authored['suite_sha256'] == closure['authored_validity_sha256'] == sha((PREP / 'formal-volitional-validity.json').read_bytes())
assert authored['native_owners'] == len(closure['entries']) == len(closure['original_native_entries']) == 43
assert all(j['source'] in suite['sources'] for c in suite['cases'] for j in c['judgments'])
protected = {name: sha((ROOT / name).read_bytes()) for name in ['tests/fixtures/validity.json', 'docs/inventory-reviews.json']}
archives = {}
for name in ['author_boundary_cases.py', 'formal-volitional-validity.json',
             'authored-native-closure.json.gz', 'independent-authoring.json', 'independent-authoring.log']:
    raw = (PREP / name).read_bytes()
    target = ROOT / 'docs' / ('formal-volitional-' + name + ('' if name.endswith('.gz') else '.gz'))
    assert not target.exists(), target
    target.write_bytes(raw if name.endswith('.gz') else gzip.compress(raw, mtime=0))
    archives[str(target.relative_to(ROOT))] = sha(target.read_bytes())
path = ROOT / 'docs/coverage-checklist.md'
text = path.read_text()
start = text.index('- [ ] **COV-017cw —')
end = text.index('- [ ] **COV-018 —', start)
block = text[start:end]
old = '  scoped inventory disposition. Remaining: independent boundary authoring,\n  implementation, source/Native/regression/corpus/browser checks, whole Rust,\n'
assert block.count(old) == 1
block = block.replace(old,
    '  scoped inventory disposition. [Independent boundary authoring](formal-volitional-independent-authoring.json.gz)\n'
    '  now preserves 59 cases: 33 required and 26 forbidden named paths, with\n'
    '  [43 complete Native owners](formal-volitional-authored-native-closure.json.gz).\n'
    '  Cases cover both styles, allomorphs, honorifics, three irregular families,\n'
    '  unlisted past/modal/retrospective prefinals and adjective/copular exclusions\n'
    '  before and after honorifics. Targets were authored without consulting engine\n'
    '  output; passing executable coverage is still unproven. Original spoken\n'
    '  pronunciation notes remain preserved separately. Remaining: implementation,\n'
    '  source/Native/regression/corpus/browser checks, whole Rust,\n')
path.write_text(text[:start] + block + text[end:])
(ROOT / 'docs/formal-volitional-boundary-archive-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
assert all(sha((ROOT / name).read_bytes()) == digest for name, digest in protected.items())
record = {'state': 'passed', 'cases': 59, 'required': 33, 'forbidden': 26, 'native_owners': 43,
          'archives': archives, 'main_ledger_and_manual_reviews_unchanged': True,
          'scope': 'Independent judgments preserved before implementation; not passing executable gold or scoped inventory completion.'}
(PREP / 'boundary-archive.json').write_text(json.dumps(record, indent=2) + '\n')
print('Archived 59 independently authored boundaries and 43 complete Native owners; executable coverage pending', flush=True)
