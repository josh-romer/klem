"""Compare every original additive-ending clause with its isolated structural proposal."""
import collections,datetime,gzip,hashlib,json,subprocess,unicodedata
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');CLI=Path('/tmp/klem-additive-ppundeoreo-cli')
DISC=Path('/tmp/klem-additive-ppundeoreo-source-discovery.json.gz')
OUT=Path('/tmp/klem-additive-ppundeoreo-source-replay.json.gz');assert not OUT.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
before=json.loads(gzip.decompress(DISC.read_bytes()));text=before['input']
expected={
 '곧을뿐더러':(['곧다'],['predicate'],['을뿐더러'],['ending']),
 '없을뿐더러':(['없다'],['predicate'],['을뿐더러'],['ending']),
 '구했을뿐더러':(['구하다'],['predicate'],['었','을뿐더러'],['prefinal','ending']),
 '예쁠뿐더러':(['예쁘다'],['predicate'],['을뿐더러'],['ending']),
 '반일뿐더러':(['반','이다'],['nominal','copula'],['을뿐더러'],['ending']),
 '배울뿐더러':(['배우다'],['predicate'],['을뿐더러'],['ending']),
 '파괴할뿐더러':(['파괴하다'],['predicate'],['을뿐더러'],['ending']),
 '심할뿐더러':(['심하다'],['predicate'],['을뿐더러'],['ending'])}
assert {v['surface'] for v in before['targets']}==set(expected)
frozen={str(p):sha(p.read_bytes()) for p in [CLI,DISC,Path(__file__),ROOT/'data/dictionaries/krdict/krdict.db']}
key=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True)
runs=[];observations=[]
for old in before['runs']:
 command=list(old['command']);command[0]=str(CLI)
 raw=unicodedata.normalize(old['encoding'],text).encode()
 job=subprocess.run(command,input=raw,capture_output=True,check=True);assert job.stderr==b''
 earlier=list(map(json.loads,old['jsonl'].splitlines()));rows=list(map(json.loads,job.stdout.splitlines()))
 assert len(rows)==len(earlier)
 for old_row,row in zip(earlier,rows,strict=True):
  for k in ['surface','span','kind']:assert old_row[k]==row[k]
  old_paths=old_row['analysis']['analyses'] if old_row.get('analysis') else []
  paths=row['analysis']['analyses'] if row.get('analysis') else []
  assert not (collections.Counter(map(key,old_paths))-collections.Counter(map(key,paths))),row['surface']
 for target in before['targets']:
  span={k:len(unicodedata.normalize(old['encoding'],text[:v]).encode()) for k,v in target['char_span'].items()}
  row=next(r for r in rows if r['span']==span);lemmas,kinds,morphs,morph_kinds=expected[target['surface']]
  matches=[a for a in row['analysis']['analyses'] if
           [l['text'] for l in a['lemmas']]==lemmas and [l['kind'] for l in a['lemmas']]==kinds and
           [m['form'] for m in a['morphemes']]==morphs and [m['kind'] for m in a['morphemes']]==morph_kinds and
           'ending.additive_ppundeoreo' in a['rules']]
  assert matches,(target['surface'],old['encoding'],old['mode'])
  observations.append({'target':target,'encoding':old['encoding'],'mode':old['mode'],'span':span,
                       'expected_shape':{'lemmas':lemmas,'lemma_kinds':kinds,'morphemes':morphs,'morpheme_kinds':morph_kinds},
                       'matched':matches,'record':row,'contextual_verdict':'unjudged','independent_review':'pending'})
 runs.append({'encoding':old['encoding'],'mode':old['mode'],'command':command,'input_sha256':sha(raw),
              'jsonl':job.stdout.decode(),'sha256':sha(job.stdout),'records':len(rows),'exit_code':0,'all_prior_raw_paths_retained':True})
assert len(observations)==60 and all(sha(Path(p).read_bytes())==v for p,v in frozen.items())
producer=Path(__file__)
report={'state':'passed','isolated_proposal_only':True,'cli':str(CLI),'cli_sha256':frozen[str(CLI)],
        'discovery_sha256':frozen[str(DISC)],'runs':runs,'observations':observations,'inputs_unchanged':True,
        'frozen_inputs':frozen,'producer':{'text':producer.read_text(),'sha256':frozen[str(producer)]},
        'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope':'All ten unchanged original example groups have their exact proposed whole-ending structure in both Unicode forms and all three filter modes, retaining every prior raw path. Boundary, Native owner closure, source-label/browser/global-ledger/broad/package tests remain separate. Root and its combined Nix gate are unchanged.'}
OUT.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('All60 original-case/filter observations have the proposed additive ending; every prior raw path remains.',flush=True)
