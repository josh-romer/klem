import hashlib,json,os,shutil
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');source=ROOT/'data/dictionaries/krdict/json';target=Path('/tmp/klem-geona-retained-dictionary-json');old=source.with_name('json.klem-geona-retained-original');out=Path('/tmp/klem-geona-dictionary-cache-relocation.json');assert source.is_dir() and not source.is_symlink() and not target.exists() and not old.exists() and not out.exists()
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();snapshot={str(p.relative_to(source)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in source.rglob('*') if p.is_file()};assert snapshot and not any(p.is_symlink() for p in source.rglob('*'))
shutil.copytree(source,target,copy_function=shutil.copy2);assert all((target/n).stat().st_size==v['bytes'] and sha(target/n)==v['sha256'] and sha(source/n)==v['sha256'] for n,v in snapshot.items())
os.rename(source,old)
try:os.symlink(target,source,target_is_directory=True)
except BaseException:os.rename(old,source);raise
assert all(sha(source/n)==v['sha256'] for n,v in snapshot.items());shutil.rmtree(old)
out.write_text(json.dumps({'state':'passed','scope':'Only ignored downloaded original dictionary JSON cache relocated. Complete raw bytes were independently SHA256-checked before and after; every original path resolves through a directory symlink. SQLite database, tracked files, stable executables and test inputs are unchanged. Original source LMF remains readable at its previous paths.','source':str(source),'target':str(target),'files':snapshot,'bytes_freed':sum(v['bytes'] for v in snapshot.values())},indent=2)+'\n');print('Retained',len(snapshot),'complete original dictionary JSON files at their old paths; freed',sum(v['bytes'] for v in snapshot.values()),'Root bytes.')
