"""Preserve the completed finite family and two explicitly bounded source reviews."""
import gzip
import json
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
ROOT = BASE / 'fear-lsera-prototype'
PREP = BASE / 'fear-lsera-prepared'
DOCS = ROOT / 'docs'
counts = [('source-controls-retry1.log', 23), ('streams-controls-retry1.log', 18),
          ('cohort-controls.log', 5), ('corpora-controls.log', 10),
          ('browser-controls.log', 19), ('broad-controls.log', 15),
          ('historical-ledger-controls.log', 78)]
for name, count in counts:
    text = (PREP / name).read_text()
    assert f'Ran {count} tests' in text and text.rstrip().endswith('OK'), name
text = (PREP / 'shared-ledger-and-focused-tests.log').read_text()
assert text.count('4 passed; 0 failed;') == 2
assert '7 passed; 0 failed;' in (PREP / 'full-parent-label-tests.log').read_text()
assert 'Finished' in (PREP / 'expanded-clippy.log').read_text()
for name in ['broad.json.gz', 'shared-ledger-append.json', 'shared-ledger-append.log',
             'restore_and_append_ledger.py', 'shared-ledger-and-focused-tests.log',
             'full-parent-label-tests.log', 'expanded-clippy.log',
             'capture_broad.py', 'capture_broad-retry1.log', 'broad-audit.log',
             'broad-controls.log', 'historical-ledger-controls.log']:
    path = PREP / name
    target = DOCS / ('fear-lsera-' + name + ('' if name.endswith('.gz') else '.gz'))
    data = path.read_bytes() if name.endswith('.gz') else gzip.compress(path.read_bytes(), mtime=0)
    assert not target.exists() or target.read_bytes() == data, target
    target.write_bytes(data)
for family, log in [('source', 'source-audit-retry2.log'), ('streams', 'streams-audit.log'),
                    ('cohort', 'cohort-audit-retry1.log'), ('corpora', 'corpora-audit-retry1.log'),
                    ('browser', 'browser-audit.log')]:
    (DOCS / ('fear-lsera-' + log + '.gz')).write_bytes(gzip.compress((PREP / log).read_bytes(), mtime=0))
paragraph = (
    'Two original ending owners (86497/86619) retain all three senses, separate short/full '
    'attachment notes and every25complete example groups, including multi-line contexts. '
    'Forty-six independently authored judgments (37required/9forbidden) cover all original '
    'targets, allomorphs, source-licensed honorific/past prefinals, explicit copulas and '
    'irregular recovery. Four focused Rust regressions preserve every prior path/order '
    'and all628observed Source additions against74complete original Native identities. '
    'Seven viewer-label tests and focused Clippy with warnings denied pass. Twelve '
    'whole-source Unicode/filter/cache streams preserve4344frames and complete original '
    'contexts. Six independent source/stream/cohort/gold/browser/broad audits pass '
    '23/18/5/10/19/15corruption controls. All53502cohort words,66570original annotated '
    'rows and1128312broad frames remain exact, including all spacing diagnostics. '
    'The first broad replay failed after a Rust integration test rebuilt the CLI; its '
    'failure and producer are retained. Exact original feature-web CLI hash was restored, '
    'and the complete repeat passed with unchanged inputs. Browser proof passes222policy '
    'decisions/222diagrams/six exact CLI exports/74fullNative responses; owned server '
    'stopped. The shared ledger preserves its exact35484case prefix and appends only '
    'the46independent cases:35530total,31300required and4246forbidden. Four shared-ledger '
    'tests and all78historical corruption controls pass. The628observed alternative '
    'paths remain contextually unjudged and are not promoted to gold. Whole Rust, actual '
    'Nix/installed/main integration, quiet performance and wider/contextual/independent '
    'linguistic review remain open.')
(DOCS / 'fear-lsera-draft.md').write_text('# Apprehensive and exclamatory endings\n\n'
    'Status: complete finite source-backed private prototype; full Rust and integration pending.\n\n'
    + paragraph + '\n\nThe component uses canonical ending key -을세라 with both original owners. '
    'The connective/final worry senses and distinct exclamation sense remain separate in '
    'the dictionary. The parser enumerates structural possibilities; context selects the sense. '
    'Unreviewed modal/retrospective attachment does not borrow the independently licensed '
    'honorific/past paths.\n')
tracker = DOCS / 'coverage-checklist.md'
text = tracker.read_text()
assert 'COV-017cv —' not in text
marker = '- [ ] **COV-018 —'
assert text.count(marker) == 1
text = text.replace(marker, '- [ ] **COV-017cv — Apprehensive and exclamatory -ㄹ세라/-을세라.**\n'
                    '  **Partial: complete finite source-backed private prototype; full Rust and integration pending.**\n'
                    '  ' + paragraph + '\n  [Finite scope](fear-lsera-draft.md).\n\n' + marker)
tracker.write_text(text)
reviews_path = DOCS / 'inventory-reviews.json'
reviews = json.loads(reviews_path.read_text())
queue = json.loads((DOCS / 'inventory-review-queue.json').read_text())
suite = json.loads((ROOT / 'tests/fixtures/fear-lsera-validity.json').read_text())
evidence = [{'path': 'docs/fear-lsera-draft.md'}, {'path': 'tests/fear_lsera.rs'},
            {'path': 'tests/fixtures/fear-lsera-validity.json'},
            {'path': 'tests/fixtures/fear-lsera-additional-native.json'},
            *[{'path': 'docs/fear-lsera-' + name} for name in [
                'source-preparation.json.gz', 'independent-source-proposals.json.gz',
                'independent-authoring.json.gz', 'baseline-gap.json.gz', 'authored-native-closure.json.gz',
                'source-streams.json.gz', 'native-closure.json.gz', 'cohorts.json.gz', 'corpora.json.gz',
                'broad.json.gz', 'closure-browser.json.gz', 'shared-ledger-append.json.gz']]]
for family in ['source', 'streams', 'cohort', 'corpora', 'browser', 'broad']:
    evidence.extend({'path': f'tools/{prefix}fear_lsera_{family}_audit.py'} for prefix in ['', 'test_'])
assert all((ROOT / item['path']).exists() for item in evidence)
for ident, key in [('krdict:86497', 'fear-lsera-short'), ('krdict:86619', 'fear-lsera-full')]:
    source = next(row for row in queue['entries'] if row['source']['id'] == ident)
    assert source['review']['status'] == 'unreviewed'
    assert not any(e['id'] == ident for e in reviews['entries'])
    judgments = [{'case': case['id'], 'judgment': j['id']} for case in suite['cases']
                 for j in case['judgments'] if j['source'] == key]
    assert judgments
    reviews['entries'].append({'id': ident, 'source_sha256': source['source_sha256'], 'status': 'scoped',
                              'checklist': ['COV-017cv'], 'scope': paragraph,
                              'remaining': 'Whole Rust/Nix/installed/main integration, quiet novel timings, '
                                           'wider attachment distributions, contextual sense selection and independent linguistic review.',
                              'evidence': evidence, 'judgments': judgments})
reviews_path.write_text(json.dumps(reviews, ensure_ascii=False, indent=2) + '\n')
flake = ROOT / 'flake.nix'
text = flake.read_text()
families = ['source', 'streams', 'cohort', 'corpora', 'browser', 'broad']
files = ''.join(f'                ./tools/{prefix}fear_lsera_{family}_audit.py\n' for family in families for prefix in ['', 'test_'])
commands = ''.join(f"            python tools/fear_lsera_{family}_audit.py\n            python -m unittest discover -s tools -p 'test_fear_lsera_{family}_audit.py'\n" for family in families)
file_marker = '                ./tools/test_familiar_geurae_browser_audit.py\n'
command_marker = "            python -m unittest discover -s tools -p 'test_familiar_geurae_browser_audit.py'\n"
assert text.count(file_marker) == text.count(command_marker) == 1 and 'fear_lsera_source_audit.py' not in text
flake.write_text(text.replace(file_marker, file_marker + files).replace(command_marker, command_marker + commands))
(DOCS / 'fear-lsera-finite-scope-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('Preserved complete finite scope, two bounded source dispositions and six Nix audit families; regenerate queue last')
