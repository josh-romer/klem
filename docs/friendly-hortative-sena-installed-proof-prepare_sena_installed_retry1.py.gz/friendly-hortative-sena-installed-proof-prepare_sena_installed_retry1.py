"""Preserve the actual ANSI-header failure and rebind a same-source continuation."""
import ast,gzip,hashlib,json,re,subprocess,sys,unittest
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=P.parents[1];W=P.parent/'friendly-hortative-sena'
shared=ROOT/'.direnv/willingness-question-prepared/continue_friendly_installed_validation.py'
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=P/'friendly-hortative-sena-installed-retry1-preparation.json';assert not manifest.exists()
failed=json.loads((P/'friendly-hortative-sena-nix-packages.json').read_bytes())
assert failed['state']=='failed' and failed['exit_code']==0 and failed['release_log_exit_code']==0
assert all(failed[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged'])
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
release=(P/'friendly-hortative-sena-release-rust.log').read_bytes()
plain=re.sub(rb'\x1b\[[0-?]*[ -/]*[@-~]',b'',release)
assert b'Doc-tests klem' not in release and b'Doc-tests klem' in plain
assert b'test src/lib.rs - (line 3) ... ok' in release
batches=re.findall(rb'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',release)
assert len(batches)==257 and [sum(int(b[i]) for b in batches) for i in [1,2,3]]==[1212,0,1]
names=['build_friendly_hortative_sena_nix_packages.py','capture_friendly_hortative_sena_installed_runtime.py','run_friendly_hortative_sena_installed_browser.py','validate_friendly_hortative_sena_installed_audit.py','friendly_hortative_sena_installed_audit.py','test_friendly_hortative_sena_installed_audit.py']
mapping={name:name[:-3]+'_retry1.py' for name in names}
mapping['continue_friendly_installed_validation.py']='continue_sena_installed_validation_retry1.py'
tokens={**mapping,**{name[:-3]:target[:-3] for name,target in mapping.items()}}
pattern=re.compile(r'\b(?:'+'|'.join(re.escape(name) for name in sorted(tokens,key=len,reverse=True))+r')\b')
files={};new={}
def preserve(name,path):
 raw=path.read_bytes();dest=P/('friendly-hortative-sena-installed-retry1-original-'+name+'.gz');assert not dest.exists();dest.write_bytes(gzip.compress(raw,mtime=0));files[name]=dict(path=dest.name,source_sha256=sha(raw),archive_sha256=sha(dest.read_bytes()));return raw
for name in ['friendly-hortative-sena-nix-packages.json','friendly-hortative-sena-nix-packages.log','friendly-hortative-sena-release-rust.log','friendly-hortative-sena-installed-continuation.json','friendly-hortative-sena-installed-continuation.log']:
 preserve(name,P/name)
for name in names+['continue_friendly_installed_validation.py']:
 path=shared if name=='continue_friendly_installed_validation.py' else P/name
 raw=preserve(name,path);text=pattern.sub(lambda match:tokens[match.group()],raw.decode())
 text=text.replace('friendly-hortative-sena-nix-packages.json','friendly-hortative-sena-nix-packages-retry1.json').replace('friendly-hortative-sena-nix-packages.log','friendly-hortative-sena-nix-packages-retry1.log').replace('friendly-hortative-sena-release-rust.log','friendly-hortative-sena-release-rust-retry1.log')
 if name=='build_friendly_hortative_sena_nix_packages.py':
  old="  assert b'Doc-tests klem' in capture.stdout and b'test src/lib.rs - (line 3) ... ok' in capture.stdout"
  new_line="  normalized_release=re.sub(rb'\\x1b\\[[0-?]*[ -/]*[@-~]',b'',capture.stdout)\n  assert b'Doc-tests klem' in normalized_release and b'test src/lib.rs - (line 3) ... ok' in normalized_release"
  assert text.count(old)==1;text=text.replace(old,new_line)
 if name=='friendly_hortative_sena_installed_audit.py':
  text=text.replace("raw(PREFIX+'nix-packages.json')","raw(PREFIX+'nix-packages-retry1.json')").replace("read(PREFIX+'nix-packages.json')","read(PREFIX+'nix-packages-retry1.json')").replace("raw(PREFIX+'nix-packages.log')","raw(PREFIX+'nix-packages-retry1.log')").replace("raw(PREFIX+'release-rust.log')","raw(PREFIX+'release-rust-retry1.log')")
  old="    assert b'Doc-tests klem' in v['release_log'] and b'test src/lib.rs - (line 3) ... ok' in v['release_log']"
  new_line="    normalized_release=re.sub(rb'\\x1b\\[[0-?]*[ -/]*[@-~]',b'',v['release_log'])\n    assert b'Doc-tests klem' in normalized_release and b'test src/lib.rs - (line 3) ... ok' in normalized_release"
  assert text.count(old)==1;text=text.replace(old,new_line)
 if name=='validate_friendly_hortative_sena_installed_audit.py':
  text=text.replace("'nix-packages.json'","'nix-packages-retry1.json'").replace("'nix-packages.log'","'nix-packages-retry1.log'").replace("'release-rust.log'","'release-rust-retry1.log'")
 if name=='test_friendly_hortative_sena_installed_audit.py':
  before={n.name:ast.dump(n) for n in ast.walk(ast.parse(raw)) if isinstance(n,ast.FunctionDef)}
  after={n.name:ast.dump(n) for n in ast.walk(ast.parse(text)) if isinstance(n,ast.FunctionDef)}
  assert before==after,'every original40 test body retained'
 if name=='continue_friendly_installed_validation.py':
  text=text.replace("('packages', 'build_friendly_hortative_sena_nix_packages_retry1.py', prefix + 'nix-packages.json')","('packages', 'build_friendly_hortative_sena_nix_packages_retry1.py', prefix + 'nix-packages-retry1.json')")
  needle="prefix + 'installed-continuation.json'), folder / (prefix + 'installed-continuation.log')";assert text.count(needle)==1
  text=text.replace(needle,"prefix + 'installed-continuation-retry1.json'), folder / (prefix + 'installed-continuation-retry1.log')")
  text=text.replace("P = Path(__file__).resolve().parent","P = Path('/home/josh/projects/klem/.direnv/willingness-question-prepared')")
 ast.parse(text);dest=P/mapping[name];assert not dest.exists();dest.write_text(text);new[dest.name]=dict(sha256=sha(dest.read_bytes()),bytes=len(dest.read_bytes()))
sys.path.insert(0,str(W/'tools'));sys.path.insert(0,str(P))
import friendly_hortative_sena_installed_audit_retry1 as audit
import test_friendly_hortative_sena_installed_audit_retry1 as controls
assert Path(audit.__file__).resolve()==P/'friendly_hortative_sena_installed_audit_retry1.py'
assert unittest.defaultTestLoader.loadTestsFromModule(controls).countTestCases()==40
manifest.write_text(json.dumps(dict(state='prepared-same-source-ANSI-header-repair',head=failed['head'],originals=files,new_producers=new,release_log_original_sha256=sha(release),same_four_package_outputs=failed['outputs'],actual_original_release_totals=[1212,0,1],actual_original_release_batches=257,all_original40_test_bodies_unchanged=True,controls_discovered=40,controls_executed=False,full_original_logs_preserved=True),indent=2)+'\n')
print('Preserved',len(files),'originals; seven new programs. Actual release1212/0/1/257 passed; ANSI header comparison repaired, original40 test bodies retained.')
