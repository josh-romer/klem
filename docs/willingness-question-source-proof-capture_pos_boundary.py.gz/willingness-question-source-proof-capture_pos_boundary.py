"""Retain primary POS evidence for a dictionary-free unknown lexical head."""
import gzip
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

prep = Path(__file__).resolve().parent
root = Path('/home/josh/projects/klem')
work = Path('/tmp/klem-willingness-question-prototype')
out = prep / 'supplemental-pos-native-closure.json.gz'
assert not out.exists()
sys.path.insert(0, str(root / 'tools'))
from native_lmf import entry, feature

expected = {}
with sqlite3.connect((root / '.direnv/dictionary-restoration/krdict.db').resolve().as_uri() + '?mode=ro', uri=True) as db:
    for (raw,) in db.execute('SELECT data FROM entries WHERE headword = ?', ('예쁘다',)):
        owner = json.loads(raw)
        if owner['lexical_unit'] == '단어':
            expected[owner['id']] = owner
assert expected and all(owner['pos'] == '형용사' for owner in expected.values())
originals, exports = {}, {}
sha = lambda raw: hashlib.sha256(raw).hexdigest()
for source in sorted((root / '.direnv/dictionary-restoration/2026-09').glob('*.json')):
    raw = source.read_bytes()
    ids = []
    for value in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
        ident = 'krdict:' + value['val']
        if ident not in expected or feature(value, 'lexicalUnit') in {'관용구', '속담'}:
            continue
        assert ident not in originals and entry(value) == expected[ident]
        originals[ident] = value
        ids.append(ident)
    exports[source.name] = {'bytes': len(raw), 'sha256': sha(raw), 'ids': ids}
assert len(exports) == 11 and set(originals) == set(expected)
native = {'LexicalResource': {'Lexicon': {'LexicalEntry': list(originals.values())}}}
path = work / 'tests/fixtures/willingness-question-pos-native.json'
assert not path.exists()
path.write_text(json.dumps(native, ensure_ascii=False, indent=2) + '\n')
receipt = {'state': 'supplemental-original-pos-boundary-preserved-before-dictionary-probe',
           'original_native_entries': originals, 'complete_imported_entries': expected,
           'original_exports': exports,
           'judgment': 'A bare predicate path 예쁘다 + 으련 is incompatible with the original adjective POS and the endings verb-only notes. Without a dictionary, the lexical head is unknown to the finite class inventory and its hypothesis remains available.',
           'prior_observation': 'Initial test incorrectly assumed the raw finite lexical class inventory knew 예쁘다; raw probe showed the hypothesis retained. This source packet was authored after that observation and before a new dictionary probe; no pristine pre-implementation provenance is claimed.',
           'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())}}
out.write_bytes(gzip.compress((json.dumps(receipt, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
print(len(originals), 'complete original adjective owners; dictionary judgment prepared')
