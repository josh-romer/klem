"""Bind installed long-command packages and compare every preserved runtime output."""
import datetime,gzip,hashlib,json,re,subprocess,unicodedata
from pathlib import Path
PREP=Path(__file__).resolve().parent
WORK=Path('/home/josh/projects/klem/.direnv/gentle-command-long')
ROOT=PREP.parents[1]
PACKAGE=PREP/'gentle-command-long-nix-packages-retry2.json'
OUT=PREP/'gentle-command-long-installed-runtime.json.gz'
PROGRESS=PREP/'gentle-command-long-installed-runtime-progress.json'
DB=ROOT/'.direnv/dictionary-restoration/krdict.db'
assert not OUT.exists() and not PROGRESS.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(name):
 raw=(PREP/name).read_bytes();return json.loads(gzip.decompress(raw) if name.endswith('.gz') else raw)
def head():return subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
package=load(PACKAGE.name);assert package['state']=='passed' and all(package[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged'])
assert head()==package['head'] and not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
assert all(sha((WORK/n).read_bytes())==digest for n,digest in package['frozen_inputs'].items())
paths={}
for value in package['outputs']:
 name=next(n for n in ['klem-web-assets','klem-corpus-adapter','klem-web','klem'] if Path(value).name.endswith('-'+n+'-0.1.0') or Path(value).name.endswith('-'+n))
 assert name not in paths;paths[name]=value
assert set(paths)=={'klem','klem-web-assets','klem-corpus-adapter','klem-web'}
cli=Path(paths['klem'])/'bin/klem';adapter=Path(paths['klem-corpus-adapter'])/'bin/klem-corpus-adapter';server=Path(paths['klem'])/'bin/klem-web';launcher=Path(paths['klem-web'])/'bin/klem-web';assets=Path(paths['klem-web-assets'])/'share/klem-web'
binding=load('gentle-command-long-runtime-binding.json');assert binding['state']=='passed'
profiles={}
for name,attr,prefix in [('klem','klem',WORK),('klem-corpus-adapter','corpus-adapter',WORK),('klem-web-assets','web-assets',WORK/'web')]:
 source=Path(subprocess.check_output(['nix','eval','--offline','--raw','git+file://'+str(WORK)+'#packages.x86_64-linux.'+attr+'.src'],cwd=WORK,text=True).strip());files={}
 for file in source.rglob('*'):
  assert not file.is_symlink()
  if not file.is_file():continue
  rel=str(file.relative_to(source));digest=sha(file.read_bytes());assert digest==sha((prefix/rel).read_bytes());files[rel]=digest
 if name!='klem-web-assets':
  assert all(files[p]==digest for p,digest in binding['production_inputs'].items()),'complete44compiled inputs'
 profiles[name]=dict(package=paths[name],source=str(source),files=files)
assert len(profiles['klem-web-assets']['files'])==18
assert str(server) in launcher.read_text() and str(assets) in launcher.read_text()
log=(PREP/'gentle-command-long-nix-packages-retry2.log').read_text();batches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
totals={k:sum(int(batch[i+1]) for batch in batches) for i,k in enumerate(['passed','failed','ignored'])}
assert totals=={'passed':1191,'failed':0,'ignored':1} and len(batches)==254 and all(batch[0]=='ok' for batch in batches)
frozen={str(p):sha(p.read_bytes()) for p in [PACKAGE,DB,cli,adapter,server,launcher,Path(__file__),PREP/'gentle-command-long-runtime-binding.json']}
for b in binding['binaries'].values():
 assert sha(Path(b['path']).read_bytes())==b['sha256'];frozen[b['path']]=b['sha256']
for p in assets.rglob('*'):
 if p.is_file():frozen[str(p)]=sha(p.read_bytes())
r=dict(state='running',captured_head=package['head'],profiles=profiles,packages=paths,binaries={n:dict(path=str(p),sha256=frozen[str(p)]) for n,p in [('klem',cli),('adapter',adapter),('server',server),('launcher',launcher)]},assets={str(p.relative_to(assets)):sha(p.read_bytes()) for p in assets.rglob('*') if p.is_file()},release_rust=dict(totals=totals,batches=len(batches)),frozen_inputs=frozen,source_runs=[],native_records=[],corpus_runs=[],broad_runs=[],extra_runs=[],producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),scope='Actual currentlong installedNix4packages; complete44-source and18frontend binding;1191releaseRust;36Source policies,48uniquecompleteNativeowners,66570originalgoldrows,1128312broadframes and12Unicode/filter/cache policies for11additionalprivate novel/class cases. Original25private/sharedcases/517reviews, original raw hypotheses and contextual scope unchanged; complete inventory/main/browser/quiet/independent review remain separate.')
def save():
 PROGRESS.write_text(json.dumps({k:v for k,v in r.items() if k not in ['source_runs','native_records','corpus_runs','broad_runs','extra_runs']},ensure_ascii=False,indent=2)+'\n');OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False)+'\n').encode(),mtime=0))
save()
try:
 native={}
 for name in ['gentle-command-long-native-cli-retry1.json','gentle-command-long-novel-native-cli.json']:
  p=PREP/name;frozen[str(p)]=sha(p.read_bytes())
  for row in load(name)['records']:
   if row['id'] in native:assert native[row['id']]['complete_original_entry']==row['complete_original_entry'] and native[row['id']]['captures'][1]['json']==row['captures'][1]['json']
   else:native[row['id']]=row
 assert len(native)==48
 for field,name in [('source_runs','gentle-command-long-source-runtime-retry1.json.gz'),('native_records',None),('corpus_runs','gentle-command-long-corpora.json.gz'),('broad_runs','gentle-command-long-broad.json.gz')]:
  if name:
   p=PREP/name;frozen[str(p)]=sha(p.read_bytes());rows=load(name)['runs']
  else:rows=list(native.values())
  for row in rows:
   original_command=row['captures'][1]['command'] if field=='native_records' else row['commands'][1] if field=='broad_runs' else row['command'];command=[str(adapter if field=='corpus_runs' else cli),*original_command[1:]]
   if field=='broad_runs':
    original=Path(row['actual_source']).read_bytes();frozen[row['actual_source']]=sha(original);assert sha(original)==row['source_sha256']
    job=subprocess.Popen(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE);digest=hashlib.sha256();cursor=count=0;changes=[]
    for line in job.stdout:
     digest.update(line);frame=json.loads(line);assert frame['span']['start']==cursor;cursor=frame['span']['end'];assert original[frame['span']['start']:cursor].decode()==frame['surface']
     for change in row['changed_frames']:
      if frame['span']==change['after']['span']:assert frame==change['after'];changes.append(change)
     count+=1
    stderr=job.stderr.read();code=job.wait();assert code==0 and not stderr and count==row['records'] and cursor==len(original);assert digest.hexdigest()==row['after_jsonl_sha256'] and changes==row['changed_frames']
    record=dict(mode=row['mode'],command=command,exit_code=code,records=count,stdout_sha256=digest.hexdigest(),source_sha256=sha(original),original_bytes_conserved=True,changed_frames=changes)
   else:
    job=subprocess.run(command,cwd=ROOT,input=row['input_text'].encode() if field=='source_runs' else None,capture_output=True);expected=row['captures'][1]['json'] if field=='native_records' else row['jsonl'];assert job.returncode==0 and not job.stderr and job.stdout.decode()==expected,(field,command)
    record=dict(original_capture=row,command=command,exit_code=job.returncode,stdout=job.stdout.decode(),stdout_sha256=sha(job.stdout))
   r[field].append(record);save()
  print('Installed complete',field,len(r[field]),flush=True)
 cases=[]
 for name in ['gentle-command-long-novel-validity.json','gentle-command-class-interaction-validity.json']:
  p=WORK/'tests/fixtures'/name;frozen[str(p)]=sha(p.read_bytes());cases+=json.loads(p.read_bytes())['cases']
 assert len(cases)==11
 def matches(path,j):return all([part[key] for part in path[field]]==j[name] for field,key,name in [('lemmas','text','lemmas'),('lemmas','kind','lemma_kinds'),('morphemes','form','morphemes'),('morphemes','kind','morpheme_kinds')]) and set(j.get('required_rules',[]))<=set(path['rules'])
 for encoding in ['NFC','NFD']:
  payload=unicodedata.normalize(encoding,' '.join(c['surface'] for c in cases)).encode()
  for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
   for cache in [0,4096]:
    command=[str(cli),'text','-','--dictionary',str(DB),*flags,'--cache-bytes',str(cache)];reference=[binding['binaries']['klem']['path'],*command[1:]]
    prior=subprocess.run(reference,input=payload,capture_output=True);job=subprocess.run(command,input=payload,capture_output=True);assert prior.returncode==job.returncode==0 and not prior.stderr and not job.stderr and job.stdout==prior.stdout
    frames=[json.loads(line) for line in job.stdout.decode().splitlines()];cursor=0
    for frame in frames:assert frame['span']['start']==cursor and payload[cursor:frame['span']['end']].decode()==frame['surface'];cursor=frame['span']['end']
    assert cursor==len(payload);offset=0;checks=[]
    for case in cases:
     located=[(i,f) for i,f in enumerate(frames) if f['span']['start']==offset];assert len(located)==1;index,frame=located[0];assert frame['surface']==unicodedata.normalize(encoding,case['surface']);offset+=len(frame['surface'].encode())+1
     for j in case['judgments']:
      found=[i for i,path in enumerate((frame.get('analysis') or {}).get('analyses',[])) if matches(path,j)]
      if j['verdict']=='forbidden':assert not found
      elif mode=='raw' or case in cases[:8]:assert found
      checks.append(dict(case_id=case['id'],judgment_id=j['id'],verdict=j['verdict'],record_index=index,analysis_indices=found))
    r['extra_runs'].append(dict(encoding=encoding,mode=mode,cache_bytes=cache,command=command,reference_command=reference,exit_code=0,input_text=payload.decode(),input_sha256=sha(payload),stdout=job.stdout.decode(),stdout_sha256=sha(job.stdout),records=len(frames),original_bytes_conserved=True,observations=checks));save()
 print('Installed additional11privatecases',len(r['extra_runs']),'policies',flush=True)
 r.update(inputs_unchanged=all(sha(Path(p).read_bytes())==digest for p,digest in frozen.items()),source_unchanged=all(sha((WORK/n).read_bytes())==digest for n,digest in package['frozen_inputs'].items()),head_unchanged=head()==package['head'],index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK))==package['index_sha256'],finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());assert all(r[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged']);assert [len(r[f]) for f in ['source_runs','native_records','corpus_runs','broad_runs','extra_runs']]==[36,48,4,8,12]
 r['state']='passed';save()
except Exception as error:r.update(state='failed',error=str(error));save();raise
print('Passed installed long1191Rust/36Source/48Native/66570gold/1128312broad/12extra policies',flush=True)
