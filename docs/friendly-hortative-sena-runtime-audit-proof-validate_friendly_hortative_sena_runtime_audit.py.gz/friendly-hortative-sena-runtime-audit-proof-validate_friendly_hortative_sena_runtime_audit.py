"""Run independent Sena source controls with all inputs frozen for this receipt."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = Path('/home/josh/projects/klem')
W = ROOT / '.direnv/friendly-hortative-sena'
G = ROOT / '.direnv/friendly-command-gena'
O = P / 'friendly-hortative-sena-runtime-audit-validation.json'
L = P / 'friendly-hortative-sena-runtime-audit-validation.log'
assert not O.exists() and not L.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=W).decode().split('\0')[:-1]
frozen = {name: sha((W / name).read_bytes()) for name in names}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
index = sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=W))
parent = json.loads((ROOT / '.direnv/willingness-question-prepared/friendly-command-gena-nix-packages.json').read_bytes())
assert parent['state'] == 'passed'
assert all(sha((G / name).read_bytes()) == digest for name, digest in parent['frozen_inputs'].items())
external = {str(Path(__file__)): sha(Path(__file__).read_bytes())}
commands = [
    ['python3', 'tools/friendly_hortative_sena_runtime_audit.py'],
    ['python3', '-m', 'unittest', '-v', 'tools/test_friendly_hortative_sena_runtime_audit.py'],
    ['git', 'diff', '--check']]
env = dict(os.environ, PYTHONPATH=str(W / 'tools'), PYTHONDONTWRITEBYTECODE='1')
r = dict(state='running', head=head, index_sha256=index, frozen_inputs=frozen,
         external_inputs=external, unchanged_parent_inputs=parent['frozen_inputs'],
         producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), results=[],
         scope='Independent actualSena runtime/compile binding controls: exact44production/fivechanges/1153compiledinputs/18frontend/currentthreebinaries, full36CLIpolicies1608frames/2916oldpaths/716newunjudged paths/324required72forbidden/36Native, everyoldassessment/order/spans/caches/Unknownprefinals andRieul homonyms. Full Source audit integrated; no broadercohort/gold/history/broad/browser/installed/Nix/main/performance/contextual claim.')

def save():
    O.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')

save()
with L.open('xb') as log:
    for command in commands:
        log.write(('COMMAND ' + json.dumps(command) + '\n').encode())
        log.flush()
        job = subprocess.run(command, cwd=W, env=env, stdout=log, stderr=subprocess.STDOUT)
        r['results'].append(dict(command=command, exit_code=job.returncode))
        save()
        print(command, 'exit', job.returncode, flush=True)
        if job.returncode:
            break
r.update(inputs_unchanged=all(sha((W / name).read_bytes()) == digest for name, digest in frozen.items()),
         external_inputs_unchanged=all(sha(Path(path).read_bytes()) == digest for path, digest in external.items()),
         gena_parent_inputs_unchanged=all(sha((G / name).read_bytes()) == digest for name, digest in parent['frozen_inputs'].items()),
         head_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip() == head,
         index_unchanged=sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=W)) == index,
         log_sha256=sha(L.read_bytes()), finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
m = re.search(r'Ran (\d+) tests', L.read_text())
r['controls'] = int(m[1]) if m else 0
r['state'] = 'passed' if len(r['results']) == len(commands) and all(x['exit_code'] == 0 for x in r['results']) and all(
    r[k] for k in ['inputs_unchanged', 'external_inputs_unchanged', 'gena_parent_inputs_unchanged', 'head_unchanged', 'index_unchanged']) else 'failed'
save()
print(r['state'], r['controls'], 'independent source controls', flush=True)
raise SystemExit(0 if r['state'] == 'passed' else 1)
