"""Verify source-bound server, assets, CLI exports and original dropdown paths."""
import hashlib,json,os,re,signal,subprocess,urllib.request
from pathlib import Path
prep=Path(__file__).resolve().parent;work=Path('/tmp/klem-willingness-question-prototype')
binding_path=prep/'browser-prototype-build.json';binding=json.loads(binding_path.read_text());assert binding['state']=='passed' and binding['inputs_unchanged'] and binding['prior_binaries_unchanged']
cli_binding_path=prep/'prototype-binaries-retry2.json';cli_binding=json.loads(cli_binding_path.read_text());assert cli_binding['state']=='passed'
server=Path(binding['server']['path']);cli=Path(cli_binding['binaries']['klem']['path']);assets=work/'web/dist'
db=Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db');driver=prep/'willingness-browser.mjs';out=prep/'willingness-prototype-browser-runtime.json';assert not out.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
assert sha(server)==binding['server']['sha256'] and sha(cli)==cli_binding['binaries']['klem']['sha256']
assert {str(p.relative_to(assets)):sha(p) for p in assets.rglob('*') if p.is_file()}==binding['assets']
files=[server,cli,db,driver,binding_path,cli_binding_path,Path(__file__),work/'web/src/grammar-labels.json']
files += [work/'tests/fixtures'/n for n in ['willingness-question-validity.json','willingness-question-boundary-validity.json','willingness-question-native-entries.json']]
files.extend(p for p in assets.rglob('*') if p.is_file());frozen={str(p):sha(p) for p in files}
command=[str(server),'--port','0','--assets',str(assets),'--dictionary',str(db)]
r={'state':'running','command':command,'frozen_inputs':frozen,'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__))}}
def save():out.write_text(json.dumps(r,indent=2)+'\n')
save();job=subprocess.Popen(command,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
try:
 line=job.stderr.readline();match=re.search(r'http://127\.0\.0\.1:\d+',line);assert match,line
 url=match.group();r['url']=url
 with urllib.request.urlopen(url+'/api/status',timeout=10) as response:r['status']=json.load(response)
 with urllib.request.urlopen(url,timeout=10) as response:html=response.read();assert html==(assets/'index.html').read_bytes()
 for path in re.findall(r'(?:src|href)="(/assets/[^"?#]+\.(?:js|css))"',html.decode()):
  with urllib.request.urlopen(url+path,timeout=10) as response:assert response.read()==(assets/path.lstrip('/')).read_bytes()
 env=dict(os.environ,KLEM_WEB_URL=url,KLEM_BIN=str(cli),KLEM_CAPTURE_PREFIX=str(prep/'willingness-prototype'),CHROMIUM_PATH='/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium')
 log=prep/'willingness-prototype-browser-runtime.log'
 with log.open('xb') as stream:p=subprocess.run(['node',str(driver)],env=env,stdout=stream,stderr=subprocess.STDOUT)
 r.update(state='passed' if p.returncode==0 else 'failed',exit_code=p.returncode,log_sha256=sha(log))
except Exception as error:r.update(state='failed',error=str(error));raise
finally:
 if job.poll() is None:job.send_signal(signal.SIGINT)
 r.update(server_exit_code=job.wait(timeout=20),server_stopped=True,inputs_unchanged=all(sha(p)==d for p,d in frozen.items()));save()
assert r['state']=='passed' and r['inputs_unchanged']
print('Original15source/boundary dropdowns, six policies/exports and29 Native endpoints passed; owned server stopped',flush=True)
