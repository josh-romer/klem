"""Preserve every same-head original owner and author targets before any runtime probe."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path

PREP = Path(__file__).resolve().parent
SOURCE = Path('/home/josh/projects/klem/docs/unreviewed-inventory-source-closure.json.gz')
OUT = PREP / 'independent-source-authoring.json'
assert not OUT.exists()
raw = gzip.decompress(SOURCE.read_bytes())
source = json.loads(raw)
owner_ids = ['krdict:76564', 'krdict:76567']
expression_ids = ['krdict:86640', 'krdict:86631']
owners = {key: entry for key, entry in source['complete_native_entries'].items() if entry['headword'] in ['-련', '-으련']}
assert set(owners) == set(owner_ids + expression_ids)
groups = [group for group in source['groups'] if group['entry_id'] in owner_ids]
assert len(groups) == 10
ending_targets = [('두련', '두다'), ('주련', '주다'), ('가련', '가다'), ('운전하련', '운전하다'), ('주련', '주다'), ('만나련', '만나다'), ('않으련', '않다'), ('걷으련', '걷다'), ('있으련', '있다'), ('먹으련', '먹다')]
items = []
for group, (surface, lemma) in zip(groups, ending_targets, strict=True):
    text = '\n'.join(group['complete_original_examples']).encode()
    target = surface.encode()
    assert text.count(target) == 1
    position = text.index(target)
    items.append({'id': 'willingness-question-' + group['entry_id'].split(':')[1] + '-sense-' + group['sense_id'] + '-group-' + str(group['example_group']),
                  'source_group_id': group['id'], 'entry_id': group['entry_id'], 'sense_id': group['sense_id'], 'example_group': group['example_group'],
                  'complete_original_group': group['complete_original_examples'], 'surface': surface,
                  'local_span': {'start': position, 'end': position + len(target)},
                  'typed_target': {'id': 'lexical-path', 'verdict': 'required', 'lemmas': [lemma], 'lemma_kinds': ['predicate'], 'morphemes': ['으련'], 'morpheme_kinds': ['ending'],
                                   'reason': 'Independent lexical and canonical ending proposal from this complete original ending example; no exact dictionary sense, speaker-context verdict or exclusion of other candidates is assigned.'},
                  'contextual_verdict': 'unjudged', 'independent_korean_review': 'pending'})
# The old discovery queue enumerated only grammar-POS owners. POS-none
# expression homonyms are nevertheless preserved completely in its Native
# closure, so derive their groups directly from those original sense examples.
expressions = []
expression_targets = iter([('주련', '주다'), ('주련', '주다'), ('도와주련', '도와주다'), ('주련', '주다'), ('입으련', '입다'), ('지으련', '짓다'), ('잡으련', '잡다'), ('먹으련', '먹다')])
for ident in expression_ids:
    for sense in owners[ident]['senses']:
        for ordinal, original in enumerate(sense['examples'], 1):
            surface, lemma = next(expression_targets)
            encoded, target = '\n'.join(original).encode(), surface.encode()
            assert encoded.count(target) == 1
            position = encoded.index(target)
            expressions.append({'id': 'willingness-question-expression-' + ident.split(':')[1] + '-sense-' + sense['id'] + '-group-' + str(ordinal),
                                'entry_id': ident, 'sense_id': sense['id'], 'example_group': ordinal, 'complete_original_group': original,
                                'surface': surface, 'local_span': {'start': position, 'end': position + len(target)},
                                'independent_lexical_proposal': [lemma], 'morphological_judgment': 'unjudged; no ending role borrowed from homonym1', 'contextual_verdict': 'unjudged'})
assert len(expressions) == 8 and next(expression_targets, None) is None
record = {'state': 'original-source-targets-authored-before-runtime-probe', 'authored_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'source_archive_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(), 'complete_source_closure_sha256': hashlib.sha256(raw).hexdigest(),
          'ending_owner_ids': owner_ids, 'expression_owner_ids': expression_ids, 'owners': owners,
          'original_lmf': {key: source['original_lmf'][key] for key in owners}, 'source_exports': source['source_exports'],
          'items': items, 'separate_expression_groups': expressions,
          'producer': {'text': Path(__file__).read_text(), 'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
          'scope': 'Allfour same-head original owners including two POS-none expressions; all10ending/8expression fullgroups, dialogues andtrailing spaces. Ten typed ending targets andeight separateexpression lexicalproposals independentlyauthored before any new baseline/implementationprobe. Endinghomonym1 asks acceptanceofspeaker-offeredaction; expressionhomonym2 asks listenerintent. No morphologicalownership/sense equivalence is inferred. Original verb attachment notes and 있으련 context remain explicit. Adjective/copula/prefinal/particle/joined-auxiliary/shortening/generaldistribution/contextual/independentreview remain open.'}
OUT.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
(PREP / 'source-targets.txt').write_text('\n\n'.join('\n'.join(item['complete_original_group']) for item in items + expressions) + '\n')
failures = {'state': 'two-initial-source-preparation-assumptions-rejected-before-writing-authoring-record',
            'attempt1': 'Complete same-head closure contains four owners, including two POS-none expression homonyms; initial assertion expected only two endings.',
            'attempt2': 'Old inventory groups list covers grammar-POS entries only, so expression groups cannot be selected from that list; derive all eight directly from original Native sense examples.',
            'scope': 'No runtime probe, implementation, gold fixture or manual review change occurred. Preserve every original field and group; no source expectation was changed to fit observed program output.'}
(PREP / 'initial-preparation-failures.json').write_text(json.dumps(failures, indent=2) + '\n')
print('Authored before probe:', len(owners), 'original owners;', len(items), 'typed ending targets;', len(expressions), 'separate expression lexical proposals', flush=True)
