import hashlib,json,os,re,signal,subprocess,urllib.request
from pathlib import Path
ROOT=Path('/home/josh/projects/klem/.direnv/reported-experience-integration');PREFIX=Path('/home/josh/projects/klem/.direnv/reported-experience-installed-validation/reported-experience-browser-runtime');OUT=Path(str(PREFIX)+'.json');assert not OUT.exists()
BIN=Path('/nix/store/dhp558y832340xnj40j6cdnivayy4hlr-klem-0.1.0/bin');ASSETS=Path('/nix/store/5zwa8iddqn0isvxfiv8bszwn5cn838yn-klem-web-assets-0.1.0/share/klem-web');DB=Path('/home/josh/projects/klem/data/dictionaries/krdict/krdict.db');DRIVER=Path('/home/josh/projects/klem/.direnv/reported-experience-installed-validation/reported-experience-browser.mjs')
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
binding=Path('/home/josh/projects/klem/.direnv/reported-experience-prepared/installed-source-binding.json');package=json.loads(binding.read_bytes());assert package['state']=='passed' and str(BIN/'klem')==next(p for p in package['outputs'] if p.endswith('-klem-0.1.0'))+'/bin/klem'
inputs={str(p):sha(p) for p in [binding,BIN/'klem',BIN/'klem-web',DB,DRIVER,Path(__file__),ROOT/'tests/fixtures/reported-experience-validity.json', ROOT/'tests/fixtures/reported-experience-native-entries.json', ROOT/'web/src/grammar-labels.json', ROOT/'src/dictionary/attachment.rs', ROOT/'src/engine.rs', ROOT/'src/grammar.rs',*[p for p in ASSETS.rglob('*') if p.is_file()]]}
command=[str(BIN/'klem-web'),'--port','0','--assets',str(ASSETS),'--dictionary',str(DB)]
r={'state':'running','command':command,'frozen_inputs':inputs};OUT.write_text(json.dumps(r,indent=2)+'\n');job=subprocess.Popen(command,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
try:
 line=job.stderr.readline();match=re.search(r'http://127\.0\.0\.1:\d+',line);assert match,line;url=match.group();r['url']=url
 with urllib.request.urlopen(url+'/api/status',timeout=10) as response:status=json.load(response)
 r['status']=status
 with urllib.request.urlopen(url,timeout=10) as response:html=response.read();assert html==(ASSETS/'index.html').read_bytes()
 for path in re.findall(r'(?:src|href)="(/assets/[^"?#]+\.(?:js|css))"',html.decode()):
  with urllib.request.urlopen(url+path,timeout=10) as response:assert response.read()==(ASSETS/path.lstrip('/')).read_bytes()
 env=dict(os.environ,KLEM_WEB_URL=url,KLEM_BIN=str(BIN/'klem'),KLEM_CAPTURE_PREFIX='/home/josh/projects/klem/.direnv/reported-experience-installed-validation/reported-experience',CHROMIUM_PATH='/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium')
 with Path(str(PREFIX)+'.log').open('xb') as log:completed=subprocess.run(['node',str(DRIVER)],env=env,stdout=log,stderr=subprocess.STDOUT)
 r.update(state='passed' if completed.returncode==0 else 'failed',exit_code=completed.returncode)
finally:
 if job.poll() is None:job.send_signal(signal.SIGINT)
 r['server_exit_code']=job.wait(timeout=20);r['server_stopped']=True;r['inputs_unchanged']=all(sha(p)==d for p,d in inputs.items());OUT.write_text(json.dumps(r,indent=2)+'\n')
assert r['state']=='passed';assert r['inputs_unchanged'];print('Installed browser capture passed; owned server stopped.')
