"""Author explicit structural targets from the novel and original grammar notes."""
import gzip
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
PROTO = OUT.parent / 'explanatory-se-prototype'
prepared = json.loads(gzip.decompress((OUT / 'source-preparation.json.gz').read_bytes()))
broad = json.loads(gzip.decompress((OUT / 'broad.json.gz').read_bytes()))
raw = next(r for r in broad['comparisons'] if r['mode'] == 'novel-raw')
# Explicit dictionary/grammar targets; do not copy lemma groups from captures.
targets = [
    ('copula-road', '길일세', ['길', '이다'], ['nominal', 'copula'], ['을세'], ['ending'], '79278'),
    ('copula-owner', '주인일세', ['주인', '이다'], ['nominal', 'copula'], ['을세'], ['ending'], '79278'),
    ('copula-words', '말일세', ['말', '이다'], ['nominal', 'copula'], ['을세'], ['ending'], '79278'),
    ('copula-thing', '것일세', ['것', '이다'], ['nominal', 'copula'], ['을세'], ['ending'], '79278'),
    ('copula-sister', '누일세', ['누이', '이다'], ['nominal', 'copula'], ['을세'], ['ending'], '79278'),
    ('copula-daughter-emphasis', '딸일세그려', ['딸', '이다'], ['nominal', 'copula'], ['을세', '그려'], ['ending', 'particle'], '79278'),
    ('formal-go', '갑니다그려', ['가다'], ['predicate'], ['습니다', '그려'], ['ending', 'particle'], '83914'),
    ('formal-absent', '없소그려', ['없다'], ['predicate'], ['소', '그려'], ['ending', 'particle'], '83914'),
    ('friendly-live', '지내게그려', ['지내다'], ['predicate'], ['게', '그려'], ['ending', 'particle'], '83914'),
    ('statement-unknown', '모르네그려', ['모르다'], ['predicate'], ['네', '그려'], ['ending', 'particle'], '83914'),
    ('statement-modal', '되겠네그려', ['되다'], ['predicate'], ['겠', '네', '그려'], ['prefinal', 'ending', 'particle'], '83914'),
    ('statement-past', '왔네그려', ['오다'], ['predicate'], ['었', '네', '그려'], ['prefinal', 'ending', 'particle'], '83914'),
    ('formal-honorific-past', '찾으셨습니다그려', ['찾다'], ['predicate'], ['시', '었', '습니다', '그려'], ['prefinal', 'prefinal', 'ending', 'particle'], '83914'),
    ('lexical-honorific', '주무십니다그려', ['주무시다'], ['predicate'], ['습니다', '그려'], ['ending', 'particle'], '83914'),
]
cases, contexts = [], []
for ident, surface, lemmas, kinds, morphemes, morph_kinds, owner in targets:
    frames = [f for f in raw['changed_frames'] if f['after']['surface'] == surface]
    assert frames
    rule = 'ending.explanatory_se' if owner == '79278' else 'particle.familiar_gryeo'
    cases.append({'id': 'explanatory-se-novel-' + ident, 'surface': surface,
                  'judgments': [{'id': 'structural', 'lemmas': lemmas, 'lemma_kinds': kinds,
                                 'morphemes': morphemes, 'morpheme_kinds': morph_kinds,
                                 'required_rules': [rule], 'verdict': 'required', 'source': 'original-' + owner,
                                 'reason': 'Manually authored structural reading from the complete unchanged novel sentence and original attachment note. Other emitted paths, contextual homonym selection and spacing stay unjudged; this is not whole-sentence precision certification.'}]})
    contexts.append({'case_id': cases[-1]['id'], 'source': raw['source'], 'source_sha256': raw['source_sha256'],
                     'source_owner': prepared['expression_entries']['krdict:' + owner],
                     'original_occurrences': [{'record': f['record'], 'span': f['after']['span'], 'complete_original_line': f['complete_original_line']} for f in frames]})
suite = {'schema_version': 1, 'review_status': 'Fourteen manually authored structural novel targets. Corpus annotations remain separate; unjudged candidates and spacing are retained, and wider/contextual/independent review stays open.',
         'sources': {'original-' + i: prepared['expression_entries']['krdict:' + i]['url'] for i in ['79278', '83914']},
         'cases': cases}
for name, value in [('explanatory-se-novel-validity.json', suite), ('explanatory-se-novel-contexts.json', contexts)]:
    p = PROTO / 'tests/fixtures' / name
    assert not p.exists()
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
print('Authored 14 structural novel cases with every complete original occurrence.', flush=True)
