"""Verify the exact eight-case append and every historical whitelist control."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

root = Path('/tmp/klem-willingness-interactions')
prep = Path(__file__).resolve().parent
out = prep / 'willingness-interaction-ledger-checks.json'
assert not out.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [root / p for p in subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')[:-1]]
files += [root / 'docs/willingness-question-interaction-parent-validity.json.gz', Path(__file__)]
frozen = {str(p): sha(p) for p in files}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
index = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=root)).hexdigest()
commands = [(['python3', 'tools/expression_conjectural_ledger_audit.py'], None),
            (['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_expression_conjectural_ledger_audit.py'], 22),
            (['python3', 'tools/literary_question_geona_runtime.py', '--report', 'docs/literary-question-geona-packaged-cli-replay.json'], None),
            (['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_literary_question_geona_runtime.py'], 97),
            (['cargo', 'fmt', '--all', '--', '--check'], None),
            (['cargo', 'test', '--locked', '--offline', '--features', 'web', '--test', 'validity', '--test', 'willingness_question'], 17),
            (['cargo', 'clippy', '--locked', '--offline', '--features', 'web', '--test', 'validity', '--test', 'willingness_question', '--', '-D', 'warnings'], None)]
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/klem-willingness-interaction-target', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2')
r = {'state': 'running', 'pid': os.getpid(), 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'head': head, 'index_sha256': index, 'frozen_inputs': frozen, 'runs': [],
     'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)},
     'scope': 'Complete 35681-case shared candidate ledger and exact Source/history/case/review preservation; only8preauthored interactions appended. All22active-ledger and97historical-whitelist corruption controls, complete validity/willingness Rust targets, whole formatting and focused Clippy. Unjudged policy/semantic proposals are not gold. Full suite/Nix/installed/browser/main, broader inventory and independent contextual review remain separate.'}
save = lambda: out.write_text(json.dumps(r, indent=2) + '\n')
save()
try:
    for i, (command, count) in enumerate(commands):
        log = prep / ('willingness-interaction-ledger-checks-' + str(i) + '.log')
        assert not log.exists()
        with log.open('xb') as stream:
            job = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
        raw = log.read_bytes(); actual = None
        if command[0] == 'python3' and count is not None and job.returncode == 0:
            matches = re.findall(rb'Ran (\d+) tests? in ', raw)
            assert len(matches) == 1 and int(matches[0]) == count and raw.rstrip().endswith(b'OK')
            actual = count
        elif command[:2] == ['cargo', 'test'] and job.returncode == 0:
            batches = re.findall(rb'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', raw)
            actual = sum(int(b[1]) for b in batches)
            assert len(batches) == 2 and all(b[0] == b'ok' and int(b[2]) == 0 for b in batches)
            assert b'test independently_authored_irregular_auxiliary_and_class_interactions ... ok' in raw
            assert b'test source_backed_judgments_pass_and_unreviewed_outputs_stay_visible ... ok' in raw
        r['runs'].append({'command': command, 'exit_code': job.returncode, 'tests': actual, 'log_sha256': sha(log)}); save()
        assert job.returncode == 0, (i, str(log))
        print('completed', i, 'tests', actual, flush=True)
    r.update(state='passed', exit_code=0, controls=119)
except Exception as error:
    r.update(state='failed', error=str(error))
    raise
finally:
    r.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), inputs_unchanged=all(sha(p) == h for p, h in frozen.items()),
             head_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == head,
             index_unchanged=hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=root)).hexdigest() == index)
    save()
assert r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged']
print('Exact ledger/historical controls and library tests passed with every captured input unchanged', flush=True)
