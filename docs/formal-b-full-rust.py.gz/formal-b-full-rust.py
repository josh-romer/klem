"""Record the actual complete private Rust run after both finite ledger appends."""
import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
proto=ROOT.parent/'formal-b-prototype'
log=ROOT/'full-rust-after-novel.log';receipt=ROOT/'full-rust-after-novel.json'
assert not log.exists() and not receipt.exists()
command=['cargo','test','--offline','--features','web']
import os
env={**os.environ,'CARGO_TARGET_DIR':str(ROOT.parent/'formal-b-target')}
with log.open('wb') as stream:r=subprocess.run(command,cwd=proto,env=env,stdout=stream,stderr=subprocess.STDOUT)
text=log.read_text();batches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
totals={k:sum(int(b[i+1]) for b in batches) for i,k in enumerate(['passed','failed','ignored'])}
value={'state':'passed' if r.returncode==0 and totals['failed']==0 else 'failed','exit_code':r.returncode,'command':command,'totals':totals,'batches':len(batches),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'scope':'Actual complete private Rust suite after 99 formal source cases and nine novel cases appended to the unchanged historical ledger. Integration/Nix/installed validation separate.'}
receipt.write_text(json.dumps(value,indent=2)+'\n');print(value,flush=True)
raise SystemExit(r.returncode)
