"""Probe immutable installed baseline only after complete original targets exist."""
import gzip
import hashlib
import json
import subprocess
import unicodedata
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
PREP = BASE / 'fear-lsera-prepared'
source = PREP / 'source-preparation.json.gz'
proposals_path = PREP / 'independent-source-proposals.json'
proposals = json.loads(proposals_path.read_bytes())
assert proposals['state'] == 'authored-before-baseline-and-implementation'
sha = lambda path: hashlib.file_digest(Path(path).open('rb'), 'sha256').hexdigest()
assert proposals['source_preparation_sha256'] == sha(source)
binding_path = BASE / 'explanatory-se-prepared/installed-source-binding.json'
binding = json.loads(binding_path.read_bytes())
assert binding['state'] == 'passed' and binding['exit_code'] == 0
cli = Path(binding['profiles']['klem']['package']) / 'bin/klem'
assert str(cli).startswith('/nix/store/')
db = BASE / 'dictionary-restoration/krdict.db'
frozen = {str(p): sha(p) for p in [source, proposals_path, binding_path, cli, db, Path(__file__)]}
output = PREP / 'baseline-gap.json.gz'
assert not output.exists()
runs = []
for proposal in proposals['proposals']:
    for encoding in ['NFC', 'NFD']:
        for mode, flags in [('raw', []), ('headword', ['--dict-only']), ('compatible', ['--dict-compatible'])]:
            command = [str(cli), 'word', unicodedata.normalize(encoding, proposal['surface']), '--dictionary', str(db), *flags]
            result = subprocess.run(command, capture_output=True, check=True)
            assert not result.stderr
            record = json.loads(result.stdout)
            lexical_matches = [path for path in record['analyses'] if [l['text'] for l in path['lemmas']] == proposal['proposed_lemmas']]
            structural_matches = [path for path in lexical_matches if [m['form'] for m in path['morphemes']] == proposal['proposed_morphemes']]
            runs.append({'id': proposal['id'], 'surface': proposal['surface'], 'encoding': encoding, 'mode': mode,
                         'command': command, 'exit_code': result.returncode, 'record': record,
                         'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                         'lexical_target_matches': len(lexical_matches), 'structural_target_matches': len(structural_matches)})
assert len(runs) == 150 and all(sha(path) == digest for path, digest in frozen.items())
report = {'state': 'actual-installed-baseline-observed-after-independent-source-proposals', 'runs': runs,
          'frozen_inputs': frozen, 'inputs_unchanged': True,
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)},
          'scope': 'Immutable actual installed explanatory baseline probes every independently authored source target in NFC/NFD and raw/headword/Compatible. Original complete groups, target identities and canonical morphs were authored before this probe. This identifies finite gaps; it does not judge other candidates or supply gold.'}
output.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
print('Captured150independent installed baseline records; lexicalmatches', sum(r['lexical_target_matches'] for r in runs),
      'structuralmatches', sum(r['structural_target_matches'] for r in runs), 'unchangedinputs', report['inputs_unchanged'], flush=True)
