"""Bring the completed familiar installed evidence into the apprehensive prototype."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
PARENT = BASE / 'familiar-geurae-integration'
ROOT = BASE / 'fear-lsera-prototype'
PREP = BASE / 'fear-lsera-prepared'
BEFORE, AFTER = 'd2deff5', '6506feb'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(PARENT), *args])


def original(path):
    return git('show', f'{BEFORE}:{path}')


def final(path):
    return git('show', f'{AFTER}:{path}')


report_path = PREP / 'installed-parent-reconciliation.json'
assert not report_path.exists()
changed = [line.split('\t') for line in git('diff', '--name-status', BEFORE, AFTER).decode().splitlines()]
assert len(changed) == 37 and all(status in {'A', 'M'} for status, _ in changed)
assert all(path.startswith(('docs/', 'tools/')) or path == 'flake.nix' for _, path in changed)
protected = ['src/grammar.rs', 'src/engine.rs', 'src/bin/klem-web/grammar_labels.rs',
             'web/src/grammar-labels.json', 'tests/fear_lsera.rs',
             'tests/fixtures/validity.json', 'tests/fixtures/fear-lsera-validity.json',
             'tests/fixtures/fear-lsera-additional-native.json']
protected_hashes = {path: sha((ROOT / path).read_bytes()) for path in protected}
fear_files = [p for sub in ['tools', 'docs', 'tests'] for p in (ROOT / sub).rglob('*')
              if p.is_file() and 'fear' in p.name and '__pycache__' not in p.parts]
fear_hashes = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in fear_files}
manual = {'docs/coverage-checklist.md', 'docs/inventory-reviews.json',
          'docs/inventory-review-queue.json', 'flake.nix'}
written = {}
for status, path in changed:
    if path in manual:
        continue
    target = ROOT / path
    if status == 'A':
        assert not target.exists() or target.read_bytes() == final(path), path
    else:
        assert target.read_bytes() in [original(path), final(path)], path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(final(path))
    written[path] = sha(target.read_bytes())

path = ROOT / 'docs/coverage-checklist.md'
text = path.read_text()
parent_text = final('docs/coverage-checklist.md').decode()
pattern = r'(?ms)^- \[ \] \*\*COV-017cu.*?(?=^- \[[ x]\] \*\*COV-)'
old = re.search(pattern, text)
new = re.search(pattern, parent_text)
assert old and new and 'COV-017cv' not in new.group()
text = text[:old.start()] + new.group() + text[old.end():]
assert text.count('COV-017cv —') == 1
path.write_text(text)

path = ROOT / 'docs/inventory-reviews.json'
reviews = json.loads(path.read_text())
parent_reviews = json.loads(final('docs/inventory-reviews.json'))
replacement = [e for e in parent_reviews['entries'] if e['id'] == 'krdict:83913']
assert len(replacement) == 1
before_reviews = {e['id']: e for e in reviews['entries']}
assert 'krdict:86497' in before_reviews and 'krdict:86619' in before_reviews
reviews['entries'] = [replacement[0] if e['id'] == 'krdict:83913' else e for e in reviews['entries']]
assert all(e == before_reviews[e['id']] for e in reviews['entries'] if e['id'] != 'krdict:83913')
path.write_text(json.dumps(reviews, ensure_ascii=False, indent=2) + '\n')

path = ROOT / 'flake.nix'
text = path.read_text()
assert 'familiar_geurae_installed_audit.py' not in text
files = '                ./tools/familiar_geurae_installed_audit.py\n                ./tools/test_familiar_geurae_installed_audit.py\n'
commands = "            python tools/familiar_geurae_installed_audit.py\n            python -m unittest discover -s tools -p 'test_familiar_geurae_installed_audit.py'\n"
file_marker = '                ./tools/test_familiar_geurae_browser_audit.py\n'
command_marker = "            python -m unittest discover -s tools -p 'test_familiar_geurae_browser_audit.py'\n"
assert text.count(file_marker) == text.count(command_marker) == 1
text = text.replace(file_marker, file_marker + files).replace(command_marker, command_marker + commands)
assert all(f'fear_lsera_{family}_audit.py' in text for family in ['source', 'streams', 'cohort', 'corpora', 'browser', 'broad'])
path.write_text(text)
assert {path: sha((ROOT / path).read_bytes()) for path in protected} == protected_hashes
assert {path: sha((ROOT / path).read_bytes()) for path in fear_hashes} == fear_hashes
report = {'state': 'passed', 'previous_parent': git('rev-parse', BEFORE).decode().strip(),
          'installed_parent': git('rev-parse', AFTER).decode().strip(), 'written_parent_files': written,
          'protected_runtime_and_judgments': protected_hashes, 'protected_fear_files': fear_hashes,
          'only_updated_review': 'krdict:83913', 'fear_reviews_unchanged': True,
          'all_six_fear_audits_retained': True, 'seventh_familiar_audit_wired': True,
          'queue_regeneration_required': True,
          'retained_initial_failures': ['installed-parent-reconciliation.log', 'installed-parent-reconciliation-retry1.log'],
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())}}
report_path.write_text(json.dumps(report, indent=2) + '\n')
print('Reconciled', len(written), 'completed-parent files; all apprehensive runtime, judgments and proof files unchanged. Regenerate queue last.', flush=True)
