"""Preserve eight individual novel occurrences and bounded lexical proposals."""
import datetime,gzip,hashlib,json,sqlite3,sys
from pathlib import Path
PREP=Path(__file__).resolve().parent
ROOT=PREP.parents[1]
WORK=ROOT/'.direnv/gentle-command-long'
BROAD=PREP/'gentle-command-long-broad.json.gz'
DB=ROOT/'.direnv/dictionary-restoration/krdict.db'
OUT=PREP/'gentle-command-long-novel-targets.json.gz'
assert not OUT.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
report=json.loads(gzip.decompress(BROAD.read_bytes()));assert report['state']=='complete-gentle-command-long-broad-comparison-passed' and report['inputs_unchanged']
# Typed proposals are explicitly authored from the preserved source paragraphs;
# they follow runtime observation, rather than being called pre-observation gold.
targets={19073:('읽으려무나','읽다',79265),269792:('참으려무나','참다',79265),
         528363:('하려무나','하다',79266),528505:('하려무나','하다',79266),629528:('하려무나','하다',79266),
         640624:('오려무나','오다',79266),702617:('앉으려무나','앉다',79265),749095:('보려무나','보다',79266)}
raw=next(r for r in report['runs'] if r['mode']=='novel-raw');compatible=next(r for r in report['runs'] if r['mode']=='novel-compatible')
assert {f['after']['span']['start'] for f in raw['changed_frames']}==set(targets)
source=Path(raw['actual_source']);source_bytes=source.read_bytes();assert sha(source)==raw['source_sha256']
heads=sorted({lemma for surface,lemma,owner in targets.values()});entries={}
with sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True) as db:
    for head in heads:
        owners=[json.loads(row[0]) for row in db.execute('SELECT data FROM entries WHERE headword=? ORDER BY id',(head,))]
        assert owners and any(owner['pos']=='동사' for owner in owners)
        entries.update({owner['id']:owner for owner in owners})
    for ident in [79266,79265]:
        owner=json.loads(db.execute('SELECT data FROM entries WHERE id=?',(f'krdict:{ident}',)).fetchone()[0]);assert owner['pos']=='어미';entries[owner['id']]=owner
frozen={str(p):sha(p) for p in [BROAD,DB,source,Path(__file__)]}
items=[];cases=[];sources={f'long-gentle-novel-{owner}':f'https://krdict.korean.go.kr/kor/dicSearch/SearchView?ParaWordNo={owner}' for owner in [79265,79266]}
for start,(surface,lemma,owner) in targets.items():
    observed=next(f for f in raw['changed_frames'] if f['after']['span']['start']==start)
    filtered=next(f for f in compatible['changed_frames'] if f['after']['span']['start']==start)
    end=observed['after']['span']['end'];assert observed['after']['surface']==surface and source_bytes[start:end].decode()==surface
    line=observed['complete_original_line'];line_start=observed['line_byte_start'];assert source_bytes[line_start:line_start+len(line.encode())].decode()==line
    target=dict(lemmas=[lemma],lemma_kinds=['predicate'],morphemes=['으려무나'],morpheme_kinds=['ending'],required_rules=['ending.gentle_command_long'])
    assert len(filtered['new_paths'])==1 and all([part[field] for part in filtered['new_paths'][0][key]]==target[t]
        for key,field,t in [('lemmas','text','lemmas'),('lemmas','kind','lemma_kinds'),('morphemes','form','morphemes'),('morphemes','kind','morpheme_kinds')])
    ident=f'long-gentle-novel-{start}-{end}'
    items.append(dict(id=ident,surface=surface,span=dict(start=start,end=end),source_sha256=sha(source),
       complete_original_line=line,line_byte_start=line_start,original_raw_before=observed['before'],original_raw_after=observed['after'],
       all_new_raw_paths=observed['new_paths'],compatible_observation=filtered,source_based_typed_proposal=target,
       ending_owner=f'krdict:{owner}',lexical_owner_ids=[ident for ident,entry in entries.items() if entry['headword']==lemma],
       candidate_scope='Only this specific lexical stem plus ending is structurally supported by the original quoted command/permission context and original verb-only notes. Other raw alternatives, dictionary senses and social/register interpretation remain unjudged.',
       independent_review='pending'))
    cases.append(dict(id=ident,surface=surface,judgments=[dict(**target,id='source-based-lexical-path',verdict='required',source=f'long-gentle-novel-{owner}',reason='Bounded lexical and ending proposal from this complete original quoted source occurrence, recorded after runtime observation; no contextual sense ranking or rejection of other raw candidates is claimed.')]))
# Recover the full original export entries, not a reduced dictionary model.
sys.path.insert(0,str(WORK/'tools'));from native_lmf import entry,feature
native={};exports={}
for file in sorted((ROOT/'.direnv/dictionary-restoration/2026-09').glob('*.json')):
    data=file.read_bytes();ids=[]
    for owner in json.loads(data)['LexicalResource']['Lexicon']['LexicalEntry']:
        ident='krdict:'+owner['val']
        if ident in entries and feature(owner,'lexicalUnit') not in {'관用句','관용구','속담'}:
            assert ident not in native and entry(owner)==entries[ident];native[ident]=owner;ids.append(ident)
    exports[file.name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),ids=ids);frozen[str(file)]=sha(file)
assert len(exports)==11 and set(native)==set(entries)
suite=dict(schema_version=1,review_status='Source-based bounded structural novel proposals recorded after candidate observation. Every original source byte and prior output is preserved; other candidates, contextual senses/register and independent Korean review pending.',sources=sources,cases=cases)
for name,data in [('gentle-command-long-novel-validity.json',suite),('gentle-command-long-novel-native.json',{'LexicalResource':{'Lexicon':{'LexicalEntry':list(native.values())}}}),('gentle-command-long-novel-native-entries.json',entries)]:
    path=PREP/name;assert not path.exists();path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
assert all(sha(path)==digest for path,digest in frozen.items())
r=dict(state='complete-original-long-gentle-novel-occurrences-and-lexical-proposals-preserved',items=items,original_native_entries=native,complete_imported_entries=entries,
       original_exports=exports,source=raw['source'],actual_source=str(source),source_sha256=sha(source),original_broad_capture_sha256=sha(BROAD),
       novel_occurrences=8,new_raw_paths=sum(len(i['all_new_raw_paths']) for i in items),typed_structural_proposals=8,native_owners=len(entries),
       frozen_inputs=frozen,inputs_unchanged=True,proposals_precede_runtime=False,active_shared_cases_or_reviews_changed=False,
       producer=dict(text=Path(__file__).read_text(),sha256=sha(__file__)),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
       scope='All eight individual occurrences at original byte spans, complete original paragraphs, every prior/new candidate, six lexical heads with every Native homonym plus both ending owners from all11originalexports. Only eight specific source-based structural proposals; other11rawpaths and contextual/sense/register choices remain unjudged; shared promotion and independent review pending.')
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Preserved8noveloccurrences/19rawpaths/8specificproposals/',len(entries),'completeNativeowners',flush=True)
