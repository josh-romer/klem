"""Track authored future-question boundaries against the isolated candidate; inherited spelling and immediate-owner expectations are authored."""
import gzip
import hashlib
import json
import subprocess
import unicodedata
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
before = Path('/nix/store/zzzi7ks8mnfl9cypx630yyszhwpnxfjy-klem-0.1.0/bin/klem')
after = Path('/tmp/klem-literary-future-kko-catalog-cli')
dictionary = ROOT/'data/dictionaries/krdict/krdict.db'
output = Path('/tmp/klem-literary-future-kko-owner-extension-preflight.json.gz')
assert not output.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
producer = Path(__file__)
frozen = {str(p):sha(p.read_bytes()) for p in [before,after,dictionary,producer]}
specs = [
    ('derived-dap-vowel','학생다울꼬',['학생'],['답다']),
    ('derived-dap-honorific','학생다우실꼬',['학생'],['답다','시']),
    ('derived-dap-past','학생다웠을꼬',['학생'],['답다','었']),
    ('derived-dap-modal-unknown','학생답겠을꼬',['학생'],['답다','겠']),
    ('derived-hada','행복할꼬',['행복'],['하다']),
    ('derived-hada-past','행복했을꼬',['행복'],['하다','었']),
    ('aux-benefactive','먹어줄꼬',['먹다','주다'],['어']),
    ('aux-change','행복해질꼬',['행복하다','지다'],['어']),
    ('aux-result','먹게될꼬',['먹다','되다'],['게']),
    ('aux-benefactive-si','먹어주실꼬',['먹다','주다'],['어','시']),
    ('aux-benefactive-past','먹어주었을꼬',['먹다','주다'],['어','었']),
    ('aux-result-modal-unknown','먹게되겠을꼬',['먹다','되다'],['게','겠']),
    ('stack-negative-existential','먹지않고있을꼬',['먹다','않다','있다'],['지','고']),
    ('stack-try-negative','읽어보지않을꼬',['읽다','보다','않다'],['어','지']),
]
forbidden = [
    ('derived-dap-unrecovered','학생답을꼬',['학생'],['답다']),
    ('derived-dap-wrong-honorific','학생답으실꼬',['학생'],['답다','시']),
    ('derived-dap-wrong-past','학생답았을꼬',['학생'],['답다','었']),
    ('aux-vowel-full','먹어주을꼬',['먹다','주다'],['어']),
    ('aux-coda-short','먹지않꼬',['먹다','않다'],['지']),
    ('aux-rieul-full','먹게될을꼬',['먹다','되다'],['게']),
]
all_cases = [{'id':'literary-future-kko-owner-extension-'+name,'surface':word,'lemmas':heads,
              'morphemes':prefix+['을꼬'],'proposal':'required',
              'contextual_verdict':'unjudged','independent_review':'pending'}
             for name,word,heads,prefix in specs]
all_cases += [{'id':'literary-future-kko-owner-extension-'+name,'surface':word,'lemmas':heads,
               'morphemes':prefix+['을꼬'],'proposal':'forbidden',
               'contextual_verdict':'unjudged','independent_review':'pending'}
              for name,word,heads,prefix in forbidden]
assert len({c['id'] for c in all_cases}) == len(all_cases) == 20
text = ' '.join(dict.fromkeys(c['surface'] for c in all_cases))
runs, observations = [], []
for encoding in ['NFC','NFD']:
    encoded = unicodedata.normalize(encoding,text).encode()
    for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
        command = [str(after),'text','-','--dictionary',str(dictionary),*flags]
        result = subprocess.run(command,input=encoded,capture_output=True,check=True)
        rows = {r['analysis']['normalized']:r for r in map(json.loads,result.stdout.splitlines()) if r.get('analysis')}
        for case in all_cases:
            row = rows[case['surface']]
            hits = [i for i,a in enumerate(row['analysis']['analyses'])
                    if [l['text'] for l in a['lemmas']] == case['lemmas']
                    and [m['form'] for m in a['morphemes']] == case['morphemes']
                    and 'ending.literary_future_question_kko' in a['rules']]
            observations.append({'encoding':encoding,'mode':mode,'case_id':case['id'],
                                 'expected_present':case['proposal']=='required','present':bool(hits),
                                 'paths':[row['analysis']['analyses'][i] for i in hits],
                                 'assessments':[row['dictionary']['readings'][i] for i in hits]})
        runs.append({'encoding':encoding,'mode':mode,'command':command,'input_sha256':sha(encoded),
                     'jsonl':result.stdout.decode(),'sha256':sha(result.stdout),'exit_code':0})
# Proposals stay visible even when a spelling policy or inherited owner needs review.
violations = [o for o in observations if o['present'] != o['expected_present']]
assert all(sha(Path(p).read_bytes()) == expected for p,expected in frozen.items())
report = {'schema_version':1,'state':'passed' if not violations else 'review-required',
          'cases':all_cases,'input':text,'runs':runs,'observations':observations,'violations':violations,
          'frozen_inputs':frozen,'inputs_unchanged':True,
          'producer':{'text':producer.read_text(),'sha256':frozen[str(producer)]},
          'scope':'Twenty authored derivation/auxiliary-owner proposals, separate from the nineteen original source occurrences. Actual candidate output in six Unicode/filter modes, with every target and Native assessment retained. Unreviewed marker/omission/negative owner distributions are tracked independently. This preflight does not promote proposals into corpus gold or global ledger judgments; regular/irregular and sense-specific conflicts require individual review.'}
output.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Authored proposals:',len(all_cases),'mode observations:',len(observations),'mismatches:',len(violations),flush=True)
for violation in violations: print(violation['encoding'],violation['mode'],violation['case_id'],violation['present'],flush=True)
