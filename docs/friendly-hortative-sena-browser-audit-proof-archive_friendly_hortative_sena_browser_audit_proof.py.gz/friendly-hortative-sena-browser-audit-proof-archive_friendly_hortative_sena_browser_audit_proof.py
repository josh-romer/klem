"""Preserve the actual independent browser controls and initial audit state-guard failure."""
import gzip,hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent/'friendly-hortative-sena';D=W/'docs'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
r=json.loads((P/'friendly-hortative-sena-browser-audit-controls.json').read_bytes())
assert r['state']=='passed' and r['controls']==64 and len(r['results'])==4 and all(x['exit_code']==0 for x in r['results'])
assert all(r[k] for k in ['inputs_unchanged','external_inputs_unchanged','head_unchanged','index_unchanged'])
assert all(sha((W/n).read_bytes())==d for n,d in r['frozen_inputs'].items())
assert all(sha(Path(p).read_bytes())==d for p,d in r['external_inputs'].items())
assert r['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
assert r['index_sha256']==sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))
assert r['log_sha256']==sha((P/'friendly-hortative-sena-browser-audit-controls.log').read_bytes())
assert json.loads((P/'friendly-hortative-sena-browser-audit-first-terminal-observation.json').read_bytes())['exit_code']==1
names=['friendly_hortative_sena_browser_audit.py','test_friendly_hortative_sena_browser_audit.py',
 'validate_friendly_hortative_sena_browser_audit.py','friendly-hortative-sena-browser-audit-controls.json',
 'friendly-hortative-sena-browser-audit-controls.log','friendly-hortative-sena-browser-audit-first-producer.py.gz',
 'friendly-hortative-sena-browser-audit-first-terminal-observation.json',Path(__file__).name]
files={}
for name in names:
 raw=(P/name).read_bytes();path='friendly-hortative-sena-browser-audit-proof-'+name+'.gz';assert not (D/path).exists()
 packed=gzip.compress(raw,mtime=0);(D/path).write_bytes(packed);files[name]=dict(path=path,source_sha256=sha(raw),archive_sha256=sha(packed))
o=D/'friendly-hortative-sena-browser-audit-proof-archive.json';assert not o.exists()
o.write_text(json.dumps(dict(state='independent-Sena-browser64-controls-passed',files=files,source_head=r['head'],controls=64,live_controls=32,captured_controls=32,browser_choices=150,required_diagrams=114,forbidden_exclusions=36,original_corpus_choices=6,exact_exports=12,complete_native_entries=37,old_browser_audit_tests_changed=False,initial_audit_state_guard_failure_preserved=True,contextual_corpus_verdict='unjudged',context_register_independent_review='pending',full_coverage_complete=False),indent=2)+'\n')
print('Archived',len(files),'full available independent browser proof originals;',sha(o.read_bytes()),flush=True)
