"""Close actual lemma owner IDs over full same-head dictionary entries and original LMF."""
import copy,datetime,gzip,hashlib,json,sqlite3,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from native_lmf import array,entry,feature,verify_native_lmf
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
OUT=Path('/tmp/klem-additive-ppundeoreo-owner-closure.json.gz');assert not OUT.exists()
paths=[Path('/tmp/klem-additive-ppundeoreo-'+s+'.json.gz') for s in ['source-replay','boundary-preflight','native-preparation']]
captures=list(map(read,paths));frozen={str(p):sha(p.read_bytes()) for p in paths}
matched=set()
for capture in captures[:2]:
    for observation in capture['observations']:
        for lemma in observation['record']['dictionary']['lemmas']:
            matched.update(v['id'] for v in lemma['entries'])
database=ROOT/'data/dictionaries/krdict/krdict.db';frozen[str(database)]=sha(database.read_bytes())
native={};heads=set()
with sqlite3.connect(database.resolve().as_uri()+'?mode=ro',uri=True) as db:
    for ident in sorted(matched):
        row=db.execute('SELECT headword,data FROM entries WHERE id=?',(ident,)).fetchone();assert row
        heads.add(row[0])
    for head in sorted(heads):
        for ident,raw in db.execute('SELECT id,data FROM entries WHERE headword=?',(head,)):
            native[ident]=json.loads(raw)
native.update(captures[2]['source_entries']);assert matched<=set(native)
original={};sources={}
for path in sorted((ROOT/'data/dictionaries/krdict/json').glob('*.json')):
    raw=path.read_bytes();data=json.loads(raw)
    for value in array(data['LexicalResource']['Lexicon'].get('LexicalEntry')):
        ident='krdict:'+value.get('val','')
        if ident not in native:continue
        assert ident not in original
        assert entry(value)==native[ident],ident
        original[ident]=value
    sources[str(path)]={'sha256':sha(raw),'bytes':len(raw)}
assert set(original)==set(native)
assert all(original[i]==v for i,v in captures[2]['original_lmf'].items())
projected=copy.deepcopy(list(original.values()))
for value in projected:
    for sense in array(value.get('Sense')):
        sense['Equivalent']=[v for v in array(sense.get('Equivalent')) if feature(v,'language')=='영어']
lmf={'LexicalResource':{'Lexicon':{'LexicalEntry':projected}}};verify_native_lmf(lmf,native)
assert all(sha(Path(p).read_bytes())==v for p,v in frozen.items())
assert all(sha(Path(p).read_bytes())==v['sha256'] for p,v in sources.items())
producer=Path(__file__)
report={'state':'passed','preparation_only':True,'matched_owner_ids':sorted(matched),'same_headwords':sorted(heads),
        'complete_native_entries':native,'original_lmf':original,'english_projection':lmf,
        'original_primary_entries_preserved':True,'source_exports':sources,'frozen_inputs':frozen,'inputs_unchanged':True,
        'producer':{'text':producer.read_text(),'sha256':sha(producer.read_bytes())},
        'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope':'Every actually referenced owner ID from all original and36 authored words is closed over full same-head Native entries. Complete original LMF equals SQLite and an English importer projection is retained. Original primary entries are unchanged. Rust import/API, source-policy/boundary tests and broad/main/package/context review remain separate.'}
OUT.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Closed',len(matched),'actual owner IDs over',len(native),'complete Native entries; exact LMF/SQLite and English projection pass.',flush=True)
