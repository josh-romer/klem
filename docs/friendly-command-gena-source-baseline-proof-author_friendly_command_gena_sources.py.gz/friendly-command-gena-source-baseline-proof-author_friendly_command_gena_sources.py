"""Author source targets before observing any -게나 runtime output."""
import datetime,gzip,hashlib,json,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');PREP=Path(__file__).resolve().parent
OUT=PREP/'friendly-command-gena-source-authoring.json'
CLOSURE=PREP/'friendly-command-gena-original-native-closure.json.gz'
SUITE=PREP/'friendly-command-gena-validity.json'
assert not OUT.exists() and not CLOSURE.exists() and not SUITE.exists()
sys.path.insert(0,str(ROOT/'tools'))
from native_lmf import array,features,entry
from review_inventory import source_entry,digest
sha=lambda raw:hashlib.sha256(raw).hexdigest()
original_path=ROOT/'docs/unreviewed-inventory-source-closure.json.gz'
original=json.loads(gzip.decompress(original_path.read_bytes()));owner=original['complete_native_entries']['krdict:66968'];assert owner['headword']=='-게나' and len(owner['senses'])==1 and len(owner['senses'][0]['examples'])==4
queue=json.loads((ROOT/'docs/inventory-review-queue.json').read_bytes());row=next(r for r in queue['entries'] if r['source']['id']=='krdict:66968');assert source_entry(owner)==row['source'] and digest(row['source'])==row['source_sha256']
heads={'-게나','앉다','들다','읽다','주다','가다','살다','먹다','듣다','돕다','짓다','낫다','푸다','예쁘다','학생','이다','-답다','공부하다','공부','사다'}
raws={};entries={};exports={}
for path in sorted((ROOT/'.direnv/dictionary-restoration/2026-09').glob('*.json')):
 raw=path.read_bytes();exports[path.name]=dict(sha256=sha(raw),bytes=len(raw));lex=json.loads(raw)['LexicalResource']['Lexicon'];assert not isinstance(lex,list)
 for item in array(lex['LexicalEntry']):
  found={h for lemma in array(item['Lemma']) for h in features(lemma,'writtenForm')}
  if not found & heads:continue
  value=entry(item);assert value['id'] not in raws;raws[value['id']]=item;entries[value['id']]=value
assert len(exports)==11 and entries['krdict:66968']==owner and raws['krdict:66968']==original['original_lmf']['krdict:66968']
assert {e['headword'] for e in entries.values()}==heads,'All selected lexical/boundary heads must exist; do not invent missing dictionary entries'
closure=dict(state='complete-original-gena-owner-lexical-boundary-closure',original_lmf=raws,complete_native_entries=entries,source_exports=exports,selected_heads=sorted(heads),scope='All same-head owners for original four targets and declared synthetic lexical/known-class boundaries; complete original multilingual senses, forms, example types, dialogue, annotations, relationships and whitespace retained. No runtime observation, gold annotation or review promotion.')
packed=gzip.compress((json.dumps(closure,ensure_ascii=False)+'\n').encode(),mtime=0);CLOSURE.write_bytes(packed)
rule='ending.friendly_command.gena';source='friendly-command-gena-66968';cases=[];items=[]
def case(ident,surface,lemmas,kinds,morphemes,morph_kinds,verdict,reason):
 c=dict(id=ident,surface=surface,judgments=[dict(id='structural-path',lemmas=lemmas,lemma_kinds=kinds,morphemes=morphemes,morpheme_kinds=morph_kinds,verdict=verdict,required_rules=[rule],source=source,reason=reason)]);cases.append(c);return c
for ordinal,(group,(surface,lemma)) in enumerate(zip(owner['senses'][0]['examples'],[('앉게나','앉다'),('들게나','들다'),('읽게나','읽다'),('주게나','주다')],strict=True),1):
 raw='\n'.join(group).encode();needle=surface.encode();assert raw.count(needle)==1;start=raw.index(needle);c=case('friendly-command-gena-66968-sense-1-group-'+str(ordinal),surface,[lemma],['predicate'],['게나'],['ending'],'required','Independent lexical and canonical ending proposal from this complete original example group; no contextual sense, register verdict or rejection of other possible paths is assigned.');items.append(dict(id=c['id'],entry_id=owner['id'],sense_id='1',example_group=ordinal,complete_original_group=group,surface=surface,local_span=dict(start=start,end=start+len(needle)),typed_target=c['judgments'][0],contextual_verdict='unjudged',independent_korean_review='pending'))
for ordinal,(surface,lemma) in enumerate([('가게나','가다'),('살게나','살다'),('먹게나','먹다'),('듣게나','듣다'),('돕게나','돕다'),('짓게나','짓다'),('낫게나','낫다'),('푸게나','푸다'),('공부하게나','공부하다')],1):
 case('friendly-command-gena-regular-boundary-'+str(ordinal),surface,[lemma],['predicate'],['게나'],['ending'],'required','Declared synthetic structural proposal: consonant-initial 게나 follows the regular verb stem; lexical homonyms and other possible readings stay unjudged. This is not a quoted corpus or dictionary example.')
for ordinal,(surface,lemma) in enumerate([('먹으시게나','먹다'),('사시게나','살다'),('도우시게나','돕다')],1):
 case('friendly-command-gena-honorific-'+str(ordinal),surface,[lemma],['predicate'],['시','게나'],['prefinal','ending'],'required','Declared synthetic verb-plus-honorific proposal, using the original explicit -으시- note. Adjective/copula predicates after honorifics and social/register interpretation remain unjudged.')
for ordinal,(surface,lemma) in enumerate([('들게나','듣다'),('도우게나','돕다'),('지으게나','짓다'),('사게나','살다'),('퍼게나','푸다')],1):
 case('friendly-command-gena-invalid-stem-boundary-'+str(ordinal),surface,[lemma],['predicate'],['게나'],['ending'],'forbidden','Declared synthetic boundary proposal: this exact restored irregular/deleted-consonant verb stem is not licensed immediately before consonant-initial 게나. Other lexical hypotheses for the surface remain unjudged.')
case('friendly-command-gena-bare-copula', '학생이게나',['학생','이다'],['nominal','copula'],['게나'],['ending'],'forbidden','The original bare attachment note lists verbs; this exact nominal plus bare copula path does not acquire the command ending. Other raw readings and honorific combinations remain unjudged.')
case('friendly-command-gena-derived-adjective', '학생답게나',['학생'],['nominal'],['답다','게나'],['suffix','ending'],'forbidden','The correctly consonant-inflected known 답다 derivation retains its nominal-plus-suffix shape and cannot borrow the bare verb command. Adverbial 게 plus particle 나 and unknown lexical readings are separate unjudged alternatives.')
case('friendly-command-gena-attached-auxiliary','먹어주게나',['먹다','주다'],['predicate','auxiliary'],['어','게나'],['ending','ending'],'required','Declared synthetic attached verbal-auxiliary structural alternative; no lexical compound, cross-token grouping or contextual interpretation is ruled out.')
suite=dict(schema_version=1,review_status='independently authored finite structural proposals before runtime; contextual and Korean review pending',sources={source:owner['url']},cases=cases)
SUITE.write_text(json.dumps(suite,ensure_ascii=False,indent=2)+'\n')
record=dict(state='gena-original-source-and-targets-authored-before-runtime',authored_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),owner_ids=[owner['id']],owners={owner['id']:owner},original_lmf={owner['id']:raws[owner['id']]},items=items,original_inventory_source=row['source'],original_inventory_sha256=row['source_sha256'],native_closure_sha256=sha(packed),suite_sha256=sha(SUITE.read_bytes()),source_archive_sha256=sha(original_path.read_bytes()),producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),candidate_runtime_observed=False,shared_cases_reviews_changed=False,bare_lexical_adjective_dictionary_targets=[dict(surface='예쁘게나',lemma='예쁘다',expected_own_pos='형용사',command_compatibility='incompatible on this known bare adjective owner; raw lexical hypotheses unjudged')],honorific_adjective_copula_scope='unjudged: do not infer or forbid their licenses from the bare-verb note; preserve explicit honorific note',scope='Complete original single-owner/four source groups and all lexical/boundary homonyms; finite synthetic morphology proposals clearly separate from original examples. Canonical게나 has no 으 allomorph; ordinary consonant-initial stem boundaries, explicit verb honorifics, barecopula/known답다 and auxiliary paths tracked. Raw candidate preservation, every fullsource mode, actualNative import/filter/UI, corpus/history/gold/novel/runtime/installed/Nix/main/performance/context/register/independent review required; no contextual precision or all-Korean completion claim.')
OUT.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print('Authored gena before runtime:',len(items),'original groups;',len(cases),'typed proposals;',len(entries),'complete Native owners; no shared changes',flush=True)
