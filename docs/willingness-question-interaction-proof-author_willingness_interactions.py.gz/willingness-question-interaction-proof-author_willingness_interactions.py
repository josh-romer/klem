"""Author structural interaction targets before any corresponding runtime probe."""
import hashlib
import json
from pathlib import Path

root = Path('/tmp/klem-willingness-question-prototype')
prep = Path(__file__).resolve().parent
out = prep / 'willingness-interaction-authored.json'
assert not out.exists()
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
native_path = root / 'tests/fixtures/willingness-question-native-entries.json'
native = json.loads(native_path.read_text())
assert any(f['written'] == '걸으니' for f in native['krdict:29667']['forms'])
assert any(f['written'] == '지으니' for f in native['krdict:66585']['forms'])
assert native['krdict:29667']['pos'] == native['krdict:66585']['pos'] == '동사'
assert "동사 뒤에서 '-어 주다'로 쓴다." in native['krdict:77245']['senses'][0]['notes']
assert "동사 뒤에서 '-지 않다'로 쓴다." in native['krdict:71581']['senses'][0]['notes']
cases = []


def add(ident, surface, verdict, lemmas, kinds, forms, form_kinds, reason):
    cases.append({'id': 'willingness-question-interaction-' + ident, 'surface': surface,
                  'judgments': [{'id': 'exact-structural-path', 'verdict': verdict,
                                 'lemmas': lemmas, 'lemma_kinds': kinds,
                                 'morphemes': forms, 'morpheme_kinds': form_kinds,
                                 'required_rules': ['ending.willingness_question'],
                                 'source': 'ending-76564-76567', 'reason': reason}]})


reason = ('Constructed morphological contrast: original ending76564/76567 bare-verb/allomorph notes, '
          'plus complete Native29667 걸으니 or Native66585 지으니. Irregular stem recovery retains '
          'the full 으 form; a shortened surface must not recover the same consonantal lexical head. '
          'This does not certify an original sentence or contextual sense.')
for ident, surface, verdict, lemma in [
    ('d-full', '걸으련', 'required', '걷다'), ('s-full', '지으련', 'required', '짓다'),
    ('d-short', '걸련', 'forbidden', '걷다'), ('s-short', '지련', 'forbidden', '짓다')]:
    add(ident, surface, verdict, [lemma], ['predicate'], ['으련'], ['ending'], reason)
add('copula', '학생이련', 'forbidden', ['학생', '이다'], ['nominal', 'copula'], ['으련'], ['ending'],
    'Original ending notes restrict this bare ending to verbs; this exact nominal/copula path must not borrow that license. Other lexical hypotheses remain unjudged.')
add('derived-adjective', '학생답련', 'forbidden', ['학생'], ['nominal'], ['답다', '으련'], ['suffix', 'ending'],
    'The known adjectival 답다 derivation must not borrow the original bare verb ending license. This named structural exclusion preserves unrelated hypotheses.')
for ident, surface, aux, connector, owner in [
    ('benefactive', '먹어주련', '주다', '어', '77245'),
    ('negative', '먹지않으련', '않다', '지', '71581')]:
    add(ident, surface, 'required', ['먹다', aux], ['predicate', 'auxiliary'], [connector, '으련'], ['ending', 'ending'],
        'Constructed composition of the ending bare-verb license with original auxiliary' + owner + ' verbal complement notes. Preserve connector and auxiliary ownership separately. Contextual sense and complete Native policy assessment remain separate.')
policies = []
for ident, surface, forms, kinds in [
    ('past', '먹었으련', ['었', '으련'], ['prefinal', 'ending']),
    ('honorific', '먹으시련', ['으시', '으련'], ['prefinal', 'ending']),
    ('modal', '먹겠으련', ['겠', '으련'], ['prefinal', 'ending']),
    ('outer-polite', '먹으련요', ['으련', '요'], ['ending', 'particle'])]:
    policies.append({'id': 'willingness-question-interaction-policy-' + ident, 'surface': surface,
                     'target': {'lemmas': ['먹다'], 'lemma_kinds': ['predicate'], 'morphemes': forms,
                                'morpheme_kinds': kinds, 'required_rules': ['ending.willingness_question']},
                     'morphological_verdict': 'unjudged', 'dictionary_status_if_present': 'unknown',
                     'reason': 'Neither original ending owner attests this prefinal/follower license. Preserve any raw hypothesis without automatic compatibility; absence is a discovery observation, not an authored forbidden raw judgment.'})
r = {'schema_version': 1, 'state': 'authored-before-interaction-probes',
     'sources': {'ending-76564-76567': 'https://krdict.korean.go.kr/kor/dicSearch/SearchView?ParaWordNo=76567'},
     'cases': cases, 'policy_proposals': policies,
     'source_inputs': {str(p.relative_to(root)): sha(p) for p in [native_path, root / 'tests/fixtures/willingness-question-source.json']},
     'complete_original_native_entries': {k: native[k] for k in ['krdict:29667', 'krdict:66585', 'krdict:77245', 'krdict:71581']},
     'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
     'scope': 'Eight independently authored named structural paths (four required/four forbidden), plus four unjudged prefinal/follower policy proposals. No runtime output informed these targets. Stable ledger/Native/Unicode/CLI/browser integration and independent contextual review remain pending.'}
out.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
print('Authored8structuralpaths and4unjudged policy proposals before interaction probes', flush=True)
