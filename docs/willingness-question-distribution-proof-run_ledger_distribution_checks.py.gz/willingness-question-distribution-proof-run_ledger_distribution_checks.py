"""Capture complete current ledger/distribution controls with frozen inputs."""
import hashlib,json,os,subprocess
from pathlib import Path
prep=Path(__file__).resolve().parent
work=Path('/tmp/klem-willingness-question-prototype')
out=prep/'ledger-distribution-controls.json'
assert not out.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
files=[p for folder in ['src','tools','tests','docs','web/src'] for p in (work/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += [work/'Cargo.toml',work/'Cargo.lock',work/'flake.nix',Path(__file__)]
frozen={str(p):sha(p) for p in files}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
index=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=work)).hexdigest()
a=[('willingness_question_source_audit',14),('willingness_question_distribution_audit',30),('expression_conjectural_ledger_audit',18),('formal_volitional_expression_ledger_audit',8),('conjectural_additive_ledger_audit',14),('literary_question_geona_runtime',94),('review_inventory',10)]
commands=[(['python3','-m','unittest','discover','-s','tools','-p','test_'+name+'.py'],count) for name,count in a]
commands.append((['python3','tools/review_inventory.py','--verify'],None))
r={'state':'running','frozen_inputs':frozen,'head':head,'index_sha256':index,'commands':[],'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__))}}
def save():out.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 for i,(command,controls) in enumerate(commands):
  log=prep/('ledger-distribution-controls-'+str(i)+'.log')
  with log.open('xb') as f:job=subprocess.run(command,cwd=work,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=f,stderr=subprocess.STDOUT)
  r['commands'].append({'command':command,'controls':controls,'exit_code':job.returncode,'log':str(log),'log_sha256':sha(log)})
  save();print(i,job.returncode,flush=True)
  assert job.returncode==0,log
  if controls:assert 'Ran '+str(controls)+' tests' in log.read_text() and log.read_text().rstrip().endswith('OK')
 r.update(state='passed',exit_code=0,controls=sum(c for _,c in commands if c),inputs_unchanged=all(sha(p)==d for p,d in frozen.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==head,index_unchanged=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=work)).hexdigest()==index)
 assert r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged']
except Exception as error:
 r.update(state='failed',error=str(error));raise
finally:save()
