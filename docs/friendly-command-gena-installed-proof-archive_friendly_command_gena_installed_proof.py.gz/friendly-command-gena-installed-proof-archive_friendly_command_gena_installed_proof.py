"""Retain full actual installed proof only after the frozen Nix jobs terminate."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

P=Path(__file__).resolve().parent
W=Path('/home/josh/projects/klem/.direnv/friendly-command-gena')
D=W/'docs'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(name):
    raw=(P/name).read_bytes()
    return json.loads(gzip.decompress(raw) if name.endswith('.gz') else raw)

package=read('friendly-command-gena-nix-packages.json')
gate=read('friendly-command-gena-complete-nix-gate.json')
installed=read('friendly-command-gena-installed-runtime.json.gz')
browser=read('friendly-command-gena-installed-browser-runtime.json')
controls=read('friendly-command-gena-installed-audits.json')
assert package['state']=='passed' and gate['state'] in ('passed','failed'), 'all relevant frozen Nix jobs must be terminal'
assert package['head']==gate['head']==controls['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()=='6cf27565c7891005de12651abcb7f18911495adf'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
assert all(sha((W/n).read_bytes())==digest for n,digest in package['frozen_inputs'].items())
for report in [package,gate,installed,browser,controls]:
    assert all(report[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged'])
assert installed['state']==browser['state']==controls['state']=='passed'
assert installed['source_unchanged'] and browser['source_unchanged'] and browser['server_stopped']
assert controls['controls']==28 and all(r['exit_code']==0 for r in controls['results'])
for report,name in [(package,'friendly-command-gena-nix-packages.log'),(gate,'friendly-command-gena-complete-nix-gate.log'),(browser,'friendly-command-gena-installed-browser-runtime.log'),(controls,'friendly-command-gena-installed-audits.log')]:
    assert report['log_sha256']==sha((P/name).read_bytes())
files={}
names=['build_friendly_command_gena_nix_packages.py','friendly-command-gena-nix-packages.json','friendly-command-gena-nix-packages.log',
       'preflight_friendly_command_gena_selected_source.py','friendly-command-gena-selected-source.json','friendly-command-gena-selected-source.log',
       'run_complete_friendly_command_gena_nix_gate.py','friendly-command-gena-complete-nix-gate.json','friendly-command-gena-complete-nix-gate.log',
       'capture_friendly_command_gena_installed_runtime.py','friendly-command-gena-installed-runtime.json.gz',
       'run_friendly_command_gena_installed_browser.py','friendly-command-gena-installed-browser.json','friendly-command-gena-installed-browser-runtime.json','friendly-command-gena-installed-browser-runtime.log','friendly-command-gena-browser.mjs',
       'friendly-command-gena-installed-browser-desktop.png','friendly-command-gena-installed-browser-mobile.png',
       'friendly_command_gena_installed_audit.py','test_friendly_command_gena_installed_audit.py','validate_friendly_command_gena_installed_audits.py','friendly-command-gena-installed-audits.json','friendly-command-gena-installed-audits.log',
       Path(__file__).name]
for name in names:
    raw=(P/name).read_bytes()
    path=D/('friendly-command-gena-installed-proof-'+name+'.gz')
    assert not path.exists()
    packed=gzip.compress(raw,mtime=0)
    path.write_bytes(packed)
    files[name]=dict(path=path.name,source_sha256=sha(raw),archive_sha256=sha(packed))
manifest=D/'friendly-command-gena-installed-proof-archive.json'
assert not manifest.exists()
manifest.write_text(json.dumps(dict(state='actual-installed-Gena-packages-CLI-native-gold-cohorts-broad-browser-and-independent-controls-passed',
    files=files,captured_head=package['head'],four_actual_packages=len(package['outputs']),
    source_selected_controls=224,release_rust_passed=1200,release_rust_ignored=1,release_rust_batches=255,
    installed_cli_policies=36,complete_native_owners=44,lemma_headword_queries=69,original_cohort_words=53502,
    original_annotated_gold_rows=66570,complete_broad_frames=1128312,
    browser_policy_decisions=144,required_diagrams=102,forbidden_exclusions=42,exact_exports=6,complete_browser_native_owners=31,
    independent_installed_controls=28,original_source_and_shared_ledger_reviews_retained=True,
    complete_nix_gate_state=gate['state'],complete_nix_gate_original_producer_receipt_log_included=True,
    shared_24_promotion_main_quiet_performance_context_register_independent_review='pending',full_coverage_complete=False),ensure_ascii=False,indent=2)+'\n')
print('Archived',len(files),'full original installed artifacts; manifest',sha(manifest.read_bytes()),flush=True)
