"""Validate complete inherited Rust tests without rewriting captured CLI binaries."""
import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

PREP = Path(__file__).resolve().parent
PROTO = PREP.parent / 'conjectural-additive-copula-prototype'
OUT = PREP / 'copula-inherited-validation.json'
assert not OUT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [PROTO / name for name in ['Cargo.toml', 'Cargo.lock']]
for folder in ['src', 'tests', 'tools', 'docs', 'web/src']:
    files.extend(path for path in (PROTO / folder).rglob('*') if path.is_file())
files.extend([Path(__file__), PREP / 'copula-inherited-tests-preparation.json'])
frozen = {str(path): sha(path) for path in sorted(set(files))}
commands = [['cargo', 'fmt', '--all', '--', '--check'],
            ['cargo', 'clippy', '--locked', '--offline', '--all-targets', '--features', 'web', '--', '-D', 'warnings'],
            ['cargo', 'test', '--locked', '--offline', '--features', 'web']]
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/klem-conjectural-additive-copula-full-target',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='4')
report = {'state': 'running', 'started_at': datetime.now(timezone.utc).isoformat(),
          'pid': os.getpid(), 'frozen_inputs': frozen, 'runs': [],
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
          'scope': 'Whole inherited parent plus new conjectural/additive and omitted-copula Rust validation. Every source/test/fixture/Rust tool/document/catalog input frozen and rechecked. Independent target preserves the separately captured CLI/server binaries. Full Nix/installed/main and distributions/contextual review remain separate.'}
OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
for ordinal, command in enumerate(commands):
    logfile = PREP / f'copula-inherited-validation-{ordinal}.log'
    assert not logfile.exists()
    with logfile.open('wb') as log:
        code = subprocess.run(command, cwd=PROTO, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
    report['runs'].append({'command': command, 'exit_code': code, 'log': str(logfile), 'log_sha256': sha(logfile)})
    report['inputs_unchanged'] = all(sha(path) == digest for path, digest in frozen.items())
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(command, code, 'inputs unchanged', report['inputs_unchanged'], flush=True)
    if code or not report['inputs_unchanged']:
        report['state'] = 'failed'
        report['finished_at'] = datetime.now(timezone.utc).isoformat()
        OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
        raise SystemExit(code or 1)
report['state'] = 'passed'
report['finished_at'] = datetime.now(timezone.utc).isoformat()
OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('Complete inherited format/Clippy/Rust passed; all source bytes retained', flush=True)
