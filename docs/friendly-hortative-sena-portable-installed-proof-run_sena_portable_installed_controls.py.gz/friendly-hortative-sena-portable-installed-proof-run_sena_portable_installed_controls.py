"""Run original installed audits with explicit non-shadowed source imports."""
import datetime
import hashlib
import importlib
import json
import os
import subprocess
import sys
import unittest
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
OUT = P / 'friendly-hortative-sena-portable-installed-validation-retry1.json'
LOG = P / 'friendly-hortative-sena-portable-installed-validation-retry1.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
raw_sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *a: subprocess.check_output(['git',*a],cwd=W)
status = git('status','--porcelain').decode()
source = {p:sha(W/p) for p in (git('ls-files','-z')+git('ls-files','--others','--exclude-standard','-z')).decode().split('\0')[:-1]}
head = git('rev-parse','HEAD').decode().strip()
index = raw_sha(git('ls-files','--stage','-z'))
names = ['friendly-hortative-sena-'+n for n in [
    'complete-nix-gate.json','complete-nix-gate.log','nix-packages-retry1.json',
    'nix-packages-retry1.log','release-rust-retry1.log','installed-runtime-completion-audit.json.gz',
    'installed-runtime-progress.json','installed-browser.json',
    'installed-browser-runtime.json','installed-browser-runtime.log',
    'installed-browser-desktop.png','installed-browser-mobile.png','browser.mjs']]
names += ['run_complete_friendly_hortative_sena_nix_gate.py',
          'build_friendly_hortative_sena_nix_packages_retry1.py',
          'audit_completed_sena_runtime.py',
          'run_friendly_hortative_sena_installed_browser_retry4.py',
                    Path(__file__).name]
frozen = {str(P/n):sha(P/n) for n in names}
binding = json.loads((P/'friendly-hortative-sena-complete-runtime-binding.json').read_bytes())
protected = {b['path']:b['sha256'] for b in binding['binaries'].values()} | binding['protected_parent_binaries']
assert all(sha(p)==d for p,d in protected.items())
frozen.update(protected)
r = dict(state='running',phase='imports',head=head,index_sha256=index,
         source_inputs=source,frozen_inputs=frozen,controls=46,
         producer=dict(text=Path(__file__).read_text(),sha256=sha(__file__)),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Actual independent installed Sena full proof and 39 corruption controls. Explicit captured historical binary evidence, no sandbox host executable claims. Every original source/corpus/Native/browser result is retained. Main/shared promotion/quiet/context/register/Korean review and full checklist completion remain separate.')
def save():
    OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
try:
    os.environ['KLEM_SENA_BINARY_EVIDENCE'] = 'captured'
    sys.dont_write_bytecode = True
    sys.path.insert(0,str(W/'tools'))
    modules = [importlib.import_module(n) for n in [
        'friendly_hortative_sena_revision','friendly_hortative_sena_runtime_audit',
        'friendly_hortative_sena_wide_audit','friendly_hortative_sena_browser_audit',
        'friendly_hortative_sena_installed_audit','test_friendly_hortative_sena_installed_audit']]
    r['imports'] = {}
    for module in modules:
        path = Path(module.__file__).resolve()
        expected = W/'tools'
        assert path.parent == expected.resolve(), ('shadowed audit import',module.__name__,path)
        r['imports'][module.__name__] = dict(path=str(path),sha256=sha(path))
    suite = unittest.defaultTestLoader.loadTestsFromModule(modules[-1])
    assert suite.countTestCases() == 46
    r['phase'] = 'all46-portable-independent-installed-controls'
    save()
    with LOG.open('x') as stream:
        result = unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    r.update(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped))
    assert result.wasSuccessful() and result.testsRun == 46 and not result.skipped
    r['summary'] = modules[-1].Controls.summary
    r['state'] = 'passed'
except BaseException as error:
    r.update(state='failed',error=repr(error))
    raise
finally:
    r.update(inputs_unchanged=all(Path(p).is_file() and sha(p)==d for p,d in frozen.items()),
             source_unchanged=all(sha(W/p)==d for p,d in source.items()),
             status_unchanged=git('status','--porcelain').decode()==status,
             head_unchanged=git('rev-parse','HEAD').decode().strip()==head,
             index_unchanged=raw_sha(git('ls-files','--stage','-z'))==index,
             log_sha256=sha(LOG) if LOG.exists() else None,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged','status_unchanged']):
        r['state'] = 'failed'
    save()
assert r['state'] == 'passed'
print('Passed actual46 portable installed controls,253 actual commands and506 full streams.',flush=True)
