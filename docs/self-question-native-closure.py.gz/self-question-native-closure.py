import gzip,hashlib,json,sqlite3,zipfile
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');DEST=Path('/tmp/klem-self-question-prototype/tests/fixtures/self-question-native.json');assert not DEST.exists()
source=json.loads(gzip.decompress(Path('/tmp/klem-self-question-source-preparation-retry1.json.gz').read_bytes()))
heads={p['proposed_lemma'] for p in source['proposals']}|{'먹다','예쁘다','많다','하다','가다','아니다','학생'}
with sqlite3.connect('file:'+str(ROOT/'data/dictionaries/krdict/krdict.db')+'?mode=ro',uri=True) as db:
 imported={id:json.loads(raw) for head in heads for id,raw in db.execute('select id,data from entries where lookup=?',(head,))}
imported.update(source['complete_imported_entries']);wanted={id.split(':')[1] for id in imported};original={};files={}
with zipfile.ZipFile(ROOT/'data/dictionaries/krdict/2026-09.zip') as archive:
 for name in archive.namelist():
  if not name.endswith('.json'):continue
  raw=archive.read(name);selected=[e for e in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry'] if str(e.get('val')) in wanted]
  if selected:files[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
  for entry in selected:original['krdict:'+str(entry['val'])]=entry
assert set(original)==set(imported)
fixture={'LexicalResource':{'Lexicon':{'LexicalEntry':list(original.values())}}};DEST.write_text(json.dumps(fixture,ensure_ascii=False,indent=2)+'\n')
report={'state':'complete-native-owner-and-ending-closure-prepared','entries':imported,'original_file_hashes':files,'native_fixture_sha256':hashlib.sha256(DEST.read_bytes()).hexdigest(),'source_preparation_sha256':hashlib.sha256(Path('/tmp/klem-self-question-source-preparation-retry1.json.gz').read_bytes()).hexdigest(),'lexical_tension':{'ending_source':'krdict:73883','owner':'krdict:63516','surface':'웃기담','source_pos':'동사','disposition':'Unknown for this exact source witness; no global POS rewrite.'},'producer':Path(__file__).read_text()}
Path('/tmp/klem-self-question-native-closure.json.gz').write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print(len(imported),'complete Native ending/suffix/lexical-owner identities preserved')
