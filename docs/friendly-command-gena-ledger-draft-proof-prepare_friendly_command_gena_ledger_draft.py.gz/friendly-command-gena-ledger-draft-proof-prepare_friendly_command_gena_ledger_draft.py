"""Prepare unchanged preauthored Gena targets for later bounded shared promotion."""
import copy
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

P=Path(__file__).resolve().parent
W=Path('/home/josh/projects/klem/.direnv/friendly-command-gena')
D=P/'friendly-command-gena-promotion-draft'
assert not D.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
package=json.loads((P/'friendly-command-gena-nix-packages.json').read_bytes())
controls=json.loads((P/'friendly-command-gena-installed-audits.json').read_bytes())
assert package['state']==controls['state']=='passed' and controls['controls']==28
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==package['head'] and not subprocess.check_output(['git','status','--porcelain'],cwd=W)
assert all(sha((W/n).read_bytes())==digest for n,digest in package['frozen_inputs'].items())
raw=(W/'tests/fixtures/friendly-command-gena-validity.json').read_bytes()
assert sha(raw)=='52dc5dae1dd3218c049be2a5f7f89e741fd9b166177102bf361892584188ed3b'
suite=json.loads(raw)
authored=json.loads((W/'tests/fixtures/friendly-command-gena-source.json').read_bytes())
assert authored['candidate_runtime_observed'] is False and authored['suite_sha256']==sha(raw)
parent=json.loads((W/'tests/fixtures/validity.json').read_bytes())
reviews=json.loads((W/'docs/inventory-reviews.json').read_bytes())
queue=json.loads((W/'docs/inventory-review-queue.json').read_bytes())
assert len(parent['cases'])==35740 and len(reviews['entries'])==519
ids={case['id'] for case in parent['cases']}
assert len(suite['cases'])==24 and not ids.intersection(case['id'] for case in suite['cases'])
assert all(key not in parent['sources'] or parent['sources'][key]==url for key,url in suite['sources'].items())
owner=next(row for row in queue['entries'] if row['source']['id']=='krdict:66968')
assert owner['review']['status']=='unreviewed' and all(row['id']!='krdict:66968' for row in reviews['entries'])
new=copy.deepcopy(suite['cases'])
judgments=[j for case in new for j in case['judgments']]
assert sum(j['verdict']=='required' for j in judgments)==17 and sum(j['verdict']=='forbidden' for j in judgments)==7
source_cases=[case for case in new if case['id'].startswith('friendly-command-gena-66968-sense-1-group-')]
assert len(source_cases)==4
review=dict(id='krdict:66968',source_sha256=owner['source_sha256'],status='scoped',checklist=['COV-017db'],
    scope="Proposed finite structural coverage of the complete original -게나 owner. All four original example groups, including dialogue, retain preauthored lexical, lemma-role, canonical-morpheme and rule targets. The original24 cases retain17required/7forbidden paths for unchanged consonant/vowel verb stems, verbal honorific 시, auxiliary composition, incorrect irregular restorations, and bare copula/nominal-답다 boundaries. Every original Native field and homonym remains intact. Actual installed packages/CLI/browser, full annotated rows and broad streams, and28 independent installed corruption controls have passed. Shared promotion requires the current complete Nix gate and a fresh parent/promotion audit; this draft makes no promotion claim.",
    remaining="Other prefinals, honorific adjective/copula and outer-particle constructions retain Unknown compatibility. Five historical words have eleven unjudged additions; eighteen original broad contexts remain unjudged. Contextual lemma/sense choice, familiar-command register and pragmatic function, independent Korean review and quiet performance remain open. The source note alone does not establish precision or full Korean coverage.",
    evidence=[dict(path='tests/friendly_command_gena.rs'),dict(path='tests/fixtures/friendly-command-gena-source.json'),dict(path='docs/friendly-command-gena-initial-runtime-proof-archive.json'),dict(path='docs/friendly-command-gena-installed-proof-archive.json'),dict(path='tools/friendly_command_gena_runtime_audit.py'),dict(path='tools/friendly_command_gena_installed_audit.py')],
    judgments=[dict(case=case['id'],judgment=j['id']) for case in source_cases for j in case['judgments']])
D.mkdir()
files={}
for label,name in [('parent-validity.json','tests/fixtures/validity.json'),('parent-inventory-reviews.json','docs/inventory-reviews.json'),('parent-inventory-review-queue.json','docs/inventory-review-queue.json')]:
    original=(W/name).read_bytes();packed=gzip.compress(original,mtime=0);(D/(label+'.gz')).write_bytes(packed);files[label]=dict(source_sha256=sha(original),archive_sha256=sha(packed))
(D/'proposed-cases.json').write_text(json.dumps(dict(sources=suite['sources'],cases=new),ensure_ascii=False,indent=2)+'\n')
(D/'proposed-scoped-reviews.json').write_text(json.dumps(dict(entries=[review]),ensure_ascii=False,indent=2)+'\n')
(D/'draft.json').write_text(json.dumps(dict(state='prepared-not-promoted',parent_head=package['head'],parent_cases=35740,proposed_cases=35764,added_cases=24,added_required=17,added_forbidden=7,parent_reviews=519,proposed_reviews=520,original_suite_sha256=sha(raw),original_case_authoring_precedes_runtime=True,review_draft_authored_after_runtime=True,all_five_historical_words_eighteen_broad_contexts_remain_unjudged=True,files=files,complete_nix_and_fresh_promotion_checks_required=True,shared_ledger_changed=False,full_coverage_complete=False),indent=2)+'\n')
assert all(sha((W/n).read_bytes())==digest for n,digest in package['frozen_inputs'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==package['head'] and not subprocess.check_output(['git','status','--porcelain'],cwd=W)
print('Prepared unchanged24original cases/17required7forbidden and one bounded review; shared ledger/source unchanged.',flush=True)
