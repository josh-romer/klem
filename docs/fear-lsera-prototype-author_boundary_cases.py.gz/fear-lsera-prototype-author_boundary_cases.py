"""Author source and immediate-allomorph boundaries before new implementation."""
import gzip
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
PREP = BASE / 'fear-lsera-prepared'
sys.path.insert(0, str(BASE / 'familiar-geurae-prototype/tools'))
from native_lmf import entry, feature

sha = lambda raw: hashlib.sha256(raw).hexdigest()
prepared = json.loads(gzip.decompress((PREP / 'source-preparation.json.gz').read_bytes()))
cases = []
def case(ident, surface, lemmas, prefinals, verdict='required', source='short', extra=()):
    kinds = ['nominal', 'copula'] if len(lemmas) == 2 else ['predicate']
    cases.append({'id': ident, 'surface': surface, 'judgments': [{
        'id': 'path', 'lemmas': lemmas, 'lemma_kinds': kinds,
        'morphemes': [*prefinals, '을세라'], 'morpheme_kinds': ['prefinal'] * len(prefinals) + ['ending'],
        'required_rules': ['ending.apprehensive_lsera', *extra], 'verdict': verdict, 'source': source,
        'reason': ('Independent structural target from the complete original ending example or its named immediate attachment boundary. Canonical 을세라 represents both original ending allomorphs. Full and short owners retain all three senses. Homonym/context selection and other paths remain unjudged.' if verdict == 'required' else
                   'The named path violates this original ending pair\'s immediate short/full allomorph or listed prefinal/copular attachment license. This rejects the named decomposition only; lexical collisions and unrelated alternatives remain unjudged.')}]})
for proposal in prepared['independent_proposals']:
    case(proposal['id'], proposal['surface'], proposal['proposed_lemmas'], proposal['proposed_morphemes'][:-1],
         source='short' if proposal['source_entry_id'] == 'krdict:86497' else 'full')
for ident, surface, lemmas, prefinals, source, extra in [
    ('consonant', '먹을세라', ['먹다'], [], 'full', []),
    ('open', '갈세라', ['가다'], [], 'short', []),
    ('rieul', '살세라', ['살다'], [], 'short', []),
    ('cluster', '읽을세라', ['읽다'], [], 'full', []),
    ('honorific', '먹으실세라', ['먹다'], ['시'], 'short', []),
    ('past', '먹었을세라', ['먹다'], ['었'], 'full', []),
    ('closed-copula', '학생일세라', ['학생', '이다'], [], 'short', []),
    ('open-copula', '의사일세라', ['의사', '이다'], [], 'short', []),
    ('negative-copula', '아닐세라', ['아니다'], [], 'short', []),
    ('reu-stem', '부를세라', ['부르다'], [], 'short', []),
    ('bieup-irregular', '고울세라', ['곱다'], [], 'short', ['irregular.bieup']),
    ('siot-irregular', '지을세라', ['짓다'], [], 'full', ['irregular.siot']),
]:
    case('fear-lsera-boundary-' + ident, surface, lemmas, prefinals, source=source, extra=extra)
for ident, surface, lemmas, prefinals, source in [
    ('closed-short', '먹세라', ['먹다'], [], 'short'),
    ('open-full', '가을세라', ['가다'], [], 'full'),
    ('rieul-full', '살을세라', ['살다'], [], 'full'),
    ('cluster-short', '읽세라', ['읽다'], [], 'short'),
    ('past-short', '먹었세라', ['먹다'], ['었'], 'short'),
    ('immediate-modal', '먹겠을세라', ['먹다'], ['겠'], 'full'),
    ('immediate-retrospective', '먹덜세라', ['먹다'], ['더'], 'short'),
    ('missing-copular-i', '학생을세라', ['학생', '이다'], [], 'short'),
    ('ordinary-rieul-before-full', '들을세라', ['들다'], [], 'full'),
]:
    case('fear-lsera-forbidden-' + ident, surface, lemmas, prefinals, verdict='forbidden', source=source)
assert len(cases) == 46 and sum(j['verdict'] == 'required' for c in cases for j in c['judgments']) == 37
assert len({c['id'] for c in cases}) == 46
suite = {'schema_version': 1, 'review_status': 'Independent complete-original-source and named immediate-boundary judgments authored before implementation. Other candidates, contextual homonyms, wider distributions and independent linguistic review remain open.',
         'sources': {name: prepared['expression_entries'][ident]['url'] for name, ident in [('fear-lsera-short', 'krdict:86497'), ('fear-lsera-full', 'krdict:86619')]}, 'cases': cases}
for c in suite['cases']:
    for j in c['judgments']:
        j['source'] = 'fear-lsera-' + j['source']
suite_path = PREP / 'fear-lsera-validity.json'
assert not suite_path.exists()
suite_path.write_text(json.dumps(suite, ensure_ascii=False, indent=2) + '\n')
db = sqlite3.connect((BASE / 'dictionary-restoration/krdict.db').resolve().as_uri() + '?mode=ro', uri=True)
needed = set(prepared['complete_imported_entries'])
for headword in {lemma for c in cases for j in c['judgments'] for lemma in j['lemmas']}:
    for ident, raw in db.execute('select id,data from entries where headword=?', (headword,)):
        if json.loads(raw)['lexical_unit'] == '단어':
            needed.add(ident)
expected = {i: json.loads(db.execute('select data from entries where id=?', (i,)).fetchone()[0]) for i in sorted(needed)}
originals = dict(prepared['original_native_entries'])
exports = {}
for path in sorted((BASE / 'dictionary-restoration/2026-09').glob('*.json')):
    raw = path.read_bytes()
    selected = []
    for value in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
        ident = 'krdict:' + value['val']
        if ident not in needed or ident in originals or feature(value, 'lexicalUnit') in {'관용구', '속담'}:
            continue
        assert entry(value) == expected[ident], ident
        originals[ident] = value
        selected.append(ident)
    if selected:
        exports[path.name] = {'bytes': len(raw), 'sha256': sha(raw), 'ids': selected}
assert set(originals) == needed and {ident: entry(value) for ident, value in originals.items()} == expected
closure = {'state': 'complete-independent-source-and-boundary-native-closure-before-implementation',
           'initial_preparation_sha256': sha((PREP / 'source-preparation.json.gz').read_bytes()),
           'entries': expected, 'original_native_entries': originals, 'additional_exports': exports,
           'authored_validity_sha256': sha(suite_path.read_bytes()), 'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())}}
(PREP / 'authored-native-closure.json.gz').write_bytes(gzip.compress((json.dumps(closure, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
(PREP / 'independent-authoring.json').write_text(json.dumps({'state': 'authored-before-implementation', 'cases': 46,
                'required': 37, 'forbidden': 9, 'suite_sha256': sha(suite_path.read_bytes()), 'native_owners': len(originals),
                'complete_original_groups': 25, 'scope': 'No engine output or verdict is consulted while authoring these targets. Baseline observations remain separate and cannot change original lemmas, roles, boundaries or source identities.'}, indent=2) + '\n')
print('Authored46cases/37required/9forbidden and', len(originals), 'complete original Native owners before implementation', flush=True)
