"""Give every newly observed original-context candidate a stable review identity."""
import gzip
import hashlib
import json
from pathlib import Path

PREP = Path(__file__).resolve().parent
SOURCE = PREP / 'complete-source-preparation.json'
BEFORE = PREP / 'before-streams.json.gz'
AFTER = PREP / 'copula-source-streams.json.gz'
OUT = PREP / 'copula-source-candidate-review-queue.json'
assert not OUT.exists()
packet = json.loads(SOURCE.read_bytes())
before = json.loads(gzip.decompress(BEFORE.read_bytes()))
after = json.loads(gzip.decompress(AFTER.read_bytes()))
pick = lambda report: next(r for r in report['runs'] if (r['family'], r['encoding'], r['mode'], r['cache_bytes']) == ('complete-original-source', 'NFC', 'raw', 0))
old_rows = [json.loads(line) for line in pick(before)['jsonl'].splitlines()]
run = pick(after)
rows = [json.loads(line) for line in run['jsonl'].splitlines()]
groups = {group['id']: group for group in packet['complete_groups']}
cases = {case['id']: case for case in after['typed_fixture']['cases'][:16]}
items = []
for occurrence in run['observed_typed_paths']:
    index = occurrence['record_index']
    row, old = rows[index], old_rows[index]
    for path_index, path in enumerate(row['analysis']['analyses']):
        if path in old['analysis']['analyses']:
            continue
        digest = hashlib.sha256(json.dumps(path, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        covered = path_index in occurrence['typed_path_indices']
        items.append({'id': occurrence['id'] + '-candidate-' + digest,
                      'source_case_id': occurrence['id'], 'source_group': groups[occurrence['id']],
                      'surface': row['surface'], 'span': row['span'],
                      'record_index': index, 'analysis_index': path_index,
                      'analysis': path, 'dictionary_reading': row['dictionary']['readings'][path_index],
                      'coverage': 'covered-by-independent-required-path' if covered else 'unjudged-alternative',
                      'independent_judgment': cases[occurrence['id']]['judgments'][0] if covered else None,
                      'contextual_sense_verdict': 'unjudged'})
assert len(items) == run['new_family_paths'] == 82
assert len({item['id'] for item in items}) == 82
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
report = {'state': 'complete-original-context-candidate-queue-preserved', 'items': items,
          'covered_paths': sum(item['coverage'] == 'covered-by-independent-required-path' for item in items),
          'unjudged_alternatives': sum(item['coverage'] == 'unjudged-alternative' for item in items),
          'frozen_inputs': {str(p): sha(p) for p in [SOURCE, BEFORE, AFTER]},
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
          'scope': 'One canonical NFC/raw/uncached original-context record for each of82new candidate paths, with complete original source fields, exact raw span, native assessment and stable full-analysis SHA identity. The independently authored16required structures are distinguished from66unjudged alternatives. No alternative is auto-promoted or forbidden, and contextual sense review remains open.'}
OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(len(items), report['covered_paths'], report['unjudged_alternatives'], flush=True)
