"""Verify complete original owners and pre-probe proposals against the pinned dictionary."""
import hashlib
import json
import sqlite3
from pathlib import Path

OUT = Path(__file__).resolve().parent
INITIAL = OUT / 'source-preparation.json'
FINAL = OUT / 'complete-source-preparation.json'
DB = OUT.parent / 'dictionary-restoration/krdict.db'
assert not FINAL.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
frozen = {str(p): sha(p) for p in [INITIAL, DB, Path(__file__)]}
packet = json.loads(INITIAL.read_bytes())
targets = [
    ('어두워지려니와', ['어둡다', '지다']), ('고생이려니와', ['고생', '이다']),
    ('상쾌하려니와', ['상쾌하다']), ('따가우려니와', ['따갑다']),
    ('처리하려니와', ['처리하다']), ('떠나려니와', ['떠나다']),
    ('출발하려니와', ['출발하다']), ('하려니와', ['하다']),
    ('같으려니와', ['같다']), ('않으려니와', ['않다']),
    ('받으려니와', ['받다']), ('괜찮으려니와', ['괜찮다']),
    ('사랑했으려니와', ['사랑하다']), ('맞으려니와', ['맞다']),
    ('주겠으려니와', ['주다']), ('하겠으려니와', ['하다']),
]
with sqlite3.connect(DB.resolve().as_uri() + '?mode=ro', uri=True) as db:
    assert packet['dictionary_metadata'] == dict(db.execute('SELECT key,value FROM metadata'))
    owners = {
        ident: json.loads(db.execute('SELECT data FROM entries WHERE id=?', (ident,)).fetchone()[0])
        for ident in ['krdict:86083', 'krdict:86084']
    }
    assert owners == packet['source_entries']
    assert [(o['headword'], o['homonym'], o['pos'], o['lexical_unit']) for o in owners.values()] == [
        ('-려니와', '0', '어미', '단어'), ('-으려니와', '0', '어미', '단어'),
    ]
    for word, original in packet['complete_lexical_entries'].items():
        assert original == [json.loads(row[0]) for row in db.execute('SELECT data FROM entries WHERE headword=?', (word,))]
groups = []
for owner in owners.values():
    for sense in owner['senses']:
        for ordinal, lines in enumerate(sense['examples']):
            groups.append({
                'id': f"conjectural-additive-{owner['id'].split(':')[1]}-sense-{sense['id']}-group-{ordinal+1}",
                'source_entry_id': owner['id'], 'source_headword': owner['headword'],
                'sense_id': sense['id'], 'group_ordinal': ordinal,
                'complete_original_group': lines, 'source_notes': owner['notes'],
                'sense_notes': sense['notes'], 'definition': sense['definition'],
            })
assert len(groups) == 16 and groups == packet['complete_groups']
assert len(packet['independent_proposals']) == 16
assert packet['complete_source_text'] == '\n'.join(line for group in groups for line in group['complete_original_group'])
for group, proposal, (surface, lemmas) in zip(groups, packet['independent_proposals'], targets, strict=True):
    assert all(proposal[key] == value for key, value in group.items())
    assert (proposal['surface'], proposal['proposed_lemmas']) == (surface, lemmas)
    assert proposal['verdict'] == 'proposed-before-probe'
    raw = '\n'.join(group['complete_original_group']).encode()
    assert raw.count(surface.encode()) == 1 and proposal['surface_byte_offset'] == raw.index(surface.encode())
assert all(sha(path) == digest for path, digest in frozen.items())
result = {
    **packet, 'state': 'complete-original-conjectural-additive-sources-verified-before-probe',
    'frozen_inputs': frozen, 'inputs_unchanged': True,
    'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)},
    'source_scope': {'ending_owners': 2, 'senses': 4, 'groups': 16, 'proposal_occurrences': 16},
}
FINAL.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('Verified all original owners, notes, translations,16groups and pre-probe proposals.')
