"""Capture individual history additions and immutable prior willingness parents."""
import datetime
import gzip
import hashlib
import json
import subprocess
import sys
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-gentle-command')
OUT = PREP / 'gentle-command-history.json'
assert not OUT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
cohort_path = PREP / 'gentle-command-cohorts.json.gz'
cohorts = json.loads(gzip.decompress(cohort_path.read_bytes()))
assert cohorts['state'] == 'complete-original-corpus-history-comparison-passed'
assert cohorts['inputs_unchanged']
binding_path = PREP / 'willingness-installed-source-binding-retry1.json'
binding = json.loads(binding_path.read_bytes())
assert binding['state'] == 'passed'
cli = Path(binding['profiles']['klem']['package']) / 'bin/klem'
sources = {
    'tests/copula-expectation-full-source.json': 'before_analyses',
    'tests/fixtures/counterfactual-ryeon-sources.json': 'source_cohort_before_analyses',
    'tests/fixtures/degree-rimankeum-sources.json': 'source_cohort_before_analyses',
    'tests/fixtures/friendly-command-sources.json': 'before_analyses',
    'tests/fixtures/native-pos-sources.json': 'before_words',
}
originals = {name: json.loads((WORK / name).read_bytes()) for name in sources}
frozen = {str(p): sha(p) for p in [cohort_path, binding_path, cli, Path(__file__),
                                WORK / 'tools/doeda_native_corpora.py',
                                *(WORK / name for name in sources)]}
changed = {row['surface']: row for row in cohorts['individual_changed_words']}
assert len(changed) == 8 and all(row['family'] == 'history' for row in changed.values())
sys.path.insert(0, str(WORK / 'tools'))
from doeda_native_corpora import words_from_cli
companions = words_from_cli(cli, sorted({word[:-1] + '련' for word in changed}))
rows = []
for surface, change in changed.items():
    parent_surface = surface[:-1] + '련'
    assert surface.endswith('렴')
    witnesses = []
    contexts = []
    for source, key in sources.items():
        original = originals[source]
        if surface in original[key]:
            witnesses.append(dict(source=source, source_sha256=sha(WORK/source),
                                  pointer='/' + key + '/' + surface,
                                  complete_original_record=original[key][surface]))
        for group_key in ['source_cohort_original_groups', 'original_groups']:
            for index, group in enumerate(original.get(group_key, [])):
                if surface in json.dumps(group.get('original_group', []), ensure_ascii=False):
                    contexts.append(dict(source=source, source_sha256=sha(WORK/source),
                                         pointer=f'/{group_key}/{index}',
                                         complete_original_record=group))
    assert witnesses, ('missing historical witness', surface)
    for analysis in change['new_paths']:
        inverse = json.loads(json.dumps(analysis))
        assert inverse['rules'].count('ending.gentle_command') == 1
        inverse['rules'].remove('ending.gentle_command')
        inverse['rules'] = sorted(set(inverse['rules'] + ['ending.willingness_question']))
        endings = [m for m in inverse['morphemes'] if m['kind'] == 'ending']
        assert len(endings) == 1 and endings[0]['form'] == '으렴'
        endings[0]['form'] = '으련'
        assert inverse in companions[parent_surface]['analyses'], (surface, analysis, inverse)
        rows.append(dict(id=f'gentle-command-history-{len(rows)+1}', surface=surface,
                         analysis=analysis, original_occurrences=witnesses,
                         original_contexts=contexts, parent_surface=parent_surface,
                         exact_parent=inverse, contextual_verdict='unjudged',
                         independent_review='pending'))
assert len(rows) == 18
assert all(sha(p) == digest for p, digest in frozen.items())
report = dict(state='complete-gentle-command-history-and-prior-parent-capture-passed',
              source_files_sha256={name: sha(WORK/name) for name in sources},
              original_cohort_capture_sha256=sha(cohort_path),
              prior_cli=str(cli), prior_cli_sha256=sha(cli),
              actual_prior_companions=companions,
              changed_words={word: dict(before=row['before'], after=row['after'])
                             for word, row in changed.items()},
              individual_additions=rows, frozen_inputs=frozen, inputs_unchanged=True,
              producer=dict(text=Path(__file__).read_text(), sha256=sha(__file__)),
              finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              scope='Exact18newpaths/eightwords attributed by unchanged original witnesses and actual prior Nix willingness parents. Every original candidate/order retained. Contextual and independent judgments pending; unknown raw hypotheses remain unjudged.')
OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
print('Captured', len(rows), 'exact additions;', len(companions), 'actual prior counterparts.')
