"""Recompute two authored owner corrections against the original full CLI boundary capture."""
import copy,gzip,hashlib,json
from pathlib import Path
sha=lambda raw:hashlib.sha256(raw).hexdigest();read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes())
initial=Path('/tmp/klem-literary-question-geona-boundary-preflight.json.gz');fixture=Path('/tmp/klem-literary-question-geona-prototype/tests/fixtures/literary-question-geona-authored-boundaries.json');OUT=Path('/tmp/klem-literary-question-geona-boundary-corrected.json.gz')
old=read(initial);draft=read(fixture);assert len(old['proposal_mismatches'])==12 and len(draft['explicit_draft_corrections'])==2
report=copy.deepcopy(old);corrections=draft['explicit_draft_corrections'];cases=draft['cases'];by_old={c['before']['id']:c['after'] for c in corrections};by_id={c['id']:c for c in cases}
report.update(cases=cases,state='passed',initial_preflight_sha256=sha(initial.read_bytes()),explicit_draft_corrections=corrections,initial_mismatches_retained=old['proposal_mismatches'],proposal_mismatches=[],scope=draft['scope'])
for o in report['observations']:
 c=by_old.get(o['case_id'],by_id.get(o['case_id']));o.update(case_id=c['id'],proposal=c['proposal'],expected_status=c['expected_status'])
 o['matches_proposed_status']=all(a['status']!='incompatible' if c['expected_status']=='not-incompatible' else a['status']==c['expected_status'] for a in o['assessments']);assert o['matches_proposed_presence'] and o['matches_proposed_status']
 if o['assessments'] and 'expected_entry_statuses' in c:
  entries={e['id']:e['status'] for a in o['assessments'] for l in a['lemmas'] for e in l['entries']};assert all(entries[i]==status for i,status in c['expected_entry_statuses'].items());o['specific_owner_statuses']=c['expected_entry_statuses']
assert {v:sum(c['proposal']==v for c in cases) for v in ['required','conditional','forbidden','native-policy-only']}=={'required':27,'conditional':11,'forbidden':5,'native-policy-only':4}
p=Path(__file__);report['correction_producer']={'text':p.read_text(),'sha256':sha(p.read_bytes()),'authored_fixture_sha256':sha(fixture.read_bytes()),'initial_preflight_sha256':sha(initial.read_bytes())}
OUT.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Preserved original CLI outputs and12draft errors; all282 observations satisfy two explicit Native-owner corrections.',flush=True)
