"""Preserve both original gentle-command ending entries before any runtime probe."""
import datetime, hashlib, json, sqlite3
from pathlib import Path
prep=Path(__file__).resolve().parent;out=prep/'gentle-command-original-source.json';assert not out.exists()
db=Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db')
with sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True) as c:
 metadata=dict(c.execute('SELECT key,value FROM metadata'))
 owners={};raw={}
 for ident,head,pos,data in c.execute('SELECT id,headword,pos,data FROM entries WHERE headword IN (?,?) ORDER BY id',('-렴','-으렴')):
  assert pos=='어미';raw[ident]=data;owners[ident]=json.loads(data)
assert list(owners)==['krdict:79340','krdict:79343']
# Linguistic proposals are written from the original examples before output is
# observed. They are not promoted into the active correctness ledger here.
authored=[('krdict:79340',1,'오렴',['오다'],['predicate'],['으렴'],['ending']),('krdict:79340',2,'하렴',['하다'],['predicate'],['으렴'],['ending']),('krdict:79340',3,'물어보렴',['물어보다'],['predicate'],['으렴'],['ending']),('krdict:79340',4,'쉬렴',['쉬다'],['predicate'],['으렴'],['ending']),('krdict:79343',1,'나으렴',['낫다'],['predicate'],['으렴'],['ending']),('krdict:79343',2,'잡으렴',['잡다'],['predicate'],['으렴'],['ending']),('krdict:79343',3,'담으렴',['담다'],['predicate'],['으렴'],['ending']),('krdict:79343',4,'적으렴',['적다'],['predicate'],['으렴'],['ending'])]
items=[]
for ident,group,surface,lemmas,kinds,morphs,morph_kinds in authored:
 sense=owners[ident]['senses'][0];assert sense['id']=='1'
 context=sense['examples'][group-1];text='\n'.join(context);encoded=text.encode();needle=surface.encode();start=encoded.index(needle);assert encoded.count(needle)==1
 items.append(dict(id='gentle-command-'+ident.split(':')[1]+'-sense-1-group-'+str(group),entry_id=ident,sense_id='1',example_group=group,complete_original_group=context,surface=surface,local_span={'start':start,'end':start+len(needle)},independent_typed_proposal={'lemmas':lemmas,'lemma_kinds':kinds,'morphemes':morphs,'morpheme_kinds':morph_kinds},remaining='Original complete Native-LMF owner/homonym closure, exact attachment and auxiliary/allomorph proof, dictionary POS rules, shared-ledger promotion, annotated/broad impact, UI/Nix/main and contextual/independent review pending.'))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
r=dict(state='source-and-typed-proposals-authored-before-runtime-probe',authored_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source='Pinned Korean Basic Dictionary September2026 SQLite projection; original complete Native LMF closure remains pending',database_sha256=sha(db.read_bytes()),dictionary_metadata=metadata,ending_owner_ids=list(owners),owners=owners,original_sqlite_entry_json=raw,items=items,expression_homonyms_seen=[],linguistic_judgments_promoted=False,observed_runtime=False,producer={'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())})
out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print('Preserved both complete ending entries and all8sourcegroups with preauthored typed proposals; no gold or runtime observed')
