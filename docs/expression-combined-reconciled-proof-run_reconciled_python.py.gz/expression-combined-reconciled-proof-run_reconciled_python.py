"""Check corrected historical history plus actual installed proof wiring."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

prep = Path(__file__).resolve().parent
work = Path('/tmp/klem-expression-conjectural-main')
out = prep / 'combined-reconciled-python.json'
assert not out.exists()
commands = [[sys.executable, '-m', 'unittest', 'discover', '-s', 'tools', '-p', name] for name in [
    'test_literary_question_geona_runtime.py', 'test_expression_conjectural_installed_audit.py',
    'test_expression_conjectural_ledger_audit.py', 'test_conjectural_additive_ledger_audit.py',
    'test_formal_volitional_expression_ledger_audit.py', 'test_review_inventory.py']]
commands += [[sys.executable, 'tools/review_inventory.py', '--verify'],
             [sys.executable, 'tools/expression_conjectural_installed_audit.py']]
sha = lambda path: hashlib.file_digest(Path(path).open('rb'), 'sha256').hexdigest()
files = [p for folder in ['src', 'tools', 'tests', 'docs', 'web/src'] for p in (work / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += [work / 'Cargo.toml', work / 'Cargo.lock', work / 'flake.nix', Path(__file__)]
frozen = {str(p): sha(p) for p in files}
receipt = {'state': 'running', 'commands': [], 'frozen_inputs': frozen,
           'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))}}
out.write_text(json.dumps(receipt, indent=2) + '\n')
try:
    for index, command in enumerate(commands):
        log = prep / ('combined-reconciled-python-' + str(index) + '.log')
        with log.open('xb') as stream:
            result = subprocess.run(command, cwd=work, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), stdout=stream, stderr=subprocess.STDOUT)
        receipt['commands'].append({'command': command, 'exit_code': result.returncode, 'log': str(log), 'log_sha256': sha(log)})
        print(index, result.returncode, flush=True)
        assert result.returncode == 0, log
    receipt.update(state='passed', exit_code=0, inputs_unchanged=all(sha(p) == digest for p, digest in frozen.items()))
    assert receipt['inputs_unchanged']
except Exception as error:
    receipt.update(state='failed', error=str(error))
    raise
finally:
    out.write_text(json.dumps(receipt, indent=2) + '\n')
