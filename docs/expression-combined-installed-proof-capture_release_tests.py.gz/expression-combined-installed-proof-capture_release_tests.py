"""Count actual retained release tests from the bound Nix derivation log."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

prep = Path(__file__).resolve().parent
binding_path = prep / 'combined-installed-source-binding.json'
binding = json.loads(binding_path.read_bytes())
assert binding['state'] == 'passed' and binding['all_tracked_inputs_unchanged']
profile = binding['profiles']['klem']
out = prep / 'combined-installed-release-tests.json'
log = prep / 'combined-installed-release-tests.log'
assert not out.exists() and not log.exists()
command = ['nix', 'log', profile['derivation']]
result = subprocess.run(command, capture_output=True)
log.write_bytes(result.stdout)
stderr = prep / 'combined-installed-release-tests.stderr'
stderr.write_bytes(result.stderr)
assert result.returncode == 0, result.stderr.decode()
batches = re.findall(rb'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', result.stdout)
totals = {key: sum(int(batch[i + 1]) for batch in batches)
          for i, key in enumerate(['passed', 'failed', 'ignored'])}
assert all(batch[0] == b'ok' for batch in batches)
assert totals == {'passed': 1164, 'failed': 0, 'ignored': 1} and len(batches) == 251
sha = lambda raw: hashlib.sha256(raw).hexdigest()
receipt = {'state': 'passed', 'derivation': profile['derivation'],
           'package': profile['package'], 'command': command, 'exit_code': result.returncode,
           'totals': totals, 'batches': len(batches), 'log_sha256': sha(result.stdout),
           'stderr_sha256': sha(result.stderr), 'binding_sha256': sha(binding_path.read_bytes()),
           'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())},
           'scope': 'Actual retained installed-package Nix build log; every release test batch counted.'}
out.write_text(json.dumps(receipt, indent=2) + '\n')
print(totals, len(batches), 'actual installed release batches')
