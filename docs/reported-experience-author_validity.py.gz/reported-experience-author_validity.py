"""Author finite source/allomorph judgments; never promote emitted candidates to gold."""
import gzip,json
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];PROTO=ROOT/'.direnv/reported-experience-prototype'
prepared=json.loads(gzip.decompress((OUT/'source-preparation.json.gz').read_bytes()))
proposals=json.loads(gzip.decompress((OUT/'proposals.json.gz').read_bytes()))['proposals']
sources={f'reported-experience-{ident.split(":")[1]}':entry['url'] for ident,entry in prepared['complete_imported_entries'].items()}
sources['reported-experience-novel-mujeong']='https://ko.wikisource.org/wiki/무정'
cases=[]
def add(ident,surface,lemmas,morphs,verdict,source,reason):
 kinds=['nominal','copula'] if len(lemmas)==2 else ['predicate']
 cases.append({'id':ident,'surface':surface,'judgments':[{'id':'path','lemmas':lemmas,'lemma_kinds':kinds,'morphemes':morphs,'morpheme_kinds':['particle' if m=='까지' else 'prefinal' for m in morphs[:-1]]+['ending'],'required_rules':['ending.reported_experience'],'verdict':verdict,'source':source,'reason':reason}]})
for p in proposals:
 add(p['id'],p['surface'],p['proposed_lemmas'],p['proposed_morphemes'],'required','reported-experience-'+p['entry_id'].split(':')[1],p['source_tension'] or 'Agent-authored structural reading of the complete original source group, without choosing a contextual sense. Independent Korean review pending.')
for tail,plain,present,command,factual,plain_id,present_full,present_short,command_full,command_short in [('까','답디까','는답디까','으랍디까','랍디까',86678,86687,86680,86336,86337),('다','답디다','는답디다','으랍디다','랍디다',86674,86692,86683,86338,86339)]:
 short=present[1:]
 boundaries=[
 ('open-present','간'+short,'가다',[present],'required',present_short),
 ('consonant-present','먹'+present,'먹다',[present],'required',present_full),
 ('rieul-present','산'+short,'살다',[present],'required',present_short),
 ('adjective','좋'+plain,'좋다',[plain],'required',plain_id),
 ('past','먹었'+plain,'먹다',['었',plain],'required',plain_id),
 ('modal','먹겠'+plain,'먹다',['겠',plain],'required',plain_id),
 ('honorific','먹으신'+short,'먹다',['시',present],'required',present_short),
 ('consonant-command','먹'+command,'먹다',[command],'required',command_full),
 ('open-command','가'+factual,'가다',[command],'required',command_short),
 ('rieul-command','살'+factual,'살다',[command],'required',command_short),
 ('copular','학생이'+factual,['학생','이다'],[factual],'required',command_short),
 ('negative-copular','아니'+factual,'아니다',[factual],'required',command_short),
 ('conjectural-factual','읽으리'+factual,'읽다',['으리',factual],'required',command_short),
 ('wrong-open-full','가'+present,'가다',[present],'forbidden',present_full),
 ('wrong-rieul-full','알'+present,'알다',[present],'forbidden',present_full),
 ('past-present','먹었'+present,'먹다',['었',present],'forbidden',present_full),
 ('retrospective-plain','먹더'+plain,'먹다',['더',plain],'forbidden',plain_id),
 ('past-command','먹었'+command,'먹다',['었',command],'forbidden',command_full),
 ('adjectival-command','좋'+command,'좋다',[command],'forbidden',command_full),
 ('negative-command','아니'+command,'아니다',[command],'forbidden',command_full),
 ('wrong-consonant-short-command','먹'+factual,'먹다',[command],'forbidden',command_short),
 ('bare-plain-copular','학생'+plain,['학생','이다'],[plain],'forbidden',plain_id),
 ('retrospective-conjectural','먹더으리'+factual,'먹다',['더','으리',factual],'forbidden',command_short)]
 for label,surface,lemmas,morphs,verdict,owner in boundaries:
  add('reported-experience-boundary-'+tail+'-'+label,surface,lemmas if isinstance(lemmas,list) else [lemmas],morphs,verdict,'reported-experience-'+str(owner),'Agent-authored finite allomorph, lexical-class or immediate-marker boundary; not an explicit source prohibition or independently annotated sentence gold.')
for surface,lemma in [('번답디까','벌다'),('들인답디까','들이다')]:
 add('reported-experience-novel-'+surface,surface,[lemma],['는답디까'],'required','reported-experience-novel-mujeong','Agent-authored structural reading of a preserved complete original novel line, backed separately by present-report allomorph entries. Other structural and spacing options remain visible; contextual and independent review pending.')
assert len(cases)==99 and len({c['id'] for c in cases})==99
suite={'schema_version':1,'review_status':'Agent-authored finite source/boundary/novel judgments. Ten original expression entries retain POS 품사 없음; contextual/independent review pending. Preserve the source categorization tension at 했답디까.','sources':sources,'cases':cases}
initial=(json.dumps(suite,ensure_ascii=False,indent=2)+'\n').encode()
assert (OUT/'initial-99-case-validity.json').read_bytes()==initial,'preserve the exact initial authored99case suite and actual failed run'
conditional=[c for c in cases if c['id'].endswith('-adjectival-command')]
assert len(conditional)==2
(PROTO/'tests/fixtures/reported-experience-native-conditional-cases.json').write_text(json.dumps({'schema_version':1,'review_status':'The two original authored forbidden judgments require dictionary POS, not raw structural generation. Initial raw failures are retained. Each case must be present in raw/headword modes and absent after actual dictionary-compatible filtering; full adjective Native identity and per-entry conflict are tested.','cases':conditional},ensure_ascii=False,indent=2)+'\n')
suite['cases']=[c for c in cases if c not in conditional]
suite['review_status']+=' Two originally raw-forbidden adjective-command cases remain separately enforced as dictionary-POS-dependent cases; they are not discarded or appended as raw gold.'
(PROTO/'tests/fixtures/reported-experience-validity.json').write_text(json.dumps(suite,ensure_ascii=False,indent=2)+'\n')
print('Authored97raw cases:',{v:sum(j['verdict']==v for c in suite['cases'] for j in c['judgments']) for v in ['required','forbidden']},'plus two retained Native-dependent judgments')
