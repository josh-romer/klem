import gzip,json,subprocess,hashlib
from pathlib import Path
OLD=Path('/tmp/klem-declarative-dao-preparation.json.gz');OUT=Path('/tmp/klem-declarative-dao-preparation-complete.json.gz');assert not OUT.exists()
r=json.load(gzip.open(OLD,'rt'));groups=[];text='';cursor=0
for original in r['complete_groups']:
 g=dict(original);s='\n'.join(g['complete_original_examples']);g['span']={'start':cursor,'end':cursor+len(s.encode())};text+=s+'\n';cursor+=len((s+'\n').encode());groups.append(g)
CLI='/nix/store/qm6ffk87sb4vl5r9zbcj77y3411i0mhj-klem-0.1.0/bin/klem';DB='/home/josh/projects/klem/data/dictionaries/krdict/krdict.db';runs={}
for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
 command=[CLI,'text','-','--dictionary',DB,*flags];job=subprocess.run(command,input=text.encode(),capture_output=True,check=True);assert not job.stderr;runs[mode]={'command':command,'records':[json.loads(line) for line in job.stdout.splitlines()],'stdout_sha256':hashlib.sha256(job.stdout).hexdigest(),'exit_code':job.returncode}
lemmas={'안다오':'알다','간다오':'가다','운다오':'울다','기다린다오':'기다리다','한다오':'하다','늦으신다오':'늦다','떠난다오':'떠나다','온다오':'오다','전화한다오':'전화하다','믿는다오':'믿다','받는다오':'받다','찾는다오':'찾다','씻는다오':'씻다','늦는다오':'늦다','먹는다오':'먹다','읽는다오':'읽다','갚는다오':'갚다','건강하다오':'건강하다','아름답다오':'아름답다','힘들다오':'힘들다','아프다오':'아프다','떴다오':'뜨다','합격했다오':'합격하다','빠르다오':'빠르다','맛있다오':'맛있다'}
proposals=[]
for ordinal,raw in enumerate(runs['raw']['records']):
 if not raw.get('analysis'):continue
 word=raw['analysis']['normalized']
 if not word.endswith('다오'):continue
 assert word in lemmas,('unreviewed target needing authored lemma',word)
 g=next(g for g in groups if g['span']['start']<=raw['span']['start']<raw['span']['end']<=g['span']['end']);ident=g['entry_id'];basis=f"{ident.split(':')[1]}-{g['sense_id']}-{g['group']}-{raw['span']['start']-g['span']['start']}"
 proposals.append({'id':'declarative-dao-source-'+basis,'source_entry':ident,'source_sense':g['sense_id'],'source_group':g['group'],'surface':word,'proposed_lemma':lemmas[word],'complete_original_group':g['complete_original_examples'],'baseline_records':{mode:data['records'][ordinal] for mode,data in runs.items()},'judgment':'proposed-unreviewed','basis':'Authored analysis of a complete native example; not annotation gold. Distinct ending/expression identities and prefinal owners need independent source review.'})
assert {p['source_entry'] for p in proposals}==r['complete_native_entries'].keys() and len(proposals)==26
r.update(state='complete-next-family-source-runtime-preparation',groups_with_offsets=groups,complete_source_text=text,baseline_runs=runs,proposals=proposals,earlier_preparation_sha256=hashlib.sha256(OLD.read_bytes()).hexdigest(),producer={'text':Path(__file__).read_text(),'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()});OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Retained all6identities/26groups and26proposals with actual three-mode current CLI observations.')
