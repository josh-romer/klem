"""Correct a copied closure label while retaining all original authored payloads."""
import gzip,hashlib,json,datetime
from pathlib import Path
P=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
source_path=P/'friendly-hortative-sena-source-authoring.json';closure_path=P/'friendly-hortative-sena-original-native-closure.json.gz';suite_path=P/'friendly-hortative-sena-validity.json'
raw_source=source_path.read_bytes();raw_closure=closure_path.read_bytes();raw_suite=suite_path.read_bytes()
source=json.loads(raw_source);closure=json.loads(gzip.decompress(raw_closure))
assert source['candidate_runtime_observed'] is False and source['historical_whole_inventory_discovery_already_exists'] is True
assert source['suite_sha256']==sha(raw_suite) and source['native_closure_sha256']==sha(raw_closure)
assert len(closure['complete_native_entries'])==36 and source['owner_ids']==['krdict:78469'] and len(source['items'])==5
original_state=closure['state'];assert original_state=='complete-original-gena-owner-lexical-boundary-closure'
closure['state']='complete-original-sena-owner-lexical-boundary-closure'
corrected=json.dumps(closure,ensure_ascii=False)+'\n';packed=gzip.compress(corrected.encode(),mtime=0)
closure_output=P/'friendly-hortative-sena-original-native-closure-reviewed.json.gz';source_output=P/'friendly-hortative-sena-source-authoring-reviewed.json'
assert not closure_output.exists() and not source_output.exists()
closure_output.write_bytes(packed)
record=dict(source)
record['original_authoring_producer']=source['producer']
record['original_authoring_sha256']=sha(raw_source)
record['original_native_closure_sha256']=sha(raw_closure)
record['native_closure_sha256']=sha(packed)
record['producer']=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes()))
record['metadata_label_correction']=dict(from_state=original_state,to_state=closure['state'],case_and_judgment_bytes_unchanged=True,all_complete_native_and_original_lmf_fields_unchanged=True,original_payloads_retained=True,corrected_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
source_output.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
assert source_path.read_bytes()==raw_source and closure_path.read_bytes()==raw_closure and suite_path.read_bytes()==raw_suite
assert {k:v for k,v in closure.items() if k!='state'}=={k:v for k,v in json.loads(gzip.decompress(raw_closure)).items() if k!='state'}
print('Preserved original authoring/25case bytes/36 completeNative owners; corrected only copied closure-family label in separate reviewed artifacts.',flush=True)
