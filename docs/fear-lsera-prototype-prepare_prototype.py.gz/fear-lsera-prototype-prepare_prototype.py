"""Copy stable parent source into a separate minimal focused-test prototype."""
import gzip
import hashlib
import json
import shutil
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
PARENT = BASE / 'familiar-geurae-prototype'
ROOT = BASE / 'fear-lsera-prototype'
PREP = BASE / 'fear-lsera-prepared'
ROOT.mkdir(exist_ok=True)
receipt = json.loads((BASE / 'familiar-geurae-prepared/full-rust.json').read_text())
selected = ['Cargo.toml', 'Cargo.lock', 'tools/validity.rs']
selected.extend(str(p.relative_to(PARENT)) for p in (PARENT / 'src').rglob('*') if p.is_file())
selected.extend(str(p.relative_to(PARENT)) for p in (PARENT / 'examples').rglob('*') if p.is_file())
selected.extend(str(p.relative_to(PARENT)) for p in (PARENT / 'web/src').rglob('*') if p.is_file())
for name in selected:
    if name in receipt['frozen_source_files']:
        assert hashlib.sha256((PARENT / name).read_bytes()).hexdigest() == receipt['frozen_source_files'][name], ('changed parent', name)
    target = ROOT / name
    assert not target.exists(), target
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(PARENT / name, target)
fixtures = ROOT / 'tests/fixtures'
fixtures.mkdir(parents=True)
shutil.copyfile(PREP / 'fear-lsera-validity.json', fixtures / 'fear-lsera-validity.json')
closure = json.loads(gzip.decompress((PREP / 'authored-native-closure.json.gz').read_bytes()))
for name, value in [('fear-lsera-native.json', {'LexicalResource': {'Lexicon': {'LexicalEntry': list(closure['original_native_entries'].values())}}}),
                    ('fear-lsera-native-entries.json', closure['entries'])]:
    (fixtures / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
prepared = json.loads(gzip.decompress((PREP / 'source-preparation.json.gz').read_bytes()))
baseline = json.loads(gzip.decompress((PREP / 'baseline-gap.json.gz').read_bytes()))
proposals = []
for original in prepared['independent_proposals']:
    proposal = dict(original)
    proposal['baseline_records'] = {mode: {'analysis': next(r['record'] for r in baseline['runs'] if (r['id'], r['encoding'], r['mode']) == (proposal['id'], 'NFC', mode))} for mode in ['raw', 'headword', 'compatible']}
    proposals.append(proposal)
(fixtures / 'fear-lsera-proposals.json').write_text(json.dumps(proposals, ensure_ascii=False, indent=2) + '\n')
rust = (PARENT / 'tests/giroseo.rs').read_text()
rust = rust[:rust.index('#[test]\nfn every_observed_source_path_has_exact_complete_native_ownership()')]
rust = rust.replace('giroseo', 'fear-lsera').replace('ending.concessive_fear-lsera', 'ending.apprehensive_lsera')
rust = rust.replace('required_total, 34', 'required_total, 37').replace('forbidden_total, 14', 'forbidden_total, 9')
rust = rust.replace('proposals.len(), 8', 'proposals.len(), 25').replace('owners.len(), 32', 'owners.len(), 69')
(ROOT / 'tests/fear_lsera.rs').write_text(rust.rstrip() + '\n')
proof = {'state': 'prepared', 'parent_inputs_copied': selected, 'parent_unchanged': True,
         'source_groups': 25, 'authored_cases': 46, 'complete_native_owners': 69,
         'scope': 'Separate minimal focused-test prototype copied from actual currently frozen familiar parent bytes. No running parent/compiler/Nix inputs changed. Complete historical parent tests/evidence restoration is required before full suite or integration.'}
(PREP / 'prototype-preparation.json').write_text(json.dumps(proof, indent=2) + '\n')
print('Prepared independent prototype from', len(selected), 'stable parent inputs with three Source/Native/boundary regressions', flush=True)
