"""Build four actual Nix packages while preserving every selected workspace input."""
import datetime,hashlib,json,os,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parent/'familiar-geurae-integration'
PREFIX='git+file://'+str(ROOT.resolve())
sha=lambda raw:hashlib.sha256(raw).hexdigest()
receipt=OUT/'integration-packages.json';log=OUT/'integration-packages.log'
assert not receipt.exists() and not log.exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
profiles={};frozen={}
for name in ['klem','web-assets','corpus-adapter']:
 source=subprocess.check_output(['nix','eval','--offline','--raw',PREFIX+'#packages.x86_64-linux.'+name+'.src'],cwd=ROOT,text=True).strip()
 base=ROOT/'web' if name=='web-assets' else ROOT
 files={}
 for p in sorted(Path(source).rglob('*')):
  if not p.is_file():continue
  assert not p.is_symlink()
  relative=str(p.relative_to(source));raw=p.read_bytes();assert (base/relative).read_bytes()==raw
  private=OUT.parent/'familiar-geurae-prototype'/('web' if name=='web-assets' else '')/relative
  assert private.read_bytes()==raw, (name,relative,'compiled prototype source differs')
  files[relative]={'bytes':len(raw),'sha256':sha(raw)};frozen[str(base/relative)]=sha(raw)
 profiles[name]={'source':source,'files':files}
for name in ['flake.nix','flake.lock']:
 p=ROOT/name;frozen[str(p)]=sha(p.read_bytes())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT))
status=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)
command=['nix','build','--offline','--option','build-dir','/tmp/klem-familiar-geurae-package-build','--cores','4','--max-jobs','1','--no-link','--print-out-paths','-L',*[PREFIX+'#packages.x86_64-linux.'+p for p in ['klem','web-assets','corpus-adapter','web']]]
Path('/tmp/klem-familiar-geurae-package-build').mkdir(exist_ok=True)
r={'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'profiles':profiles,'frozen_inputs':frozen,'head':head,'index_sha256':index,'worktree_status':status,'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'scope':'Actual complete Nix CLI/server, frontend assets, annotated adapter and web launcher build from the committed familiar-particle integration using the actual Git-backed flake. Every actual selected Rust/frontend/adapter source byte also equals the completed1135test prototype. All selected workspace package inputs, flake, HEAD/index/status frozen. Installed source binding/runtime/browser/adapter and complete inventory execution remain separate.'}
def save():receipt.write_text(json.dumps(r,indent=2)+'\n')
save();env={**os.environ,'TMPDIR':'/tmp/klem-familiar-geurae-package-build'}
with log.open('wb') as stream:job=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
r.update(state='passed' if job.returncode==0 else 'failed',exit_code=job.returncode,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),inputs_unchanged=all(sha(Path(p).read_bytes())==digest for p,digest in frozen.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==head,index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT))==index,status_unchanged=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)==status,log_sha256=sha(log.read_bytes()),outputs=[l for l in log.read_text().splitlines() if l.startswith('/nix/store/')])
save();print({k:r[k] for k in ['state','exit_code','inputs_unchanged','head_unchanged','index_unchanged','status_unchanged','outputs']},flush=True)
assert all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged','status_unchanged'])
if job.returncode==0:assert len(r['outputs'])==4
raise SystemExit(job.returncode)
