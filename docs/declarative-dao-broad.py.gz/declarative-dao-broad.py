"""Compare eight complete current-release streams with the dao draft, retaining each change."""
import copy,gzip,hashlib,itertools,json,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem')
BEFORE=Path('/nix/store/mfd8vyfqgmcbz0ns6jg05vglkzz7ldi4-klem-0.1.0/bin/klem')
AFTER=Path('/tmp/klem-declarative-dao-cli')
DB=ROOT/'data/dictionaries/krdict/krdict.db'
PRIOR=ROOT/'docs/possessive-bound-noun-broad-final.json.gz'
OUT=Path('/tmp/klem-declarative-dao-broad.json.gz')
assert not OUT.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
prior=json.loads(gzip.decompress(PRIOR.read_bytes()))
frozen={str(p):sha(p) for p in [BEFORE,AFTER,DB,PRIOR,Path(__file__)]}
comparisons=[];observations=[];parents=set()

def inspect(old,new,location):
    """Preserve every prior local path, assessment and display; record new paths."""
    assert {k:v for k,v in old.items() if k not in ['analysis','dictionary','spacing','breakdowns']} == {k:v for k,v in new.items() if k not in ['analysis','dictionary','spacing','breakdowns']}, location
    added=[]
    if old.get('analysis') is None:
        assert old==new,location
        return added
    a,b=old['analysis'],new['analysis']
    assert {k:v for k,v in a.items() if k!='analyses'} == {k:v for k,v in b.items() if k!='analyses'}
    assert [p for p in b['analyses'] if p in a['analyses']]==a['analyses'],(location,'old path lost/reordered')
    od,nd=old['dictionary'],new['dictionary']
    assert {k:v for k,v in od.items() if k not in ['lemmas','readings']}=={k:v for k,v in nd.items() if k not in ['lemmas','readings']}
    for p in a['analyses']:
        i,j=a['analyses'].index(p),b['analyses'].index(p)
        assert od['readings'][i]==nd['readings'][j],(location,'old assessment changed')
        if 'breakdowns' in old:
            assert old['breakdowns'][i]==new['breakdowns'][j]
    assert all(m in nd['lemmas'] for m in od['lemmas']),(location,'old dictionary owner lost')
    for i,p in enumerate(b['analyses']):
        if p in a['analyses']:continue
        assert 'ending.declarative_dao' in p['rules'],(location,p)
        inverse=copy.deepcopy(p);inverse['rules'].remove('ending.declarative_dao')
        m=inverse['morphemes'][-1]
        assert m['kind']=='ending' and m['form'] in ['다오','는다오']
        m['form']={'다오':'다고','는다오':'는다고'}[m['form']]
        assert b['normalized'].endswith('다오')
        parent=b['normalized'][:-1]+'고';parents.add(parent)
        owners=[next(m for m in nd['lemmas'] if m['lemma']==lemma) for lemma in p['lemmas']]
        added.append({'location':location,'surface':new['surface'],'span':new['span'],'analysis':p,'dictionary_assessment':nd['readings'][i],'dictionary_owners':owners,'parent_surface':parent,'exact_parent':inverse,'contextual_verdict':'unjudged','independent_review':'pending'})
    if 'spacing' in old:
        os,ns=old['spacing'],new['spacing']
        assert os['rule']==ns['rule'] and os['limits']==ns['limits']
        # Every old spacing option must survive with the same boundaries and
        # ordered segments; individual segment candidates may gain dao paths.
        keys=lambda h:(h['rule'],h['spaced'],tuple(h['inserted_at']))
        oldkeys=[keys(h) for h in os['alternatives']]
        assert [keys(h) for h in ns['alternatives'] if keys(h) in oldkeys]==oldkeys
        for h in os['alternatives']:
            nh=next(n for n in ns['alternatives'] if keys(n)==keys(h))
            assert {k:v for k,v in h.items() if k not in ['records','joined_contexts']}=={k:v for k,v in nh.items() if k not in ['records','joined_contexts']}
            for field in ['records','joined_contexts']:
                assert len(h.get(field,[]))==len(nh.get(field,[]))
                for index,(s,t) in enumerate(zip(h.get(field,[]),nh.get(field,[]),strict=True)):
                    added.extend(inspect(s,t,location+'/'+field+'/'+str(index)))
        assert all(keys(h) in oldkeys for h in ns['alternatives']),(location,'new spacing option requires separate review')
    return added

for previous in prior['comparisons']:
    source=Path(previous['source']);original=source.read_bytes();assert sha(source)==previous['source_sha256'];frozen[str(source)]=sha(source)
    mode=previous['mode'];flags=['--dict-compatible'] if 'compatible' in mode else ['--dict-only'] if 'headword' in mode else []
    commands=[[str(cli),'text',str(source),'--dictionary',str(DB),*flags,*(['--suggest-spacing'] if 'spacing' in mode else [])] for cli in [BEFORE,AFTER]]
    jobs=[subprocess.Popen(c,stdout=subprocess.PIPE,cwd=ROOT) for c in commands]
    hashes=[hashlib.sha256(),hashlib.sha256()];cursor=count=0;changes=[]
    try:
        for pair in itertools.zip_longest(*(p.stdout for p in jobs)):
            assert all(line is not None for line in pair);count+=1
            for digest,line in zip(hashes,pair,strict=True):digest.update(line)
            now=json.loads(pair[1]);span=now['span'];assert span['start']==cursor and original[cursor:span['end']].decode()==now['surface'];cursor=span['end']
            if pair[0]==pair[1]:continue
            old=json.loads(pair[0]);additions=inspect(old,now,'word')
            left=original.rfind(b'\n',0,span['start'])+1;right=original.find(b'\n',span['end']);right=len(original) if right<0 else right
            context=original[left:right].decode()
            changes.append({'record':count,'before':old,'after':now,'complete_original_line':context,'added_paths':len(additions)})
            for addition in additions:
                ident=hashlib.sha256(json.dumps([previous['source_sha256'],mode,count,addition],ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:24]
                observations.append({'id':'declarative-dao-broad-'+ident,'source':str(source),'source_sha256':previous['source_sha256'],'mode':mode,'record':count,'complete_original_line':context,**addition})
        codes=[p.wait() for p in jobs]
        assert codes==[0,0] and count==previous['records'] and cursor==len(original)
        assert hashes[0].hexdigest()==previous['after_jsonl_sha256'],(mode,'actual committed baseline differs')
    finally:
        for job in jobs:
            if job.poll() is None:job.terminate();job.wait()
    comparisons.append({'source':str(source),'source_sha256':sha(source),'mode':mode,'commands':commands,'exit_codes':codes,'records':count,'before_jsonl_sha256':hashes[0].hexdigest(),'after_jsonl_sha256':hashes[1].hexdigest(),'changed_frames':changes,'original_bytes_conserved':True})
    print(mode,count,'frames',len(changes),'changed',flush=True)
job=subprocess.run([str(BEFORE),'text','-'],input=('\n'.join(sorted(parents))+'\n').encode(),capture_output=True,check=True)
assert not job.stderr
companions={r['surface']:r['analysis'] for r in map(json.loads,job.stdout.splitlines()) if r.get('analysis')}
assert set(companions)==parents
for observation in observations:assert observation['exact_parent'] in companions[observation['parent_surface']]['analyses'],observation
assert len(comparisons)==8 and sum(r['records'] for r in comparisons)==1128312
assert len(observations)==len({o['id'] for o in observations})
assert all(sha(p)==digest for p,digest in frozen.items())
report={'state':'draft-complete-broad-preservation-passed','comparisons':comparisons,'individual_additions':observations,'actual_prior_companions':companions,'parent_stdout_sha256':hashlib.sha256(job.stdout).hexdigest(),'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Eight full current-release comparisons, all old local paths/assessments/display and spacing boundaries preserved; every addition has a stable ID, full source line and exact actual earlier reporting parent. Contextual judgments, complete Native-owner closure, release-package binding and independent review remain pending.','full_coverage_complete':False}
OUT.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print({'frames':1128312,'individual_additions':len(observations),'parents':len(parents)},flush=True)
