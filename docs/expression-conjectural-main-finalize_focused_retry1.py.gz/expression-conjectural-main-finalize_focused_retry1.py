"""Archive actual combined focused checks and preserve the independently tested sources."""
import gzip
import hashlib
import json
import re
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-expression-conjectural-main')
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
r = json.loads((PREP / 'focused.json').read_text())
assert r['state'] == 'passed' and all(r[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged'])
assert all(sha(path) == digest for path, digest in r['frozen_inputs'].items())
assert all(run['exit_code'] == 0 for run in r['runs'])
batches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (PREP / 'focused-1.log').read_text())
assert sum(int(b[1]) for b in batches) == 18 and all(b[0] == 'ok' and b[2] == '0' for b in batches)
controls = json.loads((PREP / 'python-controls.json').read_text())
assert controls['state'] == 'passed' and len(controls['runs']) == 5
counts = []
for i, run in enumerate(controls['runs']):
    log = PREP / ('python-controls-' + str(i) + '.log')
    assert run['exit_code'] == 0 and sha(log) == run['log_sha256']
    text = log.read_text()
    assert text.rstrip().endswith('OK')
    counts.append(int(re.search(r'Ran (\d+) tests', text)[1]))
assert counts == [16, 14, 8, 25, 10]
names = ['focused.json', 'focused-0.log', 'focused-1.log', 'focused-2.log', 'run_focused.py', 'python-controls.json', 'reconcile_branches.py', Path(__file__).name]
names += ['python-controls-' + str(i) + '.log' for i in range(5)]
for filename in names:
    target = WORK / 'docs' / ('expression-conjectural-main-' + filename + '.gz')
    if target.exists():
        assert gzip.decompress(target.read_bytes()) == (PREP / filename).read_bytes()
    else:
        target.write_bytes(gzip.compress((PREP / filename).read_bytes(), mtime=0))
tracker = WORK / 'docs/coverage-checklist.md'
text = tracker.read_text()
assert '  The [manual review ledger](inventory-reviews.json) records 513 scoped\n  dispositions; 202 entries await a disposition, including entries with\n' in text
old = '  **Partial: tested source/copula implementation and 41 authored cases are\n'
assert text.count(old) == 1
text = text.replace(old, '  **Partial: tested Source/copula/novel implementation and 56 authored cases are\n')
end = text.index('- [ ] **COV-018 —', text.index('- [ ] **COV-017cx —'))
note = '''  [Actual reconciled expression-only complete Rust](formal-volitional-expression-main-complete-expression-main-full-rust.json.gz)
  passes 1,153 tests, zero failures, one ignored and 248 batches at `b7a626b`,
  with every captured input, HEAD and index unchanged. That proof retains its
  expression-only scope. The [actual combined focused checks](expression-conjectural-main-focused.json.gz)
  now pass all 18 Source/copula/novel/expression/shared-ledger Rust tests,
  whole-project formatting and all-target web-feature Clippy with warnings
  denied. The [combined Python controls](expression-conjectural-main-python-controls.json.gz)
  pass 73 tests across the active ledger, both historical ledgers, installed
  evidence and review queue. The [active-ledger audit](../tools/expression_conjectural_ledger_audit.py)
  pins both complete historical ledgers, the complete original manual review
  snapshot, every original case/judgment/source field and all serialized
  expression-prefix bytes. Its 16 controls reject erased alternatives,
  expanded review scopes and invented dispositions. Both strict historical
  audit suites remain intact and continue to pass against their original
  archived ledgers; they also invoke the active combined audit. All three
  tools are selected and executed in Nix. Whole combined Rust, actual current
  Nix/installed/main checks, quiet performance and wider contextual/independent
  review remain pending.

'''
tracker.write_text(text[:end] + note + text[end:])
reviews_path = WORK / 'docs/inventory-reviews.json'
reviews = json.loads(reviews_path.read_text())
for review in reviews['entries']:
    if review['id'] in ['krdict:86083', 'krdict:86084']:
        review['evidence'].extend([{'path': 'tools/expression_conjectural_ledger_audit.py'},
                                  {'path': 'docs/expression-conjectural-main-focused.json.gz'}])
reviews_path.write_text(json.dumps(reviews, ensure_ascii=False, indent=2) + '\n')
from sys import path
path.insert(0, str(WORK / 'tools'))
import expression_conjectural_ledger_audit as active
active.inspect(active.inputs())
with (WORK / 'docs/inventory-review-queue.json').open('wb') as out:
    subprocess.run(['python3', 'tools/review_inventory.py', '--dictionary', '/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db'], cwd=WORK, stdout=out, check=True)
subprocess.run(['python3', 'tools/review_inventory.py', '--verify'], cwd=WORK, check=True, stdout=subprocess.DEVNULL)
print('Archived18focusedRust/73controls; every original ledger/review retained; combined queue verified', flush=True)
