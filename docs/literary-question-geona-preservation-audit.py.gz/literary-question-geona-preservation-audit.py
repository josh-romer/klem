"""Derive complete broad/corpus/history preservation and individually unjudged geona changes."""
import gzip,hashlib,json,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from friendly_command_corpora import outcome
sha=lambda raw:hashlib.sha256(raw).hexdigest();read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes())

def words_digest(words):return sha(json.dumps(words,ensure_ascii=False,sort_keys=True).encode())
def preserve(a,b):
 assert {k:v for k,v in a.items() if k!='analyses'}=={k:v for k,v in b.items() if k!='analyses'}
 assert [p for p in b['analyses'] if p in a['analyses']]==a['analyses']

def inspect(broad,corpus,history):
 before=read(ROOT/'docs/literary-future-kko-packaged-cli-replay.json')['cli_sha256'];after=read(Path('/tmp/klem-literary-question-geona-prototype-source-replay.json.gz'))['cli_sha256']
 for report in [broad,corpus,history]:
  assert report['inputs_unchanged'] is True and report['before_cli_sha256']==before and report['cli_sha256']==after
  assert sha(report['producer']['text'].encode())==report['producer']['sha256']
  assert report['contextual_verdict']=='unjudged' and report['independent_review']=='pending'
 original=read(ROOT/'docs/literary-future-kko-prototype-broad.json.gz');inputs=read(ROOT/'docs/literary-question-go-broad-inputs.json.gz')['sources'];derived=[]
 assert len(broad['comparisons'])==8 and sum(r['records'] for r in broad['comparisons'])==1128312
 assert broad['prior_capture_sha256']==sha((ROOT/'docs/literary-future-kko-prototype-broad.json.gz').read_bytes())
 for actual,old in zip(broad['comparisons'],original['comparisons'],strict=True):
  for k in ['source','source_sha256','mode','records']:assert actual[k]==old[k]
  assert actual['before_jsonl_sha256']==old['after_jsonl_sha256'] and actual['baseline_matches_previous_capture'] is True
  assert actual['exit_codes']==[0,0] and actual['original_bytes_conserved'] and actual['previous_spacing_suggestions_conserved']
  assert (actual['before_jsonl_sha256']==actual['after_jsonl_sha256'])==(not bool(actual['changed_frames']))
  raw=inputs[actual['source_sha256']]['text'].encode();assert sha(raw)==actual['source_sha256']
  for frame in actual['changed_frames']:
   a,b=frame['before'],frame['after'];preserve(a['analysis'],b['analysis'])
   for k in ['surface','span','kind']:assert a[k]==b[k]
   span=b['span'];assert raw[span['start']:span['end']].decode()==b['surface']
   for i,p in enumerate(a['analysis']['analyses']):assert a['dictionary']['readings'][i]==b['dictionary']['readings'][b['analysis']['analyses'].index(p)]
   assert all(v in b['dictionary']['lemmas'] for v in a['dictionary']['lemmas'])
   assert a.get('spacing')==b.get('spacing')
   left=raw.rfind(b'\n',0,span['start'])+1;right=raw.find(b'\n',span['end']);right=len(raw) if right<0 else right
   for p in b['analysis']['analyses']:
    if p in a['analysis']['analyses']:continue
    assert 'ending.literary_question_geona' in p['rules']
    ident=sha(json.dumps([actual['source_sha256'],actual['mode'],frame['record'],p],ensure_ascii=False,sort_keys=True).encode())[:24]
    derived.append({'id':'literary-question-geona-broad-'+ident,'source':actual['source'],'source_sha256':actual['source_sha256'],'mode':actual['mode'],'record':frame['record'],'surface':b['surface'],'span':span,'complete_original_line':raw[left:right].decode(),'analysis':p,'dictionary_assessment':b['dictionary']['readings'][b['analysis']['analyses'].index(p)],'source_entries':['krdict:80970','krdict:80972'],'structural_verdict':'unjudged broader composition','contextual_verdict':'unjudged','independent_review':'pending'})
 assert derived==broad['individual_additions'] and len(derived)==44 and len({o['id'] for o in derived})==44
 assert broad['individual_spacing_additions']==[]
 prior=read(ROOT/'docs/literary-future-kko-prototype-corpora.json.gz');assert corpus['before_words']==prior['after_words']
 for label in ['before','after']:assert words_digest(corpus[label+'_words'])==corpus[label+'_words_sha256']
 assert len(corpus['after_words'])==corpus['unique_surfaces']==32096 and corpus['converted_rows']==66570
 assert corpus['before_words']==corpus['after_words'] and corpus['changed_words']=={} and corpus['candidate_changes']==[]
 total=0
 for current,old in zip(corpus['corpora'],prior['corpora'],strict=True):
  for k in ['corpus','partition','source','source_sha256','original_source_text','original_converted_rows']:assert current[k]==old[k]
  assert sha(current['original_source_text'].encode())==current['source_sha256'];assert current['changed_gold_outcomes']==[]
  for actual,gold in zip(current['comparisons'],current['original_converted_rows'],strict=True):
   assert all(actual[k]==gold[k] for k in ['id','surface','expected']);paths=corpus['after_words'][gold['surface']]['analyses'];m,r,sets=outcome(gold['expected'],paths);expected={'matched':m,'recovered':r,'recovered_sets':sets,'candidates':len(paths)};assert actual['before']==actual['after']==expected
  counts=sorted(row['after']['candidates'] for row in current['comparisons']);n=len(counts)
  derived={'converted_rows':n,'grouped_matches':sum(row['after']['matched'] for row in current['comparisons']),'recovered_gold_lemmas':sum(row['after']['recovered'] for row in current['comparisons']),'gold_lemmas':sum(len(row['expected']) for row in current['comparisons']),'candidate_count_sum':sum(counts),'mean_candidates':sum(counts)/n,'p95_candidates':counts[min(n*95//100,n-1)],'max_candidates':max(counts)}
  total+=n;assert current['before_summary']==current['after_summary']==derived
 assert total==66570
 prior=read(ROOT/'docs/literary-future-kko-prototype-legacy-history-retry1.json.gz')
 assert set(prior['after_words'])<=set(history['before_words']) and all(history['before_words'][w]==v for w,v in prior['after_words'].items())
 assert all(history['source_files_sha256'][n]==h for n,h in prior['source_files_sha256'].items())
 assert len(history['source_files_sha256'])==58 and len(history['origins'])==history['surfaces']==21406
 assert history['before_words']==history['after_words'] and history['changed_words']==history['added_paths']==0 and history['individual_additions']==[] and history['changes']=={}
 for label in ['before','after']:assert words_digest(history[label+'_words'])==history[label+'_words_sha256']
 for word,origins in history['origins'].items():
  assert origins and word in history['after_words']
  for origin in origins:assert history['source_files_sha256'][origin['source']]==origin['source_sha256'] and origin['pointer']
 return {'broad_frames':1128312,'individual_unjudged_additions':44,'new_spacing_alternatives':0,'annotated_original_rows':66570,'corpus_surfaces':32096,'historical_surfaces':21406,'historical_sources':58,'changed_corpus_or_history_words':0,'precision_context_and_full_main':'pending'}

def inputs():return [read(Path('/tmp/klem-literary-question-geona-'+name+'.json.gz')) for name in ['prototype-broad','prototype-corpora','prototype-legacy-history']]
if __name__=='__main__':print(inspect(*inputs()))
