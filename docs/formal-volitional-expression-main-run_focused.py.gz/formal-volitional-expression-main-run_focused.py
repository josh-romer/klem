"""Validate the actual reconciled expression/main source while keeping Root frozen."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

WORK = Path('/tmp/klem-formal-expression-main')
PREP = Path(__file__).resolve().parent
OUT = PREP / 'focused.json'
assert not OUT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [WORK / name for name in ['Cargo.toml', 'Cargo.lock']]
for folder in ['src', 'tests', 'tools', 'web/src']:
    files.extend(p for p in (WORK / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
frozen = {str(p): sha(p) for p in files}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
index = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest()
commands = [['cargo', 'fmt', '--all', '--', '--check'],
            ['cargo', 'test', '--locked', '--offline', '--features', 'web', '--test', 'formal_volitional_expression', '--test', 'validity'],
            ['cargo', 'clippy', '--locked', '--offline', '--all-targets', '--features', 'web', '--', '-D', 'warnings']]
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/klem-formal-expression-main-target',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='4')
r = {'state': 'running', 'head': head, 'index_sha256': index, 'frozen_inputs': frozen, 'runs': [],
     'scope': 'Actual reconciled current-main/formal-expression source, exact35587priorcases+eightoriginalexpressions andall511manualinventoryreviews preserved. Wholeformat, threeexpression/fourgloballedgertests andalltargetweb-featureClippy. Source/test/fixture/tool/catalog/head/index frozen. Root remains unchanged for its Nix gate. Whole combined suite/newNix/main/timing andwiderreview remain separate.'}
OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
for ordinal, command in enumerate(commands):
    log = PREP / f'focused-{ordinal}.log'
    assert not log.exists()
    with log.open('xb') as stream:
        code = subprocess.run(command, cwd=WORK, env=env, stdout=stream, stderr=subprocess.STDOUT).returncode
    r['runs'].append({'command': command, 'exit_code': code, 'log_sha256': sha(log)})
    r['inputs_unchanged'] = all(sha(p) == digest for p, digest in frozen.items())
    r['head_unchanged'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == head
    r['index_unchanged'] = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest() == index
    OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
    print(command, code, 'frozen invariants', all(r[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged']), flush=True)
    if code or not all(r[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged']):
        r['state'] = 'failed'
        OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
        raise SystemExit(code or 1)
r.update(state='passed', exit_code=0, producer={'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))})
OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
