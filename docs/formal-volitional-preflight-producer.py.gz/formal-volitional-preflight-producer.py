"""Track a demonstrated inventory gap before any implementation or executable gold."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
PREP = ROOT / '.direnv/formal-volitional-prepared'
DOCS = ROOT / 'docs'
prepared = json.loads(gzip.decompress((PREP / 'source-preparation.json.gz').read_bytes()))
baseline = json.loads(gzip.decompress((PREP / 'latest-baseline-gap.json.gz').read_bytes()))
assert len(prepared['complete_groups']) == 17 and len(prepared['original_native_entries']) == 33
assert baseline['inputs_unchanged'] and baseline['exact_prior_baseline_records'] and len(baseline['runs']) == 102
assert all(r['lexical_target_matches'] == r['structural_target_matches'] == 0 for r in baseline['runs'])
ledger = (ROOT / 'tests/fixtures/validity.json').read_bytes()
reviews = (DOCS / 'inventory-reviews.json').read_bytes()
archives = {}
for name in ['source-preparation.json.gz', 'source-preparation.log', 'independent-source-proposals.json',
             'baseline-gap.json.gz', 'baseline-gap.log', 'latest-baseline-gap.json.gz',
             'latest-baseline-gap.log', 'prepare_original_sources.py',
             'capture_baseline_gaps.py', 'capture_latest_baseline.py']:
    raw = (PREP / name).read_bytes()
    target = 'formal-volitional-' + name + ('' if name.endswith('.gz') else '.gz')
    path = DOCS / target
    assert not path.exists(), target
    path.write_bytes(raw if name.endswith('.gz') else gzip.compress(raw, mtime=0))
    archives[target] = hashlib.sha256(path.read_bytes()).hexdigest()
tracker = DOCS / 'coverage-checklist.md'
text = tracker.read_text()
assert 'COV-017cw —' not in text
marker = '- [ ] **COV-018 —'
assert text.count(marker) == 1
paragraph = '''- [ ] **COV-017cw — Formal volitional -렵니다/-으렵니다 and -렵니까/-으렵니까.**
  **Missing: original-source preparation and independent targets preserved;
  implementation pending.** The four original owners (86548, 86549, 86604,
  86605) retain every sense, their separate short/full attachment notes and
  all 17 complete example groups, including multi-line dialogue. Statements
  express the speaker's intention; questions ask the listener's intention.
  [Source preparation](formal-volitional-source-preparation.json.gz) retains
  33 complete original Native owners and all lexical homonyms. Seventeen
  lexical and typed canonical targets were authored before any baseline
  probe. The [latest installed baseline](formal-volitional-latest-baseline-gap.json.gz)
  records 102 NFC/NFD/raw/headword/Compatible probes against the actual
  familiar-particle Nix package; all miss their independent lexical and
  morphological targets and exactly reproduce the earlier installed baseline.
  Morphological matching checks roles and forms without requiring a newly
  proposed rule name. These are source proposals, not passing gold or a
  scoped inventory disposition. Remaining: independent boundary authoring,
  implementation, source/Native/regression/corpus/browser checks, whole Rust,
  actual Nix/installed/main integration, quiet performance and wider review.

'''
tracker.write_text(text.replace(marker, paragraph + marker))
(DOCS / 'formal-volitional-preflight-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
assert (ROOT / 'tests/fixtures/validity.json').read_bytes() == ledger
assert (DOCS / 'inventory-reviews.json').read_bytes() == reviews
(PREP / 'preflight-archive.json').write_text(json.dumps({'state':'passed', 'archives':archives,
    'source_groups':17, 'original_native_owners':33, 'baseline_observations':102,
    'baseline_target_matches':0, 'main_ledger_unchanged':True, 'manual_reviews_unchanged':True}, indent=2)+'\n')
print('Recorded17original groups/33Native owners/102actual baseline gaps; no main code, ledger or review disposition changed')
