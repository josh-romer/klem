"""Retain raw browser timings; compare every semantic field and test the exception."""
import ast,gzip,hashlib,json,re
from pathlib import Path
P=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=P/'friendly-hortative-sena-latency-audit-retry5-preparation.json';assert not manifest.exists()
files={}
for name in ['friendly-hortative-sena-installed-audit-validation.json','friendly-hortative-sena-installed-audit-validation.log','friendly-hortative-sena-installed-continuation-retry4.json','friendly-hortative-sena-installed-continuation-retry4.log']:
 raw=(P/name).read_bytes();dest=P/('friendly-hortative-sena-latency-audit-retry5-original-'+name+'.gz')
 if dest.exists():assert gzip.decompress(dest.read_bytes())==raw
 else:dest.write_bytes(gzip.compress(raw,mtime=0))
 files[name]=dict(path=dest.name,source_sha256=sha(raw),archive_sha256=sha(dest.read_bytes()))
names=['friendly_hortative_sena_installed_audit_retry4.py','test_friendly_hortative_sena_installed_audit_retry4.py','validate_friendly_hortative_sena_installed_audit_retry4.py']
mapping={n:n.replace('_retry4.py','_retry5.py') for n in names};tokens={**mapping,**{n[:-3]:v[:-3] for n,v in mapping.items()}};pattern=re.compile(r'\b(?:'+'|'.join(re.escape(n) for n in sorted(tokens,key=len,reverse=True))+r')\b');new={}
for name in names:
 raw=(P/name).read_bytes();dest=P/('friendly-hortative-sena-latency-audit-retry5-original-'+name+'.gz')
 if dest.exists():assert gzip.decompress(dest.read_bytes())==raw
 else:dest.write_bytes(gzip.compress(raw,mtime=0))
 files[name]=dict(path=dest.name,source_sha256=sha(raw),archive_sha256=sha(dest.read_bytes()))
 text=pattern.sub(lambda m:tokens[m.group()],raw.decode())
 if name=='friendly_hortative_sena_installed_audit_retry4.py':
  text=text.replace('import json\n','import json\nimport math\n')
  old="    for key in ['exports','diagrams','spacingDiagrams','nativeEntries','policyDecisions','corpusDecisions']:\n        assert browser[key] == before[key], 'every independently audited original installed browser choice form Native export'"
  replacement="""    for key in ['exports','diagrams','spacingDiagrams','nativeEntries','policyDecisions','corpusDecisions']:
        if key == 'corpusDecisions':
            def semantic_rows(rows):
                projected=[]
                for row in rows:
                    elapsed=row['api']['elapsed_ms']
                    assert isinstance(elapsed,(int,float)) and not isinstance(elapsed,bool) and math.isfinite(elapsed) and elapsed>=0, 'valid captured corpus latency'
                    projected.append({**row,'api':{k:value for k,value in row['api'].items() if k!='elapsed_ms'}})
                return projected
            assert semantic_rows(browser[key]) == semantic_rows(before[key]), 'every independently audited original corpus semantic field'
        else:
            assert browser[key] == before[key], 'every independently audited original installed browser choice form Native export'"""
  assert text.count(old)==1;text=text.replace(old,replacement)
 if name=='test_friendly_hortative_sena_installed_audit_retry4.py':
  oldmethods={n.name:ast.dump(n) for n in next(c for c in ast.parse(raw).body if isinstance(c,ast.ClassDef) and c.name=='Controls').body if isinstance(n,ast.FunctionDef)}
  assert {n.name:ast.dump(n) for n in next(c for c in ast.parse(text).body if isinstance(c,ast.ClassDef) and c.name=='Controls').body if isinstance(n,ast.FunctionDef)}==oldmethods
  added='''    def test_corpus_latency_only_difference_remains_accepted(self):
        v=self.values.copy();v['browser']=copy.deepcopy(v['browser'])
        for row in v['browser']['corpusDecisions']:row['api']['elapsed_ms']=123.456
        audit.inspect_browser(v)

    def test_corpus_semantic_field_cannot_be_lost(self):
        def change(row):row['api'].pop(next(key for key in row['api'] if key!='elapsed_ms'))
        self.reject(audit.inspect_browser,('browser','corpusDecisions',0),change,'every independently audited original corpus semantic field')

    def test_corpus_invalid_latency_cannot_pass(self):
        self.reject(audit.inspect_browser,('browser','corpusDecisions',0,'api'),lambda api:api.update(elapsed_ms=-1),'valid captured corpus latency')

'''
  needle="if __name__=='__main__':";assert text.count(needle)==1;text=text.replace(needle,added+needle)
  after={n.name:ast.dump(n) for n in next(c for c in ast.parse(text).body if isinstance(c,ast.ClassDef) and c.name=='Controls').body if isinstance(n,ast.FunctionDef)};assert all(after[n]==v for n,v in oldmethods.items())
 if name=='validate_friendly_hortative_sena_installed_audit_retry4.py':
  text=text.replace('friendly-hortative-sena-installed-audit-validation.json','friendly-hortative-sena-installed-audit-validation-retry5.json').replace('friendly-hortative-sena-installed-audit-validation.log','friendly-hortative-sena-installed-audit-validation-retry5.log')
  text=text.replace('suite.countTestCases() == 40','suite.countTestCases() == 43').replace('result.testsRun == 40','result.testsRun == 43').replace('all40-independent-installed-controls','all43-independent-installed-controls')
 ast.parse(text);dest=P/mapping[name];dest.write_text(text);new[dest.name]=dict(sha256=sha(dest.read_bytes()))
manifest.write_text(json.dumps(dict(state='prepared-not-executed',originals=files,new_producers=new,all_original40_test_bodies_retained=True,added_controls=3,all_original_browser_outputs_unchanged=True,scope='Only measured corpus API elapsed_ms excluded from semantic comparison, consistent with existing whole API response comparison. Raw timings remain in both untouched original captures. Every other corpus decision and API field compared exactly; invalid timing rejected.'),indent=2)+'\n')
print('Preserved seven originals; all original40 test bodies retained; added3 timing-exception controls; no browser replay.')
