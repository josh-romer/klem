"""Replay complete original apprehensive examples and individually scoped cases with installed CLI."""
import gzip,hashlib,json,subprocess,unicodedata
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');OUT=Path(__file__).resolve().parent/'installed-finite.json.gz';assert not OUT.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
binding=ROOT/'.direnv/fear-lsera-prepared/installed-source-binding.json';package=read(binding);assert package['state']=='passed'
cli=Path(next(p for p in package['outputs'] if p.endswith('-klem-0.1.0')))/'bin/klem'
before=ROOT/'.direnv/fear-lsera-target/debug/klem';db=ROOT/'data/dictionaries/krdict/krdict.db'
source=ROOT/'.direnv/fear-lsera-integration/docs/fear-lsera-source-preparation.json.gz';prepared=read(source)
suites=[ROOT/'.direnv/fear-lsera-integration/tests/fixtures'/p for p in ['fear-lsera-validity.json']]
frozen={str(p):sha(p) for p in [binding,cli,before,db,source,*suites,Path(__file__)]};runs=[]
texts=[('complete-original-source',prepared['complete_source_text']),('all-individual-cases',' '.join(c['surface'] for p in suites for c in read(p)['cases']))]
for family,text in texts:
 for encoding in ['NFC','NFD']:
  original=unicodedata.normalize(encoding,text).encode()
  for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
   uncached=None
   for cache in ['0','4096']:
    outputs=[];commands=[]
    for binary in [before,cli]:
     command=[str(binary),'text','-','--dictionary',str(db),*flags,'--cache-bytes',cache];job=subprocess.run(command,input=original,capture_output=True,check=True,cwd=ROOT);assert not job.stderr
     rows=[json.loads(line) for line in job.stdout.splitlines()];cursor=0
     for row in rows:
      assert row['span']['start']==cursor;cursor=row['span']['end'];assert original[row['span']['start']:cursor].decode()==row['surface']
     assert cursor==len(original);outputs.append(job.stdout);commands.append(command)
    assert outputs[0]==outputs[1],'installed complete finite output differs'
    if uncached is None:uncached=outputs[1]
    else:assert uncached==outputs[1],'cache output differs'
    runs.append({'family':family,'encoding':encoding,'mode':mode,'cache_bytes':int(cache),'commands':commands,'input_sha256':hashlib.sha256(original).hexdigest(),'jsonl':outputs[1].decode(),'jsonl_sha256':hashlib.sha256(outputs[1]).hexdigest(),'records':len(outputs[1].splitlines()),'exit_codes':[0,0],'original_bytes_conserved':True,'exact_previous_and_installed':True})
    print(family,encoding,mode,cache,len(outputs[1].splitlines()),'exact installed frames',flush=True)
assert len(runs)==24 and all(sha(p)==h for p,h in frozen.items())
r={'state':'passed','runs':runs,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'All25complete original ending groups plus46 independently authored Source/attachment/prefinal cases, actual prototype and committed installed CLI, NFC/NFD, raw/headword/Compatible and uncached/cached. Complete frames include Native owners and assessments; all source bytes conserved. Contextual/independent judgments and large distributions remain separate.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
