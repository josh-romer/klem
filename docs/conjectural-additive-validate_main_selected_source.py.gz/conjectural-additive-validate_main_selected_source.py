"""Run new audits from the actual clean Git-backed Nix inventory source."""
import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
RESULT = OUT / 'main-selected-source.json'
assert not RESULT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head.startswith('8cb5a69')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
index = subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT)
introduced = subprocess.check_output(['git', 'show', '--pretty=', '--name-only', head], cwd=ROOT, text=True).splitlines()
selected = [name for name in introduced if name != 'flake.nix']
assert len(selected) == 21
frozen = {name: sha(ROOT / name) for name in introduced}
command = ['nix', 'eval', '--offline', '--raw', 'git+file://' + str(ROOT) + '#checks.x86_64-linux.inventory-review.src']
source = Path(subprocess.check_output(command, cwd=ROOT, text=True).strip())
assert all((source / name).read_bytes() == (ROOT / name).read_bytes() for name in selected)
runs = []
for i, argv in enumerate([
    ['python3', 'tools/conjectural_additive_source_audit.py'],
    ['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_conjectural_additive_source_audit.py'],
]):
    log = OUT / f'main-selected-audit-{i}.log'
    assert not log.exists()
    with log.open('xb') as stream:
        job = subprocess.run(argv, cwd=source, stdout=stream, stderr=subprocess.STDOUT)
    runs.append({'command': argv, 'exit_code': job.returncode, 'log_sha256': sha(log)})
    assert job.returncode == 0
assert all(sha(ROOT / name) == digest for name, digest in frozen.items())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == head
assert subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT) == index
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
receipt = {'state': 'actual-main-selected-source-audits-passed', 'head': head,
           'source': str(source), 'command': command, 'selected_files': selected,
           'frozen_inputs': frozen, 'inputs_unchanged': True, 'head_index_status_unchanged': True,
           'runs': runs, 'controls': 13,
           'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)},
           'scope': 'All21selectednewfiles exactly match the clean committed Git-backed Nix inventory source. OriginalSource/Native/before-stream audit and13controls run successfully from that actual selected source. This does not run the entire inventory gate, build the runtime, implement the new family or supply linguistic judgments.'}
RESULT.write_text(json.dumps(receipt, indent=2) + '\n')
print('Verified21actual selected files and audit+13controls from committed Nix inventory source.')
