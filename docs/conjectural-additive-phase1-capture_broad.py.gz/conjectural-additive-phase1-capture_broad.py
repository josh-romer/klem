"""Stream full frozen candidate/novel inputs and retain every changed frame."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = PREP.parents[1]
REFERENCE = ROOT / '.direnv/formal-volitional-expression-prepared/installed-source-binding.json'
BASELINE = ROOT / '.direnv/formal-volitional-expression-integration/docs/formal-volitional-broad.json.gz'
INPUTS = ROOT / '.direnv/dapnikka-integration/docs/reported-deoni-broad-inputs.json.gz'
DB = ROOT / 'data/dictionaries/krdict/krdict.db'
AFTER = Path('/tmp/klem-conjectural-additive-target/debug/klem')
OUT = PREP / 'broad.json.gz'
PROGRESS = PREP / 'broad-progress.json'
assert not OUT.exists() and not PROGRESS.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
binding = json.loads(REFERENCE.read_bytes())
assert binding['state'] == 'passed'
BEFORE = Path(next(p for p in binding['outputs'] if p.endswith('-klem-0.1.0'))) / 'bin/klem'
baseline = json.loads(gzip.decompress(BASELINE.read_bytes()))
inputs = json.loads(gzip.decompress(INPUTS.read_bytes()))
frozen = {str(p): sha(p) for p in [REFERENCE, BASELINE, INPUTS, DB, BEFORE, AFTER, Path(__file__)]}
runs = []
PROGRESS.write_text(json.dumps({'state': 'running', 'completed_streams': 0, 'frozen_inputs': frozen}, indent=2) + '\n')
for capture in baseline['comparisons']:
    original_source = capture['source']
    source = ROOT / '.direnv/reported-installed-validation/broad-inputs' / Path(original_source).name
    original = inputs['sources'][original_source]['text'].encode()
    assert source.read_bytes() == original and sha(source) == capture['source_sha256']
    frozen[str(source)] = sha(source)
    mode = capture['mode']
    flags = ['--dict-compatible'] if 'compatible' in mode else ['--dict-only'] if 'headword' in mode else []
    commands = [[str(binary), 'text', str(source), '--dictionary', str(DB), *flags,
                 *(['--suggest-spacing'] if 'spacing' in mode else [])] for binary in [BEFORE, AFTER]]
    processes = [subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE) for command in commands]
    digests = [hashlib.sha256(), hashlib.sha256()]
    changed = []
    count = cursor = preserved = additions = 0
    try:
        for before_line in processes[0].stdout:
            after_line = processes[1].stdout.readline()
            assert after_line, 'new stream ended before original'
            for digest, line in zip(digests, [before_line, after_line], strict=True):
                digest.update(line)
            old, new = json.loads(before_line), json.loads(after_line)
            assert all(old[key] == new[key] for key in ['surface', 'span', 'kind']), 'original token ownership'
            assert new['span']['start'] == cursor
            cursor = new['span']['end']
            assert original[new['span']['start']:cursor].decode() == new['surface']
            old_paths = (old.get('analysis') or {}).get('analyses', [])
            new_paths = (new.get('analysis') or {}).get('analyses', [])
            for old_index, path in enumerate(old_paths):
                assert path in new_paths, ('lost original candidate', mode, new['surface'], path)
                new_index = new_paths.index(path)
                assert old['dictionary']['readings'][old_index] == new['dictionary']['readings'][new_index], ('changed original Native assessment', mode, new['surface'])
                preserved += 1
            new_only = [path for path in new_paths if path not in old_paths]
            assert all('ending.conjectural_additive' in path['rules'] for path in new_only), ('unrelated candidate addition', mode, new['surface'])
            additions += len(new_only)
            if old != new:
                start, end = new['span']['start'], new['span']['end']
                line_start = original.rfind(b'\n', 0, start) + 1
                line_end = original.find(b'\n', end)
                if line_end < 0:
                    line_end = len(original)
                changed.append({'id': f"conjectural-additive-broad-{mode}-{start}-{end}",
                                'record_index': count, 'before': old, 'after': new,
                                'new_paths': new_only, 'complete_original_line': original[line_start:line_end].decode(),
                                'line_byte_start': line_start, 'contextual_verdict': 'unjudged'})
            count += 1
        assert not processes[1].stdout.readline(), 'new stream has extra tokens'
        codes = [process.wait() for process in processes]
    finally:
        for process in processes:
            if process.poll() is None:
                process.terminate()
                process.wait()
    assert codes == [0, 0] and count == capture['records'] and cursor == len(original)
    assert digests[0].hexdigest() == capture['after_jsonl_sha256'], 'actual bound parent must reproduce every original output byte'
    runs.append({'source': original_source, 'actual_source': str(source), 'source_sha256': sha(source),
                 'mode': mode, 'commands': commands, 'exit_codes': codes, 'records': count,
                 'before_jsonl_sha256': digests[0].hexdigest(), 'after_jsonl_sha256': digests[1].hexdigest(),
                 'original_bytes_conserved': True, 'original_paths_preserved': preserved,
                 'new_family_paths': additions, 'changed_frames': changed})
    PROGRESS.write_text(json.dumps({'state': 'running', 'completed_streams': len(runs),
                                   'completed_records': sum(run['records'] for run in runs),
                                   'changed_frames': sum(len(run['changed_frames']) for run in runs),
                                   'frozen_inputs': frozen}, indent=2) + '\n')
    print(mode, count, 'complete frames;', len(changed), 'changed frames;', additions, 'new candidates', flush=True)
assert len(runs) == 8 and sum(run['records'] for run in runs) == 1128312
assert all(sha(path) == digest for path, digest in frozen.items())
report = {'state': 'complete-broad-candidate-comparison-passed', 'runs': runs,
          'frozen_inputs': frozen, 'inputs_unchanged': True,
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
          'scope': 'All1128312originalframes/eight candidate/novel/default-dictionary/filter/spacing streams compared with the actual bound parent Nix CLI. Every original byte/candidate/Native assessment remains. Every differing complete record and original full line has an individual ID; new candidates carry only the new family rule and remain contextually unjudged. Changed spacing/display fields are captured but require independent review. Independent broad audit, gold rows, ledger, newNix/main/performance and contextual Korean review remain required.'}
OUT.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
PROGRESS.write_text(json.dumps({'state': report['state'], 'completed_streams': 8, 'completed_records': 1128312,
                               'inputs_unchanged': True, 'changed_frames': sum(len(run['changed_frames']) for run in runs)}, indent=2) + '\n')
print('Passed all1128312originalframes; every changed record retained', flush=True)
