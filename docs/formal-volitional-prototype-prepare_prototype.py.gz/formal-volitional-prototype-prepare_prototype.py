"""Prepare a focused prototype and explicit raw/dictionary evaluation policy."""
import gzip
import hashlib
import json
import shutil
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
PARENT = BASE / 'fear-lsera-prototype'
ROOT = BASE / 'formal-volitional-prototype'
PREP = BASE / 'formal-volitional-prepared'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert not ROOT.exists()
reconciliation = json.loads((BASE / 'fear-lsera-prepared/installed-parent-reconciliation.json').read_text())
assert reconciliation['state'] == 'passed'
suite = json.loads((PREP / 'formal-volitional-validity.json').read_text())
authored = json.loads((PREP / 'independent-authoring.json').read_text())
assert sha((PREP / 'formal-volitional-validity.json').read_bytes()) == authored['suite_sha256']
dictionary_cases = [c['id'] for c in suite['cases']
                    if any(c['id'].endswith('-forbidden-' + suffix)
                           for suffix in ['adjective', 'honorific-adjective', 'negative-copula'])]
assert len(dictionary_cases) == 6
policy = {
    'state': 'evaluation-policy-authored-before-implementation-and-prototype-observation',
    'authored_suite_sha256': authored['suite_sha256'], 'dictionary_required_case_ids': dictionary_cases,
    'raw_cases': 53, 'raw_required': 33, 'raw_forbidden': 20,
    'dictionary_cases': 59, 'dictionary_required': 33, 'dictionary_forbidden': 26,
    'scope': 'All authored targets, verdicts, roles and source identities remain unchanged. The six adjective/negative-copula POS judgments require the complete original dictionary owners. The dictionary-free engine does not know general lexical POS and may enumerate unknown predicate hypotheses. All 59 judgments are evaluated through dictionary compatibility, while all 53 spelling/prefinal/copular structure cases are independently checked on raw output. This is a layer distinction, not a changed linguistic verdict. Full historical restoration, whole Rust, Nix/installed/main integration and wider review remain required.',
}
(PREP / 'evaluation-policy.json').write_text(json.dumps(policy, indent=2) + '\n')
selected = ['Cargo.toml', 'Cargo.lock', 'tools/validity.rs']
for directory in ['src', 'examples', 'web/src']:
    selected.extend(str(p.relative_to(PARENT)) for p in (PARENT / directory).rglob('*') if p.is_file())
frozen = {name: sha((PARENT / name).read_bytes()) for name in selected}
for name in selected:
    target = ROOT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(PARENT / name, target)
assert all(sha((PARENT / name).read_bytes()) == digest == sha((ROOT / name).read_bytes()) for name, digest in frozen.items())
fixtures = ROOT / 'tests/fixtures'
fixtures.mkdir(parents=True)
shutil.copyfile(PREP / 'formal-volitional-validity.json', fixtures / 'formal-volitional-validity.json')
closure = json.loads(gzip.decompress((PREP / 'authored-native-closure.json.gz').read_bytes()))
for name, value in [
    ('formal-volitional-native.json', {'LexicalResource': {'Lexicon': {'LexicalEntry': list(closure['original_native_entries'].values())}}}),
    ('formal-volitional-native-entries.json', closure['entries']),
    ('formal-volitional-evaluation-policy.json', policy),
]:
    (fixtures / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
prepared = json.loads(gzip.decompress((PREP / 'source-preparation.json.gz').read_bytes()))
baseline = json.loads(gzip.decompress((PREP / 'latest-baseline-gap.json.gz').read_bytes()))
proposals = []
for original in prepared['independent_proposals']:
    proposal = dict(original)
    proposal['baseline_records'] = {
        mode: {'analysis': next(r['record'] for r in baseline['runs']
                               if (r['id'], r['encoding'], r['mode']) == (proposal['id'], 'NFC', mode))}
        for mode in ['raw', 'headword', 'compatible']
    }
    proposals.append(proposal)
(fixtures / 'formal-volitional-proposals.json').write_text(json.dumps(proposals, ensure_ascii=False, indent=2) + '\n')
(PREP / 'prototype-preparation.json').write_text(json.dumps({
    'state': 'prepared', 'parent_inputs_copied': frozen, 'parent_inputs_unchanged': True,
    'source_groups': 17, 'authored_cases': 59, 'complete_native_owners': 43,
    'scope': 'Separate minimal focused-test prototype from stable apprehensive source bytes. No running Nix inputs changed. Complete historical parent restoration and all additional checklist gates remain required.',
}, indent=2) + '\n')
print('Prepared', len(selected), 'exact parent inputs; all 59 unchanged judgments and 43 Native owners preserved', flush=True)
