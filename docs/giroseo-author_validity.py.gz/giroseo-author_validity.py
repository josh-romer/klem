"""Author finite concessive source/marker boundaries independently of engine output."""
import gzip,json
from pathlib import Path
OUT=Path(__file__).resolve().parent;prepared=json.loads(gzip.decompress((OUT/'source-preparation.json.gz').read_bytes()))
proposals=json.loads((OUT/'authored-proposals.json').read_bytes());sources={f'giroseo-{ident.split(":")[1]}':owner['url'] for ident,owner in prepared['expression_entries'].items()};cases=[]
def add(ident,surface,lemmas,morphs,verdict,source,reason):
 cases.append({'id':ident,'surface':surface,'judgments':[{'id':'path','lemmas':lemmas,'lemma_kinds':['nominal','copula'] if len(lemmas)==2 else ['predicate'],'morphemes':morphs,'morpheme_kinds':['prefinal']*(len(morphs)-1)+['ending'],'required_rules':['ending.concessive_giroseo'],'verdict':verdict,'source':source,'reason':reason}]})
for p in proposals:add(p['id'],p['surface'],p['proposed_lemmas'],p['proposed_morphemes'],'required','giroseo-'+p['source_entry_id'].split(':')[1],'Independently read structural target from the complete original dictionary group; no contextual sense choice or independent precision certification.')
for ending,source in [('기로서','giroseo-83919'),('기로서니','giroseo-83918')]:
 for label,stem,lemma,markers in [('open-verb','가','가다',[]),('consonant-verb','먹','먹다',[]),('rieul-verb','살','살다',[]),('adjective','좋','좋다',[]),('past','먹었','먹다',['었']),('modal','먹겠','먹다',['겠']),('honorific','먹으시','먹다',['시']),('honorific-past','먹으셨','먹다',['시','었']),('past-modal','먹었겠','먹다',['었','겠']),('negative-copula','아니','아니다',[])]:
  add('giroseo-boundary-'+ending+'-'+label,stem+ending,[lemma],markers+[ending],'required',source,'Finite agent-authored class and immediate marker path within the source attachment note. The note excludes -더- and -으리-; other untested sequences stay outside this judgment scope.')
 for label,stem,lemmas,markers in [('nominal-copula','학생이',['학생','이다'],[]),('copular-honorific','학생이시',['학생','이다'],['시']),('copular-past','학생이었',['학생','이다'],['었'])]:
  add('giroseo-boundary-'+ending+'-'+label,stem+ending,lemmas,markers+[ending],'required',source,'Source explicitly licenses 이다; preserve explicit nominal/copula roles and canonical marker order without selecting a lexical homonym.')
 for label,stem,lemma,markers in [('retrospective','먹더','먹다',['더']),('retrospective-after-past','먹었더','먹다',['었','더']),('conjectural','먹으리','먹다',['으리']),('conjectural-after-past','먹었으리','먹다',['었','으리'])]:
  add('giroseo-boundary-'+ending+'-'+label,stem+ending,[lemma],markers+[ending],'forbidden',source,'Named canonical path violates the original attachment note excluding -더-/-으리-. This judgment does not prohibit other lexical analyses of the surface.')
 for label,stem,lemmas,markers in [('copular-retrospective','학생이더',['학생','이다'],['더']),('copular-conjectural','학생이으리',['학생','이다'],['으리']),('copular-conjectural-vowel','학생이리',['학생','이다'],['으리'])]:
  add('giroseo-boundary-'+ending+'-'+label,stem+ending,lemmas,markers+[ending],'forbidden',source,'The same explicit retrospective/conjectural exclusion applies at the immediately represented copular owner; unrelated alternatives remain unjudged.')
assert len(cases)==48 and len({c['id'] for c in cases})==48
suite={'schema_version':1,'review_status':'Agent-authored finite original source and immediate-boundary judgments prepared before implementation. Source note wider ending distributions, contextual sense/precision and independent Korean review remain open. No emitted candidates used as gold.','sources':sources,'cases':cases}
(OUT/'authored-validity.json').write_text(json.dumps(suite,ensure_ascii=False,indent=2)+'\n')
print('Authored48source/marker cases independently:',{v:sum(j['verdict']==v for c in cases for j in c['judgments']) for v in ['required','forbidden']},flush=True)
