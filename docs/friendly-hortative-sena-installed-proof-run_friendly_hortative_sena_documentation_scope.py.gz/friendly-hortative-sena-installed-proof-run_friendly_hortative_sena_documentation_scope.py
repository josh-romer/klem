"""Add the omitted original doctest and derive default release versus all-target scope."""
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
OUT = P / 'friendly-hortative-sena-documentation-scope.json'
LOG = P / 'friendly-hortative-sena-documentation-scope.log'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=W)


def main():
    assert not OUT.exists() and not LOG.exists()
    original_path = P / 'friendly-hortative-sena-full-rust-serial-retry.json'
    original = json.loads(original_path.read_bytes())
    old_log = (P / 'friendly-hortative-sena-full-rust-serial-retry.log').read_bytes()
    assert original['state'] == 'passed' and sha(old_log) == original['log_sha256']
    sys.path.insert(0, str(P.parent / 'willingness-question-prepared'))
    import audit_friendly_command_gena_promotion_full_rust as inventory_audit
    inventory_audit.W = W  # Same complete-inventory algorithm, explicit Sena manifest root.
    complete = inventory_audit.inspect_commands(original, old_log)
    assert complete['targets'] == 262 and complete['commands'] == 266
    gate_path = P / 'friendly-hortative-sena-complete-nix-gate.json'
    gate = json.loads(gate_path.read_bytes())
    assert gate['head'] == git('rev-parse', 'HEAD').decode().strip()
    assert sha(git('ls-files', '--stage', '-z')) == gate['index_sha256']
    assert all(original['frozen_inputs'][name] == digest for name, digest in gate['profiles']['klem']['files'].items()), 'all original tested Rust inputs exactly preserved'
    assert all(sha((W / name).read_bytes()) == digest for name, digest in gate['frozen_inputs'].items())
    protected = gate['protected_binaries']
    assert len(protected) == 6 and all(sha(Path(name).read_bytes()) == digest for name, digest in protected.items())
    examples = [row for row in complete['summaries'] if row['kind'] == ['example']]
    assert len(examples) == 6 and all(row['passed'] == row['failed'] == row['ignored'] == 0 for row in examples)
    r = dict(state='running', head=gate['head'], index_sha256=gate['index_sha256'], frozen_inputs=gate['frozen_inputs'],
             protected_binaries=protected, original_serial_receipt_sha256=sha(original_path.read_bytes()),
             original_serial_log_sha256=sha(old_log), complete_original_inventory_audit=complete,
             producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
             started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             scope='Independent full original262-target/266-command audit plus actual previously omitted lib.rs doctest. Same current e443 source closures and six protected binaries. Derives default cargo test release scope by excluding six zero-test example targets and including the original doctest. No current package/release/Nix/installed/browser/main/timing/context/register/Korean review completion claim.')
    def save(): OUT.write_text(json.dumps(r, indent=2) + '\n')
    save()
    try:
        env = dict(os.environ, **original['environment_overrides'])
        command = ['cargo', 'test', '--locked', '--offline', '--features', 'web', '--doc']
        r['command'] = command; save()
        with LOG.open('xb') as log:
            log.write(('COMMAND ' + json.dumps(command) + '\n').encode()); log.flush()
            job = subprocess.run(command, cwd=W, env=env, stdout=log, stderr=subprocess.STDOUT)
            r['exit_code'] = job.returncode
            assert job.returncode == 0
        text = LOG.read_text()
        batches = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, flags=re.M)
        assert batches == [('ok', '1', '0', '0')] and 'test src/lib.rs - (line 3) ... ok' in text
        combined = {key: complete['totals'][key] + (1 if key == 'passed' else 0) for key in ['passed', 'failed', 'ignored']}
        r.update(state='passed', documentation_totals=dict(passed=1, failed=0, ignored=0), documentation_batches=1,
                 combined_all_target_and_documentation_totals=combined,
                 combined_all_target_and_documentation_batches=complete['batches'] + 1,
                 expected_default_release_totals=combined, expected_default_release_batches=complete['batches'] - len(examples) + 1,
                 excluded_zero_test_example_targets=[row['target'] for row in examples])
    except BaseException as error:
        r.update(state='failed', error=repr(error)); raise
    finally:
        r.update(inputs_unchanged=all(sha((W / name).read_bytes()) == digest for name, digest in gate['frozen_inputs'].items()),
                 head_unchanged=git('rev-parse', 'HEAD').decode().strip() == gate['head'],
                 index_unchanged=sha(git('ls-files', '--stage', '-z')) == gate['index_sha256'],
                 protected_binaries_unchanged=all(sha(Path(name).read_bytes()) == digest for name, digest in protected.items()),
                 original_receipt_and_log_unchanged=sha(original_path.read_bytes()) == r['original_serial_receipt_sha256'] and sha((P / 'friendly-hortative-sena-full-rust-serial-retry.log').read_bytes()) == r['original_serial_log_sha256'],
                 log_sha256=sha(LOG.read_bytes()) if LOG.exists() else None,
                 finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
        if not all(r[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged', 'original_receipt_and_log_unchanged']): r['state'] = 'failed'
        save()
    assert r['state'] == 'passed'
    print('Sena original doctest passed. Combined full Rust:', combined, '; default release expectation:', r['expected_default_release_batches'], 'batches.', flush=True)


if __name__ == '__main__': main()
