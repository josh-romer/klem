"""Keep actual146 sandbox result and full available original failure/retry artifacts."""
import gzip,hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent/'friendly-hortative-sena';D=W/'docs'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda n:json.loads((P/n).read_bytes())
r=read('friendly-hortative-sena-sandbox-controls-retry2.json');failed=read('friendly-hortative-sena-sandbox-controls.json')
assert r['state']=='passed' and r['exit_code']==0 and r['controls']==146 and r['actual_sandbox_host_executables_absent']
assert failed['state']=='failed' and failed['exit_code']==1 and failed['controls']==0
assert r['frozen_inputs']==failed['frozen_inputs'] and r['profiles']==failed['profiles']
for receipt in [r,failed]:
 assert all(receipt[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged'])
assert all(sha((W/n).read_bytes())==d for n,d in r['frozen_inputs'].items())
assert r['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
assert r['index_sha256']==sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))
assert {k:len(v['files']) for k,v in r['profiles'].items()}=={'klem':1158,'corpus-adapter':1158,'web-assets':18}
assert r['nix_expression']==failed['nix_expression']
assert r['log_sha256']==sha((P/'friendly-hortative-sena-sandbox-controls-retry2.log').read_bytes())
assert failed['log_sha256']==sha((P/'friendly-hortative-sena-sandbox-controls.log').read_bytes())
assert 'No such file or directory' in (P/'friendly-hortative-sena-sandbox-controls.log').read_text()
assert read('friendly-hortative-sena-sandbox-retry1.json')['state']=='failed'
names=['run_friendly_hortative_sena_sandbox_controls.py','friendly-hortative-sena-sandbox-controls.nix',
 'friendly-hortative-sena-sandbox-first-preflight-failure.json','run_friendly_hortative_sena_sandbox_retry1.py',
 'friendly-hortative-sena-sandbox-retry1.json','friendly-hortative-sena-sandbox-retry1.log',
 'friendly-hortative-sena-sandbox-controls.json','friendly-hortative-sena-sandbox-controls.log',
 'run_friendly_hortative_sena_sandbox_controls_retry2.py','friendly-hortative-sena-sandbox-controls-retry2.json',
 'friendly-hortative-sena-sandbox-controls-retry2.log',Path(__file__).name]
files={}
for name in names:
 raw=(P/name).read_bytes();path='friendly-hortative-sena-sandbox-proof-'+name+'.gz';assert not (D/path).exists()
 packed=gzip.compress(raw,mtime=0);(D/path).write_bytes(packed);files[name]=dict(path=path,source_sha256=sha(raw),archive_sha256=sha(packed))
o=D/'friendly-hortative-sena-sandbox-proof-archive.json';assert not o.exists()
o.write_text(json.dumps(dict(state='actual-current-Sena-Nix-sandbox146-passed',files=files,source_head=r['head'],source_files=len(r['frozen_inputs']),controls=146,compiled_profile_counts={'klem':1158,'corpus-adapter':1158,'web-assets':18},all_six_host_executables_actually_absent=True,binary_evidence_mode='captured',live_executable_files_verified=False,original_preflight_disk_failure_retained_as_observation=True,original_offline_dependency_failure_retained_complete=True,actual_retry_used_unchanged_Nix_expression=True,shared_cases_reviews_changed=False,full_coverage_complete=False,remaining='Historical inventory Source adapters, complete four Nix checks/packages/installed/browser audits, shared promotion/main/timing/context/register/Korean review.'),indent=2)+'\n')
print('Archived',len(files),'full available sandbox originals;',sha(o.read_bytes()),flush=True)
