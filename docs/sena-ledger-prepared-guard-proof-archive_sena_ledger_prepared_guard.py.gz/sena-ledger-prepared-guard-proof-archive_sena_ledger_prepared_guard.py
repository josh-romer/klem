"""Keep the prepared complete-tail proof and its original failed attempt."""
import gzip
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parent
OUT = P / 'sena-ledger-prepared-guard-proof-archive.json'
assert not OUT.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
r = json.loads((P / 'sena-ledger-prepared-guard-controls.json').read_bytes())
assert r['state'] == 'passed' and r['controls'] == 30 and not r['actual_shared_promotion']
assert all(r[k] for k in ('source_unchanged', 'head_unchanged', 'index_unchanged', 'prepared_inputs_unchanged'))
assert len(r['results']) == 2 and all(row['exit_code'] == 0 for row in r['results'])
assert all(sha((P / name).read_bytes()) == digest for name, digest in r['prepared_inputs'].items())
assert sha((P / 'sena-ledger-prepared-guard-controls.log').read_bytes()) == r['log_sha256']
assert r['producer'] == dict(text=(P / 'validate_sena_ledger_prepared_guard.py').read_text(),
                           sha256=sha((P / 'validate_sena_ledger_prepared_guard.py').read_bytes()))
failed = json.loads((P / 'sena-ledger-prepared-first-failure.json').read_bytes())
assert failed['state'] == 'failed' and failed['failures'] == 2 and failed['exit_code'] == 1
names = list(r['prepared_inputs']) + [
    'validate_sena_ledger_prepared_guard.py', 'sena-ledger-prepared-guard-controls.json',
    'sena-ledger-prepared-guard-controls.log', 'sena-ledger-prepared-first-failure.json',
    'sena-ledger-prepared-first-failure.log', 'archive_sena_ledger_prepared_guard.py']
for name, row in failed['files'].items():
    path = Path(row['path']); packed = path.read_bytes()
    assert sha(packed) == row['archive_sha256'] and sha(gzip.decompress(packed)) == row['source_sha256']
    names.append(path.name)
files = {}
for name in names:
    raw = (P / name).read_bytes(); packed = gzip.compress(raw, mtime=0)
    target = P / ('sena-ledger-prepared-guard-proof-' + name + '.gz')
    assert not target.exists(); target.write_bytes(packed)
    assert gzip.decompress(target.read_bytes()) == raw
    files[name] = dict(path=target.name, source_sha256=sha(raw), archive_sha256=sha(packed), bytes=len(raw))
OUT.write_text(json.dumps(dict(state='prepared30-controls-passed-original-failure-retained', files=files,
                              controls=30, original_draft_controls=12, new_complete_tail_controls=18,
                              actual_shared_promotion=False, full_coverage_complete=False,
                              first_failed_log_origin='Exact terminal tool output transcribed after completion; original failed producer and test bytes also retained.',
                              scope='Prepared draft and actual-input guard only. No active shared append, new runtime, current Nix or main integration claim.'),
                          indent=2) + '\n')
print(json.dumps(dict(files=len(files), manifest_sha256=sha(OUT.read_bytes()))), flush=True)
