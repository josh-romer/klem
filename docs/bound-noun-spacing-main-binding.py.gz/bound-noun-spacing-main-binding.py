"""Bind integrated Root bytes and actual current flake outputs to the tested package."""
import gzip,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');PROOF=Path('/tmp/klem-bound-noun-spacing-installed-sources.json.gz');PACKAGE=Path('/tmp/klem-bound-noun-spacing-nix.json');OUT=Path('/tmp/klem-bound-noun-spacing-main-binding.json');assert not OUT.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=json.load(gzip.open(PROOF,'rt'));package=json.loads(PACKAGE.read_bytes());assert proof['state']==package['state']=='passed' and package['exit_code']==0
files=proof['snapshot_files'];assert len(files)==973
for name,record in files.items():
 p=ROOT/name;assert p.is_file() and not p.is_symlink();assert sha(p)==record['sha256'] and p.stat().st_size==record['bytes'],name
command=['nix','eval','--impure','--offline','--file','/tmp/klem-predicate-auxiliary-spacing-combined-checks.nix','--json','--apply','x: builtins.mapAttrs (name: value: value.outPath) { inherit (x) klem web-assets corpus-adapter; }']
actual=json.loads(subprocess.check_output(command,cwd=ROOT));expected={label:p['package'] for label,p in proof['profiles'].items()};assert actual==expected,(actual,expected)
assert all(sha(ROOT/name)==record['sha256'] for name,record in files.items())
r={'schema_version':1,'state':'current-root-tested-package-binding-passed','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source_files':files,'source_proof_sha256':sha(PROOF),'package_sha256':sha(PACKAGE),'actual_current_flake_command':command,'actual_current_flake_outputs':actual,'exact_installed_package_outputs':True,'all_source_bytes_exact':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'All973actual Root compiled/frontend inputs exactly match the tested source NAR profiles; the actual unchanged current flake produces the same three tested package identities. No rebuilding is inferred from code similarity. Broader linguistics, independent/contextual review and a new combined inventory gate remain separate.'}
OUT.write_text(json.dumps(r,indent=2)+'\n');print('All973current Root inputs and actual three flake package outputs match the tested Nix packages.')
