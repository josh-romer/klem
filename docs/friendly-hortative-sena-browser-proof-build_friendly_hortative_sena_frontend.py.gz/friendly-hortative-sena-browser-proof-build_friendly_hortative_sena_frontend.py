"""Build the exact18-input SolidJS frontend without changing any captured source."""
import datetime
import hashlib
import json
import os
import subprocess
from pathlib import Path

P=Path(__file__).resolve().parent
W=P.parent/'friendly-hortative-sena'
ROOT=P.parents[1]
O=P/'friendly-hortative-sena-frontend-build.json'
L=P/'friendly-hortative-sena-frontend-build.log'
assert not O.exists() and not L.exists()
MODULES=ROOT/'.direnv/dapnikka-integration/web/node_modules'
assert MODULES.is_dir() and (MODULES.parent/'package-lock.json').read_bytes()==(W/'web/package-lock.json').read_bytes()
link=W/'web/node_modules';assert not link.exists();link.symlink_to(MODULES,target_is_directory=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=W)
frozen={n:sha((W/n).read_bytes()) for n in git('ls-files','-z').decode().split('\0')[:-1]}
head,index=git('rev-parse','HEAD').decode().strip(),sha(git('ls-files','--stage','-z'))
selected=json.loads((P/'friendly-hortative-sena-wide-selected-source.json').read_bytes())
frontend=selected['profiles']['web-assets']['files']
assert len(frontend)==18 and all(frozen['web/'+n]==d for n,d in frontend.items())
binding=json.loads((P/'friendly-hortative-sena-complete-runtime-binding.json').read_bytes())
assert all(frozen[n]==d for n,d in binding['production_inputs'].items())
temp=P/'frontend-temp';temp.mkdir(exist_ok=True)
command=['npm','run','build']
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,frontend_inputs=frontend,
       production_inputs=binding['production_inputs'],command=command,
       producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
       started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
       scope='Actual SolidJS TypeScript/Vite production build with all18frontend inputs equal captured passing139selected and1158RustSource; same cached pinned dependency lock. AllSource/head/index frozen. New own78469label only, no installedNix/browser/context claim.')
def save():O.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
    with L.open('xb') as log:job=subprocess.run(command,cwd=W/'web',env=dict(os.environ,TMPDIR=str(temp)),stdout=log,stderr=subprocess.STDOUT)
    r.update(exit_code=job.returncode,state='passed' if job.returncode==0 else 'failed')
except BaseException as error:r.update(state='failed',error=repr(error));raise
finally:
    assets=W/'web/dist'
    r.update(inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),
             head_unchanged=git('rev-parse','HEAD').decode().strip()==head,
             index_unchanged=sha(git('ls-files','--stage','-z'))==index,
             log_sha256=sha(L.read_bytes()) if L.exists() else None,
             assets={str(p.relative_to(assets)):sha(p.read_bytes()) for p in assets.rglob('*') if p.is_file()},
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not r['assets'] or not all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged']):r['state']='failed'
    save()
assert r['state']=='passed','Actual frontend build failed;full producer/receipt/log retained.'
print('Passedactual18-inputSolidJSproductionbuild;',len(r['assets']),'assets;allSource/head/index unchanged.',flush=True)
