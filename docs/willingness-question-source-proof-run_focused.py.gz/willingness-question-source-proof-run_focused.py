"""Verify new source paths and existing correctness/stress/label contracts."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

prep = Path(__file__).resolve().parent
work = Path('/tmp/klem-willingness-question-prototype')
out = prep / 'prototype-focused.json'
assert not out.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [p for folder in ['src', 'tests', 'tools', 'web/src'] for p in (work / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += [work / 'Cargo.toml', work / 'Cargo.lock', work / 'docs/coverage-checklist.md', Path(__file__)]
frozen = {str(p): sha(p) for p in files}
commands = [
    ['cargo', 'test', '--locked', '--offline', '--features', 'web', '--test', 'willingness_question', '--test', 'candidate_correctness', '--test', 'stress', '--test', 'formal_volitional', '--test', 'formal_volitional_expression', '--test', 'conjectural_additive'],
    ['cargo', 'test', '--locked', '--offline', '--features', 'web', '--bin', 'klem-web', 'grammar_labels::tests'],
    ['cargo', 'test', '--locked', '--offline', '--features', 'web', '--lib', 'grammar::tests'],
    ['cargo', 'fmt', '--all', '--', '--check'],
]
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/klem-expression-conjectural-main-target',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='4')
receipt = {'state': 'running', 'commands': [], 'frozen_inputs': frozen,
           'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
           'scope': 'Focused new source and prior correctness/stress/ending/label regressions. Full compiled Rust/Nix/installed/browser/corpus/novel/performance and ledger/review integration remain separate.'}
out.write_text(json.dumps(receipt, indent=2) + '\n')
try:
    for index, command in enumerate(commands):
        log = prep / ('prototype-focused-' + str(index) + '.log')
        with log.open('xb') as stream:
            result = subprocess.run(command, cwd=work, env=env, stdout=stream, stderr=subprocess.STDOUT)
        receipt['commands'].append({'command': command, 'exit_code': result.returncode, 'log': str(log), 'log_sha256': sha(log)})
        out.write_text(json.dumps(receipt, indent=2) + '\n')
        print(index, result.returncode, flush=True)
        assert result.returncode == 0, log
    receipt.update(state='passed', exit_code=0, inputs_unchanged=all(sha(p) == digest for p, digest in frozen.items()))
    assert receipt['inputs_unchanged']
except Exception as error:
    receipt.update(state='failed', error=str(error))
    raise
finally:
    out.write_text(json.dumps(receipt, indent=2) + '\n')
