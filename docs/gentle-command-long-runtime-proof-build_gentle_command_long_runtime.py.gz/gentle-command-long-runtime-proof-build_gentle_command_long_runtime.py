"""Build actual longer-command binaries with complete production/source bindings."""
import datetime,gzip,hashlib,json,os,subprocess
from pathlib import Path
PREP=Path(__file__).resolve().parent
WORK=Path('/home/josh/projects/klem/.direnv/gentle-command-long')
TARGET=Path('/home/josh/projects/klem/.direnv/gentle-command-long-target')
OUT=PREP/'gentle-command-long-runtime-binding.json'
LOG=PREP/'gentle-command-long-runtime-build.log'
assert not OUT.exists() and not LOG.exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
index=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK)).hexdigest()
names=subprocess.check_output(['git','ls-files','-z'],cwd=WORK).decode().split('\0')[:-1]
frozen={str(WORK/name):sha(WORK/name) for name in names}
frozen[str(Path(__file__))]=sha(__file__)
archive=WORK/'docs/gentle-command-runtime-proof-archive.json'
assert sha(archive)=='5500e8b18cc6a6051d5792c2397c2f429684a24d8f8f1d73cd21e11dfeeaad69'
item=json.loads(archive.read_bytes())['files']['gentle-command-current-production-closure.json']
raw=(WORK/'docs'/item['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==item['archive_sha256']
original=gzip.decompress(raw);assert hashlib.sha256(original).hexdigest()==item['source_sha256']
parent=json.loads(original)
production={str(Path(path).relative_to('/tmp/klem-gentle-command')):sha(WORK/Path(path).relative_to('/tmp/klem-gentle-command')) for path in parent['production_inputs']}
assert len(production)==44 and 'src/dictionary/proper_names.json' in production
changes={str(Path(path).relative_to('/tmp/klem-gentle-command')):dict(before=digest,after=production[str(Path(path).relative_to('/tmp/klem-gentle-command'))])
         for path,digest in parent['production_inputs'].items() if digest!=production[str(Path(path).relative_to('/tmp/klem-gentle-command'))]}
assert set(changes)=={'src/grammar.rs','src/engine.rs','src/dictionary/attachment.rs','src/bin/klem-web/grammar_labels.rs','web/src/grammar-labels.json'}
full=json.loads((PREP/'gentle-command-long-full-rust.json').read_bytes())
assert full['head']==head and all(full['frozen_inputs'][str(WORK/name)]==digest for name,digest in production.items())
command=['cargo','build','--locked','--offline','--features','web','--bin','klem','--bin','klem-web','--example','evaluate']
r=dict(state='running',captured_head=head,index_sha256=index,frozen_inputs=frozen,production_inputs=production,
       parent_production_inputs=parent['production_inputs'],individual_production_changes=changes,
       observed_full_rust_state=full['state'],observed_full_rust_receipt=full,
       command=command,producer=dict(text=Path(__file__).read_text(),sha256=sha(__file__)),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
       scope='Actual isolated CLI/server/adapter build with complete44-source/data closure, all tracked source bytes/head/index frozen, explicit five production changes against unchanged previous capture. The full Rust receipt observation remains historical; terminal full Rust, output/corpus/Native/browser/Nix/main/quiet and contextual review are separate.')
save=lambda:OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');save()
with LOG.open('xb') as stream:
    job=subprocess.run(command,cwd=WORK,env=dict(os.environ,CARGO_TARGET_DIR=str(TARGET),CARGO_PROFILE_DEV_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2'),stdout=stream,stderr=subprocess.STDOUT)
r.update(exit_code=job.returncode,inputs_unchanged=all(sha(path)==digest for path,digest in frozen.items()),
         head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,
         index_unchanged=hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK)).hexdigest()==index,
         log_sha256=sha(LOG),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
if job.returncode==0:
    r['binaries']={name:dict(path=str(path),sha256=sha(path)) for name,path in [('klem',TARGET/'debug/klem'),('klem-web',TARGET/'debug/klem-web'),('adapter',TARGET/'debug/examples/evaluate')]}
r['state']='passed' if job.returncode==0 and r['inputs_unchanged'] and r['head_unchanged'] and r['index_unchanged'] else 'failed'
save();print(r['state'],'actual CLI/server/adapter;44production inputs;',len(frozen),'frozen source files',flush=True)
raise SystemExit(0 if r['state']=='passed' else 1)
