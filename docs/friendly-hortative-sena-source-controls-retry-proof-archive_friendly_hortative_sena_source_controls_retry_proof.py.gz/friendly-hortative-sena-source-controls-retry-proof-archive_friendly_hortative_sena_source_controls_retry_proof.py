"""Archive the actual independent Source audit and its complete controls."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = Path('/home/josh/projects/klem/.direnv/friendly-hortative-sena')
D = W / 'docs'
sha = lambda b: hashlib.sha256(b).hexdigest()
receipt = P / 'friendly-hortative-sena-source-audit-validation-retry1.json'
r = json.loads(receipt.read_bytes())
assert r['state'] == 'failed' and r['controls'] == 42
assert len(r['results']) == 3 and [x['exit_code'] for x in r['results']] == [0,0,1]
assert 'stale queue: regenerate from the pinned dictionary' in (P/'friendly-hortative-sena-source-audit-validation-retry1.log').read_text()
assert all(r[k] for k in ['inputs_unchanged', 'external_inputs_unchanged',
                         'gena_parent_inputs_unchanged', 'head_unchanged', 'index_unchanged'])
assert all(sha((W / name).read_bytes()) == digest for name, digest in r['frozen_inputs'].items())
assert r['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
assert r['index_sha256'] == sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=W))
assert sha((P / 'friendly-hortative-sena-source-audit-validation-retry1.log').read_bytes()) == r['log_sha256']
files = {}
for path in [P / 'validate_friendly_hortative_sena_source_audit_retry1.py', receipt,
             P / 'friendly-hortative-sena-source-audit-validation-retry1.log', Path(__file__),
             W / 'tools/friendly_hortative_sena_source_audit.py',
             W / 'tools/test_friendly_hortative_sena_source_audit.py',
             P / 'optimize_friendly_hortative_sena_source_controls.py',
             P / 'friendly-hortative-sena-control-optimization-preparation-failure.json',
             P / 'friendly-hortative-sena-control-optimization-preparation-failure-producer.py.gz',
             P / 'friendly-hortative-sena-control-optimization-preparation-failure2.json',
             P / 'friendly-hortative-sena-control-optimization-preparation-failure2-producer.py.gz']:
    raw = path.read_bytes()
    name = 'friendly-hortative-sena-source-controls-retry-proof-' + path.name + '.gz'
    output = D / name
    assert not output.exists()
    packed = gzip.compress(raw, mtime=0)
    output.write_bytes(packed)
    files[path.name] = dict(path=name, source_sha256=sha(raw), archive_sha256=sha(packed))
output = D / 'friendly-hortative-sena-source-controls-retry-proof-archive.json'
assert not output.exists()
output.write_text(json.dumps(dict(
    state='optimized-same42-source-controls-passed-final-stale-queue-failure-retained', files=files,
    source_baseline_manifest_sha256='1a2e9d3f9430b00c743e47ef262623ab19e33c29429af8a9fe50a72e34a3257b',
    source_groups=5, private_cases=25, required=19, forbidden=6, full_native_owners=36,
    baseline_runs=36, baseline_frames=1608, required_observations=324, original_raw_words=63,
    independent_controls=42, original_overall_validation_state='failed', final_failure='stale inventory queue evidence hash after checklist update; all715source/review rows unchanged', no_original_test_assertions_removed=True, canonical_typed_matches=0, required_lemma_role_matches=0,
    actual_source_head_index_and_parent_inputs_unchanged=True,
    shared_cases_and_reviews_changed=False, original_metadata_correction_retained=True,
    full_Rust_history_broad_gold_CLI_browser_installed_Nix_main_quiet_context_register_independent_review='pending',
    full_coverage_complete=False), indent=2) + '\n')
print('Archived11 full optimized-source-control/preparation originals;42 tests passed, final stale-queue failure retained honestly.', flush=True)
