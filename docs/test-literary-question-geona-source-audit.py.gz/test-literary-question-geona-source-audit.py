"""Corrupt semantic captures, rebinding payload checksums when necessary."""
import copy,importlib.util,json,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('geona_audit','/tmp/klem-literary-question-geona-source-audit.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
R=a.inputs()

class Guards(unittest.TestCase):
 def reject(self,index,change):
  reports=list(R);reports[index]=copy.deepcopy(reports[index]);change(reports[index])
  with self.assertRaises((AssertionError,KeyError,ValueError,TypeError,StopIteration)):a.inspect(*reports)
 def test_all_actual_source_and_boundaries(self):self.assertEqual(a.inspect(*R)['complete_native_entries'],97)
 def test_original_reply_cannot_disappear(self):self.reject(0,lambda r:r['all_original_groups'][-1]['original'].pop())
 def test_source_attachment_note_cannot_be_simplified(self):self.reject(0,lambda r:r['sqlite_entries']['krdict:80970'].__setitem__('notes',[]))
 def test_source_char_span(self):self.reject(1,lambda r:r['original_cases'][0]['source_occurrence']['char_span'].__setitem__('start',0))
 def test_parent_cannot_be_invented(self):self.reject(1,lambda r:r['original_cases'][0]['earlier_parent']['analysis']['rules'].append('invented'))
 def test_original_adjective_tension_is_unknown(self):
  def change(r):
   run=r['runs'][0];rows=list(map(json.loads,run['jsonl'].splitlines()));case=next(c for c in R[1]['original_cases'] if c['surface']=='좋을거나');row=next(row for row in rows if row.get('analysis') and row['analysis']['normalized']==case['surface']);i=next(i for i,p in enumerate(row['analysis']['analyses']) if a.matches(p,case['expected']));row['dictionary']['readings'][i]['status']='compatible';run['jsonl']=''.join(json.dumps(row,ensure_ascii=False)+'\n' for row in rows);run['sha256']=a.sha(run['jsonl'].encode())
  self.reject(2,change)
 def test_all_unicode_filter_modes(self):self.reject(2,lambda r:r['runs'].pop())
 def test_raw_spelling_is_not_a_prohibition(self):
  self.reject(3,lambda r:next(c for c in r['cases'] if c['id'].endswith('wrong-bieup-unrecovered'))['expected_presence'].__setitem__('raw',False))
 def test_conditional_case_cannot_be_promoted(self):self.reject(3,lambda r:next(c for c in r['cases'] if c['proposal']=='conditional').__setitem__('proposal','required'))
 def test_homonym_statuses_stay_separate(self):self.reject(3,lambda r:next(c for c in r['cases'] if c['id'].endswith('eu-homonyms'))['expected_entry_statuses'].__setitem__('krdict:66586','compatible'))
 def test_original_draft_errors_remain(self):self.reject(3,lambda r:r['initial_mismatches_retained'].pop())
 def test_complete_native_owner_notes(self):self.reject(4,lambda r:r['complete_native_entries']['krdict:80970']['notes'].append('invented'))
 def test_every_owner_is_retained(self):self.reject(4,lambda r:r['matched_owner_ids'].pop())

if __name__=='__main__':unittest.main()
