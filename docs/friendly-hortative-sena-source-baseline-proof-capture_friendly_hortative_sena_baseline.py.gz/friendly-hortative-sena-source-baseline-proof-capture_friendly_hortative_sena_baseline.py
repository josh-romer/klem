"""Capture Sena typed paths and lemma alternatives after independent authoring."""
import datetime,gzip,hashlib,itertools,json,subprocess,unicodedata
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=Path('/home/josh/projects/klem');W=ROOT/'.direnv/friendly-command-gena'
GENA=ROOT/'.direnv/willingness-question-prepared'
O=P/'friendly-hortative-sena-baseline.json';C=P/'friendly-hortative-sena-baseline-records.json.gz';L=P/'friendly-hortative-sena-baseline.log'
assert not O.exists() and not C.exists() and not L.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
installed_path=GENA/'friendly-command-gena-installed-runtime.json.gz'
installed=json.loads(gzip.decompress(installed_path.read_bytes()));assert installed['state']=='passed' and all(installed[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged'])
CLI=Path(installed['binaries']['klem']['path']);assert sha(CLI.read_bytes())==installed['binaries']['klem']['sha256']
DB=ROOT/'.direnv/dictionary-restoration/krdict.db';assert sha(DB.read_bytes())=='23d993696c55d0e54660e4a2b23dac7d68525fecb1fdc44341e1f2b3f75dead5'
author_path=P/'friendly-hortative-sena-source-authoring-reviewed.json';suite_path=P/'friendly-hortative-sena-validity.json';closure_path=P/'friendly-hortative-sena-original-native-closure-reviewed.json.gz'
author=json.loads(author_path.read_bytes());suite=json.loads(suite_path.read_bytes());closure=json.loads(gzip.decompress(closure_path.read_bytes()))
assert not author['candidate_runtime_observed'] and author['historical_whole_inventory_discovery_already_exists'] and not author['prior_discovery_outputs_used_for_target_selection']
assert sha(suite_path.read_bytes())==author['suite_sha256'] and sha(closure_path.read_bytes())==author['native_closure_sha256']
assert len(suite['cases'])==25 and len(author['items'])==5 and len(closure['complete_native_entries'])==36
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))
assert head==installed['captured_head'] and not subprocess.check_output(['git','status','--porcelain'],cwd=W)
names=subprocess.check_output(['git','ls-files','-z'],cwd=W).decode().split('\0')[:-1];source_inputs={name:sha((W/name).read_bytes()) for name in names}
assert all(source_inputs[name]==digest for name,digest in installed['profiles']['klem']['files'].items())
frozen={str(path):sha(path.read_bytes()) for path in [CLI,DB,author_path,suite_path,closure_path,installed_path,Path(__file__)]}
families={'complete-original-groups':'\n\n'.join('\n'.join(item['complete_original_group']) for item in author['items'])+'\n',
          'preauthored-25-proposals':'\n'.join(case['surface'] for case in suite['cases'])+'\n',
          'unjudged-lexical-prefinal-boundaries':'\n'.join(['예쁘세나','예쁘시세나','학생이시세나','학생답시세나','먹었세나','먹겠세나','가세나요'])+'\n'}
def typed_match(a,j):return [l['text'] for l in a['lemmas']]==j['lemmas'] and [l['kind'] for l in a['lemmas']]==j['lemma_kinds'] and [m['form'] for m in a['morphemes']]==j['morphemes'] and [m['kind'] for m in a['morphemes']]==j['morpheme_kinds']
def lemma_match(a,j):return [l['text'] for l in a['lemmas']]==j['lemmas'] and [l['kind'] for l in a['lemmas']]==j['lemma_kinds']
r=dict(state='running',head=head,index_sha256=index,source_inputs=source_inputs,frozen_inputs=frozen,source_authoring_sha256=sha(author_path.read_bytes()),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),scope='Actual installed current Gena CLI baseline for Sena after25independent finite proposals/5complete original groups. Historical whole-inventory discovery already exists and remains separate; this is the first targeted current output observation. Match canonical typed paths AND lexical lemma-role alternatives independently of future ruleIDs, so an absent canonical trace is not called a missing lemma. AllownNative fields/homonyms/order/span/filter/cache andunjudged adjective/copula/prefinal probes retained. Source6985HEADindex immutable; no runtime/shared case/review/gold changes or contextual precision claims.')
captures=[];native={}
def save():
    C.write_bytes(gzip.compress((json.dumps(dict(captures=captures,native_entries=native),ensure_ascii=False)+'\n').encode(),mtime=0));O.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
try:
 with L.open('x') as log:
  for family,norm,mode,cache in itertools.product(families,['NFC','NFD'],['all','headwords','compatible'],[0,4096]):
   text=unicodedata.normalize(norm,families[family]);command=[str(CLI),'text','-','--dictionary',str(DB),'--cache-bytes',str(cache)]
   if mode=='headwords':command+=['--dict-only']
   if mode=='compatible':command+=['--dict-compatible']
   job=subprocess.run(command,input=text.encode(),capture_output=True);capture=dict(family=family,normalization=norm,mode=mode,cache_bytes=cache,input=text,command=command,exit_code=job.returncode,stdout=job.stdout.decode(),stderr=job.stderr.decode(),frames=[],observations=[]);captures.append(capture);save();assert job.returncode==0
   frames=[json.loads(line) for line in job.stdout.splitlines()];capture['frames']=frames;cursor=0
   for frame in frames:
    span=frame['span'];assert span['start']==cursor and text.encode()[span['start']:span['end']].decode()==frame['surface'];cursor=span['end']
   assert cursor==len(text.encode())
   for case in suite['cases']:
    j=case['judgments'][0]
    for frame in frames:
     if unicodedata.normalize('NFC',frame['surface'])!=case['surface']:continue
     analyses=frame['analysis']['analyses'];capture['observations'].append(dict(case_id=case['id'],span=frame['span'],verdict=j['verdict'],typed_path_present=any(typed_match(a,j) for a in analyses),lemma_role_path_present=any(lemma_match(a,j) for a in analyses)))
   row=dict(family=family,normalization=norm,mode=mode,cache_bytes=cache,frames=len(frames),canonical_typed_matches=sum(o['typed_path_present'] for o in capture['observations']),required_lemma_role_matches=sum(o['lemma_role_path_present'] for o in capture['observations'] if o['verdict']=='required'));log.write(json.dumps(row,ensure_ascii=False)+'\n');log.flush();save();print(row,flush=True)
  for ident,expected in sorted(closure['complete_native_entries'].items()):
   command=[str(CLI),'dict','entry',str(DB),ident];job=subprocess.run(command,capture_output=True);native[ident]=dict(command=command,stdout=job.stdout.decode(),stderr=job.stderr.decode(),exit_code=job.returncode);save();assert job.returncode==0
   value=json.loads(job.stdout);native[ident]['response']=value;save();assert value['entry']==expected,ident
 for a in captures:
  b=next(x for x in captures if all(a[k]==x[k] for k in ['family','normalization','mode']) and x['cache_bytes']!=a['cache_bytes']);assert a['stdout']==b['stdout']
 r.update(state='passed',runs=36,complete_native_owners=len(native),frame_count=sum(len(c['frames']) for c in captures),preauthored_cases=25,
          canonical_typed_matches=sum(o['typed_path_present'] for c in captures for o in c['observations']),
          required_canonical_typed_matches=sum(o['typed_path_present'] for c in captures for o in c['observations'] if o['verdict']=='required'),
          forbidden_canonical_typed_matches=sum(o['typed_path_present'] for c in captures for o in c['observations'] if o['verdict']=='forbidden'),
          required_lemma_role_matches=sum(o['lemma_role_path_present'] for c in captures for o in c['observations'] if o['verdict']=='required'),
          required_observations=sum(o['verdict']=='required' for c in captures for o in c['observations']),production_changed=False,shared_judgments_reviews_changed=False)
except BaseException as error:r.update(state='failed',error=repr(error));raise
finally:
 r.update(inputs_unchanged=all(sha(Path(path).read_bytes())==digest for path,digest in frozen.items()),source_unchanged=all(sha((W/name).read_bytes())==digest for name,digest in source_inputs.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==head,index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))==index,capture_path=C.name,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save();r['capture_sha256']=sha(C.read_bytes());r['log_sha256']=sha(L.read_bytes()) if L.exists() else None;O.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
assert r['state']=='passed' and all(r[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged'])
print('Passed Sena baseline:',r['runs'],'complete policies;',r['complete_native_owners'],'completeNative owners;',r['canonical_typed_matches'],'canonical matches;',r['required_lemma_role_matches'],'required lemma-role observations.',flush=True)
