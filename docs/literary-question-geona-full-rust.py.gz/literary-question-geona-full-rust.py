import datetime,hashlib,json,os,subprocess
from pathlib import Path
P=Path('/tmp/klem-literary-question-geona-prototype'); BASE=Path('/tmp/klem-literary-question-geona-full-rust'); receipt=BASE.with_suffix('.json');log=BASE.with_suffix('.log');assert not receipt.exists() and not log.exists()
prepared=json.loads(Path('/tmp/klem-literary-question-geona-full-preparation.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();snapshot=prepared['snapshot_files']
for name,value in snapshot.items():assert sha((P/name).read_bytes())==value['sha256'],name
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TARGET_DIR='/tmp/klem-literary-future-kko-final-retained-cargo-cache/literary-question-go-prototype-cargo')
command=['cargo','test','--offline','--locked','--features','web','-j','4']
r={'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'cwd':str(P),'snapshot_files':snapshot,'environment':{k:env[k] for k in ['CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_TARGET_DIR']}}
receipt.write_text(json.dumps(r,indent=2)+'\n');print('Running full frozen956-input Rust suite',flush=True)
with log.open('wb') as out:result=subprocess.run(command,cwd=P,env=env,stdout=out,stderr=subprocess.STDOUT)
r.update(state='passed' if result.returncode==0 else 'failed',exit_code=result.returncode,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=sha(log.read_bytes()),inputs_unchanged=all(sha((P/n).read_bytes())==v['sha256'] for n,v in snapshot.items()))
receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['state','exit_code','inputs_unchanged','log_sha256']}),flush=True);raise SystemExit(result.returncode)
