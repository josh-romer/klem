"""Capture all source groups and private judgments under Unicode/filter/cache policies."""
import datetime
import gzip
import hashlib
import json
import subprocess
import unicodedata
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-gentle-command')
OUT = PREP / 'gentle-command-source-runtime.json.gz'
PROGRESS = PREP / 'gentle-command-source-runtime-progress.json'
assert not OUT.exists() and not PROGRESS.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
digest = lambda raw: hashlib.sha256(raw).hexdigest()
binding_path = PREP / 'gentle-command-current-production-binding.json'
source_path = WORK / 'tests/fixtures/gentle-command-source.json'
suite_path = WORK / 'tests/fixtures/gentle-command-validity.json'
baseline_path = WORK / 'docs/gentle-command-proof-gentle-command-installed-baseline.json.gz'
binding = json.loads(binding_path.read_bytes())
assert binding['state'] == 'passed' and binding['inputs_unchanged']
source = json.loads(source_path.read_bytes())
suite = json.loads(suite_path.read_bytes())
baseline = json.loads(gzip.decompress(baseline_path.read_bytes()))
assert len(source['items']) == 8 and len(suite['cases']) == 23
cli = Path(binding['binaries']['klem']['path'])
assert sha(cli) == binding['binaries']['klem']['sha256']
db = Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db')
assert sha(db) == source['database_sha256']
frozen = {str(p): sha(p) for p in [binding_path, source_path, suite_path, baseline_path,
                                cli, db, Path(__file__)]}
frozen.update(binding['production_inputs'])
r = dict(state='running', started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         captured_head=binding['captured_head'], frozen_inputs=frozen, runs=[],
         producer=dict(text=Path(__file__).read_text(), sha256=sha(__file__)),
         scope='Every independently authored source and private judgment checked with original bytes, all filter/cache/Unicode policies. Every prior source candidate and Native assessment retained. Original judgments/baselines remain unchanged; contextual and independent review pending.')
save = lambda: PROGRESS.write_text(json.dumps({**r, 'runs': len(r['runs'])}, ensure_ascii=False, indent=2)+'\n')
save()


def matches(path, target):
    return (all([part[key] for part in path[field]] == target[expected]
                for field, key, expected in [('lemmas', 'text', 'lemmas'),
                                             ('lemmas', 'kind', 'lemma_kinds'),
                                             ('morphemes', 'form', 'morphemes'),
                                             ('morphemes', 'kind', 'morpheme_kinds')])
            and set(target.get('required_rules', [])) <= set(path['rules']))


def frames(payload, stdout):
    result = [json.loads(line) for line in stdout.splitlines()]
    cursor = 0
    for frame in result:
        assert frame['span']['start'] == cursor
        cursor = frame['span']['end']
        assert payload[frame['span']['start']:cursor].decode() == frame['surface']
    assert cursor == len(payload)
    return result


try:
    for family in ['complete-source', 'individual-targets', 'individual-validity']:
        text = ('\n\n'.join('\n'.join(item['complete_original_group']) for item in source['items'])
                if family == 'complete-source' else
                ' '.join(item['surface'] for item in (suite['cases'] if family == 'individual-validity' else source['items'])))
        for encoding in ['NFC', 'NFD']:
            payload = unicodedata.normalize(encoding, text).encode()
            for mode, flags in [('raw', []), ('headword', ['--dict-only']), ('compatible', ['--dict-compatible'])]:
                cache_outputs = []
                for cache in [0, 4096]:
                    command = [str(cli), 'text', '-', '--dictionary', str(db), *flags, '--cache-bytes', str(cache)]
                    job = subprocess.run(command, input=payload, capture_output=True)
                    assert job.returncode == 0 and not job.stderr, job.stderr
                    current = frames(payload, job.stdout)
                    observations = []
                    if family != 'individual-validity':
                        prior = next(run for run in baseline['runs'] if
                                     (run['family'], run['encoding'], run['mode'], run['cache_bytes']) == (family, encoding, mode, cache))
                        assert prior['input_text'].encode() == payload
                        old_job = subprocess.run(prior['command'], input=payload, capture_output=True)
                        assert old_job.returncode == 0 and not old_job.stderr and old_job.stdout.decode() == prior['jsonl'], 'actual immutable installed baseline'
                        previous = frames(payload, old_job.stdout)
                        assert len(current) == len(previous)
                        for old, new in zip(previous, current, strict=True):
                            if old['kind'] != 'word':
                                assert old == new
                                continue
                            assert {k: v for k, v in old.items() if k not in ['analysis', 'dictionary']} == {k: v for k, v in new.items() if k not in ['analysis', 'dictionary']}
                            before, after = old['analysis'], new['analysis']
                            assert {k: v for k, v in before.items() if k != 'analyses'} == {k: v for k, v in after.items() if k != 'analyses'}
                            assert [p for p in after['analyses'] if p in before['analyses']] == before['analyses'], 'every prior candidate/order'
                            bd, ad = old['dictionary'], new['dictionary']
                            assert {k: v for k, v in bd.items() if k not in ['lemmas', 'readings']} == {k: v for k, v in ad.items() if k not in ['lemmas', 'readings']}
                            assert all(owner in ad['lemmas'] for owner in bd['lemmas']), 'every original Native owner'
                            for index, path in enumerate(before['analyses']):
                                assert bd['readings'][index] == ad['readings'][after['analyses'].index(path)], 'every original Native assessment'
                        for item in source['items']:
                            located = [(i, frame) for i, frame in enumerate(current) if frame['kind'] == 'word' and unicodedata.normalize('NFC', frame['surface']) == item['surface']]
                            assert len(located) == 1
                            index, frame = located[0]
                            target = {**item['independent_typed_proposal'], 'required_rules': ['ending.gentle_command']}
                            indices = [i for i, path in enumerate(frame['analysis']['analyses']) if matches(path, target)]
                            assert indices, ('source target missing', family, encoding, mode, item['id'])
                            observations.append(dict(case_id=item['id'], record_index=index, required_analysis_indices=indices))
                    else:
                        offset = 0
                        for case in suite['cases']:
                            token = unicodedata.normalize(encoding, case['surface']).encode()
                            located = [(i, frame) for i, frame in enumerate(current) if frame['span']['start'] == offset]
                            assert len(located) == 1 and located[0][1]['surface'].encode() == token
                            index, frame = located[0]
                            offset += len(token)+1
                            for judgment in case['judgments']:
                                indices = [i for i, path in enumerate(frame['analysis']['analyses']) if matches(path, judgment)]
                                assert bool(indices) == (judgment['verdict'] == 'required'), (case['id'], mode, indices)
                                observations.append(dict(case_id=case['id'], judgment_id=judgment['id'], verdict=judgment['verdict'], record_index=index, analysis_indices=indices))
                    cache_outputs.append(job.stdout)
                    r['runs'].append(dict(family=family, encoding=encoding, mode=mode, cache_bytes=cache,
                                          command=command, exit_code=0, input_text=payload.decode(),
                                          input_sha256=digest(payload), records=len(current),
                                          original_bytes_conserved=True, jsonl=job.stdout.decode(),
                                          jsonl_sha256=digest(job.stdout), observations=observations))
                    save()
                assert cache_outputs[0] == cache_outputs[1], 'exact cache output parity'
            print(family, encoding, 'all filters/cache policies passed', flush=True)
    r.update(state='complete-gentle-command-source-runtime-passed',
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             streams=len(r['runs']), frames=sum(run['records'] for run in r['runs']),
             inputs_unchanged=all(sha(p) == value for p, value in frozen.items()),
             linguistic_judgments_promoted=False)
    assert r['streams'] == 36 and r['inputs_unchanged']
    OUT.write_bytes(gzip.compress((json.dumps(r, ensure_ascii=False, indent=2)+'\n').encode(), mtime=0))
    save()
    print('Complete runtime:', r['streams'], 'streams /', r['frames'], 'frames', flush=True)
except Exception as error:
    r.update(state='failed', error=str(error))
    save()
    raise
