"""Retain the full first portable audit failure before correcting its path guard."""
import gzip
import hashlib
import json
from pathlib import Path
P = Path(__file__).resolve().parent
W = P.parent / 'friendly-command-gena'
OUT = P / 'gena-promoted-portable-first-failure-originals.json'
assert not OUT.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
names = ['validate_gena_portable_promoted_installed.py',
         'friendly-command-gena-promoted-portable-audit.json',
         'friendly-command-gena-promoted-portable-audit.log',
         'gena-promoted-portable-before-inventory-queue.json.gz']
files = {}
for name in names:
    raw = (P / name).read_bytes()
    packed = gzip.compress(raw, mtime=0)
    path = P / ('gena-promoted-portable-first-failure-original-' + name + '.gz')
    path.write_bytes(packed)
    files[name] = dict(path=str(path), source_sha256=sha(raw), archive_sha256=sha(packed), bytes=len(raw))
for name in ['tools/friendly_command_gena_promoted_installed_audit.py',
             'tools/friendly_command_gena_promoted_streams.py',
             'tools/test_friendly_command_gena_promoted_installed_audit.py',
             'docs/coverage-checklist.md', 'docs/inventory-review-queue.json', 'flake.nix']:
    raw = (W / name).read_bytes()
    packed = gzip.compress(raw, mtime=0)
    path = P / ('gena-promoted-portable-first-failure-source-' + name.replace('/', '-') + '.gz')
    path.write_bytes(packed)
    files[name] = dict(path=str(path), source_sha256=sha(raw), archive_sha256=sha(packed), bytes=len(raw))
r = json.loads((P / names[1]).read_bytes())
assert r['state'] == 'failed' and (r['controls'], r['failures'], r['errors']) == (46, 0, 1)
OUT.write_text(json.dumps(dict(state='actual-failed-portable-audit-preserved', files=files,
                              failure='Relative original receipt path looked up as an absolute key; queue hash regeneration also finished after the source snapshot.',
                              original_receipt_remains_failed=True), indent=2) + '\n')
print('Preserved10 whole original portable failure artifacts.')
