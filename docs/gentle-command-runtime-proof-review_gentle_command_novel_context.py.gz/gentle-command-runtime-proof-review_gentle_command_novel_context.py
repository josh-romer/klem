"""Record a bounded contextual review without forbidding valid word hypotheses."""
import datetime
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-gentle-command')
OUT = PREP / 'gentle-command-novel-context-review.json'
assert not OUT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
broad_path = PREP / 'gentle-command-broad.json.gz'
binding_path = PREP / 'gentle-command-current-production-binding.json'
inputs_path = WORK / 'docs/reported-deoni-broad-inputs.json.gz'
broad = json.loads(gzip.decompress(broad_path.read_bytes()))
binding = json.loads(binding_path.read_bytes())
inputs = json.loads(gzip.decompress(inputs_path.read_bytes()))
assert broad['state'] == 'complete-gentle-command-broad-comparison-passed' and broad['inputs_unchanged']
cli = Path(binding['binaries']['klem']['path'])
db = Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db')
command = [str(cli), 'dict', 'lookup', str(db), '주렴']
job = subprocess.run(command, capture_output=True)
assert job.returncode == 0 and not job.stderr
lookup = json.loads(job.stdout)
assert lookup['entries'] == []
records = []
for run in broad['runs']:
    for change in run['changed_frames']:
        assert change['after']['surface'] == '주렴'
        raw = inputs['sources'][run['source']]['text'].encode()
        assert sha(Path(run['actual_source'])) == run['source_sha256'] == hashlib.sha256(raw).hexdigest()
        start, end = change['after']['span']['start'], change['after']['span']['end']
        assert raw[start:end].decode() == '주렴'
        assert '주렴 같은 비' in change['complete_original_line']
        command_paths = [path for path in change['new_paths']
                         if [lemma['text'] for lemma in path['lemmas']] == ['주다']]
        assert len(command_paths) == 1
        records.append(dict(id='gentle-command-context-'+run['mode'], mode=run['mode'],
                            original_change=change,
                            source=run['source'], source_sha256=run['source_sha256'],
                            contextual_hypothesis='Noun referring to a curtain in a rain simile.',
                            inference=True, word_lemma_hypothesis='주렴',
                            command_contextual_disposition='not_supported_in_this_passage',
                            exact_command_candidate=command_paths[0],
                            raw_word_command_licence='valid possible standalone command; retain',
                            other_raw_hypotheses='unjudged', independent_review='pending'))
assert len(records) == 5
frozen = {str(p): sha(p) for p in [broad_path, binding_path, inputs_path, cli, db, Path(__file__)]}
report = dict(state='bounded-novel-context-review-recorded', authored_after_runtime_observation=True,
              records=records, full_coverage_complete=False, independent_review='pending',
              primary_lexical_reference=dict(
                  publisher='한국가사문학관', title='경계가라',
                  url='https://gasa.go.kr/?gasa=18&mode=view&pg=3&uid=132',
                  uci='G001+KR08-4850000101005',
                  short_excerpt='주렴(珠簾): 구슬 따위를 꿰어 만든 발.',
                  retrieval='Primary publisher search-index excerpt verified; direct web-tool fetch timed out.',
                  classification='Reference for the noun; not a new imported KRDict entry.'),
              missing_krdict_lookup=dict(command=command, exit_code=0, json=job.stdout.decode(),
                                          stdout_sha256=hashlib.sha256(job.stdout).hexdigest()),
              frozen_inputs=frozen, inputs_unchanged=all(sha(p) == value for p, value in frozen.items()),
              created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              producer=dict(text=Path(__file__).read_text(), sha256=sha(__file__)),
              scope='One original novel occurrence/five policy records. Contextual noun inference is separately recorded; no blanket raw forbidden judgment, invented dictionary owner, baseline refresh or precision certification. Dictionary matching removes the missing noun and retains a possible command, which demonstrates a lexicon/context boundary.')
assert report['inputs_unchanged']
OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
print('Tracked one contextual dictionary gap across five exact novel records; raw command remains a valid alternative.')
