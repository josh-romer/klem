"""Preserve every original Native word homonym for independent novel targets."""
import datetime
import gzip
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = PREP.parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from native_lmf import entry, feature

DB = ROOT / '.direnv/dictionary-restoration/krdict.db'
AUTHOR = PREP / 'novel-context-authoring.json'
FIXTURE = PREP / 'novel-context-validity-authored.json'
OUT = PREP / 'novel-context-native-closure.json.gz'
assert not OUT.exists()
sha = lambda path: hashlib.file_digest(Path(path).open('rb'), 'sha256').hexdigest()
author = json.loads(AUTHOR.read_text())
assert sha(FIXTURE) == author['fixture_sha256']
words = {'하다', '그러다', '그렇다', '그만', '알다', '들리다', '되다',
         '덤비다', '돌려보내다', '있다', '내다', '장래', '이다',
         '-려니와', '-으려니와'}
expected = {}
with sqlite3.connect(DB.resolve().as_uri() + '?mode=ro', uri=True) as db:
    for word in sorted(words):
        rows = [json.loads(row[0]) for row in db.execute(
            'SELECT data FROM entries WHERE headword=?', (word,))]
        owners = [row for row in rows if row['lexical_unit'] == '단어']
        assert owners, word
        for owner in owners:
            assert owner['id'] not in expected
            expected[owner['id']] = owner
originals = {}
exports = {}
for source in sorted((ROOT / '.direnv/dictionary-restoration/2026-09').glob('*.json')):
    raw = source.read_bytes()
    ids = []
    for value in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
        ident = 'krdict:' + value['val']
        if ident not in expected or feature(value, 'lexicalUnit') != '단어':
            continue
        assert ident not in originals and entry(value) == expected[ident]
        originals[ident] = value
        ids.append(ident)
    exports[source.name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'ids': ids}
assert len(exports) == 11 and set(originals) == set(expected)
for name, value in [
    ('novel-context-native.json', {'LexicalResource': {'Lexicon': {'LexicalEntry': list(originals.values())}}}),
    ('novel-context-native-entries.json', expected),
]:
    path = PREP / name
    assert not path.exists()
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
report = {
    'state': 'complete-original-novel-context-native-closure-preserved',
    'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'authoring_sha256': sha(AUTHOR), 'fixture_sha256': sha(FIXTURE),
    'owners': len(originals), 'selected_headwords': sorted(words),
    'original_native_entries': originals, 'complete_imported_entries': expected,
    'original_exports': exports, 'original_database_sha256': sha(DB),
    'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
    'scope': 'Every original word homonym of all independently selected novel lexemes, both endings and copula is retained with every field. Eleven original exports and the pinned database are hashed; Python Native projections equal that database exactly. No dictionary sense is selected or candidate forbidden. The adverb 그만 and determiner homonym retain their true POS; no idiom is assigned its base owner ID. Actual Rust import, new regression paths, CLI/library/browser/export and contextual expert review remain separate.',
}
OUT.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
print(report['state'], len(originals), 'original owners', flush=True)
