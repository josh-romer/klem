"""Validate committed archive helpers in Nix with every captured host path absent."""
import datetime
import gzip
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent/'friendly-command-gena'
OUT = P/'friendly-command-gena-completed-evidence-sandbox.json'
LOG = P/'friendly-command-gena-completed-evidence-sandbox.log'
EXPR = P/'friendly-command-gena-completed-evidence-sandbox.nix'
BUILD = Path('/var/tmp/klem-friendly-command-gena-completed-evidence')
assert not OUT.exists() and not LOG.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git',*args],cwd=W)
assert not git('status','--porcelain')
prior = json.loads((P/'friendly-command-gena-completed-evidence-validation.json').read_bytes())
assert prior['state'] == 'passed' and prior['controls'] == 81 and all(prior[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged'])
frozen = {n:sha((W/n).read_bytes()) for n in git('ls-files','-z').decode().split('\0')[:-1]}
changed = {p for p,d in prior['source_inputs'].items() if frozen[p] != d}
assert changed == {'docs/coverage-checklist.md','docs/inventory-review-queue.json'}, 'only completed-proof checklist/queue digests differ from actual81 run'
catalog = json.loads((W/'docs/friendly-command-gena-completed-evidence-proof-archive.json').read_bytes())
item = catalog['files']['source-docs-inventory-review-queue.json']
old_raw = gzip.decompress((W/'docs'/item['path']).read_bytes())
assert sha(old_raw) == item['source_sha256'] == prior['source_inputs']['docs/inventory-review-queue.json']
expected_queue = json.loads(old_raw)
expected_queue['evidence_sha256']['docs/coverage-checklist.md'] = frozen['docs/coverage-checklist.md']
assert json.loads((W/'docs/inventory-review-queue.json').read_bytes()) == expected_queue, 'all original715 source rows and519 reviews retained'
head = git('rev-parse','HEAD').decode().strip()
index = sha(git('ls-files','--stage','-z'))
binding = json.loads((P.parent/'friendly-hortative-sena-prepared/friendly-hortative-sena-complete-runtime-binding.json').read_bytes())
protected = {b['path']:b['sha256'] for b in binding['binaries'].values()} | binding['protected_parent_binaries']
assert len(protected) == 6 and all(sha(Path(p).read_bytes()) == d for p,d in protected.items())
BUILD.mkdir(exist_ok=True);BUILD.chmod(0o1777)
env = dict(os.environ,TMPDIR=str(BUILD),PYTHONDONTWRITEBYTECODE='1')
flake = 'git+file://'+str(W)
command = ['nix','build','--option','build-dir',str(BUILD),'--option','auto-optimise-store','true','--cores','4','--max-jobs','1','--no-link','--json','-L','--impure','--file',str(EXPR)]
r = dict(state='running',phase='selection',head=head,index_sha256=index,frozen_inputs=frozen,
         completed_proof_only_document_changes=sorted(changed),
         protected_binaries=protected,command=command,
         nix_expression=dict(text=EXPR.read_text(),sha256=sha(EXPR.read_bytes())),
         producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Actual clean committed Git-selected Gena installed/timing/draft archive tests and715queue. Every selected file equals current source; complete1146/1146/18 compile profiles and every old selected tool byte equal original passed Gena gate. All19 captured host paths absent in Nix. Six original protected debug executables retained on host. Current full inventory/four-package execution, shared/main promotion/context/register/independent review and full checklist remain separate.')
def save():
    OUT.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
    with LOG.open('xb') as log:
        def source(attr):
            args = ['nix','eval','--offline','--raw',flake+'#'+attr]
            job = subprocess.run(args,cwd=W,env=env,stdout=subprocess.PIPE,stderr=log)
            assert job.returncode == 0
            return Path(job.stdout.decode().strip())
        def files(root,prefix=''):
            result = {}
            for file in root.rglob('*'):
                assert not file.is_symlink()
                if file.is_file():
                    n = str(file.relative_to(root));digest = sha(file.read_bytes())
                    assert frozen[prefix+n] == digest
                    result[n] = digest
            return result
        selected = source('checks.x86_64-linux.inventory-review.src')
        r['selected_source'] = str(selected)
        r['selected_files'] = files(selected)
        previous = json.loads((P/'friendly-command-gena-complete-nix-gate.json').read_bytes())
        for p,d in previous['inventory_source_files'].items():
            if p.startswith('tools/'):
                assert r['selected_files'][p] == d, 'every original selected Gena tool byte'
        for kind in ['installed','performance','ledger']:
            assert all('tools/'+stem+'friendly_command_gena_'+kind+'_audit.py' in r['selected_files'] for stem in ['', 'test_']), 'all six new current audit/control files selected'
        r['profiles'] = {}
        for name,prefix in [('klem',''),('corpus-adapter',''),('web-assets','web/')]:
            root = source('packages.x86_64-linux.'+name+'.src')
            r['profiles'][name] = dict(source=str(root),files=files(root,prefix))
            prior_name = {'klem':'klem','corpus-adapter':'klem-corpus-adapter','web-assets':'klem-web-assets'}[name]
            assert r['profiles'][name]['files'] == previous['compiled_source_profiles'][prior_name]['files'], 'every original passed1146/1146/18 compile input'
        r['phase'] = 'actual-nix-sandbox81-controls';save()
        job = subprocess.run(command,cwd=W,env=env,stdout=subprocess.PIPE,stderr=log)
        r.update(exit_code=job.returncode,stdout=job.stdout.decode())
        assert job.returncode == 0
        r['outputs'] = json.loads(job.stdout)
        r['state'] = 'passed'
except BaseException as error:
    r.update(state='failed',error=repr(error))
    raise
finally:
    text = LOG.read_text(errors='replace') if LOG.exists() else ''
    r.update(inputs_unchanged=all(sha((W/p).read_bytes()) == d for p,d in frozen.items()),
             head_unchanged=git('rev-parse','HEAD').decode().strip() == head,
             index_unchanged=sha(git('ls-files','--stage','-z')) == index,
             protected_binaries_unchanged=all(sha(Path(p).read_bytes()) == d for p,d in protected.items()),
             controls=sum(int(c) for c in re.findall(r'Ran (\d+) tests',text)),
             actual19_host_paths_absent='Confirmed actual Nix sandbox: all19 captured host paths absent; archive evidence only.' in text,
             log_sha256=sha(LOG.read_bytes()) if LOG.exists() else None,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged','actual19_host_paths_absent']) or r['controls'] != 81:
        r['state'] = 'failed'
    save()
assert r['state'] == 'passed'
print('Passed actual committed-source Nix81 archived Gena controls;19 host paths absent,1146/1146/18 compile inputs unchanged.',flush=True)
