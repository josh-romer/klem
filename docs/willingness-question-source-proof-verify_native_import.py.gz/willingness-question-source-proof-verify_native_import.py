"""Verify every new original Native owner through the actual installed Rust importer."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

prep = Path(__file__).resolve().parent
binding_path = prep.parent / 'expression-conjectural-main-prepared/combined-installed-source-binding.json'
binding = json.loads(binding_path.read_bytes())
assert binding['state'] == 'passed' and binding['inputs_unchanged']
cli = Path(binding['profiles']['klem']['package']) / 'bin/klem'
native = prep / 'native.json'
owners_path = prep / 'native-entries.json'
owners = json.loads(owners_path.read_bytes())
db = prep / 'native.db'
out = prep / 'native-import-verification.json'
assert not db.exists() and not out.exists()
sha = lambda path: hashlib.file_digest(Path(path).open('rb'), 'sha256').hexdigest()
frozen = {str(p): sha(p) for p in [native, owners_path, binding_path, cli, Path(__file__)]}
command = [str(cli), 'dict', 'import-krdict', str(native), str(db), '--snapshot', 'independent-willingness-question-native']
result = subprocess.run(command, capture_output=True)
receipt = {'state': 'running', 'command': command, 'exit_code': result.returncode,
           'import_stdout': result.stdout.decode(), 'import_stderr': result.stderr.decode(),
           'frozen_inputs': frozen, 'entries': [],
           'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))}}
try:
    assert result.returncode == 0 and not result.stderr
    for ident, owner in owners.items():
        lookup = subprocess.run([str(cli), 'dict', 'entry', str(db), ident], capture_output=True)
        assert lookup.returncode == 0 and not lookup.stderr, ident
        actual = json.loads(lookup.stdout)
        assert actual['entry'] == owner, ('all original Native fields', ident)
        receipt['entries'].append({'id': ident, 'entry': actual['entry'], 'complete_original_fields_exact': True})
    receipt.update(state='passed', owners=len(owners), database_sha256=sha(db),
                   inputs_unchanged=all(sha(p) == digest for p, digest in frozen.items()))
    assert receipt['inputs_unchanged']
except Exception as error:
    receipt.update(state='failed', error=str(error))
    raise
finally:
    out.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(len(owners), 'complete original owners passed actual installed Rust import')
