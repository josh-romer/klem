"""Run the entire current Git-backed four-check Nix gate without changing baselines."""
import datetime,hashlib,json,os,subprocess
from pathlib import Path
PREP=Path(__file__).resolve().parent
WORK=Path('/home/josh/projects/klem/.direnv/gentle-command-long')
OUT=PREP/'gentle-command-long-complete-nix-gate.json'
LOG=PREP/'gentle-command-long-complete-nix-gate.log'
BUILD=Path('/var/tmp/klem-gentle-command-long-nix-packages-build')
assert not OUT.exists() and not LOG.exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
assert BUILD.is_dir() and BUILD.stat().st_mode & 0o7777 == 0o1777
sha=lambda raw:hashlib.sha256(raw).hexdigest()
paths=subprocess.check_output(['git','ls-files','-z'],cwd=WORK).decode().split('\0')[:-1]
frozen={n:sha((WORK/n).read_bytes()) for n in paths}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK))
flake='git+file://'+str(WORK)
source=subprocess.check_output(['nix','eval','--offline','--raw',flake+'#checks.x86_64-linux.inventory-review.src'],cwd=WORK,text=True).strip()
selected={}
for p in Path(source).rglob('*'):
 if not p.is_file():continue
 name=str(p.relative_to(source));digest=sha(p.read_bytes());assert frozen[name]==digest;selected[name]=digest
for name in ['tools/gentle_command_long_installed_audit.py','tools/test_gentle_command_long_installed_audit.py','docs/gentle-command-long-installed-proof-archive.json']:
 assert name in selected,('new audit must be selected',name)
command=['nix','build','--offline','--option','auto-optimise-store','true','--option','build-dir',str(BUILD),'--cores','4','--max-jobs','1','--no-link','--print-out-paths','-L']+[flake+'#checks.x86_64-linux.'+n for n in ['klem','web-assets','corpus-adapter','inventory-review']]
r=dict(state='running',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,index_sha256=index,frozen_inputs=frozen,inventory_source=source,inventory_source_files=selected,command=command,producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),scope='Actual entire current four-check Nix gate, including all selected independent inventory/source/history/installed/browser auditors and newly added long-command audit. Original datasets/judgments unchanged. Currentmain merge/quietperformance/contextual independent review remain separate.')
def save():OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
with LOG.open('xb') as stream:job=subprocess.run(command,cwd=WORK,env=dict(os.environ,TMPDIR=str(BUILD)),stdout=stream,stderr=subprocess.STDOUT)
r.update(exit_code=job.returncode,inputs_unchanged=all(sha((WORK/n).read_bytes())==digest for n,digest in frozen.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK))==index,outputs=[line for line in LOG.read_text().splitlines() if line.startswith('/nix/store/')],log_sha256=sha(LOG.read_bytes()),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
r['state']='passed' if job.returncode==0 and len(r['outputs'])==4 and all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged']) else 'failed'
save();print(r['state'],'actual complete currentlong four-check Nix gate;',len(selected),'selected source files',flush=True)
raise SystemExit(0 if r['state']=='passed' else 1)
