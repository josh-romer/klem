"""Validate the current merged main source without changing original evidence."""
import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=Path('/home/josh/projects/klem')
O=P/'main-long-promotion-merge-validation.json';L=P/'main-long-promotion-merge-validation.log';assert not O.exists() and not L.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
names=subprocess.check_output(['git','ls-files','-z'],cwd=W).decode().split('\0')[:-1];frozen={n:sha((W/n).read_bytes()) for n in names};head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();index=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))
commands=[['python3','-m','unittest','discover','-s','tools','-p','test_literary_question_geona_runtime.py'],['python3','-m','unittest','discover','-s','tools','-p','test_gentle_command_long_ledger_audit.py'],['python3','tools/review_inventory.py','--verify'],['git','diff','--check']]
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,results=[],producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Actual main local merge of passed3ad long promotion into dd01486 preserving original35704orderedcases/Source declarations/metadata,517reviews andMainfailurearchive. CurrenthistoricalGeona101 andstrictlongledger29 controls plus715queueverify/diff; not newmainfullNix/performance or anyGena/Sena/contextualcompletion claim.')
def save():O.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save()
with L.open('xb') as log:
 for c in commands:
  log.write(('COMMAND '+json.dumps(c)+'\n').encode());log.flush();j=subprocess.run(c,cwd=W,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log.write(j.stdout);log.flush();m=re.search(rb'Ran (\d+) tests',j.stdout);r['results'].append(dict(command=c,exit_code=j.returncode,controls=int(m[1]) if m else 0));save();print(c[-1],j.returncode,r['results'][-1]['controls'],flush=True)
  if j.returncode:break
r.update(inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==head,index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))==index,controls=sum(v['controls'] for v in r['results']),log_sha256=sha(L.read_bytes()),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());r['state']='passed' if len(r['results'])==len(commands) and all(v['exit_code']==0 for v in r['results']) and all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged']) else 'failed';save();print(r['state'],r['controls'],'currentmainmerge controls',flush=True);raise SystemExit(0 if r['state']=='passed' else 1)
