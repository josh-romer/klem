"""Replay every original group and target without refreshing parent expectations."""
import gzip
import hashlib
import json
import subprocess
import unicodedata
from pathlib import Path

prep = Path(__file__).resolve().parent
root = Path('/home/josh/projects/klem')
author_path = prep / 'independent-source-authoring.json'
baseline_path = prep / 'original-installed-baseline.json.gz'
binding_path = prep / 'prototype-binaries-retry2.json'
out = prep / 'willingness-source-streams.json.gz'
assert not out.exists()
sha = lambda path: hashlib.file_digest(Path(path).open('rb'), 'sha256').hexdigest()
digest = lambda raw: hashlib.sha256(raw).hexdigest()
author = json.loads(author_path.read_bytes())
baseline = json.loads(gzip.decompress(baseline_path.read_bytes()))
binding = json.loads(binding_path.read_bytes())
assert binding['state'] == 'passed' and binding['inputs_unchanged']
cli = Path(binding['binaries']['klem']['path'])
assert sha(cli) == binding['binaries']['klem']['sha256']
db = root / '.direnv/dictionary-restoration/krdict.db'
frozen = {str(path): sha(path) for path in [author_path, baseline_path, binding_path, cli, db, Path(__file__)]}
items = author['items'] + author['separate_expression_groups']
runs, cache_outputs = [], {}
for old_run in baseline['runs']:
    family, encoding, mode, cache = [old_run[k] for k in ['family', 'encoding', 'mode', 'cache_bytes']]
    groups = ['\n'.join(item['complete_original_group']) if family == 'complete-original-source' else item['surface'] for item in items]
    text = unicodedata.normalize(encoding, ('\n' if family == 'complete-original-source' else ' ').join(groups))
    raw = text.encode()
    assert digest(raw) == old_run['input_sha256']
    flags = ['--dict-only'] if mode == 'headword' else ['--dict-compatible'] if mode == 'compatible' else []
    command = [str(cli), 'text', '-', '--dictionary', str(db), *flags, '--cache-bytes', str(cache)]
    result = subprocess.run(command, cwd=root, input=raw, capture_output=True)
    assert result.returncode == 0 and not result.stderr
    current = [json.loads(line) for line in result.stdout.splitlines()]
    previous = [json.loads(line) for line in old_run['jsonl'].splitlines()]
    assert len(current) == len(previous) == old_run['records']
    changed, preserved, added, cursor = [], 0, 0, 0
    for index, (old, new) in enumerate(zip(previous, current, strict=True)):
        assert all(old[key] == new[key] for key in ['surface', 'span', 'kind'])
        assert new['span']['start'] == cursor and raw[cursor:new['span']['end']].decode() == new['surface']
        cursor = new['span']['end']
        old_paths = (old.get('analysis') or {}).get('analyses', [])
        new_paths = (new.get('analysis') or {}).get('analyses', [])
        assert [path for path in new_paths if path in old_paths] == old_paths
        for old_index, path in enumerate(old_paths):
            assert old['dictionary']['readings'][old_index] == new['dictionary']['readings'][new_paths.index(path)], 'every original Native assessment'
        additions = [path for path in new_paths if path not in old_paths]
        assert all('ending.willingness_question' in path['rules'] for path in additions)
        preserved += len(old_paths)
        added += len(additions)
        if old != new:
            changed.append({'record_index': index, 'before': old, 'after': new, 'new_paths': additions, 'contextual_verdict': 'unjudged'})
    assert cursor == len(raw)
    observations = []
    for old, item in zip(old_run['observations'], items, strict=True):
        record = current[old['record_index']]
        assert record['surface'] == unicodedata.normalize(encoding, item['surface'])
        paths = record['analysis']['analyses']
        if 'typed_target' in item:
            target = item['typed_target']
            indices = [index for index, path in enumerate(paths) if [h['text'] for h in path['lemmas']] == target['lemmas'] and [h['kind'] for h in path['lemmas']] == target['lemma_kinds'] and [m['form'] for m in path['morphemes']] == target['morphemes'] and [m['kind'] for m in path['morphemes']] == target['morpheme_kinds'] and 'ending.willingness_question' in path['rules']]
            assert indices, ('independent original ending target missing', item['id'], mode)
            observations.append({'id': item['id'], 'record_index': old['record_index'], 'typed_path_indices': indices})
        else:
            observations.append({'id': item['id'], 'record_index': old['record_index'], 'morphological_judgment': 'unjudged; ending semantic ownership not assigned'})
    key = (family, encoding, mode)
    if key in cache_outputs:
        assert cache_outputs[key] == result.stdout, 'cache must preserve every ordered output byte'
    else:
        cache_outputs[key] = result.stdout
    runs.append({'family': family, 'encoding': encoding, 'mode': mode, 'cache_bytes': cache,
                 'command': command, 'exit_code': result.returncode, 'input_sha256': digest(raw),
                 'records': len(current), 'jsonl': result.stdout.decode(), 'jsonl_sha256': digest(result.stdout),
                 'before_jsonl_sha256': old_run['jsonl_sha256'], 'original_bytes_conserved': True,
                 'original_paths_preserved': preserved, 'new_family_paths': added,
                 'changed_frames': changed, 'observations': observations})
    print(family, encoding, mode, cache, len(current), 'frames;', added, 'new paths', flush=True)
assert len(runs) == 24 and all(sha(path) == expected for path, expected in frozen.items())
report = {'state': 'complete-original-source-stream-comparison-passed', 'runs': runs,
          'frozen_inputs': frozen, 'inputs_unchanged': True,
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
          'scope': 'All18 original groups and standalone targets, all24NFC/NFD/raw/headword/compatible/cache streams. Ten independently authored ending paths are required; eight expression semantic/morphological judgments remain separate and unjudged. Every original byte, candidate and Native assessment is preserved. All new paths are tagged and every changed frame retained without refreshing baseline output. Wider/corpus/novel/installed/browser/performance/contextual and independent review remain separate.'}
out.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
print('All original source streams passed')
