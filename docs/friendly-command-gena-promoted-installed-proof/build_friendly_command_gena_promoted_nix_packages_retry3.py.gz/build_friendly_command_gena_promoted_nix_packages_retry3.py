"""Materialize and bind all packages after the complete promoted Nix gate passes."""
import datetime
import gzip
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-command-gena'
OUT = P / 'friendly-command-gena-promoted-nix-packages.json'
LOG = P / 'friendly-command-gena-promoted-nix-packages.log'
RELEASE = P / 'friendly-command-gena-promoted-release-rust.log'
BUILD = Path('/var/tmp/klem-friendly-command-gena-promoted-nix-build')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=W)


def main():
    assert not OUT.exists() and not LOG.exists() and not RELEASE.exists()
    gate_path = P / 'friendly-command-gena-promoted-completed-nix-output-audit.json'
    gate = json.loads(gate_path.read_bytes())
    assert gate['state'] == 'passed' and len(gate['outputs']) == 4
    assert gate['selected_controls'] == 214
    assert gate['original_wrapper_state']=='failed' and gate['original_wrapper_failure_preserved'] and gate['Nix_build_replays']==0
    assert gate['expected_output_types']==['directory','directory','directory','empty-file']
    assert all(gate[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged'])
    assert not git('status', '--porcelain')
    names = git('ls-files', '-z').decode().split('\0')[:-1]
    frozen = {name: sha((W / name).read_bytes()) for name in names}
    assert frozen == gate['frozen_inputs']
    head, index = git('rev-parse', 'HEAD').decode().strip(), sha(git('ls-files', '--stage', '-z'))
    assert head == gate['head'] and index == gate['index_sha256']
    protected = gate['protected_binaries']
    assert len(protected) == 6 and all(sha(Path(name).read_bytes()) == digest for name, digest in protected.items())
    old_manifest_path = W / 'docs/friendly-command-gena-installed-proof-archive.json'
    old_manifest = json.loads(old_manifest_path.read_bytes())
    assert sha(old_manifest_path.read_bytes()) == '545fbd3cc756746e5afadf12f5c5008e96fe4fc70de63452b441b51252764c8e'
    row = old_manifest['files']['friendly-command-gena-installed-runtime.json.gz']
    packed = (W / 'docs' / row['path']).read_bytes()
    assert sha(packed) == row['archive_sha256']
    payload = gzip.decompress(packed)
    assert sha(payload) == row['source_sha256']
    old_installed = json.loads(gzip.decompress(payload))
    assert old_installed['state'] == 'passed'
    BUILD.mkdir(exist_ok=True); BUILD.chmod(0o1777)
    env = dict(os.environ, TMPDIR=str(BUILD), PYTHONDONTWRITEBYTECODE='1')
    flake = 'git+file://' + str(W)
    command = ['nix', 'build', '--offline', '--option', 'auto-optimise-store', 'true', '--option', 'build-dir', str(BUILD), '--cores', '4', '--max-jobs', '1', '--no-link', '--print-out-paths', '-L'] + [flake + '#packages.x86_64-linux.' + name for name in ['klem', 'web-assets', 'corpus-adapter', 'web']]
    r = dict(state='running', head=head, index_sha256=index, frozen_inputs=frozen,
             protected_binaries=protected, complete_gate_sha256=sha(gate_path.read_bytes()),
             command=command, profiles=gate['compiled_source_profiles'],
             original_installed_manifest_sha256=sha(old_manifest_path.read_bytes()),
             original_installed_payload_sha256=sha(payload),
             original_executable_evidence='Complete immutable historical installed receipt fingerprints; no historical executable live-read claim.',
             producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
             started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             scope='Actual committed35764/520 complete four-check prerequisite, then allfour current packages, full original current release Rust log and complete1146/1146/18 source closures. Fresh installed executable/asset/launcher measurements compared with pinned complete historical installed evidence. Does not itself execute current installed CLI/cohort/gold/broad/browser/performance replays or prove main/context/register/Korean review completion.')
    def save(): OUT.write_text(json.dumps(r, indent=2) + '\n')
    save()
    try:
        with LOG.open('xb') as log:
            log.write(('COMMAND ' + json.dumps(command) + '\n').encode()); log.flush()
            job = subprocess.run(command, cwd=W, env=env, stdout=subprocess.PIPE, stderr=log)
            outputs = job.stdout.decode().splitlines()
            r.update(exit_code=job.returncode, stdout=job.stdout.decode(), outputs=outputs); save()
            assert job.returncode == 0 and len(outputs) == 4
            assert all(path.startswith('/nix/store/') and Path(path).is_dir() for path in outputs)
            packages = {}
            for output in outputs:
                name = next(name for name in ['klem-web-assets', 'klem-corpus-adapter', 'klem-web', 'klem'] if Path(output).name.endswith('-' + name + '-0.1.0') or Path(output).name.endswith('-' + name))
                assert name not in packages
                packages[name] = output
            assert set(packages) == {'klem', 'klem-web-assets', 'klem-corpus-adapter', 'klem-web'}
            release_command = ['nix', 'log', flake + '#packages.x86_64-linux.klem']
            log.write(('COMMAND ' + json.dumps(release_command) + '\n').encode()); log.flush()
            capture = subprocess.run(release_command, cwd=W, env=env, stdout=subprocess.PIPE, stderr=log)
            RELEASE.write_bytes(capture.stdout)
            r.update(release_log_command=release_command, release_log_exit_code=capture.returncode, release_log_sha256=sha(capture.stdout)); save()
            assert capture.returncode == 0
            plain_log = re.sub(rb'\x1b\[[0-?]*[ -/]*[@-~]', b'', capture.stdout)
            batches = re.findall(rb'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', plain_log, flags=re.M)
            totals = {key: sum(int(batch[i + 1]) for batch in batches) for i, key in enumerate(['passed', 'failed', 'ignored'])}
            assert totals == dict(passed=1200, failed=0, ignored=1) and len(batches) == 255 and all(batch[0] == b'ok' for batch in batches)
            assert b'Doc-tests klem' in plain_log and b'test src/lib.rs - (line 3) ... ok' in plain_log
            binaries = {name: dict(path=packages[owner] + '/bin/' + binary) for name, owner, binary in [
                ('klem', 'klem', 'klem'), ('server', 'klem', 'klem-web'), ('adapter', 'klem-corpus-adapter', 'klem-corpus-adapter'), ('launcher', 'klem-web', 'klem-web'),
            ]}
            for name, value in binaries.items():
                path = Path(value['path'])
                assert path.is_file() and os.access(path, os.X_OK)
                value.update(sha256=sha(path.read_bytes()), previous_captured_sha256=old_installed['binaries'][name]['sha256'])
                value['matches_original_captured_bytes'] = value['sha256'] == value['previous_captured_sha256']
            assets = Path(packages['klem-web-assets']) / 'share/klem-web'
            asset_files = {str(path.relative_to(assets)): sha(path.read_bytes()) for path in assets.rglob('*') if path.is_file()}
            assert asset_files == old_installed['assets'], 'complete immutable frontend assets preserved'
            launcher = Path(binaries['launcher']['path']).read_text()
            assert binaries['server']['path'] in launcher and str(assets) in launcher
            assert '"$@"' in launcher and '--assets' in launcher
            for name, profile in r['profiles'].items():
                prefix = 'web/' if name == 'klem-web-assets' else ''
                assert all(frozen[prefix + path] == digest for path, digest in profile['files'].items())
                prior = old_installed['profiles'][name]['files']
                changes = {path for path in set(prior) | set(profile['files']) if prior.get(path) != profile['files'].get(path)}
                assert changes == (set() if prefix else {'tests/fixtures/validity.json', 'tests/validity.rs'})
            r.update(state='passed', packages=packages, binaries=binaries, assets=asset_files,
                     release_rust=dict(totals=totals, batches=len(batches)),
                     runtime_byte_identity=all(binaries[name]['matches_original_captured_bytes'] for name in ['klem', 'server', 'adapter']),
                     frontend_byte_identity=True, launcher_bound_to_current_packages=True)
    except BaseException as error:
        r.update(state='failed', error=repr(error)); raise
    finally:
        current_names = git('ls-files', '-z').decode().split('\0')[:-1]
        r.update(inputs_unchanged=set(current_names) == set(frozen) and all(sha((W / n).read_bytes()) == d for n, d in frozen.items()),
                 head_unchanged=git('rev-parse', 'HEAD').decode().strip() == head,
                 index_unchanged=sha(git('ls-files', '--stage', '-z')) == index,
                 protected_binaries_unchanged=all(sha(Path(n).read_bytes()) == d for n, d in protected.items()),
                 log_sha256=sha(LOG.read_bytes()) if LOG.exists() else None,
                 finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
        if not all(r[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged']): r['state'] = 'failed'
        save()
    assert r['state'] == 'passed'
    print('Passed allfour actual promoted Gena packages; full release Rust:', r['release_rust'], '; measured runtime byte identity:', r['runtime_byte_identity'], flush=True)


if __name__ == '__main__': main()
