"""Build the Sena CLI/server/adapter and bind their complete production source."""
import datetime
import hashlib
import json
import os
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = Path('/home/josh/projects/klem')
W = ROOT / '.direnv/friendly-hortative-sena'
G = ROOT / '.direnv/friendly-command-gena'
T = ROOT / '.direnv/friendly-hortative-sena-target'
O = P / 'friendly-hortative-sena-complete-runtime-binding.json'
L = P / 'friendly-hortative-sena-complete-runtime-binding.log'
assert not O.exists() and not L.exists()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=W)
sha = lambda b: hashlib.sha256(b).hexdigest()
parent_path = ROOT / '.direnv/willingness-question-prepared/friendly-command-gena-complete-runtime-binding.json'
parent = json.loads(parent_path.read_bytes())
selected_path = P / 'friendly-hortative-sena-selected-source.json'
selected = json.loads(selected_path.read_bytes())
assert selected['state'] == 'passed' and all(selected[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged'])
production = selected['production_inputs']
assert len(production) == 44 and all(sha((W / n).read_bytes()) == digest for n, digest in production.items())
assert production == {n: sha((W / n).read_bytes()) for n in parent['production_inputs']}
for attr, prefix in [('klem', ''), ('corpus-adapter', ''), ('web-assets', 'web/')]:
    assert all(sha((W / (prefix + n)).read_bytes()) == digest
               for n, digest in selected['profiles'][attr]['files'].items()), 'every actual selected compile input'
assert all(sha((G / n).read_bytes()) == digest for n, digest in parent['production_inputs'].items())
protected = {v['path']: v['sha256'] for v in parent['binaries'].values()}
assert all(sha(Path(path).read_bytes()) == digest for path, digest in protected.items())
names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=W).decode().split('\0')[:-1]
frozen = {n: sha((W / n).read_bytes()) for n in names}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
index = sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=W))
external = {str(path): sha(path.read_bytes()) for path in [Path(__file__), parent_path, selected_path]}
env = dict(os.environ, CARGO_TARGET_DIR=str(T), CARGO_PROFILE_DEV_DEBUG='0',
           CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='4')
commands = [['cargo', 'build', '--locked', '--offline', '--features', 'web', '--bins', '--example', 'evaluate']]
r = dict(state='running', head=head, index_sha256=index, frozen_inputs=frozen, external_inputs=external,
         production_inputs=production, parent_production_inputs=parent['production_inputs'],
         compiled_profiles=selected['profiles'],
         declared_production_changes=selected['declared_production_changes'],
         frontend_inputs={('web/' + n): digest for n, digest in selected['profiles']['web-assets']['files'].items()},
         protected_parent_binaries=protected, results=[],
         producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Actual isolated current Sena debug CLI/server/corpus-adapter build; all44 production inputs checked against actual selected compiled sources, five explicit changes from original Gena source, frontend18 inputs and every Source/HEAD/index frozen. Does not claim full Rust, history/gold/broad/browser, installed Nix, main, timing or contextual review completion.')

def save():
    O.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')

save()
try:
    with L.open('xb') as log:
        for command in commands:
            log.write(('COMMAND ' + json.dumps(command) + '\n').encode())
            log.flush()
            job = subprocess.run(command, cwd=W, env=env, stdout=log, stderr=subprocess.STDOUT)
            r['results'].append(dict(command=command, exit_code=job.returncode))
            save()
            assert job.returncode == 0, 'actual runtime build failed'
    r['binaries'] = {name: dict(path=str(path), sha256=sha(path.read_bytes())) for name, path in [
        ('klem', T / 'debug/klem'), ('server', T / 'debug/klem-web'), ('adapter', T / 'debug/examples/evaluate')]}
    r['state'] = 'passed'
except BaseException as error:
    r.update(state='failed', error=repr(error))
    raise
finally:
    r.update(inputs_unchanged=all(sha((W / n).read_bytes()) == digest for n, digest in frozen.items()),
             external_inputs_unchanged=all(sha(Path(path).read_bytes()) == digest for path, digest in external.items()),
             parent_production_unchanged=all(sha((G / n).read_bytes()) == digest for n, digest in parent['production_inputs'].items()),
             protected_parent_binaries_unchanged=all(sha(Path(path).read_bytes()) == digest for path, digest in protected.items()),
             head_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip() == head,
             index_unchanged=sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=W)) == index,
             log_sha256=sha(L.read_bytes()) if L.exists() else None,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['inputs_unchanged', 'external_inputs_unchanged', 'parent_production_unchanged',
                             'protected_parent_binaries_unchanged', 'head_unchanged', 'index_unchanged']):
        r['state'] = 'failed'
    save()
assert r['state'] == 'passed'
print('Passed actual Sena CLI/server/adapter binding:44 production inputs and18 frontend inputs;', len(frozen), 'frozen source files.', flush=True)
