"""Preserve existing training evidence for the known surname-owner coverage gap."""
import hashlib,json,sqlite3,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');source=ROOT/'data/corpora/kaist/ko_kaist-ud-train.conllu';readme=ROOT/'data/corpora/kaist/README.md';license_path=ROOT/'data/corpora/kaist/LICENSE.txt';out=Path('/tmp/klem-surname-corpus-preparation.json');assert not out.exists()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
raw=source.read_text();observations=[]
for block in raw.strip().split('\n\n'):
 lines=block.splitlines();ids=[line.removeprefix('# sent_id = ') for line in lines if line.startswith('# sent_id = ')]
 rows=[line.split('\t') for line in lines if not line.startswith('#')]
 for row in rows:
  if len(row)==10 and row[1:5]==['박','박','PROPN','nq']:
   assert len(ids)==1
   observations.append({'id':'kaist-training-surname-park-'+ids[0]+'-'+row[0],'sentence_id':ids[0],'token_id':row[0],'original_row':row,'complete_original_sentence':block,'source_partition':'train','lexical_verdict':'The original training row marks standalone 박 as a proper noun; its following title is retained in the complete context. This does not establish every meaning of 박 or contextual correctness of arbitrary joined strings.'})
assert len(observations)==5
native={}
with sqlite3.connect((ROOT/'data/dictionaries/krdict/krdict.db').resolve().as_uri()+'?mode=ro',uri=True) as db:
 for ident,value in db.execute('SELECT id,data FROM entries WHERE headword=?',('박',)):native[ident]=json.loads(value)
 bound=json.loads(db.execute('SELECT data FROM entries WHERE id=?',('krdict:62835',)).fetchone()[0])
source_sense=next(s for s in bound['senses'] if s['id']=='3');assert any('박 선생님 것' in line for group in source_sense['examples'] for line in group)
cli='/nix/store/mfd8vyfqgmcbz0ns6jg05vglkzz7ldi4-klem-0.1.0/bin/klem';command=[cli,'word','박선생님것','--dictionary',str(ROOT/'data/dictionaries/krdict/krdict.db'),'--suggest-spacing'];job=subprocess.run(command,capture_output=True,check=True);assert not job.stderr
r={'state':'surname-evidence-prepared-runtime-gap-open','checklist':'COV-020u','unchanged_original_requirement':'박선생님것 → 박 선생님 것','observations':observations,'complete_native_same_head_entries':native,'complete_native_bound_noun_entry':bound,'actual_current_cli':{'command':command,'record':json.loads(job.stdout),'stdout_sha256':hashlib.sha256(job.stdout).hexdigest()},'source_files':{str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in [source,readme,license_path]},'corpus_metadata':{'url':'https://github.com/UniversalDependencies/UD_Korean-Kaist','license':'CC BY-SA 4.0','upos':'converted from manual','xpos':'converted from manual','partition':'train'},'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'remaining':['Represent corpus-backed proper-name lexical evidence with its own identity and source, separate from unrelated same-head dictionary entries.','License the bounded surname/title/possessive template from its original source; retain the unchanged known-unmet case until actual runtime passes.','Test word/spacing/filter/Unicode behavior and preserve existing dictionary/API fields and alternatives.'],'scope':'Preparation only: five complete original training sentences and rows, exact current Native homonyms, original bound-noun source and current runtime. Existing held-out partitions are not used to construct a lexicon. No program behavior or inventory disposition changed.','full_coverage_complete':False}
out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print('Preserved five original training proper-name rows; original surname requirement remains open.')
