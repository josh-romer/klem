"""Keep a durable outer record, including failures before the inner receipt exists."""
import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

P = Path(__file__).resolve().parent
producer = P / 'run_friendly_hortative_sena_sandbox_controls.py'
expression = P / 'friendly-hortative-sena-sandbox-controls.nix'
output = P / 'friendly-hortative-sena-sandbox-retry1.json'
log = P / 'friendly-hortative-sena-sandbox-retry1.log'
failure = P / 'friendly-hortative-sena-sandbox-first-preflight-failure.json'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert not output.exists() and not log.exists() and not failure.exists()
assert not (P / 'friendly-hortative-sena-sandbox-controls.json').exists()
assert not (P / 'friendly-hortative-sena-sandbox-controls.log').exists()
failure.write_text(json.dumps(dict(
    state='failed-before-inner-receipt', actual_session=3664, exit_code=1,
    producer=dict(text=producer.read_text(), sha256=sha(producer.read_bytes())),
    expression=dict(text=expression.read_text(), sha256=sha(expression.read_bytes())),
    observed_terminal_excerpt="database or disk is full ... /home/josh/.cache/nix/fetcher-cache-v1.sqlite; nix eval --offline --raw git+file:///home/josh/projects/klem/.direnv/friendly-hortative-sena#checks.x86_64-linux.inventory-review.src returned non-zero exit status 1",
    observation_scope='Terminal failure and excerpt retained from tool observation; full original terminal output is unavailable. Preflight failed before receipt/log creation. No sandbox tests ran; this is not a test failure or a passing run.'
), indent=2) + '\n')
r = dict(state='running', command=[sys.executable, str(producer)],
         producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
         original_failure_sha256=sha(failure.read_bytes()),
         inner_producer_sha256=sha(producer.read_bytes()),
         expression_sha256=sha(expression.read_bytes()),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
def save():
    output.write_text(json.dumps(r, indent=2) + '\n')
save()
try:
    with log.open('xb') as stream:
        job = subprocess.run(r['command'], stdout=stream, stderr=subprocess.STDOUT)
    r.update(exit_code=job.returncode, state='passed' if job.returncode == 0 else 'failed')
finally:
    r.update(log_sha256=sha(log.read_bytes()) if log.exists() else None,
             inner_producer_unchanged=sha(producer.read_bytes()) == r['inner_producer_sha256'],
             expression_unchanged=sha(expression.read_bytes()) == r['expression_sha256'],
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    receipt = P / 'friendly-hortative-sena-sandbox-controls.json'
    if receipt.exists():
        r['inner_receipt_sha256'] = sha(receipt.read_bytes())
        r['inner_state'] = json.loads(receipt.read_bytes())['state']
    if not r['inner_producer_unchanged'] or not r['expression_unchanged']:
        r['state'] = 'failed'
    save()
assert r['state'] == 'passed' and r['inner_state'] == 'passed'
print('Actual sandbox retry passed; original preflight failure kept separately.', flush=True)
