import copy,gzip,hashlib,json,sqlite3,sys
from pathlib import Path
root=Path('/home/josh/projects/klem');sys.path.insert(0,str(root/'tools'))
from native_lmf import array,entry,feature,verify_native_lmf
previous_path=root/'docs/predicate-auxiliary-spacing-owner-native-closure.json.gz';previous=json.load(gzip.open(previous_path,'rt'));db_path=root/'data/dictionaries/krdict/krdict.db';con=sqlite3.connect(db_path.resolve().as_uri()+'?mode=ro',uri=True)
heads=['것','수','줄','바','적','지','듯','뿐','대로','만큼','때문','따름'];native=copy.deepcopy(previous['complete_native_entries'])
for head in heads:
 for ident,raw in con.execute('select id,data from entries where headword=?',(head,)):native[ident]=json.loads(raw)
ids={i.split(':')[1] for i in native};original={};exports={}
sha=lambda raw:hashlib.sha256(raw).hexdigest()
for p in sorted((root/'data/dictionaries/krdict/json').glob('*.json')):
 raw=p.read_bytes();exports[str(p)]={'sha256':sha(raw),'bytes':len(raw)}
 for value in array(json.loads(raw)['LexicalResource']['Lexicon'].get('LexicalEntry')):
  if value.get('val') not in ids:continue
  projected=entry(value);ident=projected['id']
  if ident not in native:continue
  assert projected==native[ident];assert ident not in original;original[ident]=value
assert set(original)==set(native)
assert all(native[i]==e and original[i]==previous['original_lmf'][i] for i,e in previous['complete_native_entries'].items())
projection=copy.deepcopy(list(original.values()))
for value in projection:
 for sense in array(value.get('Sense')):sense['Equivalent']=[v for v in array(sense.get('Equivalent')) if feature(v,'language')=='영어']
lmf={'LexicalResource':{'Lexicon':{'LexicalEntry':projection}}};verify_native_lmf(lmf,native)
out=Path('/tmp/klem-bound-noun-spacing-native-closure.json.gz');assert not out.exists()
report={'state':'passed-preparation-only','previous_entries':105,'heads':heads,'complete_native_entries':native,'original_lmf':original,'english_projection':lmf,'source_exports':exports,'dictionary_sha256':sha(db_path.read_bytes()),'previous_capture_sha256':sha(previous_path.read_bytes()),'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'scope':'Complete same-head Native and original LMF closure for twelve proposed bound-noun profiles. All previous105entries unchanged. Structural/runtime/main/Nix/contextual review remains separate.'}
out.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
p=Path('/tmp/klem-bound-noun-spacing-prototype/tests/fixtures/bound-noun-spacing-native.json');assert not p.exists();p.write_text(json.dumps(lmf,ensure_ascii=False,indent=2)+'\n')
print('Closed',len(native),'complete entries; previous105preserved; originalLMF/SQLite/English projection exact.')
