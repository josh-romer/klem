"""Bind actual Nix sources and compare installed outputs with complete captures."""
import datetime
import gzip
import hashlib
import json
import re
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-gentle-command')
ROOT = PREP.parents[1]
OUT = PREP / 'gentle-command-installed-runtime.json.gz'
PROGRESS = PREP / 'gentle-command-installed-runtime-progress.json'
PACKAGE = PREP / 'gentle-command-nix-packages-retry2.json'
DB = ROOT / '.direnv/dictionary-restoration/krdict.db'
assert not OUT.exists() and not PROGRESS.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
load = lambda name: json.loads(gzip.decompress((PREP / name).read_bytes()) if name.endswith('.gz') else (PREP / name).read_bytes())
package = json.loads(PACKAGE.read_bytes())
assert package['state'] == 'passed' and all(package[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged'])
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == package['head']
assert all(sha((WORK/n).read_bytes()) == digest for n, digest in package['frozen_inputs'].items())
paths = {}
for value in package['outputs']:
    name = next(n for n in ['klem-web-assets', 'klem-corpus-adapter', 'klem-web', 'klem'] if Path(value).name.endswith(n+'-0.1.0') or Path(value).name.endswith('-'+n))
    assert name not in paths
    paths[name] = value
assert set(paths) == {'klem', 'klem-web-assets', 'klem-corpus-adapter', 'klem-web'}
cli = Path(paths['klem']) / 'bin/klem'
adapter = Path(paths['klem-corpus-adapter']) / 'bin/klem-corpus-adapter'
server = Path(paths['klem']) / 'bin/klem-web'
launcher = Path(paths['klem-web']) / 'bin/klem-web'
assets = Path(paths['klem-web-assets']) / 'share/klem-web'
closure = load('gentle-command-current-production-closure.json')
profiles = {}
for name, attr, prefix in [('klem', 'klem', WORK), ('klem-corpus-adapter', 'corpus-adapter', WORK), ('klem-web-assets', 'web-assets', WORK/'web')]:
    source = Path(subprocess.check_output(['nix', 'eval', '--offline', '--raw', 'git+file://'+str(WORK)+'#packages.x86_64-linux.'+attr+'.src'], cwd=WORK, text=True).strip())
    files = {}
    for file in source.rglob('*'):
        assert not file.is_symlink()
        if not file.is_file(): continue
        rel = str(file.relative_to(source)); digest = sha(file.read_bytes())
        assert digest == sha((prefix/rel).read_bytes()), (name, rel)
        files[rel] = digest
    if name != 'klem-web-assets':
        for p, digest in closure['production_inputs'].items():
            assert files[str(Path(p).relative_to(WORK))] == digest, ('actual complete compiled closure', name, p)
    profiles[name] = dict(package=paths[name], source=str(source), files=files)
assert str(cli) in launcher.read_text() or str(Path(paths['klem'])/'bin/klem-web') in launcher.read_text()
assert str(assets) in launcher.read_text()
log = (PREP/'gentle-command-nix-packages-retry2.log').read_text()
batches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
totals = {k:sum(int(batch[i+1]) for batch in batches) for i,k in enumerate(['passed', 'failed', 'ignored'])}
assert totals == {'passed':1182, 'failed':0, 'ignored':1} and len(batches) == 253 and all(batch[0] == 'ok' for batch in batches)
frozen = {str(p):sha(p.read_bytes()) for p in [PACKAGE, DB, cli, adapter, server, launcher, Path(__file__)]}
for p in assets.rglob('*'):
    if p.is_file(): frozen[str(p)] = sha(p.read_bytes())
r = dict(state='running', captured_head=package['head'], profiles=profiles,
         packages=paths, binaries={n:dict(path=str(p), sha256=frozen[str(p)]) for n,p in [('klem',cli),('adapter',adapter),('server',server),('launcher',launcher)]},
         assets={str(p.relative_to(assets)):sha(p.read_bytes()) for p in assets.rglob('*') if p.is_file()},
         release_rust=dict(totals=totals,batches=len(batches)), frozen_inputs=frozen,
         source_runs=[], native_records=[], corpus_runs=[], broad_runs=[],
         producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
         scope='Actual installed current-source four Nix packages, full release Rust,36source Unicode/filter/cache streams,47completeNativeowners,66570originalannotatedrows and1128312broadframes compared byte-for-byte or whole-stream SHA against preserved audited current-debug outputs. Original judgments and contextual scope unchanged; full inventory/main/browser/quiet performance and independent review remain separate.')
def save():
    PROGRESS.write_text(json.dumps({k:v for k,v in r.items() if k not in ['source_runs','native_records','corpus_runs','broad_runs']},ensure_ascii=False,indent=2)+'\n')
    OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False)+'\n').encode(),mtime=0))
save()
try:
    for report_name, field in [('gentle-command-source-runtime.json.gz','source_runs'), ('gentle-command-native-cli.json','native_records'), ('gentle-command-corpora.json.gz','corpus_runs'), ('gentle-command-broad.json.gz','broad_runs')]:
        report_path = PREP/report_name; frozen[str(report_path)] = sha(report_path.read_bytes())
        report = load(report_name)
        rows = report['records'] if field == 'native_records' else report['runs']
        for row in rows:
            original_command = row['captures'][1]['command'] if field == 'native_records' else row['commands'][1] if field == 'broad_runs' else row['command']
            command = [str(adapter if field == 'corpus_runs' else cli), *original_command[1:]]
            if field == 'broad_runs':
                original = Path(row['actual_source']).read_bytes(); frozen[row['actual_source']] = sha(original)
                assert sha(original) == row['source_sha256']
                job = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                digest = hashlib.sha256(); cursor = count = 0; changes = []
                for line in job.stdout:
                    digest.update(line); frame = json.loads(line)
                    assert frame['span']['start'] == cursor
                    cursor = frame['span']['end']
                    assert original[frame['span']['start']:cursor].decode() == frame['surface']
                    for change in row['changed_frames']:
                        if frame['span'] == change['after']['span']:
                            assert frame == change['after']; changes.append(change)
                    count += 1
                stderr = job.stderr.read(); code = job.wait()
                assert code == 0 and not stderr and count == row['records'] and cursor == len(original)
                assert digest.hexdigest() == row['after_jsonl_sha256'] and changes == row['changed_frames']
                record = dict(mode=row['mode'],command=command,exit_code=code,records=count,stdout_sha256=digest.hexdigest(),source_sha256=sha(original),original_bytes_conserved=True,changed_frames=changes)
            else:
                job = subprocess.run(command, cwd=ROOT, input=row['input_text'].encode() if field == 'source_runs' else None, capture_output=True)
                expected = row['captures'][1]['json'] if field == 'native_records' else row['jsonl']
                assert job.returncode == 0 and not job.stderr and job.stdout.decode() == expected, (field,command)
                record = dict(original_capture=row, command=command, exit_code=job.returncode, stdout=job.stdout.decode(), stdout_sha256=sha(job.stdout))
            r[field].append(record); save()
        print('Installed complete',field,len(r[field]),flush=True)
    r.update(inputs_unchanged=all(sha(Path(p).read_bytes()) == digest for p,digest in frozen.items()),
             source_unchanged=all(sha((WORK/n).read_bytes()) == digest for n,digest in package['frozen_inputs'].items()),
             head_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip() == package['head'],
             index_unchanged=sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=WORK)) == package['index_sha256'],
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    assert all(r[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged'])
    assert [len(r[f]) for f in ['source_runs','native_records','corpus_runs','broad_runs']] == [36,47,4,8]
    r['state'] = 'passed'; save()
except Exception as error:
    r.update(state='failed',error=str(error));save();raise
print('Passed actual installed Nix36source/47Native/66570gold/1128312broad checks; original candidates and judgments unchanged.',flush=True)
