"""Preserve both complete original additive-ending LMF entries and verify SQLite/import projections."""
import copy, datetime, gzip, hashlib, json, mmap, re, sqlite3, sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from native_lmf import array, entry, feature, verify_native_lmf
sha=lambda raw:hashlib.sha256(raw).hexdigest()
OUT=Path('/tmp/klem-additive-ppundeoreo-native-preparation.json.gz');assert not OUT.exists()
discovery_path=Path('/tmp/klem-additive-ppundeoreo-source-discovery.json.gz')
discovery=json.loads(gzip.decompress(discovery_path.read_bytes()));native=discovery['sqlite_entries']
ids={i.split(':')[1] for i in native};original={};sources={};global_information={}
for p in sorted((ROOT/'data/dictionaries/krdict/json').glob('*.json')):
    with p.open('rb') as stream, mmap.mmap(stream.fileno(),0,access=mmap.ACCESS_READ) as mapped:
        if not any(re.search(rb'"val"\s*:\s*"'+i.encode()+rb'"',mapped) for i in ids):continue
        raw=mapped[:]
    data=json.loads(raw);lexicon=data['LexicalResource']['Lexicon']
    selected=[v for v in array(lexicon.get('LexicalEntry')) if v.get('att')=='id' and v.get('val') in ids]
    if not selected:continue
    sources[str(p)]={'sha256':sha(raw),'bytes':len(raw)}
    global_information[str(p)]=data['LexicalResource'].get('GlobalInformation')
    for value in selected:
        ident='krdict:'+value['val'];assert ident not in original
        assert entry(value)==native[ident],ident
        original[ident]=value
assert set(original)==set(native)=={'krdict:74341','krdict:74021'}
projected=copy.deepcopy(list(original.values()))
for value in projected:
    for sense in array(value.get('Sense')):
        sense['Equivalent']=[v for v in array(sense.get('Equivalent')) if feature(v,'language')=='영어']
lmf={'LexicalResource':{'Lexicon':{'LexicalEntry':projected}}};verify_native_lmf(lmf,native)
for p,v in sources.items():assert sha(Path(p).read_bytes())==v['sha256']
assert sha(discovery_path.read_bytes())==sha(gzip.compress(gzip.decompress(discovery_path.read_bytes()),mtime=0))
producer=Path(__file__)
r={'state':'passed','preparation_only':True,'source_entries':native,'original_lmf':original,
   'english_projection':lmf,'source_exports':sources,'source_global_information':global_information,
   'discovery_sha256':sha(discovery_path.read_bytes()),'inputs_unchanged':True,
   'producer':{'text':producer.read_text(),'sha256':sha(producer.read_bytes())},
   'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
   'scope':'Both complete original Native LMF entries, their exact SQLite equality and English projection are preserved. This does not certify owner closure, rule boundaries, production import behavior, broad preservation, context, precision or independent review.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Both complete original Native entries match SQLite and the English projection; all10 original groups retained.',flush=True)
