"""Author original-source and attachment targets without consulting engine output."""
import gzip
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
PREP = BASE / 'formal-volitional-prepared'
sys.path.insert(0, '/home/josh/projects/klem/tools')
from native_lmf import entry, feature

sha = lambda raw: hashlib.sha256(raw).hexdigest()
prepared = json.loads(gzip.decompress((PREP / 'source-preparation.json.gz').read_bytes()))
cases = []


def case(ident, surface, lemmas, prefinals, canonical, owner, verdict='required', kinds=None, extra=()):
    cases.append({'id': ident, 'surface': surface, 'judgments': [{
        'id': 'path', 'lemmas': lemmas, 'lemma_kinds': kinds or ['predicate'],
        'morphemes': [*prefinals, canonical],
        'morpheme_kinds': ['prefinal'] * len(prefinals) + ['ending'],
        'required_rules': ['ending.formal_volitional', *extra],
        'verdict': verdict, 'source': owner,
        'reason': (
            'Independent structural target from the complete original ending example or a named attachment boundary. Question and statement source owners remain separate. The canonical full form represents its short/full allomorph pair. Contextual sense selection and unrelated candidates remain unjudged.'
            if verdict == 'required' else
            'The named path violates the original verb attachment, immediate short/full allomorph, or listed honorific prefinal license. This rejects this decomposition only; dictionary homonyms and unrelated alternatives remain unjudged. Known adjective and copular owners must not borrow a verb attachment license.'
        )}]})


for proposal in prepared['independent_proposals']:
    case(proposal['id'], proposal['surface'], proposal['proposed_lemmas'],
         proposal['proposed_morphemes'][:-1], proposal['proposed_morphemes'][-1],
         proposal['source_entry_id'])

positive = [
    ('open', '가', ['가다'], [], 'short', []),
    ('closed', '먹으', ['먹다'], [], 'full', []),
    ('rieul', '살', ['살다'], [], 'short', []),
    ('cluster', '읽으', ['읽다'], [], 'full', []),
    ('honorific', '먹으시', ['먹다'], ['시'], 'short', []),
    ('digeut-irregular', '들으', ['듣다'], [], 'full', ['irregular.digeut']),
    ('bieup-irregular', '도우', ['돕다'], [], 'full', ['irregular.bieup']),
    ('siot-irregular', '지으', ['짓다'], [], 'full', ['irregular.siot']),
]
negative = [
    ('closed-short', '먹', ['먹다'], [], 'short', ['predicate']),
    ('open-full', '가으', ['가다'], [], 'full', ['predicate']),
    ('rieul-full', '살으', ['살다'], [], 'full', ['predicate']),
    ('cluster-short', '읽', ['읽다'], [], 'short', ['predicate']),
    ('past', '먹었으', ['먹다'], ['었'], 'full', ['predicate']),
    ('modal', '먹겠으', ['먹다'], ['겠'], 'full', ['predicate']),
    ('retrospective', '먹더', ['먹다'], ['더'], 'short', ['predicate']),
    ('copula', '학생이', ['학생', '이다'], [], 'short', ['nominal', 'copula']),
    ('negative-copula', '아니', ['아니다'], [], 'short', ['predicate']),
    ('adjective', '좋으', ['좋다'], [], 'full', ['predicate']),
    ('nominal', '학생으', ['학생'], [], 'full', ['nominal']),
    ('honorific-adjective', '좋으시', ['좋다'], ['시'], 'short', ['predicate']),
    ('honorific-copula', '학생이시', ['학생', '이다'], ['시'], 'short', ['nominal', 'copula']),
]
for style, tail, short_id, full_id in [
    ('question', '렵니까', 'krdict:86548', 'krdict:86604'),
    ('statement', '렵니다', 'krdict:86549', 'krdict:86605'),
]:
    canonical = '으' + tail
    for ident, stem, lemmas, prefinals, allomorph, extra in positive:
        case(f'formal-volitional-{style}-boundary-{ident}', stem + tail,
             lemmas, prefinals, canonical, short_id if allomorph == 'short' else full_id,
             extra=extra)
    for ident, stem, lemmas, prefinals, allomorph, kinds in negative:
        case(f'formal-volitional-{style}-forbidden-{ident}', stem + tail,
             lemmas, prefinals, canonical, short_id if allomorph == 'short' else full_id,
             verdict='forbidden', kinds=kinds)

assert len(cases) == 59 and len({c['id'] for c in cases}) == 59
assert sum(j['verdict'] == 'required' for c in cases for j in c['judgments']) == 33
suite = {
    'schema_version': 1,
    'review_status': 'Independent original-source and named immediate attachment judgments authored before implementation. Other candidates, contextual homonyms, wider distributions and independent linguistic review remain open.',
    'sources': {ident: owner['url'] for ident, owner in prepared['expression_entries'].items()},
    'cases': cases,
}
suite_path = PREP / 'formal-volitional-validity.json'
assert not suite_path.exists()
suite_path.write_text(json.dumps(suite, ensure_ascii=False, indent=2) + '\n')
db = sqlite3.connect((BASE / 'dictionary-restoration/krdict.db').resolve().as_uri() + '?mode=ro', uri=True)
needed = set(prepared['complete_imported_entries'])
for headword in {lemma for c in cases for j in c['judgments'] for lemma in j['lemmas']}:
    for ident, raw in db.execute('select id,data from entries where headword=?', (headword,)):
        if json.loads(raw)['lexical_unit'] == '단어':
            needed.add(ident)
expected = {i: json.loads(db.execute('select data from entries where id=?', (i,)).fetchone()[0]) for i in sorted(needed)}
originals = dict(prepared['original_native_entries'])
exports = {}
for path in sorted((BASE / 'dictionary-restoration/2026-09').glob('*.json')):
    raw = path.read_bytes()
    selected = []
    for value in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
        ident = 'krdict:' + value['val']
        if ident not in needed or ident in originals or feature(value, 'lexicalUnit') in {'관용구', '속담'}:
            continue
        assert entry(value) == expected[ident], ident
        originals[ident] = value
        selected.append(ident)
    if selected:
        exports[path.name] = {'bytes': len(raw), 'sha256': sha(raw), 'ids': selected}
assert set(originals) == needed and {ident: entry(value) for ident, value in originals.items()} == expected
closure = {
    'state': 'complete-independent-source-and-boundary-native-closure-before-implementation',
    'initial_preparation_sha256': sha((PREP / 'source-preparation.json.gz').read_bytes()),
    'entries': expected, 'original_native_entries': originals, 'additional_exports': exports,
    'authored_validity_sha256': sha(suite_path.read_bytes()),
    'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())},
}
(PREP / 'authored-native-closure.json.gz').write_bytes(gzip.compress((json.dumps(closure, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
(PREP / 'independent-authoring.json').write_text(json.dumps({
    'state': 'authored-before-implementation', 'cases': 59, 'required': 33, 'forbidden': 26,
    'suite_sha256': sha(suite_path.read_bytes()), 'native_owners': len(originals),
    'complete_original_groups': 17,
    'scope': 'No engine output or verdict was consulted while authoring these targets. All original statement/question and short/full licenses are retained. Adjective/copular negative targets also cover honorific attachment. Spoken pronunciation notes remain original evidence; they are not silently rewritten as new spelling targets.',
}, indent=2) + '\n')
print('Authored 59 cases: 33 required / 26 forbidden;', len(originals), 'complete Native owners before implementation', flush=True)
