"""Bind all original broad streams to the actual installed integration CLI."""

import gzip
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
PACKAGE = ROOT / '.direnv/fear-lsera-prepared/installed-source-binding.json'
SOURCE = ROOT / '.direnv/fear-lsera-integration/docs/fear-lsera-broad.json.gz'
OUT = ROOT / '.direnv/fear-lsera-installed-validation/installed-broad.json.gz'
DB = ROOT / 'data/dictionaries/krdict/krdict.db'
assert not OUT.exists()


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


package = json.loads(PACKAGE.read_bytes())
assert package['state'] == 'passed' and package['exit_code'] == 0
assert package['inputs_unchanged'] and package['head_unchanged'] and package['index_unchanged']
cli = Path(next(p for p in package['outputs'] if p.endswith('-klem-0.1.0'))) / 'bin/klem'
previous = json.loads(gzip.decompress(SOURCE.read_bytes()))
frozen = {str(p): sha(p) for p in [PACKAGE, SOURCE, cli, DB, Path(__file__)]}
runs = []
for capture in previous['comparisons']:
    original_source = capture['source']
    source = ROOT / '.direnv/reported-installed-validation/broad-inputs' / Path(original_source).name
    source.parent.mkdir(parents=True, exist_ok=True)
    input_report = json.loads(gzip.decompress((ROOT / '.direnv/dapnikka-integration/docs/reported-deoni-broad-inputs.json.gz').read_bytes()))
    original = input_report['sources'][original_source]['text'].encode()
    if source.exists():
        assert source.read_bytes() == original
    else:
        source.write_bytes(original)
    assert sha(source) == capture['source_sha256']
    frozen[str(source)] = sha(source)
    mode = capture['mode']
    flags = ['--dict-compatible'] if 'compatible' in mode else ['--dict-only'] if 'headword' in mode else []
    command = [str(cli), 'text', str(source), '--dictionary', str(DB), *flags, *(['--suggest-spacing'] if 'spacing' in mode else [])]
    job = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE)
    digest = hashlib.sha256()
    cursor = count = 0
    try:
        for line in job.stdout:
            digest.update(line)
            count += 1
            row = json.loads(line)
            assert row['span']['start'] == cursor
            cursor = row['span']['end']
            assert original[row['span']['start']:cursor].decode() == row['surface']
        code = job.wait()
    finally:
        if job.poll() is None:
            job.terminate()
            job.wait()
    assert code == 0 and count == capture['records'] and cursor == len(original)
    assert digest.hexdigest() == capture['after_jsonl_sha256'], 'complete installed output differs'
    runs.append({'mode': mode, 'source': str(source), 'source_sha256': sha(source), 'command': command, 'exit_code': code, 'records': count, 'actual_jsonl_sha256': digest.hexdigest(), 'exact_preserved_capture': True, 'original_bytes_conserved': True})
    print(mode, count, 'exact complete installed frames', flush=True)
assert len(runs) == 8 and sum(r['records'] for r in runs) == 1128312
assert all(sha(path) == digest for path, digest in frozen.items())
report = {'state': 'complete-installed-broad-binding-passed', 'runs': runs, 'frozen_inputs': frozen, 'inputs_unchanged': True, 'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)}, 'scope': 'Actual committed installed fear-lsera CLI reproduces every byte of all eight preserved complete default-provider streams, including candidate/Native-assessment/display/spacing output. Complete finite/browser/annotated checks and quiet timings are separate; contextual and independent review remain pending.'}
OUT.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
print('Passed all 1128312 installed frames', flush=True)
