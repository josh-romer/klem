"""Replay complete preserved corpus/history word cohorts against both actual binaries."""
import gzip,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');SOURCE=ROOT/'.direnv/formal-volitional-integration/docs/formal-volitional-cohorts.json.gz';OUT=ROOT / '.direnv/formal-volitional-installed-validation/installed-cohorts.json.gz';assert not OUT.exists()
BEFORE=Path('/home/josh/projects/klem/.direnv/formal-volitional-target/debug/klem');AFTER=None
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
sys.path.insert(0,str(ROOT/'tools'));from doeda_native_corpora import words_from_cli
binding=ROOT/'.direnv/formal-volitional-prepared/installed-source-binding.json';package=json.loads(binding.read_bytes());assert package['state']=='passed';AFTER=Path(next(p for p in package['outputs'] if p.endswith('-klem-0.1.0')))/'bin/klem'
frozen={str(binding):sha(binding),**{str(p):sha(p) for p in [SOURCE,BEFORE,AFTER,Path(__file__),ROOT/'tools/doeda_native_corpora.py']}};runs=[]
for cohort in json.loads(gzip.decompress(SOURCE.read_bytes()))['runs']:
 expected=cohort['captures'][1]['words'];captures=[]
 for binary in [BEFORE,AFTER]:
  words=words_from_cli(binary,sorted(expected));assert words==expected
  captures.append({'binary':str(binary),'words':words,'word_sha256':hashlib.sha256(json.dumps(words,ensure_ascii=False,sort_keys=True).encode()).hexdigest()})
 runs.append({'family':cohort['family'],'surfaces':len(expected),'captures':captures,'changed_words':cohort['changed_words']})
 print(cohort['family'],len(expected),'complete captured prototype words reproduced',flush=True)
assert all(sha(p)==digest for p,digest in frozen.items())
r={'state':'complete-corpus-history-cohorts-passed','runs':runs,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Actual complete formal-volitional prototype and actual committed installed integration package reproduce every complete recorded corpus/history word, candidate, field and order, preserving zero changed surfaces and zero additions, including existing Source and licensed ending readings in the reference. This is unannotated candidate coverage, not spacing/contextual or main integration validation.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
