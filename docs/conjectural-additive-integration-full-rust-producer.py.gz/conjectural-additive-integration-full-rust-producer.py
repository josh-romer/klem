"""Run the complete new integration suite with its source and artifacts frozen."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-conjectural-additive-integration')
OUT = PREP / 'conjectural-integration-full-rust.json'
LOG = PREP / 'conjectural-integration-full-rust.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [WORK / name for name in ['Cargo.toml', 'Cargo.lock', 'README.md', 'flake.nix']]
for folder in ['src', 'tests', 'tools', 'docs', 'web/src']:
    files.extend(path for path in (WORK / folder).rglob('*') if path.is_file() and '__pycache__' not in path.parts)
files.append(Path(__file__))
frozen = {str(path): sha(path) for path in sorted(set(files))}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
index = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest()
command = ['cargo', 'test', '--locked', '--offline', '--features', 'web']
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/klem-conjectural-additive-integration-target',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='4')
r = {'state': 'running', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': os.getpid(),
     'head': head, 'index_sha256': index, 'frozen_inputs': frozen, 'command': command,
     'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
     'scope': 'Actualfullupdatedintegration on162e826 withonly41independentcases appendedtoexact35587serializedoldprefix; all511oldreviews/two boundedscopes513202. EightSource/copula+fourgloballedgertests/wholeformat/alltargetClippy alreadypassed, allthreeportableaudits andactual38/17/9 controls passed; Nixwiring includesallthree. EverySource/fixture/tool/document/catalog inputandprivateHEAD/index frozen. RootmainstillfrozenforNix75926; noRootruntimepromotion yet. FullnewNixselectedSource/installed/broadernovel/Koreanreview/quiettiming remainrequired.'}
OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
with LOG.open('xb') as stream:
    job = subprocess.run(command, cwd=WORK, env=env, stdout=stream, stderr=subprocess.STDOUT)
batches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', LOG.read_text())
totals = {key: sum(int(batch[i + 1]) for batch in batches) for i, key in enumerate(['passed', 'failed', 'ignored'])}
unchanged = all(sha(Path(path)) == digest for path, digest in frozen.items())
head_same = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == head
index_same = hashlib.sha256(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=WORK)).hexdigest() == index
r.update(state='passed' if job.returncode == 0 and unchanged and head_same and index_same else 'failed',
         exit_code=job.returncode, inputs_unchanged=unchanged, head_unchanged=head_same, index_unchanged=index_same,
         totals=totals, batches=len(batches), log_sha256=sha(LOG), finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
print(r['state'], totals, len(batches), 'batches; Sourcefiles', len(frozen), 'unchanged', unchanged, flush=True)
raise SystemExit(0 if r['state'] == 'passed' else 1)
