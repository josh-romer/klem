"""Compare complete original dao groups against the actual prior three-mode captures."""
import copy, gzip, hashlib, json, subprocess
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
PREP = Path('/tmp/klem-declarative-dao-preparation-complete.json.gz')
CLI = Path('/tmp/klem-declarative-dao-cli')
DB = ROOT / 'data/dictionaries/krdict/krdict.db'
OUT = Path('/tmp/klem-declarative-dao-runtime.json.gz')
assert not OUT.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
prepared = json.loads(gzip.decompress(PREP.read_bytes()))
text = prepared['complete_source_text']
frozen = {str(p): sha(p.read_bytes()) for p in [PREP, CLI, DB, Path(__file__)]}
runs, changes = [], []

def reading(record, index):
    dictionary = record['dictionary']
    value = copy.deepcopy(dictionary['readings'][index])
    for owner in value['lemmas']:
        lemma = record['analysis']['analyses'][index]['lemmas'][owner.pop('lemma_index')]
        owner['lemma'] = next(m for m in dictionary['lemmas'] if m['lemma'] == lemma)
    return value

for mode, flags in [('raw', []), ('headword', ['--dict-only']), ('compatible', ['--dict-compatible'])]:
    before = prepared['baseline_runs'][mode]['records']
    streams = []
    for cache in [0, 4096]:
        command = [str(CLI), 'text', '-', '--dictionary', str(DB), *flags, '--cache-bytes', str(cache)]
        job = subprocess.run(command, input=text.encode(), capture_output=True, check=True)
        assert not job.stderr
        records = [json.loads(line) for line in job.stdout.splitlines()]
        assert len(records) == len(before)
        streams.append(sha(job.stdout))
        added_count = 0
        for index, (old, now) in enumerate(zip(before, records, strict=True)):
            assert (old['surface'], old['span'], old['kind']) == (now['surface'], now['span'], now['kind'])
            if old['analysis'] is None:
                assert old == now
                continue
            old_paths = old['analysis']['analyses']
            new_paths = now['analysis']['analyses']
            assert [a for a in new_paths if a in old_paths] == old_paths
            for old_index, path in enumerate(old_paths):
                new_index = new_paths.index(path)
                assert reading(old, old_index) == reading(now, new_index), (mode, old['surface'], path, reading(old, old_index), reading(now, new_index))
            added = [a for a in new_paths if a not in old_paths]
            assert all('ending.declarative_dao' in a['rules'] for a in added)
            added_count += len(added)
            if added and cache == 0:
                changes.append({'mode': mode, 'record': index, 'surface': now['surface'],
                                'span': now['span'], 'before': old, 'after': now,
                                'additions': added, 'contextual_verdict': 'unjudged'})
        runs.append({'mode': mode, 'cache_bytes': cache, 'command': command,
                     'records': records, 'stdout_sha256': sha(job.stdout),
                     'added_candidates': added_count, 'exit_code': 0})
    assert streams[0] == streams[1]
assert all(sha(Path(p).read_bytes()) == h for p, h in frozen.items())
report = {'state': 'draft-complete-source-runtime-passed', 'complete_original_groups': 26,
          'ending_entries': prepared['inventory_entries'], 'expression_entries': prepared['expression_entries'],
          'runs': runs, 'changes': changes, 'frozen_inputs': frozen, 'inputs_unchanged': True,
          'producer': {'text': Path(__file__).read_text(), 'sha256': frozen[str(Path(__file__))]},
          'scope': 'Six original source identities, all 26 unabridged groups, exact prior hypotheses and per-candidate dictionary assessments. New alternatives are structurally reviewed individually; contextual and independent correctness, wider corpus and installed integration are not established.',
          'full_coverage_complete': False}
OUT.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
print({'groups': 26, 'streams': len(runs), 'frames_per_stream': len(runs[0]['records']),
       'added_candidates': {r['mode']: r['added_candidates'] for r in runs if r['cache_bytes'] == 0}})
