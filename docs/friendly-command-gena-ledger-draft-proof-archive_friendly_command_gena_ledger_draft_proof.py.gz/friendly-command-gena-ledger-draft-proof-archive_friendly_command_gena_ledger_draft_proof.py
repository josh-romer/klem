"""Preserve the successful Gena draft audit and original failed import packet."""
import gzip,hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=Path('/home/josh/projects/klem/.direnv/friendly-command-gena');D=W/'docs'
sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((P/'friendly-command-gena-ledger-draft-validation-retry1.json').read_bytes())
gate=json.loads((P/'friendly-command-gena-complete-nix-gate.json').read_bytes())
assert gate['state'] in ('passed','failed'), 'frozen full Nix gate must first terminate'
assert r['state']=='passed' and r['controls']==24 and len(r['results'])==2 and all(x['exit_code']==0 for x in r['results'])
assert all(r[k] and gate[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged'])
assert r['head']==gate['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
assert all(sha(Path(name).read_bytes())==digest for name,digest in r['frozen_inputs'].items())
assert sha((P/'friendly-command-gena-ledger-draft-validation-retry1.log').read_bytes())==r['log_sha256']
failure=json.loads((P/'friendly-command-gena-ledger-draft-import-failure.json').read_bytes())
assert failure['state']=='actual-draft-preflight-import-shadow-failed' and failure['controls_executed']==0
files={}
def add(name,raw):
    path=D/('friendly-command-gena-ledger-draft-proof-'+name+'.gz');assert not path.exists()
    packed=gzip.compress(raw,mtime=0);path.write_bytes(packed)
    files[name]=dict(path=path.name,source_sha256=sha(raw),archive_sha256=sha(packed))
for name in ['prepare_friendly_command_gena_ledger_draft.py','friendly_command_gena_ledger_audit.py','test_friendly_command_gena_ledger_audit.py','validate_friendly_command_gena_ledger_draft_retry1.py','friendly-command-gena-ledger-draft-validation-retry1.json','friendly-command-gena-ledger-draft-validation-retry1.log','friendly-command-gena-ledger-draft-import-failure.json',Path(__file__).name]:add(name,(P/name).read_bytes())
for name,item in failure['files'].items():
    packed=(P/item['path']).read_bytes();assert sha(packed)==item['archive_sha256'];raw=gzip.decompress(packed);assert sha(raw)==item['source_sha256'];add('import-failure-original-'+name,raw)
draft=P/'friendly-command-gena-promotion-draft';draft_files={}
for name,target in [('parent-validity.json.gz','friendly-command-gena-parent-validity.json.gz'),('parent-inventory-reviews.json.gz','friendly-command-gena-parent-inventory-reviews.json.gz'),('parent-inventory-review-queue.json.gz','friendly-command-gena-parent-inventory-review-queue.json.gz'),('draft.json','friendly-command-gena-ledger-draft.json'),('proposed-cases.json','friendly-command-gena-ledger-proposed-cases.json'),('proposed-scoped-reviews.json','friendly-command-gena-scoped-reviews.json')]:
    raw=(draft/name).read_bytes();path=D/target;assert not path.exists();path.write_bytes(raw);draft_files[name]=dict(path=target,sha256=sha(raw))
manifest=D/'friendly-command-gena-ledger-draft-proof-archive.json';assert not manifest.exists()
manifest.write_text(json.dumps(dict(state='exact-Gena-24-case-single-owner-DRAFT-and24-controls-passed',files=files,draft_files=draft_files,
    actual_failed_import_session=54591,actual_passed_retry_session=79310,failed_import_controls=0,successful_draft_controls=24,
    parent_cases=35740,proposed_cases=35764,added_required=17,added_forbidden=7,parent_reviews=519,proposed_reviews=520,
    source_example_groups=4,all_original_cases_reviews_source_queue_and_private_fixtures_retained=True,
    original_case_authoring_precedes_runtime=True,review_draft_authored_after_runtime=True,
    historical_and_broad_hypotheses_promoted=False,actual_shared_promotion=False,
    full_nix_gate_at_archive=gate['state'],selected_source_and_actual_promotion_audits='pending',
    quiet_performance_context_register_independent_review='pending',full_coverage_complete=False),indent=2)+'\n')
print('Archived',len(files),'full draft/import failure artifacts and',len(draft_files),'exact parent/proposal files; sharedledger unchanged.',flush=True)
