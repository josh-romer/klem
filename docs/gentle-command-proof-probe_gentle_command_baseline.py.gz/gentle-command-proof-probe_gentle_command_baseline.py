"""Observe unchanged installed runtime only after independent source proposals exist."""
import datetime,gzip,hashlib,json,subprocess,unicodedata
from pathlib import Path
prep=Path(__file__).resolve().parent;source_path=prep/'gentle-command-original-source.json';binding_path=prep/'willingness-installed-source-binding-retry1.json';out=prep/'gentle-command-installed-baseline.json.gz';assert not out.exists()
source=json.loads(source_path.read_bytes());assert not source['observed_runtime'] and not source['linguistic_judgments_promoted'];binding=json.loads(binding_path.read_bytes());assert binding['state']=='passed'
cli=Path(binding['profiles']['klem']['package'])/'bin/klem';db=Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db')
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
frozen={str(p):sha(p) for p in [source_path,binding_path,cli,db,Path(__file__)]};assert frozen[str(db)]==source['database_sha256']
r=dict(state='running',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=sha(source_path),binding_sha256=sha(binding_path),frozen_inputs=frozen,runs=[],producer={'text':Path(__file__).read_text(),'sha256':sha(__file__)},scope='All complete original8sourcegroups and independent typed proposals observed on unchanged7dfinstalled runtime. Not gold, new implementation or contextual correctness certification.')
for family,text in [('complete-source','\n\n'.join('\n'.join(i['complete_original_group']) for i in source['items'])),('individual-targets',' '.join(i['surface'] for i in source['items']))]:
 for encoding in ['NFC','NFD']:
  payload=unicodedata.normalize(encoding,text).encode()
  for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
   cache_outputs=[]
   for cache in [0,4096]:
    cmd=[str(cli),'text','-','--dictionary',str(db),*flags,'--cache-bytes',str(cache)]
    completed=subprocess.run(cmd,input=payload,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert completed.returncode==0,completed.stderr
    frames=[json.loads(line) for line in completed.stdout.splitlines()];cursor=0;observations=[]
    for frame in frames:
     assert frame['span']['start']==cursor and payload[cursor:frame['span']['end']].decode()==frame['surface'];cursor=frame['span']['end']
    assert cursor==len(payload)
    for item in source['items']:
     observed=[(ix,frame) for ix,frame in enumerate(frames) if frame['kind']=='word' and unicodedata.normalize('NFC',frame['surface'])==item['surface']];assert len(observed)==1,(item['id'],len(observed))
     ix,frame=observed[0];paths=frame['analysis']['analyses'];target=item['independent_typed_proposal']
     lexical=[j for j,p in enumerate(paths) if [h['text'] for h in p['lemmas']]==target['lemmas']]
     typed=[j for j in lexical if [h['kind'] for h in paths[j]['lemmas']]==target['lemma_kinds'] and [m['form'] for m in paths[j]['morphemes']]==target['morphemes'] and [m['kind'] for m in paths[j]['morphemes']]==target['morpheme_kinds']]
     observations.append(dict(id=item['id'],record_index=ix,actual_record=frame,lexical_path_indices=lexical,typed_ending_path_indices=typed))
    cache_outputs.append(completed.stdout)
    r['runs'].append(dict(family=family,encoding=encoding,mode=mode,cache_bytes=cache,command=cmd,exit_code=completed.returncode,input_sha256=hashlib.sha256(payload).hexdigest(),input_text=payload.decode(),records=len(frames),original_bytes_conserved=True,jsonl=completed.stdout.decode(),jsonl_sha256=hashlib.sha256(completed.stdout).hexdigest(),observations=observations))
   assert cache_outputs[0]==cache_outputs[1]
r.update(state='complete-original-installed-baseline-observed',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),inputs_unchanged=all(sha(p)==h for p,h in frozen.items()),streams=len(r['runs']),frames=sum(x['records'] for x in r['runs']),linguistic_judgments_promoted=False);assert r['inputs_unchanged']
out.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Captured',r['streams'],'streams /',r['frames'],'frames with complete original output and unchanged input bytes')
for item in source['items']:
 observed=[o for run in r['runs'] for o in run['observations'] if o['id']==item['id']]
 print(item['surface'],'lexical',sum(bool(o['lexical_path_indices']) for o in observed),'typed',sum(bool(o['typed_ending_path_indices']) for o in observed),'of',len(observed))
