"""Update only derived evidence hashes; preserve every original queue row."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

PREP = Path(__file__).resolve().parent
OUT = PREP / 'gentle-command-history-queue-reconciliation.json'
assert not OUT.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
results = []
for name, root in [('gentle-command', Path('/tmp/klem-gentle-command')),
                   ('expression-conjectural', Path('/tmp/klem-expression-conjectural-main'))]:
    source = root / 'tools/review_inventory.py'
    spec = importlib.util.spec_from_file_location('inventory_' + name, source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    queue_path = root / module.QUEUE
    original_raw = queue_path.read_bytes()
    original = json.loads(original_raw)
    ledger_path = root / 'tests/fixtures/validity.json'
    reviews_path = root / 'docs/inventory-reviews.json'
    pinned = {str(p): sha(p.read_bytes()) for p in [source, ledger_path, reviews_path]}
    rebuilt = module.build_queue(root, original['dictionary_metadata'],
                                 [row['source'] for row in original['entries']])
    assert rebuilt['entries'] == original['entries'] and len(rebuilt['entries']) == 715
    assert {k: v for k, v in rebuilt.items() if k != 'evidence_sha256'} == {
        k: v for k, v in original.items() if k != 'evidence_sha256'}
    assert set(rebuilt['evidence_sha256']) == set(original['evidence_sha256'])
    archive = root / ('docs/' + name + '-history-repair-parent-inventory-queue.json.gz')
    assert not archive.exists()
    archive.write_bytes(gzip.compress(original_raw, mtime=0))
    queue_path.write_text(json.dumps(rebuilt, ensure_ascii=False, indent=2)+'\n')
    module.verify_queue(root, rebuilt)
    assert all(sha(Path(p).read_bytes()) == digest for p, digest in pinned.items())
    results.append(dict(worktree=str(root), original_queue_sha256=sha(original_raw),
                        new_queue_sha256=sha(queue_path.read_bytes()),
                        all715rows_exact=True, counts=rebuilt['counts'],
                        changed_evidence=[path for path in original['evidence_sha256']
                                          if rebuilt['evidence_sha256'][path] != original['evidence_sha256'][path]],
                        unchanged_inputs=pinned))
OUT.write_text(json.dumps(dict(state='passed', results=results,
               producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes()))),
               ensure_ascii=False, indent=2)+'\n')
print('Reconciled both queues: all715rows/cases/manualreviews exact; only derived evidence hashes changed.')
