"""Record the complete passed portable audit without promoting any judgment."""
import gzip,hashlib,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent/'friendly-hortative-sena';sha=lambda b:hashlib.sha256(b).hexdigest()
p=P/'friendly-hortative-sena-portable-installed-validation-retry1.json';r=json.loads(p.read_bytes());assert r['state']=='passed' and (r['tests_run'],r['failures'],r['errors'],r['skipped'])==(46,0,0,0)
assert all(r[k] for k in ['inputs_unchanged','source_unchanged','head_unchanged','index_unchanged','status_unchanged'])
assert all(sha((W/n).read_bytes())==d for n,d in r['source_inputs'].items())
files={}
for name,path in [(p.name,p),('friendly-hortative-sena-portable-installed-validation-retry1.log',P/'friendly-hortative-sena-portable-installed-validation-retry1.log'),('run_sena_portable_installed_controls.py',P/'run_sena_portable_installed_controls.py'),('install_sena_portable_controls.py',P/'install_sena_portable_controls.py'),('tools/friendly_hortative_sena_installed_audit.py',W/'tools/friendly_hortative_sena_installed_audit.py'),('tools/test_friendly_hortative_sena_installed_audit.py',W/'tools/test_friendly_hortative_sena_installed_audit.py'),('archive_sena_installed_proof.py',P/'archive_sena_installed_proof.py'),(Path(__file__).name,Path(__file__))]:
 raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);dest=W/'docs'/('friendly-hortative-sena-portable-installed-proof-'+name.replace('/','_')+'.gz');assert not dest.exists();dest.write_bytes(packed);files[name]=dict(path=dest.name,source_sha256=sha(raw),archive_sha256=sha(packed),bytes=len(raw))
manifest=W/'docs/friendly-hortative-sena-portable-installed-proof-archive.json';assert not manifest.exists();manifest.write_text(json.dumps(dict(state='actual46-portable-installed-controls-passed',files=files,original43_test_methods_unchanged=True,actual_commands=253,complete_streams=506,summary=r['summary'],scope='Actual repository controls verify complete installed source and outputs; this is a captured proof, not a claim to read historical host executables inside Nix. Main/shared promotion/quiet/context/register/independent Korean review remain open.'),indent=2)+'\n')
p=W/'docs/coverage-checklist.md';s=p.read_text();old='''  The full historical Nix inventory and four package checks, installed Sena
  runtime/browser, main integration, quiet timing and shared-ledger promotion
  remain required. Contextual sense,
''';assert s.count(old)==1
new='''  The complete historical Nix inventory and all four package checks now pass
  at the original e4436e3 checkpoint. The installed klem, corpus adapter,
  SolidJS assets and web launcher are source-bound to the same frozen inputs.
  All 1,212 release Rust tests and the original doctest pass in 257 batches,
  with one ignored test. The [complete installed archive](friendly-hortative-sena-installed-proof-archive.json)
  retains 935 full originals, including all failed wrapper attempts, producers,
  logs and partial streams. All 253 actual installed replay commands completed:
  48 complete source/corpus policies, 46 full Native owners, 72 headword queries,
  every 53,502 corpus/history word record, all 66,570 annotated gold rows and
  1,128,312 broad frames. An independent completed-output audit verifies all
  506 complete stdout/stderr streams without rerunning commands; the original
  metadata-wrapper failure remains failed and unchanged. The packaged browser
  passes 150 choices, 114 diagrams, 12 exact exports and 37 full Native endpoints.
  Both desktop and mobile screenshots were visually inspected. All semantic
  fields remain exact; only finite nonnegative measured API latency is excluded
  from corpus-response equality, with both original timing values retained.
  The [portable installed auditor](../tools/friendly_hortative_sena_installed_audit.py)
  reconstructs every installed cohort word from actual stdout and checks every
  complete finite/gold/broad stream. Its [46 rejection controls](../tools/test_friendly_hortative_sena_installed_audit.py)
  pass, retaining all 43 original method bodies and adding three full-stream
  and failed-wrapper controls. [Complete audit evidence](friendly-hortative-sena-portable-installed-proof-archive.json)
  is preserved and both commands are wired into the flake with explicit captured
  evidence scope. Execution from the new selected Nix source, main integration,
  quiet timing and shared-ledger promotion remain required. Contextual sense,
'''
p.write_text(s.replace(old,new))
sys.path.insert(0,str(W/'tools'));from review_inventory import build_queue,verify_queue
p=W/'docs/inventory-review-queue.json';raw=p.read_bytes();old=json.loads(raw);new=build_queue(W,old['dictionary_metadata'],[r['source'] for r in old['entries']]);assert new['entries']==old['entries'] and new['counts']==old['counts'];changed={n for n,d in new['evidence_sha256'].items() if old['evidence_sha256'].get(n)!=d};assert changed=={'docs/coverage-checklist.md'},changed
(P/'friendly-hortative-sena-pre-installed-proof-queue.json.gz').write_bytes(gzip.compress(raw,mtime=0));p.write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n');verify_queue(W,new)
print('Complete installed archive/current46 controls integrated;715 original queue rows and all judgments unchanged.',flush=True)
