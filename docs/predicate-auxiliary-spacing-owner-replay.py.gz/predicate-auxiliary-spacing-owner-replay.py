"""Retain all predeclared owner requirements and distinguish actual joined-reading gaps."""
import json,gzip,hashlib,subprocess,unicodedata
from pathlib import Path
P=Path('/tmp/klem-predicate-auxiliary-spacing-prototype');CLI='/tmp/klem-predicate-auxiliary-spacing-owner-cli';DB='/home/josh/projects/klem/data/dictionaries/krdict/krdict.db';OUT=Path('/tmp/klem-predicate-auxiliary-spacing-owner-replay.json.gz');assert not OUT.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest();proposal_path=P/'tests/fixtures/predicate-auxiliary-spacing-owner-cases.json';proposal=json.loads(proposal_path.read_text());frozen={str(p):sha(Path(p).read_bytes()) for p in [CLI,DB,proposal_path]};observations=[]
for case in proposal['cases']:
 for encoding in ['NFC','NFD']:
  surface=unicodedata.normalize(encoding,case['surface'])
  for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
   command=[CLI,'word',surface,'--dictionary',DB,'--suggest-spacing',*flags]
   job=subprocess.run(command,capture_output=True,text=True);assert job.returncode==0,job.stderr
   record=json.loads(job.stdout);spaces={unicodedata.normalize('NFC',a['spaced']) for a in record['spacing']['alternatives'] if a.get('rule')=='spacing.predicate_auxiliary'}
   observations.append({'case_id':case['id'],'encoding':encoding,'mode':mode,'command':command,'record':record,'target_present':case['required_space'] in spaces})
assert all(sha(Path(p).read_bytes())==v for p,v in frozen.items())
missing=sorted({r['case_id'] for r in observations if not r['target_present']})
assert missing==['auxiliary-nominalization-topic']
assert all(o['target_present'] for o in observations if o['case_id'] not in missing)
r={'state':'nine-owner-requirements-passed-one-bound-noun-requirement-unmet','proposal':proposal,'observations':observations,'unmet_requirements':missing,'unmet_disposition':'Original required split remains unmet, not converted to a forbidden case. The current engine has no joined auxiliary/adnominal-bound-noun reading for 먹어준것은; broader bound-noun joining/spacing remains open.','frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'scope':'All60actual Unicode/filter observations retain predeclared requirements. Copular, suffix-derived, negative and nominalized auxiliary owners are structurally checked; contextual spacing, main/Nix/broad validation remain separate.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Passed54owner observations; retained6unmet bound-noun observations.',flush=True)
