"""Preserve rhetorical/reported-question homonyms and every complete source group."""
import gzip
import hashlib
import json
import sqlite3
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path('/home/josh/projects/klem/.direnv/coverage-integration')
DATA = Path('/home/josh/projects/klem/data/dictionaries/krdict')
DB = DATA / 'krdict.db'
ZIP = DATA / '2026-09.zip'
CLOSURE = ROOT / 'docs/unreviewed-inventory-source-closure.json.gz'
CLI = Path('/home/josh/projects/klem/.direnv/integration-compact-target/debug/klem')
OUT = Path('/tmp/klem-dapnikka-source-preparation.json.gz')
assert not OUT.exists()
sys.path.insert(0, str(ROOT / 'tools'))
from native_lmf import entry, feature

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

ids = ['krdict:78782', 'krdict:78786', 'krdict:78797', 'krdict:78803', 'krdict:86563', 'krdict:86566', 'krdict:86628', 'krdict:86630', 'krdict:80909', 'krdict:85833']
closure = json.loads(gzip.decompress(CLOSURE.read_bytes()))
assert sha(DB) == closure['dictionary_sha256']
original = {i: closure['original_lmf'][i] for i in ids if i in closure['original_lmf']}
missing = set(ids) - set(original)
source_exports = {}
with zipfile.ZipFile(ZIP) as archive:
    for name in archive.namelist():
        if not missing:
            break
        if not name.endswith('.json'):
            continue
        raw = archive.read(name)
        if not any(i.split(':')[1].encode() in raw for i in missing):
            continue
        found = []
        for e in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry']:
            ident = 'krdict:' + str(e.get('val'))
            if ident in missing and feature(e, 'lexicalUnit') not in {'관용구', '속담'}:
                assert ident not in original
                original[ident] = e
                found.append(ident)
        if found:
            source_exports[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'ids': found}
            missing -= set(found)
assert not missing and set(original) == set(ids)
with sqlite3.connect(DB.resolve().as_uri() + '?mode=ro', uri=True) as db:
    complete = {ident: json.loads(raw) for ident, raw in db.execute('select id,data from entries where id in (' + ','.join('?' for _ in ids) + ')', ids)}
    metadata = dict(db.execute('select key,value from metadata'))
assert {ident: entry(raw) for ident, raw in original.items()} == complete, 'complete Native projection'
assert [complete[i]['pos'] for i in ids[:4]] == ['어미'] * 4
assert all(complete[i]['pos'] == '품사 없음' for i in ids[4:])
text = ''
groups = []
for ident in ids:
    for sense in complete[ident]['senses']:
        for ordinal, examples in enumerate(sense['examples'], 1):
            block = '\n'.join(examples)
            start = len(text.encode())
            text += block + '\n'
            groups.append({'id': f"dapnikka-source-{ident.split(':')[1]}-{sense['id']}-{ordinal}", 'entry_id': ident, 'sense_id': sense['id'], 'group': ordinal, 'complete_original_examples': examples, 'span': {'start': start, 'end': start + len(block.encode())}})
assert len(groups) == 46
captures = {}
for mode, flags in [('raw', []), ('headword', ['--dict-only']), ('compatible', ['--dict-compatible'])]:
    command = [str(CLI), 'text', '-', '--dictionary', str(DB), *flags]
    result = subprocess.run(command, input=text.encode(), capture_output=True, check=True)
    assert not result.stderr
    rows = [json.loads(line) for line in result.stdout.splitlines()]
    cursor = 0
    for row in rows:
        assert row['span']['start'] == cursor
        cursor = row['span']['end']
        assert text.encode()[row['span']['start']:cursor].decode() == row['surface']
    assert cursor == len(text.encode())
    captures[mode] = {'command': command, 'records': rows, 'exit_code': result.returncode, 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest()}
lemmas = {
    '좋아한답니까': ['좋아하다'], '덧난답니까': ['덧나다'], '한답니까': ['하다'], '산답니까': ['살다'], '간답니까': ['가다'],
    '먹는답니까': ['먹다'], '닳는답니까': ['닳다'], '찾는답니까': ['찾다'], '늦는답니까': ['늦다'],
    '없답니까': ['없다'], '가셔야겠답니까': ['가다'], '있답니까': ['있다'], '야박하답니까': ['야박하다'],
    '모양이랍니까': ['모양', '이다'], '컴퓨터랍니까': ['컴퓨터', '이다'], '교수랍니까': ['교수', '이다'], '아니랍니까': ['아니다'],
    '주무신답니까': ['주무시다'], '사용하신답니까': ['사용하다'], '준답니까': ['주다'], '닫는답니까': ['닫다'], '믿는답니까': ['믿다'], '읽는답니까': ['읽다'],
    '출발했답니까': ['출발하다'], '많답니까': ['많다'], '힘들답니까': ['힘들다'], '아프답니까': ['아프다'],
    '동생이랍니까': ['동생', '이다'], '언제랍니까': ['언제', '이다'], '친구랍니까': ['친구', '이다'],
    '가랍니까': ['가다'], '끝내랍니까': ['끝내다'], '하랍니까': ['하다'], '쓰랍니까': ['쓰다'],
    '찾으랍니까': ['찾다'], '먹으랍니까': ['먹다'], '앉으랍니까': ['앉다'], '묶으랍니까': ['묶다'],
    '좋았더랍니까': ['좋다'], '잘하겠더랍니까': ['잘하다'], '어떻더랍니까': ['어떻다'], '봤더랍니까': ['보다'],
}
proposals = []
for index, row in enumerate(captures['raw']['records']):
    if row['kind'] != 'word' or not row['analysis']['normalized'].endswith(('답니까', '랍니까')):
        continue
    surface = row['analysis']['normalized']
    assert surface in lemmas, surface
    group = next(g for g in groups if g['span']['start'] <= row['span']['start'] < row['span']['end'] <= g['span']['end'])
    proposed = lemmas[surface]
    existing = [[lemma['text'] for lemma in a['lemmas']] for a in row['analysis']['analyses']]
    proposals.append({'id': group['id'] + '-' + str(row['span']['start'] - group['span']['start']), 'source_group_id': group['id'], 'surface': surface, 'proposed_lemmas': proposed, 'already_generated': proposed in existing, 'complete_original_group': group['complete_original_examples'], 'baseline_records': {mode: capture['records'][index] for mode, capture in captures.items()}, 'judgment': 'authored-proposal-unreviewed', 'basis': 'Source-example analysis; ending vs reported expression and command vs copular scope require separate ownership. This is not annotated gold.'})
assert len(proposals) == 46 and {p['source_group_id'] for p in proposals} == {g['id'] for g in groups}
frozen = {str(p): sha(p) for p in [DB, ZIP, CLOSURE, CLI, Path(__file__), ROOT / 'tools/native_lmf.py']}
result = {'state': 'complete-native-source-and-current-baseline-prepared', 'dictionary_metadata': metadata, 'original_native_entries': original, 'complete_imported_entries': complete, 'additional_original_source_exports': source_exports, 'complete_groups': groups, 'complete_source_text': text, 'baseline_runs': captures, 'proposals': proposals, 'frozen_inputs': frozen, 'inputs_unchanged': all(sha(p) == digest for p, digest in frozen.items()), 'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)}, 'scope': 'Four unreviewed rhetorical ending identities and six separate reported/command/retrospective expression identities; all46complete source groups and authored proposals. Actual current integration debug CLI in allthree filters; no implementation, review disposition or contextual correctness claim.', 'full_coverage_complete': False}
assert result['inputs_unchanged']
OUT.write_bytes(gzip.compress((json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
print('Prepared', len(complete), 'complete Native identities,', len(groups), 'original groups;', sum(p['already_generated'] for p in proposals), 'of46source proposals already generated', flush=True)
