import hashlib,json,os,subprocess,datetime
from pathlib import Path
PREP=Path(__file__).resolve().parent;WORK=Path('/home/josh/projects/klem/.direnv/friendly-command-gena')
OUT=PREP/'friendly-command-gena-frontend-build.json';LOG=PREP/'friendly-command-gena-frontend-build.log';assert not OUT.exists() and not LOG.exists()
MODULES=Path('/home/josh/projects/klem/.direnv/dapnikka-integration/web/node_modules');assert MODULES.is_dir();assert (MODULES.parent/'package-lock.json').read_bytes()==(WORK/'web/package-lock.json').read_bytes()
link=WORK/'web/node_modules';assert not link.exists();link.symlink_to(MODULES,target_is_directory=True)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
files=[p for p in (WORK/'web/src').rglob('*') if p.is_file()]+[WORK/'web'/n for n in ['package.json','package-lock.json','vite.config.ts','tsconfig.json','index.html']];frozen={str(p):sha(p) for p in files}
r=dict(state='running',frozen_inputs=frozen,producer=dict(text=Path(__file__).read_text(),sha256=sha(__file__)),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Actual SolidJS TypeScript/Vite production build using identical pinned cached node dependencies; own new -게나 label included. Source/head/index and dictionary data unchanged; this is not an installed Nix package claim.')
OUT.write_text(json.dumps(r,indent=2)+'\n')
with LOG.open('xb') as stream:job=subprocess.run(['npm','run','build'],cwd=WORK/'web',stdout=stream,stderr=subprocess.STDOUT,env=dict(os.environ,TMPDIR='/var/tmp/klem-gentle-command-long-nix-packages-build'))
r.update(exit_code=job.returncode,inputs_unchanged=all(sha(p)==v for p,v in frozen.items()),log_sha256=sha(LOG),assets={str(p.relative_to(WORK/'web/dist')):sha(p) for p in (WORK/'web/dist').rglob('*') if p.is_file()},finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());r['state']='passed' if job.returncode==0 and r['inputs_unchanged'] and r['assets'] else 'failed';OUT.write_text(json.dumps(r,indent=2)+'\n');print(r['state'],'currentSolidJSproduction assets;',len(r['assets']),'files',flush=True);raise SystemExit(0 if r['state']=='passed' else 1)
