"""Execute the isolated bound-noun server with actual frozen SolidJS assets."""
import datetime,hashlib,json,os,re,signal,socket,subprocess,time,urllib.request
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');PREFIX=Path('/tmp/klem-bound-noun-spacing-installed-browser');ASSETS=Path('/nix/store/pzcmhjvgc3z8qj0qj62ka0k1pdpyzfp3-klem-web-assets-0.1.0/share/klem-web');OUT=Path(str(PREFIX)+'-browser-runtime.json');assert not OUT.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cli=Path('/nix/store/qm6ffk87sb4vl5r9zbcj77y3411i0mhj-klem-0.1.0/bin/klem');server=Path('/nix/store/qm6ffk87sb4vl5r9zbcj77y3411i0mhj-klem-0.1.0/bin/klem-web');driver=Path('/tmp/klem-bound-noun-spacing-browser-retry1.mjs');DB=ROOT/'data/dictionaries/krdict/krdict.db'
fixture=Path('/tmp/klem-bound-noun-spacing-prototype/tests/fixtures/bound-noun-spacing-cases.json');closure=Path('/tmp/klem-bound-noun-spacing-native-closure.json.gz')
frozen={str(p):sha(p) for p in [cli,server,driver,DB,fixture,closure,Path(__file__)]}
assets={str(p.relative_to(ASSETS)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in ASSETS.rglob('*') if p.is_file()}
with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
url=f'http://127.0.0.1:{port}';command=[str(server),'--port',str(port),'--assets',str(ASSETS),'--dictionary',str(DB)]
r={'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'url':url,'assets':assets,'frozen_inputs':frozen,'scope':'Actual isolated installed Nix CLI/server and Nix SolidJS assets. Exact exports, actual diagrams, optional auxiliary contexts ending before noun, Native and geometry. Root integration/Nix/independent linguistic review remain pending.'}
def save():OUT.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
save();job=None;serverlog=Path(str(PREFIX)+'-browser-server.log');browserlog=Path(str(PREFIX)+'-browser-driver.log')
try:
 with serverlog.open('xb') as log:
  job=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT);r['server_pid']=job.pid;save();deadline=time.monotonic()+30
  while True:
   assert job.poll() is None
   try:
    with urllib.request.urlopen(url,timeout=2) as response:html=response.read()
    break
   except OSError:assert time.monotonic()<deadline;time.sleep(.1)
  assert html==(ASSETS/'index.html').read_bytes();checks=[]
  for path in re.findall(r'(?:src|href)="(/assets/[^"?#]+\.(?:js|css))"',html.decode()):
   with urllib.request.urlopen(url+path,timeout=20) as response:raw=response.read()
   assert raw==(ASSETS/path.lstrip('/')).read_bytes();checks.append({'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
  assert len(checks)==2;r['served_asset_checks']=checks
  env=dict(os.environ,KLEM_ROOT=str(ROOT),KLEM_WEB_URL=url,KLEM_BIN=str(cli),KLEM_DICTIONARY=str(DB),KLEM_CAPTURE_PREFIX=str(PREFIX),KLEM_BOUND_CASES=str(fixture),KLEM_BOUND_NATIVE=str(closure),CHROMIUM_PATH='/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium')
  r['browser_command']=['node',str(driver)];save()
  with browserlog.open('xb') as output:completed=subprocess.run(r['browser_command'],cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT)
  assert completed.returncode==0,f'Browser exit {completed.returncode}; see {browserlog}'
  r.update(state='passed',exit_code=0,browser_sha256=sha(str(PREFIX)+'-browser.json'))
except BaseException as error:r.update(state='failed',exit_code=1,error=repr(error));raise
finally:
 if job is not None:
  if job.poll() is None:job.send_signal(signal.SIGINT)
  r.update(server_exit_code=job.wait(timeout=20),server_stopped=True)
 r['inputs_unchanged']=all(sha(p)==h for p,h in frozen.items()) and all(sha(ASSETS/p)==h['sha256'] for p,h in assets.items())
 r['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();r['server_log_sha256']=sha(serverlog) if serverlog.exists() else None;r['driver_log_sha256']=sha(browserlog) if browserlog.exists() else None;save()
assert r['inputs_unchanged'] and r['server_stopped'] and r['server_exit_code'] in [-2,130]
print('Actual isolated browser, exact CLI/Native and served assets passed; owned server stopped.')
