"""Capture complete expression sources and independently authored paths without rebuilding binaries."""
import gzip
import hashlib
import json
import subprocess
import unicodedata
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
PREP = Path(__file__).resolve().parent
OUT = PREP / 'source-streams.json.gz'
assert not OUT.exists()
read = lambda p: json.loads(gzip.decompress(p.read_bytes()) if p.suffix == '.gz' else p.read_bytes())
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
packet_path = ROOT / 'docs/formal-volitional-expression-source-preparation.json.gz'
suite_path = ROOT / 'tests/fixtures/formal-volitional-expression-validity.json'
packet, suite = read(packet_path), read(suite_path)
cli = ROOT / '.direnv/formal-volitional-target/debug/klem'
db = ROOT / 'data/dictionaries/krdict/krdict.db'
frozen = {str(p): sha(p) for p in [packet_path, suite_path, cli, db, Path(__file__)]}
runs = []
texts = [('complete-original-source', packet['complete_source_text']),
         ('all-individual-cases', ' '.join(case['surface'] for case in suite['cases']))]
for family, text in texts:
    for encoding in ['NFC', 'NFD']:
        original = unicodedata.normalize(encoding, text).encode()
        positions = []
        if family == 'complete-original-source':
            offset = 0
            for group, case in zip(packet['complete_groups'], suite['cases'], strict=True):
                group_bytes = unicodedata.normalize(encoding, '\n'.join(group['complete_original_group'])).encode()
                target = unicodedata.normalize(encoding, case['surface']).encode()
                positions.append(offset + group_bytes.index(target))
                offset += len(group_bytes) + 1
        else:
            offset = 0
            for case in suite['cases']:
                positions.append(offset)
                offset += len(unicodedata.normalize(encoding, case['surface']).encode()) + 1
        for mode, flags in [('raw', []), ('headword', ['--dict-only']), ('compatible', ['--dict-compatible'])]:
            uncached = None
            for cache in [0, 4096]:
                command = [str(cli), 'text', '-', '--dictionary', str(db), *flags, '--cache-bytes', str(cache)]
                job = subprocess.run(command, input=original, capture_output=True, check=True, cwd=ROOT)
                assert not job.stderr
                rows = [json.loads(line) for line in job.stdout.splitlines()]
                cursor = 0
                for row in rows:
                    assert row['span']['start'] == cursor
                    cursor = row['span']['end']
                    assert original[row['span']['start']:cursor].decode() == row['surface']
                assert cursor == len(original)
                matched = []
                for position, case in zip(positions, suite['cases'], strict=True):
                    row_index, row = next((i, r) for i, r in enumerate(rows) if r['span']['start'] == position)
                    assert row['surface'] == unicodedata.normalize(encoding, case['surface'])
                    judgment = case['judgments'][0]
                    paths = row['analysis']['analyses']
                    indices = [i for i, path in enumerate(paths)
                               if [l['text'] for l in path['lemmas']] == judgment['lemmas']
                               and [l['kind'] for l in path['lemmas']] == judgment['lemma_kinds']
                               and [m['form'] for m in path['morphemes']] == judgment['morphemes']
                               and [m['kind'] for m in path['morphemes']] == judgment['morpheme_kinds']
                               and all(rule in path['rules'] for rule in judgment['required_rules'])]
                    assert indices, (family, encoding, mode, case['id'])
                    matched.append({'case_id': case['id'], 'record_index': row_index, 'analysis_indices': indices})
                if uncached is None:
                    uncached = job.stdout
                else:
                    assert uncached == job.stdout
                runs.append({'family': family, 'encoding': encoding, 'mode': mode, 'cache_bytes': cache,
                             'command': command, 'exit_code': 0, 'input_sha256': hashlib.sha256(original).hexdigest(),
                             'jsonl': job.stdout.decode(), 'jsonl_sha256': hashlib.sha256(job.stdout).hexdigest(),
                             'records': len(rows), 'matched_independent_targets': matched,
                             'original_bytes_conserved': True})
                print(family, encoding, mode, cache, len(rows), 'complete frames; eight independent paths recovered', flush=True)
assert len(runs) == 24 and all(sha(p) == digest for p, digest in frozen.items())
report = {'state': 'passed', 'runs': runs, 'frozen_inputs': frozen, 'inputs_unchanged': True,
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)},
          'scope': 'Completed formal-volitional prototype CLI only. All eight independently authored original expression paths in complete source contexts and finite case streams, NFC/NFD, raw/headword/Compatible, zero/4096-byte cache. Every record/candidate/assessment retained, all source bytes conserved and cache outputs identical. Other alternatives stay unjudged. Actual installed/library/browser/full-ledger/main/contextual precision remain separate.'}
OUT.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
