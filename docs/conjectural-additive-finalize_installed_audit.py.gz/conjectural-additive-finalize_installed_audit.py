"""Wire the independently validated installed audit without changing runtime inputs."""
import gzip
import hashlib
import json
import subprocess
import sys
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-conjectural-additive-integration')
MAIN = Path('/home/josh/projects/klem')
controls = (PREP / 'installed-independent-controls.log').read_text()
assert 'Ran 25 tests' in controls and controls.rstrip().endswith('OK')
sys.path.insert(0, str(WORK / 'tools'))
import conjectural_additive_installed_audit as audit
result = audit.inspect(audit.inputs())
assert result['state'] == 'complete-installed-conjectural-audit-passed'
out = PREP / 'installed-independent-audit.json'
assert not out.exists()
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
for filename in ['installed-independent-audit.json', 'installed-independent-controls.log', Path(__file__).name]:
    target = WORK / 'docs' / ('conjectural-additive-' + filename + '.gz')
    assert not target.exists()
    target.write_bytes(gzip.compress((PREP / filename).read_bytes(), mtime=0))
flake = WORK / 'flake.nix'
text = flake.read_text()
anchor = '                ./tools/test_conjectural_additive_novel_audit.py\n'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + '                ./tools/conjectural_additive_installed_audit.py\n                ./tools/test_conjectural_additive_installed_audit.py\n')
anchor = "            python -m unittest discover -s tools -p 'test_conjectural_additive_novel_audit.py'\n"
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + "            python tools/conjectural_additive_installed_audit.py\n            python -m unittest discover -s tools -p 'test_conjectural_additive_installed_audit.py'\n")
flake.write_text(text)
checklist = WORK / 'docs/coverage-checklist.md'
text = checklist.read_text()
end = text.index('- [ ] **COV-018 —', text.index('- [ ] **COV-017cx —'))
note = '''  The [actual installed proof archive](conjectural-additive-installed-archive.json.gz)
  now binds all four Nix packages and their selected sources at `a23eb576`.
  The actual retained Nix release log also passes 1,161 tests, zero failures,
  one ignored and 250 batches. All 106 original audit controls pass directly
  from the selected Nix inventory source. The installed CLI exactly reproduces
  72 complete Source/copula/novel Unicode/filter/cache streams (57,432 frames),
  all 53,502 corpus/history words and paths, all 66,570 annotated rows and
  summaries, and all 1,128,312 broad workload frames. The installed SolidJS
  application passes all 288 independently authored path decisions and component
  orders, six exact exports and 57 complete original Native entry endpoints;
  its owned server stops cleanly. Both local 그러다/그렇다 targets are retained.
  [Mobile](conjectural-additive-installed-browser-mobile.png) and
  [desktop](conjectural-additive-installed-browser-desktop.png) captures are
  preserved. The initial Playwright module-resolution failure and the corrected
  cached-dependency harness remain separate unchanged artifacts.

  The [independent installed audit](../tools/conjectural_additive_installed_audit.py)
  derives every filter choice and full export from raw API records, checks
  typed forms against original Source/copula/novel judgments and compares all
  Native fields against their original closures. Its 25 mutation controls pass,
  including missing Unicode streams, the second novel alternative, fabricated
  POS, reordered morphemes, changed output hashes and missing spacing flags.
  Both tools are selected and executed by the private Nix inventory check.
  The new complete four-check inventory gate, current main integration, quiet
  performance and wider contextual/independent Korean review remain required.

'''
checklist.write_text(text[:end] + note + text[end:])
reviews_path = WORK / 'docs/inventory-reviews.json'
reviews = json.loads(reviews_path.read_text())
for review in reviews['entries']:
    if review['id'] in ['krdict:86083', 'krdict:86084']:
        review['evidence'].extend([{'path': 'docs/conjectural-additive-installed-archive.json.gz'},
                                   {'path': 'tools/conjectural_additive_installed_audit.py'},
                                   {'path': 'docs/conjectural-additive-installed-independent-controls.log.gz'}])
original = json.loads((MAIN / 'docs/inventory-reviews.json').read_text())['entries']
indexed = {r['id']: r for r in reviews['entries']}
assert len(original) == 511 and all(indexed[r['id']] == r for r in original)
reviews_path.write_text(json.dumps(reviews, ensure_ascii=False, indent=2) + '\n')
# Documentation/tool/Nix wiring changed; compiled runtime, tests and fixtures
# remain byte-identical to the actual package profiles already exercised.
binding = json.loads((PREP / 'conjectural-integration-installed-source-binding.json').read_text())
for profile in binding['profiles'].values():
    for metadata in profile['files'].values():
        path = WORK / metadata['snapshot_path']
        assert hashlib.file_digest(path.open('rb'), 'sha256').hexdigest() == metadata['sha256'], path
with (WORK / 'docs/inventory-review-queue.json').open('wb') as stream:
    subprocess.run(['python3', 'tools/review_inventory.py', '--dictionary', str(MAIN / '.direnv/dictionary-restoration/krdict.db')], cwd=WORK, stdout=stream, check=True)
subprocess.run(['python3', 'tools/review_inventory.py', '--verify'], cwd=WORK, check=True, stdout=subprocess.DEVNULL)
print('Installed audit and 25 controls archived; selected-source/runtime bytes retained; queue verified', flush=True)
