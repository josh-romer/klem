import assert from 'node:assert/strict';
import {isDeepStrictEqual} from 'node:util';
import {gunzipSync} from 'node:zlib';
import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root='/home/josh/projects/klem',proto='/home/josh/projects/klem/.direnv/formal-volitional-integration';
const url=process.env.KLEM_WEB_URL,cli=process.env.KLEM_BIN||'/home/josh/projects/klem/.direnv/formal-volitional-target/debug/klem',db=root+'/data/dictionaries/krdict/krdict.db',prefix=process.env.KLEM_CAPTURE_PREFIX||'/home/josh/projects/klem/.direnv/formal-volitional-installed-validation/formal-volitional-installed';
const suites=await Promise.all(['formal-volitional-validity.json','formal-volitional-novel-validity.json'].map(async name=>JSON.parse(await readFile(proto+'/tests/fixtures/'+name,'utf8'))));
const suite={cases:suites.flatMap(suite=>suite.cases)};
const grammarLabels=JSON.parse(await readFile(proto+'/web/src/grammar-labels.json','utf8'));
const cases=suite.cases.filter(c=>c.judgments.some(j=>j.verdict==='required'));
const {chromium}=createRequire(proto+'/web/package.json')('playwright');
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH,args:['--no-sandbox']});
const errors=[],exports=[],responses=[],diagrams=[],spacingDiagrams=[],nativeEntries=[],policyDecisions=[];
try {
 const page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});
 page.on('pageerror',error=>errors.push(String(error)));await page.goto(url);
 const breakdown=page.getByRole('region',{name:'Sentence breakdown',exact:true});
 for(const encoding of ['NFC','NFD']) {
  const text=cases.map(c=>c.surface.normalize(encoding)).join(' ');
  await page.getByLabel('Your sentence',{exact:true}).fill(text);
  const pending=page.waitForResponse(r=>r.url().endsWith('/api/analyze')&&r.request().postDataJSON()?.text===text);
  await page.getByRole('button',{name:'Analyze sentence',exact:true}).click();
  const response=await pending;assert.equal(response.status(),200);const api=await response.json();responses.push({encoding,api});
  assert.ok(api.rules['ending.formal_volitional']);
  await page.waitForFunction(t=>document.querySelector('.sentence')?.textContent===t,text);
  for(const [mode,flag]of[['raw',null],['headword','--dict-only'],['compatible','--dict-compatible']]) {
   if(flag){await page.getByLabel('Dictionary matches only').check();if(mode==='compatible')await page.getByLabel('Exclude known grammar conflicts').check();else await page.getByLabel('Exclude known grammar conflicts').uncheck();}
   else await page.getByLabel('Dictionary matches only').uncheck();
   const expected=execFileSync(cli,['text','-','--dictionary',db,...(flag?[flag]:[])],{input:text,encoding:'utf8',maxBuffer:32*1024*1024}).trim().split('\n').map(JSON.parse);
   const pending=page.waitForEvent('download');await page.getByRole('button',{name:'Export JSON',exact:true}).click();
   const exported=JSON.parse(await readFile(await(await pending).path(),'utf8'));assert.deepEqual(exported.records,expected);exports.push({encoding,mode,records:expected});
   for(const [ordinal,c]of cases.entries()) {
    const recordIndex=api.records.findIndex((r,i)=>r.kind==='word'&&api.records.slice(0,i).filter(t=>t.kind==='word').length===ordinal);
    const token=api.records[recordIndex];assert.equal(token.surface,c.surface.normalize(encoding));
    const judgment=c.judgments.find(j=>j.verdict==='required');
    const index=token.analysis.analyses.findIndex(a=>JSON.stringify(a.lemmas.map(l=>l.text))===JSON.stringify(judgment.lemmas)&&(!judgment.morphemes||JSON.stringify(a.morphemes.map(m=>m.form))===JSON.stringify(judgment.morphemes))&&judgment.required_rules.every(rule=>a.rules.includes(rule)));
    assert.ok(index>=0,c.id);
    const word=breakdown.locator('.breakdown-word').nth(ordinal),selector=word.getByRole('combobox');
    // Preserve the CLI policy for every originally authored path.
    const offered=await selector.locator('option').evaluateAll(os=>os.map(o=>o.value));
    const selectedPath=token.analysis.analyses[index];
    const allowed=expected[recordIndex].analysis?.analyses?.some(path=>isDeepStrictEqual(path,selectedPath))||false;
    assert.equal(offered.includes(String(index)),allowed,c.id+'/'+mode+'/policy');
    const decision={case_id:c.id,encoding,mode,record_index:recordIndex,raw_analysis_index:index,analysis:selectedPath,allowed,offered_indices:offered};
    if(!allowed){
     if(!expected[recordIndex].analysis?.analyses?.length){assert.ok(await selector.isDisabled());assert.equal(await word.locator('.breakdown-unavailable').textContent(),'No matching reading');decision.empty_message='No matching reading';}
     policyDecisions.push(decision);continue;
    }
    policyDecisions.push(decision);
    await selector.selectOption(String(index));
    const order=api.breakdowns[recordIndex][index];assert.ok(order);
    assert.equal(await word.locator('.part-form').count(),order.length,c.id);
    const ending=word.locator('.breakdown-component').last();
    const form=token.analysis.analyses[index].morphemes.at(-1).form;
    const last = token.analysis.analyses[index].morphemes.at(-1);
    const label = grammarLabels[last.kind==='particle'?form:'-'+form];
    const details = label ? {label:label.label,ids:label.sources.map(s=>s.id)} : null;
    assert.ok(details,c.id+'/'+form);
    assert.equal(await ending.locator('.part-gloss').textContent(),details.label,c.id);
    const refs=await ending.locator('.grammar-references a').evaluateAll(as=>as.map(a=>a.href));
    const ids=details.ids;
    const hint=await ending.locator('.breakdown-part').getAttribute('title');
    for(const id of ids)assert.ok(hint.includes(String(id)),c.id+'/'+id);
    assert.equal(refs.length,0,'KRDict label sources use the entry button and hint');
    diagrams.push({case_id:c.id,encoding,mode,analysis:token.analysis.analyses[index],forms:await word.locator('.part-form').allTextContents(),references:refs,source_hint:hint});
   }
  }
 }
 await page.getByLabel('Dictionary matches only').uncheck();
 await page.getByLabel('Your sentence',{exact:true}).fill('가렵니까 먹으렵니다 들으렵니까 하시렵니다');
 await page.getByRole('button',{name:'Analyze sentence',exact:true}).click();
 await page.waitForFunction(()=>document.querySelector('.sentence')?.textContent==='가렵니까 먹으렵니다 들으렵니까 하시렵니다');
 await breakdown.scrollIntoViewIfNeeded();assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 await page.screenshot({path:prefix+'-browser-desktop.png'});
 await page.setViewportSize({width:390,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:prefix+'-browser-mobile.png'});
 const native=JSON.parse(await readFile(proto+'/tests/fixtures/formal-volitional-browser-native-entries.json','utf8'));
 for(const[id,value]of Object.entries(native)) {
  const response=await page.request.post(url+'/api/entry',{data:{id}});assert.equal(response.status(),200);const data=await response.json();assert.deepEqual(data.entry,value);nativeEntries.push({id,entry:data.entry});
 }
 assert.deepEqual(errors,[]);assert.equal(exports.length,6);assert.equal(policyDecisions.length,cases.length*6);assert.equal(diagrams.length,policyDecisions.filter(decision=>decision.allowed).length);
 await writeFile(prefix+'-browser.json',JSON.stringify({state:'actual-installed-browser-passed',producer_sha256:createHash('sha256').update(await readFile(new URL(import.meta.url))).digest('hex'),responses,exports,diagrams,spacingDiagrams,nativeEntries,policyDecisions,errors,scope:'Actual installed Nix-launcher formal-volitional SolidJS prototype; all37required Source/boundary/novel paths under six Unicode/filter policies, exact CLI exports, and complete original Source/novel Native-owner closure. Contextual and independent review remain separate.'},null,2)+'\n');
 console.log('Passed',diagrams.length,'individual diagrams and six exact exports.');
} finally {await browser.close();}
