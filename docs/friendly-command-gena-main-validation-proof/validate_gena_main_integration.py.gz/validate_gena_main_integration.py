"""Fresh main integration checks; own Cargo target protects captured executables."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path
P = Path(__file__).resolve().parent
ROOT = P.parents[1]
OUT = P / 'friendly-command-gena-main-validation.json'
LOG = P / 'friendly-command-gena-main-validation.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *a: subprocess.check_output(['git', *a], cwd=ROOT)
assert not git('status', '--porcelain')
source = {n:sha((ROOT/n).read_bytes()) for n in git('ls-files', '-z').decode().split('\0')[:-1]}
head = git('rev-parse', 'HEAD').decode().strip(); index = sha(git('ls-files', '--stage', '-z'))
package = json.loads((P/'friendly-command-gena-promoted-nix-packages.json').read_bytes())
protected = package['protected_binaries']
assert all(sha(Path(p).read_bytes()) == h for p,h in protected.items())
selected = json.loads((P/'friendly-command-gena-promoted-portable-selected-source.json').read_bytes())
assert selected['state'] == 'passed'
for name, profile in selected['profiles'].items():
    prefix = 'web/' if name == 'klem-web-assets' else ''
    assert all(source[prefix + n] == h for n,h in profile['files'].items())
commands = [['cargo','test','--locked','--offline','--features','web',
             '--test','friendly_command_gena','--test','validity','--test','deoniman'],
            ['cargo','fmt','--all','--','--check'],
            ['cargo','clippy','--locked','--offline','--features','web',
             '--test','friendly_command_gena','--test','validity','--test','deoniman','--','-D','warnings']]
controls = [('test_friendly_command_gena_promoted_installed_audit.py',46),
            ('test_friendly_command_gena_ledger_audit.py',24),
            ('test_friendly_command_gena_ledger_descendant.py',12),
            ('test_friendly_command_historical_gena.py',8),
            ('test_literary_question_geona_runtime.py',112),
            ('test_gentle_command_long_ledger_audit.py',32),
            ('test_gentle_command_ledger_audit.py',26)]
commands += [['python3','-m','unittest','discover','-s','tools','-p',name] for name,_ in controls]
commands += [['python3','tools/review_inventory.py','--verify'],['git','diff','--check']]
env = dict(os.environ,CARGO_TARGET_DIR=str(ROOT/'.direnv/gena-main-integration-target'),CARGO_INCREMENTAL='0',PYTHONDONTWRITEBYTECODE='1')
r = dict(state='running',head=head,index_sha256=index,source_inputs=source,protected_binaries=protected,
         results=[],expected_python_controls=sum(n for _,n in controls),
         compiled_input_identity={k:len(v['files']) for k,v in selected['profiles'].items()},
         producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Fresh main23 Rust tests/three suites and260 portable/current/historical controls,fmt/focusedClippy/715-row queue. No full new main Nix/browser/quiet/contextual independent-review claim.')
def save():OUT.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
    with LOG.open('xb') as log:
        for command in commands:
            r['current_command'] = command;save()
            log.write(('COMMAND '+json.dumps(command)+'\n').encode());log.flush()
            job = subprocess.run(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            log.write(job.stdout);log.flush()
            r['results'].append(dict(command=command,exit_code=job.returncode,stdout=job.stdout.decode()))
            save();assert job.returncode==0
            if command[:2] == ['cargo','test']:
                batches = re.findall(rb'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',job.stdout,flags=re.M)
                assert len(batches)==3 and all(b[0]==b'ok' for b in batches)
                totals = [sum(int(b[i]) for b in batches) for i in [1,2,3]]
                assert totals==[23,0,0]
                r['rust'] = dict(passed=23,failed=0,ignored=0,batches=3)
            if command[:3] == ['python3','-m','unittest']:
                expected = dict(controls)[command[-1]]
                assert re.search(rb'Ran '+str(expected).encode()+rb' tests? in ',job.stdout) and job.stdout.rstrip().endswith(b'OK')
    r.update(state='passed',python_controls=sum(n for _,n in controls))
except BaseException as error:r.update(state='failed',error=repr(error));raise
finally:
    r.update(source_unchanged=all(sha((ROOT/n).read_bytes())==h for n,h in source.items()),
             head_unchanged=git('rev-parse','HEAD').decode().strip()==head,
             index_unchanged=sha(git('ls-files','--stage','-z'))==index,
             protected_binaries_unchanged=all(sha(Path(p).read_bytes())==h for p,h in protected.items()),
             log_sha256=sha(LOG.read_bytes()) if LOG.exists() else None,
             completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['source_unchanged','head_unchanged','index_unchanged','protected_binaries_unchanged']):r['state']='failed'
    save()
assert r['state']=='passed'
print('Fresh main23 Rust tests/260 controls/fmt/Clippy/715 queue passed; allsource/head/index/six binaries unchanged.',flush=True)
