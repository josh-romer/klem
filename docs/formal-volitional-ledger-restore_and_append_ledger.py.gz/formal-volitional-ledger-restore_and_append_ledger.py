"""Restore the full apprehensive parent and preserve the independent raw/dictionary scopes."""
import copy
import gzip
import hashlib
import json
import shutil
from pathlib import Path

BASE = Path('/home/josh/projects/klem/.direnv')
PARENT = BASE / 'fear-lsera-prototype'
ROOT = BASE / 'formal-volitional-prototype'
PREP = BASE / 'formal-volitional-prepared'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(p.read_bytes())
receipt_path = PREP / 'shared-ledger-append.json'
assert not receipt_path.exists()
excluded = {'node_modules', 'dist', '__pycache__', '.git', '.direnv', 'target'}
selected = lambda root: [p for p in root.rglob('*') if p.is_file() and not excluded & set(p.relative_to(root).parts)]
files = selected(PARENT)
parent = {str(p.relative_to(PARENT)): sha(p.read_bytes()) for p in files}
existing = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in selected(ROOT)}
allowed = {'src/engine.rs', 'src/grammar.rs', 'src/bin/klem-web/grammar_labels.rs', 'web/src/grammar-labels.json'}
for path in parent:
    if (ROOT / path).exists():
        assert path in allowed or existing[path] == parent[path], ('unexpected parent difference', path)
suite_path = ROOT / 'tests/fixtures/formal-volitional-validity.json'
suite = read(suite_path)
authored = read(PREP / 'independent-authoring.json')
assert sha(suite_path.read_bytes()) == authored['suite_sha256']
policy = read(PREP / 'evaluation-policy.json')
assert read(ROOT / 'tests/fixtures/formal-volitional-evaluation-policy.json') == policy
raw_suite = copy.deepcopy(suite)
conditional = set(policy['dictionary_required_case_ids'])
raw_suite['cases'] = [c for c in raw_suite['cases'] if c['id'] not in conditional]
raw_suite['review_status'] += ' Raw shared-ledger projection excludes only the six dictionary-POS-dependent cases in the pre-implementation evaluation policy; the unchanged full59 suite remains separately enforced with the original Native dictionary.'
assert len(raw_suite['cases']) == 53 and len(conditional) == 6
novel_path = ROOT / 'tests/fixtures/formal-volitional-novel-validity.json'
novel = read(novel_path)
prior = read(PARENT / 'tests/fixtures/validity.json')
assert len(prior['cases']) == 35530
assert not set(prior['sources']) & set(raw_suite['sources'])
assert not (set(prior['sources']) | set(raw_suite['sources'])) & set(novel['sources'])
assert len(novel['cases']) == 4
assert not {c['id'] for c in prior['cases']} & {c['id'] for c in raw_suite['cases'] + novel['cases']}
missing = []
for path, digest in parent.items():
    target = ROOT / path
    if target.exists():
        continue
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(PARENT / path, target)
    missing.append({'path': path, 'sha256': digest})
assert all(sha((ROOT / p).read_bytes()) == digest for p, digest in existing.items())
assert all(sha((PARENT / p).read_bytes()) == digest for p, digest in parent.items())
ledger_path = ROOT / 'tests/fixtures/validity.json'
assert read(ledger_path) == prior
before = ledger_path.read_bytes()
raw_path = ROOT / 'tests/fixtures/formal-volitional-raw-validity.json'
assert not raw_path.exists()
raw_path.write_text(json.dumps(raw_suite, ensure_ascii=False, indent=2) + '\n')
ledger = copy.deepcopy(prior)
for append in [raw_suite, novel]:
    ledger['cases'].extend(append['cases'])
    ledger['sources'].update(append['sources'])
assert ledger['cases'][:35530] == prior['cases']
assert ledger['cases'][35530:35583] == raw_suite['cases']
assert ledger['cases'][35583:] == novel['cases']
assert {k:v for k,v in ledger.items() if k not in ['cases','sources']} == {k:v for k,v in prior.items() if k not in ['cases','sources']}
counts = {v:sum(j['verdict'] == v for c in ledger['cases'] for j in c['judgments']) for v in ['required','forbidden']}
assert counts == {'required':31337, 'forbidden':4266}
ledger_path.write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n')
registry = ROOT / 'tools/literary_question_geona_runtime.py'
text = registry.read_text()
assert 'formal-volitional-raw-validity.json' not in text
marker = "    ('fear-lsera-validity.json',46,'2ccc67014adcae61861ee24774ddd2eae92bf82c7a9f3d138179460851390f25','fear-lsera'),\n"
assert text.count(marker) == 1
additions = ''.join("    ('" + filename + "'," + str(count) + ",'" + sha(path.read_bytes()) + "','" + label + "'),\n"
                    for filename,count,path,label in [
                        ('formal-volitional-raw-validity.json',53,raw_path,'formal-volitional raw'),
                        ('formal-volitional-novel-validity.json',4,novel_path,'formal-volitional novel')])
registry.write_text(text.replace(marker, marker + additions))
tests = ROOT / 'tools/test_literary_question_geona_runtime.py'
text = tests.read_text()
old = "'familiar-geurae-validity.json','fear-lsera-validity.json']"
assert text.count(old) == 2
text = text.replace(old, "'familiar-geurae-validity.json','fear-lsera-validity.json','formal-volitional-raw-validity.json','formal-volitional-novel-validity.json']")
new_tests = ''' def test_exact_pre_formal_volitional_ledger_still_passes(self):
  self.assertEqual(audit.verify_ledger(self.ledger_through(35530),self.proposal)['preserved_cases'],34920)
 def test_exact_pre_formal_volitional_novel_ledger_still_passes(self):
  self.assertEqual(audit.verify_ledger(self.ledger_through(35583),self.proposal)['preserved_cases'],34920)
 def test_formal_volitional_case_order_change_cannot_pass(self):
  c=copy.deepcopy(self.current);c['cases'][35582],c['cases'][35581]=c['cases'][35581],c['cases'][35582]
  with self.assertRaisesRegex(AssertionError,'append-only ledger'):audit.verify_ledger(c,self.proposal)
 def test_formal_volitional_source_change_cannot_pass(self):
  c=copy.deepcopy(self.current);c['sources']['krdict:86549']='https://example.invalid/changed'
  with self.assertRaisesRegex(AssertionError,'append-only ledger'):audit.verify_ledger(c,self.proposal)
 def test_coordinated_formal_volitional_raw_fixture_rewrite(self):
  self.coordinated_append_mutation('formal-volitional-raw-validity.json',35582,'formal-volitional raw')
 def test_coordinated_formal_volitional_novel_fixture_rewrite(self):
  self.coordinated_append_mutation('formal-volitional-novel-validity.json',35586,'formal-volitional novel')
'''
marker = "if __name__=='__main__':unittest.main()"
assert text.count(marker) == 1
tests.write_text(text.replace(marker, new_tests + marker))
assert sha(suite_path.read_bytes()) == authored['suite_sha256']
proof = {
    'state':'full-parent-restored-and-independent-ledger-scopes-prepared',
    'parent_files':parent, 'restored_files':missing, 'existing_files_conserved':len(existing),
    'previous_cases':35530, 'cases':len(ledger['cases']), 'counts':counts,
    'before_sha256':sha(before), 'after_sha256':sha(ledger_path.read_bytes()),
    'original_full59_sha256':sha(suite_path.read_bytes()), 'raw53_sha256':sha(raw_path.read_bytes()),
    'novel4_sha256':sha(novel_path.read_bytes()), 'dictionary_only_case_ids':sorted(conditional),
    'historical_controls':'six new controls prepared, not executed',
    'scope':'Exact full5096-file apprehensive parent restored without overwriting any formal private input. Preserve full59 original judgments unchanged and separately enforce all59 through Native dictionary compatibility. Shared raw ledger appends only the53 non-POS-dependent original cases and four manually reviewed novel paths; all earlier35530cases/source/metadata retained. Observed alternatives remain unjudged. Rust/historical/queue controls and browser/fullRust/Nix/installed/main integration remain pending.',
    'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},
}
receipt_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
(ROOT / 'docs/formal-volitional-shared-ledger-append.json.gz').write_bytes(gzip.compress(receipt_path.read_bytes(), mtime=0))
print('Restored',len(missing),'files; preserved',len(existing),'private inputs; ledger35530+53+4=',len(ledger['cases']),counts,flush=True)
