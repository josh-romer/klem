"""Run original Source/copula/novel dropdown regressions through the installed launcher."""
import hashlib
import json
import os
import re
import signal
import subprocess
import urllib.request
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = Path('/tmp/klem-willingness-interactions')
BINDING = PREP / 'willingness-installed-source-binding-retry1.json'
PREFIX = PREP / 'willingness-interaction-installed-browser-runtime'
OUT = Path(str(PREFIX) + '.json')
assert not OUT.exists()
binding = json.loads(BINDING.read_text())
assert binding['state'] == 'passed' and binding['inputs_unchanged']
# The installed package is the actual7dfparent. Require all current production
# Rust/manifest/frontend bytes to match; only two changed integration test files, the shared test ledger
# and one new fixture distinguish this regression branch's compiled-test profile.
different = []
for profile in binding['profiles'].values():
    for record in profile['files'].values():
        path = ROOT / record['snapshot_path']
        if hashlib.sha256(path.read_bytes()).hexdigest() != record['sha256']:
            different.append(record['snapshot_path'])
assert sorted(set(different)) == ['tests/fixtures/validity.json', 'tests/validity.rs', 'tests/willingness_question.rs'], 'only actual integration-test source differs'
BIN = Path(binding['profiles']['klem']['package']) / 'bin'
ASSETS = Path(binding['profiles']['web-assets']['package']) / 'share/klem-web'
LAUNCHER = Path(binding['launcher']['package']) / 'bin/klem-web'
DB = Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db')
DRIVER = PREP / 'willingness-interaction-installed-browser.mjs'
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [BIN / 'klem', BIN / 'klem-web', LAUNCHER, DB, DRIVER, Path(__file__), BINDING,
         ROOT / 'tests/fixtures/willingness-question-native-entries.json', ROOT / 'web/src/grammar-labels.json']
files.extend(ROOT / 'tests/fixtures' / name for name in ['willingness-question-validity.json', 'willingness-question-boundary-validity.json', 'willingness-question-interaction-validity.json'])
files.extend(path for path in ASSETS.rglob('*') if path.is_file())
frozen = {str(path): sha(path) for path in files}
command = [str(LAUNCHER), '--port', '0', '--dictionary', str(DB)]
r = {'state': 'running', 'command': command, 'frozen_inputs': frozen,
     'binding_sha256': sha(BINDING), 'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))}, 'scope': 'Actual7dfparent installed CLI/server/frontend/launcher, with every current production file byte-identical. Two integration-test sources, the shared test ledger and the new interaction fixture are outside this inherited compiled-test profile. All19source-authored paths,114policies/diagrams,sixCLIexports and29completeNative entries are checked. Newbranchfulltest/Nix/current-main and contextual/independent review stay separate.'}
OUT.write_text(json.dumps(r, indent=2) + '\n')
job = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
try:
    line = job.stderr.readline()
    match = re.search(r'http://127\.0\.0\.1:\d+', line)
    assert match, line
    url = match.group()
    r['url'] = url
    with urllib.request.urlopen(url + '/api/status', timeout=10) as response:
        r['status'] = json.load(response)
    with urllib.request.urlopen(url, timeout=10) as response:
        html = response.read()
        assert html == (ASSETS / 'index.html').read_bytes()
    for path in re.findall(r'(?:src|href)="(/assets/[^"?#]+\.(?:js|css))"', html.decode()):
        with urllib.request.urlopen(url + path, timeout=10) as response:
            assert response.read() == (ASSETS / path.lstrip('/')).read_bytes()
    env = dict(os.environ, KLEM_WEB_URL=url, KLEM_BIN=str(BIN / 'klem'),
               KLEM_CAPTURE_PREFIX=str(PREP / 'willingness-interaction-installed'),
               CHROMIUM_PATH='/nix/store/g0yvxs8p2ijrvmxpd5mim1ni0fyk9bnh-chromium-154.0.8037.57/bin/chromium')
    with Path(str(PREFIX) + '.log').open('xb') as log:
        completed = subprocess.run(['node', str(DRIVER)], env=env, stdout=log, stderr=subprocess.STDOUT)
    r.update(state='passed' if completed.returncode == 0 else 'failed', exit_code=completed.returncode)
finally:
    if job.poll() is None:
        job.send_signal(signal.SIGINT)
    r['server_exit_code'] = job.wait(timeout=20)
    r['server_stopped'] = True
    r['inputs_unchanged'] = all(sha(path) == digest for path, digest in frozen.items())
    OUT.write_text(json.dumps(r, indent=2) + '\n')
assert r['state'] == 'passed' and r['inputs_unchanged']
print('Actual installed parent-runtime interaction browser passed; owned server stopped', flush=True)
