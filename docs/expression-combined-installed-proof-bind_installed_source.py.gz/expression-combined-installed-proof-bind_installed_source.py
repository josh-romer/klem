"""Bind installed integration outputs to the actual current evaluated source profiles."""
import hashlib
import json
import subprocess
import datetime
import traceback
from pathlib import Path

import argparse
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
ROOT = Path('/tmp/klem-expression-conjectural-main')
OUT = args.output
assert not OUT.exists()
try:
    Path('/tmp/klem-expression-conjectural-main-nix-build').mkdir(parents=True, exist_ok=True)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
    index = subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT)
    sha_file = lambda path: hashlib.file_digest(Path(path).open('rb'), 'sha256').hexdigest()
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')[:-1]
    frozen = {name: sha_file(ROOT / name) for name in tracked}
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
    receipt = {'state': 'running', 'stage': 'evaluating-selected-sources', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head, 'all_tracked_files': frozen, 'source_profiles': {}}
    OUT.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    for name in ['klem', 'web-assets', 'corpus-adapter']:
        source = Path(subprocess.check_output(['nix', 'eval', '--offline', '--raw', 'git+file://' + str(ROOT) + '#packages.x86_64-linux.' + name + '.src'], cwd=ROOT, text=True).strip())
        files = {}
        for path in source.rglob('*'):
            assert not path.is_symlink()
            if not path.is_file():
                continue
            relative = str(path.relative_to(source))
            original = 'web/' + relative if name == 'web-assets' else relative
            data = path.read_bytes()
            assert data == (ROOT / original).read_bytes()
            files[relative] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'snapshot_path': original}
        receipt['source_profiles'][name] = {'source': str(source), 'files': files}
    full_path = Path('/home/josh/projects/klem/.direnv/expression-conjectural-main-prepared/combined-main-full-rust.json')
    full = json.loads(full_path.read_text())
    assert full['state'] == 'passed' and full['inputs_unchanged'] and full['head_unchanged'] and full['index_unchanged']
    assert full['totals']['failed'] == 0
    for profile in receipt['source_profiles'].values():
        for f in profile['files'].values():
            tested = str(ROOT / f['snapshot_path'])
            if tested in full['frozen_inputs']:
                assert f['sha256'] == full['frozen_inputs'][tested], ('selected source differs from full Rust input', tested)
    receipt.update(stage='building-packages', full_rust_totals=full['totals'], full_rust_inputs_bound=True)
    OUT.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    LOG = OUT.with_suffix('.log')
    assert not LOG.exists()
    with LOG.open('xb') as stream:
        built = subprocess.run(['nix', 'build', '--offline', '--option', 'build-dir', '/tmp/klem-expression-conjectural-main-nix-build', '--cores', '4', '--max-jobs', '1', '--no-link', '--print-out-paths', *['git+file://' + str(ROOT) + '#packages.x86_64-linux.' + n for n in ['klem', 'web-assets', 'corpus-adapter', 'web']]], cwd=ROOT, stdout=subprocess.PIPE, stderr=stream, text=True)
    assert built.returncode == 0, ('Nix package build failed', built.returncode, str(LOG))
    outputs = built.stdout.splitlines()
    assert len(outputs) == 4
    sha = lambda raw: hashlib.sha256(raw).hexdigest()
    profiles = {}
    for name, source_record in receipt['source_profiles'].items():
        ending = {'klem': '-klem-0.1.0', 'web-assets': '-klem-web-assets-0.1.0', 'corpus-adapter': '-klem-corpus-adapter-0.1.0'}[name]
        package = next(p for p in outputs if p.endswith(ending))
        derivation = subprocess.check_output(['nix-store', '--query', '--deriver', package], text=True).strip()
        raw = subprocess.check_output(['nix', 'derivation', 'show', derivation])
        parsed = json.loads(raw)
        assert set(parsed) == {derivation}
        drv = parsed[derivation]
        assert drv['outputs']['out']['path'] == package
        assert drv['env']['src'] == source_record['source']
        source = Path(source_record['source'])
        actual_files = {}
        for path in source.rglob('*'):
            assert not path.is_symlink()
            if not path.is_file():
                continue
            relative = str(path.relative_to(source))
            expected = source_record['files'][relative]
            data = path.read_bytes()
            assert sha(data) == expected['sha256'] and len(data) == expected['bytes']
            assert data == (ROOT / expected['snapshot_path']).read_bytes()
            actual_files[relative] = expected
        assert actual_files == source_record['files']
        profiles[name] = {'package': package, 'derivation': derivation, 'derivation_json': raw.decode(), 'derivation_json_sha256': sha(raw), 'source': str(source), 'files': actual_files}
    launcher_package = next(p for p in outputs if p.endswith('-klem-web'))
    launcher = Path(launcher_package) / 'bin/klem-web'
    text = launcher.read_text()
    assert profiles['klem']['package'] + '/bin/klem-web' in text
    assert profiles['web-assets']['package'] + '/share/klem-web' in text
    assert profiles['klem']['files'] == profiles['corpus-adapter']['files']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == head
    assert subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT) == index
    assert all(sha((ROOT / f['snapshot_path']).read_bytes()) == f['sha256']
               for p in profiles.values() for f in p['files'].values())
    assert all(sha_file(ROOT / name) == digest for name, digest in frozen.items()), 'every tracked source/proof input frozen'
    result = {'state': 'passed', 'outputs': outputs, 'head': head, 'exit_code': 0, 'inputs_unchanged': True, 'head_unchanged': True, 'index_unchanged': True, 'profiles': profiles, 'launcher': {'package': launcher_package, 'text': text, 'sha256': sha(launcher.read_bytes())}, 'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())}, 'scope': 'All actual installed CLI/server, frontend and adapter derivations bind the exact Git-backed evaluated sources; every source file equals the current integration source. Every bound source file and HEAD/index remain unchanged during this binding. Actual launcher binds the same CLI/server and assets. Runtime/browser/adapter/performance remain separate.', 'full_coverage_complete': False, 'full_rust_input_receipt_sha256': sha(full_path.read_bytes()), 'full_rust_totals': full['totals'], 'all_tracked_files': frozen, 'all_tracked_inputs_unchanged': True, 'log_sha256': sha_file(LOG)}
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print('Bound installed exact source profiles:', {name: len(v['files']) for name, v in profiles.items()}, 'and launcher', flush=True)
except Exception as error:
    failure = {'state': 'failed', 'error_type': type(error).__name__, 'error': str(error), 'traceback': traceback.format_exc(), 'producer': {'text': Path(__file__).read_text(), 'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
    if 'receipt' in globals():
        failure['started_capture'] = receipt
    OUT.write_text(json.dumps(failure, ensure_ascii=False, indent=2) + '\n')
    raise
