"""Classify source-tail observations for triage, never as gold lemma judgments."""
import bisect,gzip,hashlib,json,unicodedata
from collections import Counter
from pathlib import Path
PREFIX=Path('/tmp/klem-unreviewed-inventory');OUT=Path(str(PREFIX)+'-discovery.json.gz');assert not OUT.exists()
read=lambda p:json.load(gzip.open(p,'rt'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
closure_path=Path(str(PREFIX)+'-source-closure.json.gz');runtime_path=Path(str(PREFIX)+'-preflight.json.gz');closure=read(closure_path);runtime=read(runtime_path);assert runtime['state']=='complete-unreviewed-source-runtime-preparation-passed'
groups=closure['groups'];starts=[g['span']['start'] for g in groups];assert starts==sorted(starts)
entries={r['source']['id']:r for r in closure['review_entries']};assert len(entries)==237
nfd=lambda s:unicodedata.normalize('NFD',s)
translate=str.maketrans({'ㄴ':'ᆫ','ㄹ':'ᆯ','ㅁ':'ᆷ','ㅂ':'ᆸ'})
streams=[];paths=[]
for mode in ['raw','headword','compatible']:
 path=Path(str(PREFIX)+f'-{mode}-0.jsonl.gz');paths.append(path);streams.append(gzip.open(path,'rt'))
observations=[];tallies={ident:Counter() for ident in entries};frames=0
try:
 import itertools
 for triple in itertools.zip_longest(*streams):
  assert all(line is not None for line in triple);frames+=1;records=[json.loads(line) for line in triple]
  raw=records[0];assert all(r['surface']==raw['surface'] and r['span']==raw['span'] for r in records)
  if not raw.get('analysis'):continue
  group=groups[bisect.bisect_right(starts,raw['span']['start'])-1];assert group['span']['start']<=raw['span']['start']<raw['span']['end']<=group['span']['end']
  source=entries[group['entry_id']]['source'];head=source['headword'];pattern=nfd(head.strip('-').translate(translate));word=nfd(raw['analysis']['normalized']);infix=head.endswith('-')
  if not pattern or not (pattern in word if infix else word.endswith(pattern)):continue
  kinds={'ending','prefinal'} if source['pos']=='어미' else {'particle'}
  def traces(record):
   matches=[]
   for ordinal,a in enumerate(record['analysis']['analyses']):
    morphs=[m['form'] for m in a['morphemes'] if m['kind'] in kinds]
    forms=morphs+[''.join(morphs)]
    if any(pattern in nfd(f) if infix else nfd(f).endswith(pattern) for f in forms):matches.append(ordinal)
   return matches
  matches={mode:traces(record) for mode,record in zip(['raw','headword','compatible'],records,strict=True)}
  status='source-label-trace-present' if matches['compatible'] else 'compatible-empty' if not records[-1]['analysis']['analyses'] else 'no-direct-source-label-trace'
  tallies[source['id']][status]+=1
  ident=group['id']+'-token-'+str(raw['span']['start']-group['span']['start'])
  observations.append({'id':ident,'entry_id':source['id'],'source_group_id':group['id'],'source_headword':head,'surface':raw['surface'],'span':raw['span'],'complete_original_group':group['complete_original_examples'],'matching_analysis_ordinals':matches,'discovery_status':status,'records':dict(zip(['raw','headword','compatible'],records,strict=True)),'linguistic_verdict':'unjudged','note':'NFD orthographic tail/infix plus canonical morpheme-label matching is triage. Whole lexical homonyms, composite bundles, allomorph classes and source context may differ; neither present nor absent traces establish intended lemma correctness.'})
finally:
 for stream in streams:stream.close()
assert len({o['id'] for o in observations})==len(observations)
summary=[{'entry_id':ident,'headword':entries[ident]['source']['headword'],'pos':entries[ident]['source']['pos'],'observations':dict(tallies[ident]),'no_direct_source_observation':not tallies[ident],'disposition':'unreviewed'} for ident in entries]
r={'state':'complete-source-runtime-discovery-preparation-passed','entries':237,'original_groups':1621,'frames_per_mode':frames,'direct_source_observations':observations,'summary':summary,'input_sha256':{str(p):sha(p) for p in [closure_path,runtime_path,*paths,Path(__file__)]},'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'All237entries remain unreviewed. Complete original groups and actual raw/headword/Compatible readings retained for every observed orthographic tail/infix. Canonical source-label traces are discovery signals, not annotation gold, contextual sense judgments or completeness proof.'};OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Prepared',len(observations),'direct-tail/infix observations across',len(entries),'unreviewed entries; states:',Counter(o['discovery_status'] for o in observations))
