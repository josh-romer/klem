{
  description = "A rule-based Korean lemmatizer: Rust library, CLI, and development environment";

  inputs.nixpkgs.url = "github:NixOS/nixpkgs/nixpkgs-unstable";

  outputs = { self, nixpkgs, ... }:
    let
      systems = [
        "x86_64-linux"
        "aarch64-linux"
        "aarch64-darwin"
      ];
      forAllSystems = nixpkgs.lib.genAttrs systems;
      manifest = builtins.fromTOML (builtins.readFile ./Cargo.toml);
    in
    {
      packages = forAllSystems (system:
        let
          pkgs = nixpkgs.legacyPackages.${system};
          klem = pkgs.rustPlatform.buildRustPackage {
            pname = manifest.package.name;
            version = manifest.package.version;

            # Keep build outputs, downloaded corpora, and local caches out of the source.
            src = pkgs.lib.fileset.toSource {
              root = ./.;
              fileset = pkgs.lib.fileset.unions [
                ./Cargo.toml
                ./Cargo.lock
                ./src
                ./tests
                ./docs/adverb-root-inventory.json
                ./docs/ssik-morphology-projection.json
                ./docs/question-case-source-preflight.json
                ./docs/question-clause-additive-preflight.json
                ./docs/continuation-left-source-preflight.json
                ./docs/continuation-inflection-source-preflight.json
                ./docs/continuation-gold-residual-preflight.json
                ./examples
                ./tools/corpus.rs
                ./tools/validity.rs
                ./tools/adjectival_allomorph.rs
                ./tools/hada_nominal_preservation.rs
                ./README.md
                ./LICENSE-MIT
                ./LICENSE-APACHE
                ./web/src/grammar-labels.json
              ];
            };

            cargoLock.lockFile = ./Cargo.lock;
            buildFeatures = [ "web" ];
            checkFeatures = [ "web" ];
            doCheck = true;

            meta = {
              description = manifest.package.description;
              license = with pkgs.lib.licenses; [ mit asl20 cc-by-sa-40 ];
              mainProgram = "klem";
              platforms = systems;
            };
          };
          web-assets = pkgs.buildNpmPackage {
            pname = "klem-web-assets";
            version = manifest.package.version;
            src = pkgs.lib.fileset.toSource {
              root = ./web;
              fileset = pkgs.lib.fileset.unions [
                ./web/package.json ./web/package-lock.json ./web/index.html
                ./web/tsconfig.json ./web/vite.config.ts ./web/src ./web/public
              ];
            };
            npmDepsHash = "sha256-TPUi4+ekXlwgRQDE9CVwvENqwIgQIi1LOvRGiPDiyDg=";
            installPhase = ''
              runHook preInstall
              mkdir -p $out/share/klem-web
              cp -r dist/. $out/share/klem-web/
              runHook postInstall
            '';
          };
          web = pkgs.writeShellApplication {
            name = "klem-web";
            text = ''
              exec ${klem}/bin/klem-web --assets ${web-assets}/share/klem-web "$@"
            '';
          };
          corpus-adapter = klem.overrideAttrs (old: {
            pname = "klem-corpus-adapter";
            cargoBuildFlags = [ "--example" "evaluate" ];
            # The main check tests this exact library source. Adapter parity
            # checks separately exercise every held-out annotated corpus row.
            doCheck = false;
            installPhase = ''
              runHook preInstall
              mkdir -p $out/bin
              cp target/${pkgs.stdenv.hostPlatform.rust.rustcTarget}/release/examples/evaluate $out/bin/klem-corpus-adapter
              runHook postInstall
            '';
            meta = old.meta // {
              description = "Korean annotated-corpus evaluation adapter";
              mainProgram = "klem-corpus-adapter";
            };
          });
        in
        {
          inherit klem web web-assets corpus-adapter;
          default = klem;
        });

      apps = forAllSystems (system:
        let
          app = {
            type = "app";
            program = nixpkgs.lib.getExe self.packages.${system}.klem;
            meta.description = manifest.package.description;
          };
        in
        {
          klem = app;
          default = app;
          web = {
            type = "app";
            program = nixpkgs.lib.getExe self.packages.${system}.web;
            meta.description = "Local SolidJS Korean sentence explorer";
          };
        });

      checks = forAllSystems (system:
        let pkgs = nixpkgs.legacyPackages.${system};
        in {
          inherit (self.packages.${system}) klem web-assets corpus-adapter;
          inventory-review = pkgs.runCommand "klem-inventory-review" {
            nativeBuildInputs = [ pkgs.python3 ];
            src = pkgs.lib.fileset.toSource {
              root = ./.;
              fileset = pkgs.lib.fileset.unions [
                # Package audits bind the complete Rust and frontend source
                # snapshots, including manifests and production import tests.
                ./Cargo.toml ./Cargo.lock ./src ./examples
                ./README.md ./LICENSE-MIT ./LICENSE-APACHE
                ./tools/corpus.rs ./tools/validity.rs
                ./web/package.json ./web/package-lock.json ./web/index.html
                ./web/tsconfig.json ./web/vite.config.ts ./web/src ./web/public
                ./tools/review_inventory.py ./tools/test_review_inventory.py
                ./tools/excluded_paradigm_audit.py
                ./tools/excluded_paradigm_queue.py
                ./tools/question_topic_audit.py
                ./tools/question_topic_queue.py
                ./tools/question_additive_audit.py
                ./tools/question_additive_queue.py
                ./tools/continuation_left_audit.py
                ./tools/continuation_left_compare.py
                ./tools/continuation_left_queue.py
                ./tools/continuation_left_broad_queue.py
                ./tools/continuation_left_corpus_audit.py
                ./tools/continuation_residual_audit.py
                ./tools/continuation_inflection_audit.py
                ./tools/continuation_inflection_additional.py
                ./tools/continuation_inflection_review.py
                ./tools/continuation_inflection_compare.py
                ./tools/continuation_inflection_queue.py
                ./tools/bare_noun_spacing_audit.py
                ./tools/bare_noun_spacing_additional.py
                ./tools/bare_noun_spacing_compare.py
                ./tools/bare_noun_spacing_runtime.py
                ./tools/bare_noun_spacing_queue.py
                ./tools/lexical_nada_audit.py
                ./tools/lexical_nada_review.py
                ./tools/lexical_nada_fixtures.py
                ./tools/lexical_nada_dependencies.py
                ./tools/lexical_nada_priority.py
                ./tools/lexical_nada_compare.py
                ./tools/lexical_nada_runtime.py
                ./tools/lexical_nada_queue.py
                ./tools/lexical_nada_country_tree_review.py
                ./tools/lexical_nada_listed_review.py
                ./tools/lexical_nada_listed_fixtures.py
                ./tools/lexical_nada_listed_compare.py
                ./tools/lexical_nada_listed_runtime.py
                ./tools/lexical_nada_listed_additional.py
                ./tools/lexical_nada_listed_queue.py
                ./tools/rya_boundary_audit.py
                ./tools/rya_boundary_regressions.py
                ./tools/rya_boundary_compare.py
                ./tools/rya_boundary_runtime.py
                ./tools/rya_boundary_queue.py
                ./tools/rya_copula_audit.py
                ./tools/rya_copula_compare.py
                ./tools/rya_copula_runtime.py
                ./tools/rya_copula_queue.py
                ./tools/caution_ending_audit.py
                ./tools/caution_ending_compare.py
                ./tools/caution_ending_runtime.py
                ./tools/caution_ending_queue.py
                ./tools/future_question_audit.py
                ./tools/future_question_compare.py
                ./tools/future_question_additional.py
                ./tools/future_question_runtime.py
                ./tools/future_question_queue.py
                ./tools/reported_retrospective_audit.py
                ./tools/reported_retrospective_corrections.py
                ./tools/reported_retrospective_compare.py
                ./tools/reported_retrospective_additional.py
                ./tools/reported_retrospective_queue.py
                ./tools/reported_retrospective_runtime.py
                ./tools/adjectival_allomorph_audit.py
                ./tools/adjectival_allomorph_corrections.py
                ./tools/adjectival_allomorph_policy.py
                ./tools/adjectival_allomorph_checkpoint.py
                ./tools/adjectival_allomorph_corpora.py
                ./tools/adjectival_allomorph_compare.py
                ./tools/adjectival_allomorph_runtime.py
                ./tools/adjectival_allomorph_browser.py
                ./tools/gam_question_audit.py
                ./tools/gam_question_regressions.py
                ./tools/gam_question_compare.py
                ./tools/gam_question_corpora.py
                ./tools/gam_question_runtime.py
                ./tools/gam_question_queue.py
                ./tools/gam_question_implementation.py
                ./tools/emphatic_ending_audit.py
                ./tools/emphatic_ending_regressions.py
                ./tools/emphatic_ending_corpora.py
                ./tools/emphatic_ending_diagnostics.py
                ./tools/emphatic_ending_compare.py
                ./tools/emphatic_ending_runtime.py
                ./tools/emphatic_ending_queue.py
                ./tools/doeda_role_audit.py
                ./tools/doeda_role_regressions.py
                ./tools/doeda_role_diagnostics.py
                ./tools/doeda_role_historical.py
                ./tools/doeda_role_stress.py
                ./tools/doeda_role_corpora.py
                ./tools/doeda_role_compare.py
                ./tools/doeda_role_runtime.py
                ./tools/doeda_role_browser.py
                ./tools/doeda_complement_audit.py
                ./tools/doeda_complement_regressions.py
                ./tools/doeda_complement_diagnostics.py
                ./tools/doeda_complement_package.py
                ./tools/doeda_complement_compare.py
                ./tools/doeda_complement_corpora.py
                ./tools/test_doeda_complement_corpora.py
                ./tools/doeda_noun_suffix_discovery.py
                ./tools/doeda_suffix_audit.py
                ./tools/doeda_suffix_regressions.py
                ./tools/doeda_suffix_diagnostics.py
                ./tools/doeda_suffix_package.py
                ./tools/doeda_suffix_compare.py
                ./tools/doeda_suffix_corpora.py
                ./tools/doeda_suffix_performance.py
                ./tools/test_doeda_suffix_regressions.py
                ./tools/test_doeda_suffix_diagnostics.py
                ./tools/test_doeda_suffix_package.py
                ./tools/test_doeda_suffix_compare.py
                ./tools/test_doeda_suffix_corpora.py
                ./tools/test_doeda_suffix_performance.py
                ./tools/doeda_native_audit.py
                ./tools/doeda_native_preflight.py
                ./tools/doeda_native_implementation.py
                ./tools/doeda_native_regressions.py
                ./tools/doeda_native_diagnostics.py
                ./tools/doeda_native_runtime.py
                ./tools/doeda_native_package.py
                ./tools/doeda_native_compare.py
                ./tools/doeda_native_corpora.py
                ./tools/doeda_native_performance.py
                ./tools/test_doeda_native_audit.py
                ./tools/test_doeda_native_diagnostics.py
                ./tools/test_doeda_native_package.py
                ./tools/test_doeda_native_compare.py
                ./tools/test_doeda_native_corpora.py
                ./tools/test_doeda_native_performance.py
                ./tools/doeda_identity_audit.py
                ./tools/doeda_identity_implementation.py
                ./tools/doeda_identity_diagnostics.py
                ./tools/doeda_identity_runtime.py
                ./tools/doeda_identity_package.py
                ./tools/doeda_identity_observations.py
                ./tools/doeda_identity_corpora.py
                ./tools/doeda_identity_performance.py
                ./tools/test_doeda_identity_release.py
                ./tools/test_doeda_identity.py
                ./src/doeda_identity.rs
                ./src/doeda_originless_forms.rs
                ./tools/doeda_originless_audit.py
                ./tools/doeda_originless_implementation.py
                ./tools/doeda_originless_diagnostics.py
                ./tools/test_doeda_originless.py
                ./tools/doeda_originless_runtime.py
                ./tools/doeda_originless_package.py
                ./tools/doeda_originless_observations.py
                ./tools/doeda_originless_corpora.py
                ./tools/doeda_originless_performance.py
                ./tools/test_doeda_originless_release.py
                ./tools/doeda_partial_origins.py
                ./tools/well_doeda_audit.py
                ./tools/test_well_doeda_audit.py
                ./tools/well_doeda_broad.py
                ./tools/well_doeda_corpora.py
                ./tools/well_doeda_runtime.py
                ./tools/well_doeda_release.py
                ./tools/well_doeda_performance.py
                ./tools/test_well_doeda_release.py
                ./tools/nominal_si_audit.py
                ./tools/nominal_si_broad.py
                ./tools/nominal_si_corpora.py
                ./tools/nominal_si_runtime.py
                ./tools/test_nominal_si_audit.py
                ./tools/test_nominal_si_runtime.py
                ./tools/nominal_si_release.py
                ./tools/nominal_si_performance.py
                ./tools/test_nominal_si_release.py
                ./tools/nominal_hwa_audit.py
                ./tools/test_nominal_hwa_audit.py
                ./tools/nominal_hwa_broad.py
                ./tools/nominal_hwa_corpora.py
                ./tools/nominal_hwa_runtime.py
                ./tools/test_nominal_hwa_runtime.py
                ./tools/nominal_hwa_release.py
                ./tools/nominal_hwa_performance.py
                ./tools/test_nominal_hwa_release.py
                ./tools/nominal_hwa_hada_release.py
                ./tools/nominal_hwa_hada_performance.py
                ./tools/test_nominal_hwa_hada_release.py
                ./tools/nominal_hwa_hada_broad.py
                ./tools/nominal_hwa_hada_corpora.py
                ./tools/test_nominal_hwa_hada_corpora.py
                ./tools/nominal_hwa_hada_audit.py
                ./tools/test_nominal_hwa_hada_audit.py
                ./tools/nominal_hwa_hada_runtime.py
                ./tools/test_nominal_hwa_hada_runtime.py
                ./tools/nominal_si_hada_release.py
                ./tools/nominal_si_hada_performance.py
                ./tools/test_nominal_si_hada_release.py
                ./tools/hada_nominal_release.py
                ./tools/hada_nominal_performance.py
                ./tools/test_hada_nominal_release.py
                ./tools/hada_nominal_broad.py
                ./tools/hada_nominal_corpora.py
                ./tools/test_hada_nominal_release_audits.py
                ./tools/hada_nominal_runtime.py
                ./tools/test_hada_nominal_runtime.py
                ./web/tests/hada-nominal.mjs
                ./tools/hada_nominal_audit.py
                ./tools/test_hada_nominal_audit.py
                ./tools/hada_remaining_audit.py
                ./tools/test_hada_remaining_audit.py
                ./web/src/hada-sources.json
                ./tools/hada_remaining_context.py
                ./tools/hada_remaining_runtime.py
                ./tools/test_hada_remaining_runtime.py
                ./web/tests/hada-remaining.mjs
                ./web/tests/hada-remaining-scoped.mjs
                ./web/src/breakdown.ts
                ./tools/hada_remaining_scoped_runtime.py
                ./tools/test_hada_remaining_scoped_runtime.py
                ./tools/replay_scoped_browser.py
                ./tools/hada_remaining_broad.py
                ./tools/hada_remaining_corpora.py
                ./tools/test_hada_remaining_release_audits.py
                ./tools/hada_remaining_release.py
                ./tools/hada_remaining_performance.py
                ./tools/test_hada_remaining_release.py
                ./tools/ssik_audit.py
                ./tools/ssik_adverb_audit.py
                ./tools/ssik_adverb_comparison.py
                ./tools/ssik_adverb_morphology.py
                ./tools/ssik_adverb_runtime.py
                ./tools/ssik_adverb_outer_tails.py
                ./tools/friendly_command_preparation.py
                ./tools/friendly_command_audit.py
                ./tools/degree_expectation_audit.py
                ./tools/degree_expectation_parent.py
                ./tools/degree_expectation_runtime.py
                ./tools/degree_expectation_corpora.py
                ./tools/degree_expectation_broad.py
                ./tools/degree_expectation_release.py
                ./tools/test_degree_expectation_release.py
                ./tools/copula_expectation_production.py
                ./tools/copula_expectation_browser.py
                ./tools/copula_expectation_audit.py
                ./tools/test_copula_expectation_audit.py
                ./tools/copula_expectation_release.py
                ./tools/test_copula_expectation_release.py
                ./tools/copula_expectation_performance.py
                ./tools/reported_deoni_parent.py
                ./tools/reported_deoni_audit.py
                ./tools/reported_deoni_broad.py
                ./tools/reported_deoni_corpora.py
                ./tools/reported_deoni_production.py
                ./tools/reported_deoni_browser.py
                ./tools/test_reported_deoni.py
                ./tools/reported_deoni_release.py
                ./tools/test_reported_deoni_release.py
                ./tools/reported_deoni_complete_sources.py
                ./tools/test_reported_deoni_complete_sources.py
                ./tools/reported_dana_parent.py
                ./tools/reported_dana_inputs.py
                ./tools/present_prefinal_audit.py
                ./tools/test_present_prefinal_audit.py
                ./tools/past_prefinal_audit.py
                ./tools/test_past_prefinal_audit.py
                ./tools/double_past_prefinal_audit.py
                ./tools/test_double_past_prefinal_audit.py
                ./tools/literary_ri_prefinal_audit.py
                ./tools/test_literary_ri_prefinal_audit.py
                ./tools/literary_ri_prefinal_preservation.py
                ./tools/test_literary_ri_prefinal_preservation.py
                ./tools/literary_ri_prefinal_replay.py
                ./tools/literary_ri_prefinal_adapter_replay.py
                ./tools/literary_ri_prefinal_runtime.py
                ./tools/test_literary_ri_prefinal_runtime.py
                ./tools/literary_ri_prefinal_sources.py
                ./tools/test_literary_ri_prefinal_sources.py
                ./tools/klem_declarative_contrast_inversion.py
                ./tools/declarative_contrast_audit.py
                ./tools/test_declarative_contrast_audit.py
                ./tools/declarative_contrast_preservation.py
                ./tools/test_declarative_contrast_preservation.py
                ./tools/declarative_contrast_replay.py
                ./tools/declarative_contrast_adapter_replay.py
                ./tools/declarative_contrast_sources.py
                ./tools/test_declarative_contrast_sources.py
                ./tools/declarative_contrast_runtime.py
                ./tools/test_declarative_contrast_runtime.py
                ./tools/declarative_contrast_performance.py
                ./tools/capture_declarative_contrast_performance.py
                ./tools/test_declarative_contrast_performance.py
                ./tools/literary_question_go_browser_audit.py
                ./tools/test_literary_question_go_browser_audit.py
                ./tools/literary_question_go_preservation.py
                ./tools/test_literary_question_go_preservation.py
                ./tools/literary_question_go_package.py
                ./tools/test_literary_question_go_package.py
                ./tools/test_literary_question_go_package_runtime.py
                ./tools/test_literary_question_go_package_adapter_audit.py
                ./tools/test_literary_question_go_package_browser_audit.py
                ./tools/capture_literary_question_go_launcher.py
                ./tools/capture_literary_question_go_performance.py
                ./tools/literary_question_go_performance.py
                ./tools/test_literary_question_go_performance.py
                ./tools/literary_question_go_sources.py
                ./tools/test_literary_question_go_sources.py
                ./tools/literary_future_kko_audit.py
                ./tools/test_literary_future_kko_audit.py
                ./tools/literary_future_kko_preservation.py
                ./tools/test_literary_future_kko_preservation.py
                ./tools/literary_future_kko_runtime.py
                ./tools/test_literary_future_kko_runtime.py
                ./tools/literary_future_kko_replay.py
                ./tools/literary_future_kko_adapter_replay.py
                ./tools/literary_future_kko_adapter_audit.py
                ./tools/test_literary_future_kko_adapter_audit.py
                ./tools/literary_future_kko_browser_audit.py
                ./tools/test_literary_future_kko_browser_audit.py
                ./tools/capture_literary_future_kko_web.py
                ./web/tests/literary-future-kko.mjs
                ./tools/capture_literary_future_kko_performance.py
                ./tools/literary_future_kko_performance.py
                ./tools/test_literary_future_kko_performance.py
                ./tools/capture_literary_future_kko_sources.py
                ./tools/literary_future_kko_sources.py
                ./tools/test_literary_future_kko_sources.py
                ./tools/literary_future_kko_package.py
                ./tools/test_literary_future_kko_package.py
                ./tools/capture_literary_question_geona_performance.py
                ./tools/capture_literary_question_geona_sources.py
                ./tools/capture_literary_question_geona_web.py
                ./tools/literary_question_geona_adapter_audit.py
                ./tools/literary_question_geona_adapter_replay.py
                ./tools/literary_question_geona_browser_audit.py
                ./tools/literary_question_geona_package.py
                ./tools/literary_question_geona_package_binding.py
                ./tools/literary_question_geona_performance.py
                ./tools/literary_question_geona_replay.py
                ./tools/literary_question_geona_runtime.py
                ./tools/literary_question_geona_sources.py
                ./tools/test_literary_question_geona_adapter_audit.py
                ./tools/test_literary_question_geona_browser_audit.py
                ./tools/test_literary_question_geona_package.py
                ./tools/test_literary_question_geona_performance.py
                ./tools/test_literary_question_geona_runtime.py
                ./tools/test_literary_question_geona_sources.py
                ./web/tests/literary-question-geona.mjs
                ./tools/additive_ppundeoreo_audit.py
                ./tools/additive_ppundeoreo_main.py
                ./tools/additive_ppundeoreo_sources.py
                ./tools/additive_ppundeoreo_package.py
                ./tools/additive_ppundeoreo_performance.py
                ./tools/capture_additive_ppundeoreo_performance.py
                ./tools/test_additive_ppundeoreo_sources.py
                ./tools/test_additive_ppundeoreo_package.py
                ./tools/test_additive_ppundeoreo_performance.py
                ./tools/test_additive_ppundeoreo_main.py
                ./tools/additive_ppundeoreo_adapter_audit.py
                ./tools/additive_ppundeoreo_browser_audit.py
                ./tools/additive_ppundeoreo_preservation_audit.py
                ./tools/predicate_auxiliary_spacing_runtime.py
                ./tools/test_predicate_auxiliary_spacing_runtime.py
                ./tools/predicate_auxiliary_spacing_sources.py
                ./tools/capture_predicate_auxiliary_spacing_sources.py
                ./tools/capture_predicate_auxiliary_spacing_cli.py
                ./tools/capture_predicate_auxiliary_spacing_adapter.py
                ./tools/predicate_auxiliary_spacing_adapter_audit.py
                ./tools/predicate_auxiliary_spacing_package.py
                ./tools/capture_predicate_auxiliary_spacing_performance.py
                ./tools/predicate_auxiliary_spacing_performance.py
                ./tools/test_predicate_auxiliary_spacing_performance.py
                ./tools/possessive_bound_noun_runtime.py
                ./tools/test_possessive_bound_noun_runtime.py
                ./tools/possessive_bound_noun_package_audit.py
                ./tools/test_possessive_bound_noun_package_audit.py
                ./tools/possessive_bound_noun_performance.py
                ./tools/test_possessive_bound_noun_performance.py
                ./tools/declarative_dao_audit.py
                ./tools/test_declarative_dao_audit.py
                ./tools/declarative_dao_preservation.py
                ./tools/test_declarative_dao_preservation.py
                ./tools/declarative_dao_performance.py
                ./tools/proper_name_source_audit.py
                ./tools/test_proper_name_source_audit.py
                ./tools/self_question_source_audit.py
                ./tools/test_self_question_source_audit.py
                ./tools/self_question_cohort_audit.py
                ./tools/test_self_question_cohort_audit.py
                ./tools/dapnikka_source_audit.py
                ./tools/test_dapnikka_source_audit.py
                ./tools/dapnikka_cohort_audit.py
                ./tools/test_dapnikka_cohort_audit.py
                ./tools/dapnikka_broad_audit.py
                ./tools/test_dapnikka_broad_audit.py
                ./tools/formal_b_source_audit.py
                ./tools/test_formal_b_source_audit.py
                ./tools/formal_b_cohort_audit.py
                ./tools/test_formal_b_cohort_audit.py
                ./tools/formal_b_broad_audit.py
                ./tools/test_formal_b_broad_audit.py
                ./tools/formal_b_installed_audit.py
                ./tools/test_formal_b_installed_audit.py
                ./tools/reported_experience_source_audit.py
                ./tools/test_reported_experience_source_audit.py
                ./tools/reported_experience_cohort_audit.py
                ./tools/test_reported_experience_cohort_audit.py
                ./tools/reported_experience_broad_audit.py
                ./tools/test_reported_experience_broad_audit.py
                ./tools/reported_experience_corpora_audit.py
                ./tools/test_reported_experience_corpora_audit.py
                ./tools/reported_experience_installed_audit.py
                ./tools/test_reported_experience_installed_audit.py
                ./tools/reported_experience_performance.py
                ./tools/test_reported_experience_performance.py
                ./tools/formal_volitional_expression_audit.py
                ./tools/test_formal_volitional_expression_audit.py
                ./tools/formal_volitional_expression_streams_audit.py
                ./tools/test_formal_volitional_expression_streams_audit.py
                ./tools/conjectural_additive_source_audit.py
                ./tools/test_conjectural_additive_source_audit.py
                ./tools/conjectural_additive_prototype_audit.py
                ./tools/test_conjectural_additive_prototype_audit.py
                ./tools/conjectural_additive_distribution_audit.py
                ./tools/test_conjectural_additive_distribution_audit.py
                ./tools/conjectural_additive_ledger_audit.py
                ./tools/test_conjectural_additive_ledger_audit.py
                ./tools/conjectural_additive_novel_audit.py
                ./tools/test_conjectural_additive_novel_audit.py
                ./tools/conjectural_additive_installed_audit.py
                ./tools/test_conjectural_additive_installed_audit.py
                ./tools/expression_conjectural_ledger_audit.py
                ./tools/test_expression_conjectural_ledger_audit.py
                ./tools/expression_conjectural_installed_audit.py
                ./tools/test_expression_conjectural_installed_audit.py
                ./tools/willingness_question_source_audit.py
                ./tools/test_willingness_question_source_audit.py
                ./tools/willingness_question_distribution_audit.py
                ./tools/test_willingness_question_distribution_audit.py
                ./tools/willingness_question_browser_audit.py
                ./tools/test_willingness_question_browser_audit.py
                ./tools/willingness_question_installed_audit.py
                ./tools/test_willingness_question_installed_audit.py
                ./tools/willingness_question_interaction_browser_audit.py
                ./tools/test_willingness_question_interaction_browser_audit.py
                ./tools/gentle_command_source_audit.py
                ./tools/test_gentle_command_source_audit.py
                ./tools/gentle_command_history_audit.py
                ./tools/test_gentle_command_history_audit.py
                ./tools/gentle_command_runtime_audit.py
                ./tools/test_gentle_command_runtime_audit.py
                ./tools/gentle_command_installed_audit.py
                ./tools/test_gentle_command_installed_audit.py
                ./tools/gentle_command_ledger_audit.py
                ./tools/test_gentle_command_ledger_audit.py
                ./tools/gentle_command_long_source_audit.py
                ./tools/test_gentle_command_long_source_audit.py
                ./tools/gentle_command_long_revision.py
                ./tools/gentle_command_long_runtime_audit.py
                ./tools/test_gentle_command_long_runtime_audit.py
                ./tools/giroseo_source_audit.py
                ./tools/test_giroseo_source_audit.py
                ./tools/giroseo_streams_audit.py
                ./tools/test_giroseo_streams_audit.py
                ./tools/giroseo_cohort_audit.py
                ./tools/test_giroseo_cohort_audit.py
                ./tools/giroseo_broad_audit.py
                ./tools/test_giroseo_broad_audit.py
                ./tools/giroseo_corpora_audit.py
                ./tools/test_giroseo_corpora_audit.py
                ./tools/giroseo_installed_audit.py
                ./tools/test_giroseo_installed_audit.py
                ./tools/explanatory_se_source_audit.py
                ./tools/test_explanatory_se_source_audit.py
                ./tools/explanatory_se_streams_audit.py
                ./tools/test_explanatory_se_streams_audit.py
                ./tools/explanatory_se_cohort_audit.py
                ./tools/test_explanatory_se_cohort_audit.py
                ./tools/explanatory_se_broad_audit.py
                ./tools/test_explanatory_se_broad_audit.py
                ./tools/explanatory_se_corpora_audit.py
                ./tools/test_explanatory_se_corpora_audit.py
                ./tools/explanatory_se_browser_audit.py
                ./tools/test_explanatory_se_browser_audit.py
                ./tools/explanatory_se_installed_audit.py
                ./tools/test_explanatory_se_installed_audit.py
                ./tools/familiar_geurae_source_audit.py
                ./tools/test_familiar_geurae_source_audit.py
                ./tools/familiar_geurae_streams_audit.py
                ./tools/test_familiar_geurae_streams_audit.py
                ./tools/familiar_geurae_cohort_audit.py
                ./tools/test_familiar_geurae_cohort_audit.py
                ./tools/familiar_geurae_broad_audit.py
                ./tools/test_familiar_geurae_broad_audit.py
                ./tools/familiar_geurae_corpora_audit.py
                ./tools/test_familiar_geurae_corpora_audit.py
                ./tools/familiar_geurae_browser_audit.py
                ./tools/test_familiar_geurae_browser_audit.py
                ./tools/familiar_geurae_installed_audit.py
                ./tools/test_familiar_geurae_installed_audit.py
                ./tools/fear_lsera_source_audit.py
                ./tools/test_fear_lsera_source_audit.py
                ./tools/fear_lsera_streams_audit.py
                ./tools/test_fear_lsera_streams_audit.py
                ./tools/fear_lsera_cohort_audit.py
                ./tools/test_fear_lsera_cohort_audit.py
                ./tools/fear_lsera_corpora_audit.py
                ./tools/test_fear_lsera_corpora_audit.py
                ./tools/fear_lsera_browser_audit.py
                ./tools/test_fear_lsera_browser_audit.py
                ./tools/fear_lsera_broad_audit.py
                ./tools/test_fear_lsera_broad_audit.py
                ./tools/fear_lsera_installed_audit.py
                ./tools/test_fear_lsera_installed_audit.py
                ./tools/formal_volitional_source_audit.py
                ./tools/test_formal_volitional_source_audit.py
                ./tools/formal_volitional_streams_audit.py
                ./tools/test_formal_volitional_streams_audit.py
                ./tools/formal_volitional_cohort_audit.py
                ./tools/test_formal_volitional_cohort_audit.py
                ./tools/formal_volitional_corpora_audit.py
                ./tools/test_formal_volitional_corpora_audit.py
                ./tools/formal_volitional_broad_audit.py
                ./tools/test_formal_volitional_broad_audit.py
                ./tools/formal_volitional_browser_audit.py
                ./tools/test_formal_volitional_browser_audit.py
                ./tools/formal_volitional_ledger_audit.py
                ./tools/test_formal_volitional_ledger_audit.py
                ./tools/formal_volitional_installed_audit.py
                ./tools/test_formal_volitional_installed_audit.py
                ./tools/formal_volitional_expression_audit.py
                ./tools/test_formal_volitional_expression_audit.py
                ./tools/formal_volitional_expression_streams_audit.py
                ./tools/test_formal_volitional_expression_streams_audit.py
                ./tools/formal_volitional_expression_ledger_audit.py
                ./tools/test_formal_volitional_expression_ledger_audit.py
                ./tools/formal_volitional_expression_browser_audit.py
                ./tools/test_formal_volitional_expression_browser_audit.py
                ./tools/formal_volitional_expression_installed_audit.py
                ./tools/test_formal_volitional_expression_installed_audit.py
                ./tools/bound_noun_spacing_runtime.py
                ./tools/test_bound_noun_spacing_runtime.py
                ./tools/bound_noun_spacing_package_audit.py
                ./tools/test_bound_noun_spacing_package.py
                ./tools/bound_noun_spacing_performance.py
                ./tools/test_bound_noun_spacing_performance.py
                ./web/tests/predicate-auxiliary-spacing.mjs
                ./tools/test_additive_ppundeoreo_audit.py
                ./tools/test_additive_ppundeoreo_adapter_audit.py
                ./tools/test_additive_ppundeoreo_browser_audit.py
                ./tools/test_additive_ppundeoreo_preservation.py
                ./web/tests/additive-ppundeoreo.mjs
                ./tools/literary_question_go_runtime.py
                ./tools/test_literary_question_go_runtime.py
                ./tools/literary_question_go_replay.py
                ./tools/literary_question_go_adapter_replay.py
                ./tools/literary_question_go_adapter_audit.py
                ./tools/test_literary_question_go_adapter_audit.py
                ./tools/capture_literary_question_go_web.py
                ./web/tests/literary-question-go.mjs
                ./tools/literary_question_go_audit.py
                ./tools/test_literary_question_go_audit.py
                ./tools/ostensible_reason_audit.py
                ./tools/test_ostensible_reason_audit.py
                ./tools/ostensible_reason_preservation.py
                ./tools/test_ostensible_reason_preservation.py
                ./tools/ostensible_reason_replay.py
                ./tools/ostensible_reason_adapter_replay.py
                ./tools/ostensible_reason_sources.py
                ./tools/test_ostensible_reason_sources.py
                ./tools/ostensible_reason_runtime.py
                ./tools/test_ostensible_reason_runtime.py
                ./tools/capture_ostensible_reason_modes.py
                ./tools/capture_ostensible_reason_packages.py
                ./tools/capture_ostensible_reason_web.py
                ./tools/capture_ostensible_reason_performance.py
                ./tools/ostensible_reason_performance.py
                ./tools/test_ostensible_reason_performance.py
                ./web/tests/ostensible-reason.mjs
                ./web/tests/declarative-contrast.mjs
                ./web/tests/literary-ri-prefinal-model.mjs
                ./web/tests/literary-ri-prefinal.mjs
                ./web/tests/double-past-prefinal.mjs
                ./web/tests/double-past-prefinal-model.mjs
                ./web/src/model.ts
                ./web/tests/past-prefinal.mjs
                ./src/bin/klem-web/grammar_labels.rs
                ./tools/test_reported_dana_inputs.py
                ./tools/reported_dana_audit.py
                ./tools/reported_dana_native.py
                ./tools/reported_dana_corpora.py
                ./tools/reported_dana_broad.py
                ./tools/reported_dana_legacy.py
                ./tools/reported_dana_legacy_audit.py
                ./tools/reported_dana_legacy_replay.py
                ./tools/reported_dana_release.py
                ./tools/test_reported_dana_release.py
                ./tools/reported_dana_cache.py
                ./tools/reported_dana_timing.py
                ./tools/reported_dana_performance.py
                ./tools/test_reported_dana_performance.py
                ./tools/reported_dana_production.py
                ./tools/reported_dana_browser.py
                ./tools/reported_dana_sources.py
                ./tools/test_reported_dana_sources.py
                ./web/tests/reported-dana.mjs
                ./tools/reported_deoni_performance.py
                ./web/tests/reported-deoni.mjs
                ./web/tests/copula-expectation.mjs
                ./src/dictionary/attachment.rs
                ./tools/degree_expectation_performance.py
                ./tools/degree_expectation_individual.py
                ./web/tests/degree-expectation.mjs
                ./tools/friendly_command_runtime.py
                ./tools/friendly_command_comparison.py
                ./tools/friendly_command_corpora.py
                ./tools/friendly_command_broad.py
                ./tools/friendly_command_release.py
                ./tools/friendly_command_performance.py
                ./web/tests/friendly-command.mjs
                ./tools/ssik_adverb_corpora.py
                ./tools/ssik_adverb_broad.py
                ./tools/ssik_adverb_release.py
                ./tools/ssik_adverb_performance.py
                ./web/tests/ssik-adverb.mjs
                ./tools/ssik_comparison.py
                ./tools/ssik_runtime.py
                ./tools/ssik_corpora.py
                ./tools/ssik_broad.py
                ./tools/ssik_morphology.py
                ./tools/ssik_release.py
                ./tools/ssik_performance.py
                ./tools/fresh_passage_audit.py
                ./web/tests/ssik.mjs
                ./tools/nominal_si_hada_audit.py
                ./tools/test_nominal_si_hada_audit.py
                ./tools/nominal_si_hada_runtime.py
                ./tools/test_nominal_si_hada_runtime.py
                ./tools/nominal_si_hada_broad.py
                ./tools/nominal_si_hada_corpora.py
                ./tools/test_nominal_si_hada_corpora.py
                ./web/tests/nominal-si-hada.mjs
                ./src/hada_suffix.rs
                ./web/tests/nominal-hwa-hada.mjs
                ./web/tests/nominal-hwa.mjs
                ./src/nominal_hwa.rs
                ./src/nominal_si.rs
                ./web/tests/nominal-si.mjs
                ./web/tests/well-doeda.mjs
                ./tools/doeda_partial_origin_diagnostics.py
                ./tools/test_doeda_partial_origins.py
                ./tools/test_doeda_partial_origin_diagnostics.py
                ./tools/doeda_partial_origin_runtime.py
                ./tools/doeda_partial_origin_package.py
                ./tools/doeda_partial_origin_observations.py
                ./tools/doeda_partial_origin_corpora.py
                ./tools/doeda_partial_origin_performance.py
                ./tools/test_doeda_partial_origin_release.py
                ./web/tests/doeda-originless.mjs
                ./web/tests/doeda-identity.mjs
                ./src/doeda_native_forms.rs
                ./web/tests/doeda-native.mjs
                ./web/tests/doeda-complement.mjs
                ./web/tests/doeda-suffix.mjs
                ./src/engine.rs ./src/grammar.rs
                ./web/tests/gam-question.mjs
                ./web/tests/emphatic-ending.mjs
                ./web/tests/doeda-role.mjs
                ./examples/audit_adjectival_allomorph.rs
                ./web/tests/adjectival-allomorph.mjs
                ./tools/adjectival_allomorph.rs
                ./tools/hada_nominal_preservation.rs
                ./tools/native_lmf.py ./tools/test_native_lmf.py
                ./docs ./tests ./web/src/grammar-labels.json
                ./web/tests/browser.mjs
                ./web/tests/question-topic.mjs
                ./web/tests/question-additive.mjs
                ./web/tests/continuation-left.mjs
                ./web/tests/continuation-inflection.mjs
                ./web/tests/bare-noun-spacing.mjs
                ./web/tests/lexical-nada.mjs
                ./web/tests/lexical-nada-listed.mjs
                ./web/tests/rya-boundary.mjs
                ./web/tests/rya-copula.mjs
                ./web/tests/caution-ending.mjs
                ./web/tests/future-question.mjs
                ./web/tests/reported-retrospective.mjs
              ];
            };
          } ''
            cd "$src"
            export PYTHONDONTWRITEBYTECODE=1
            python tools/review_inventory.py --verify
            python -m unittest discover -s tools -p 'test_review_inventory.py'
            python -m unittest discover -s tools -p 'test_native_lmf.py'
            python tools/excluded_paradigm_audit.py --verify
            python tools/excluded_paradigm_queue.py --verify
            python tools/question_topic_audit.py --verify
            python tools/question_topic_queue.py --verify
            python tools/question_additive_audit.py --verify
            python tools/question_additive_queue.py --verify
            python tools/continuation_left_audit.py --verify
            python tools/continuation_left_queue.py --verify
            python tools/continuation_left_broad_queue.py --verify
            python tools/continuation_left_corpus_audit.py --verify
            python tools/continuation_residual_audit.py --verify
            python tools/continuation_inflection_audit.py --verify
            python tools/continuation_inflection_additional.py --verify
            python tools/continuation_inflection_review.py --verify
            python tools/continuation_inflection_queue.py --verify
            python tools/bare_noun_spacing_audit.py --verify
            python tools/bare_noun_spacing_additional.py --verify
            python tools/bare_noun_spacing_queue.py --verify
            python tools/lexical_nada_audit.py --verify
            python tools/lexical_nada_review.py --verify
            python tools/lexical_nada_fixtures.py --verify
            python tools/lexical_nada_dependencies.py --verify
            python tools/lexical_nada_priority.py --verify
            python tools/lexical_nada_queue.py --verify
            python tools/lexical_nada_country_tree_review.py --verify
            python tools/lexical_nada_listed_review.py --verify
            python tools/lexical_nada_listed_fixtures.py --verify
            python tools/lexical_nada_listed_queue.py --verify
            python tools/rya_boundary_audit.py --verify
            python tools/rya_boundary_regressions.py --verify
            python tools/rya_boundary_queue.py --verify
            python tools/rya_copula_audit.py --verify
            python tools/rya_copula_queue.py --verify
            python tools/caution_ending_audit.py --verify
            python tools/future_question_audit.py --verify
            python tools/reported_retrospective_queue.py --verify
            python tools/adjectival_allomorph_audit.py --verify
            python tools/adjectival_allomorph_corrections.py --verify
            python tools/adjectival_allomorph_policy.py --verify
            python tools/adjectival_allomorph_checkpoint.py --verify
            python tools/adjectival_allomorph_corpora.py --verify
            python tools/adjectival_allomorph_compare.py --verify
            python tools/adjectival_allomorph_runtime.py --verify
            python tools/adjectival_allomorph_browser.py --verify
            python tools/gam_question_audit.py --verify
            python tools/gam_question_regressions.py --verify
            python tools/gam_question_compare.py --verify
            python tools/gam_question_corpora.py --verify
            python tools/gam_question_queue.py --verify
            python tools/gam_question_implementation.py --verify
            python tools/emphatic_ending_audit.py --verify
            python tools/emphatic_ending_regressions.py --verify
            python tools/emphatic_ending_corpora.py --verify
            python tools/emphatic_ending_diagnostics.py --verify
            python tools/emphatic_ending_compare.py --verify
            python tools/emphatic_ending_runtime.py --verify
            python tools/emphatic_ending_queue.py --verify
            python tools/doeda_role_audit.py --verify
            python tools/doeda_role_regressions.py --verify
            python tools/doeda_role_diagnostics.py --verify
            python tools/doeda_role_historical.py --verify
            python tools/doeda_role_stress.py --verify
            python tools/doeda_role_corpora.py --verify
            python tools/doeda_role_compare.py --verify
            python tools/doeda_role_runtime.py --verify
            python tools/doeda_role_browser.py --verify
            python tools/doeda_complement_audit.py --verify
            python tools/doeda_complement_regressions.py --verify
            python tools/doeda_complement_diagnostics.py --verify
            python tools/doeda_complement_package.py --verify
            python tools/doeda_complement_compare.py --verify
            python tools/doeda_complement_corpora.py --verify
            python -m unittest discover -s tools -p 'test_doeda_complement_corpora.py'
            python tools/doeda_noun_suffix_discovery.py --verify
            python tools/doeda_suffix_audit.py --verify
            python tools/doeda_suffix_regressions.py --verify
            python tools/doeda_suffix_diagnostics.py --verify
            python tools/doeda_suffix_package.py --verify
            python tools/doeda_suffix_compare.py --verify
            python tools/doeda_suffix_corpora.py --verify
            python tools/doeda_suffix_performance.py --verify
            python -m unittest discover -s tools -p 'test_doeda_suffix_*.py'
            python tools/doeda_native_audit.py --verify
            python tools/doeda_native_preflight.py --verify
            python tools/doeda_native_implementation.py --verify
            python tools/doeda_native_regressions.py --verify
            python tools/doeda_native_diagnostics.py --verify
            python tools/doeda_native_package.py --verify
            python tools/doeda_native_compare.py --verify
            python tools/doeda_native_corpora.py --verify
            python tools/doeda_native_performance.py --verify
            python -m unittest discover -s tools -p 'test_doeda_native_*.py'
            python tools/doeda_identity_audit.py --verify
            python tools/doeda_identity_implementation.py --verify
            python tools/doeda_identity_diagnostics.py --verify
            python -m unittest discover -s tools -p 'test_doeda_identity.py'
            python tools/doeda_identity_package.py --verify
            python tools/doeda_identity_observations.py --verify
            python tools/doeda_identity_corpora.py --verify
            python tools/doeda_identity_performance.py --verify
            python -m unittest discover -s tools -p 'test_doeda_identity_release.py'
            python tools/doeda_originless_audit.py --verify
            python tools/doeda_originless_implementation.py --verify
            python tools/doeda_originless_diagnostics.py --verify
            python -m unittest discover -s tools -p 'test_doeda_originless.py'
            python tools/doeda_originless_package.py --verify
            python tools/doeda_originless_observations.py --verify
            python tools/doeda_originless_corpora.py --verify
            python tools/doeda_originless_performance.py --verify
            python -m unittest discover -s tools -p 'test_doeda_originless_release.py'
            python tools/doeda_partial_origins.py --verify
            python tools/doeda_partial_origin_diagnostics.py --verify
            python -m unittest discover -s tools -p 'test_doeda_partial_origins.py'
            python -m unittest discover -s tools -p 'test_doeda_partial_origin_diagnostics.py'
            python tools/doeda_partial_origin_package.py --verify
            python tools/doeda_partial_origin_observations.py --verify
            python tools/doeda_partial_origin_corpora.py --verify
            python tools/doeda_partial_origin_performance.py --verify
            python -m unittest discover -s tools -p 'test_doeda_partial_origin_release.py'
            python tools/well_doeda_audit.py --verify
            python tools/well_doeda_audit.py --verify --comparison docs/well-doeda-diagnostics.json.gz
            python tools/well_doeda_broad.py --verify
            python tools/well_doeda_corpora.py --verify
            python tools/well_doeda_runtime.py --verify
            python -m unittest discover -s tools -p 'test_well_doeda_audit.py'
            python tools/well_doeda_release.py --verify
            python tools/well_doeda_broad.py --verify --report docs/well-doeda-packaged-observations.json.gz
            python tools/well_doeda_corpora.py --verify --report docs/well-doeda-packaged-corpora.json.gz
            python tools/well_doeda_performance.py --verify
            python -m unittest discover -s tools -p 'test_well_doeda_release.py'
            python tools/nominal_si_audit.py --verify --comparison docs/nominal-si-diagnostics.json.gz
            python tools/nominal_si_broad.py --verify
            python tools/nominal_si_corpora.py --verify
            python tools/nominal_si_runtime.py --verify
            python -m unittest discover -s tools -p 'test_nominal_si_audit.py'
            python -m unittest discover -s tools -p 'test_nominal_si_runtime.py'
            python tools/nominal_si_release.py --verify
            python tools/nominal_si_broad.py --verify --report docs/nominal-si-packaged-observations.json.gz
            python tools/nominal_si_corpora.py --verify --report docs/nominal-si-packaged-corpora.json.gz
            python tools/nominal_si_performance.py --verify
            python -m unittest discover -s tools -p 'test_nominal_si_release.py'
            python tools/nominal_hwa_audit.py --verify --comparison docs/nominal-hwa-diagnostics.json.gz
            python -m unittest discover -s tools -p 'test_nominal_hwa_audit.py'
            python tools/nominal_hwa_broad.py --verify
            python tools/nominal_hwa_corpora.py --verify
            python tools/nominal_hwa_runtime.py --verify
            python -m unittest discover -s tools -p 'test_nominal_hwa_runtime.py'
            python tools/nominal_hwa_release.py --verify
            python tools/nominal_hwa_broad.py --verify --report docs/nominal-hwa-packaged-observations.json.gz
            python tools/nominal_hwa_corpora.py --verify --report docs/nominal-hwa-packaged-corpora.json.gz
            python tools/nominal_hwa_performance.py --verify
            python -m unittest discover -s tools -p 'test_nominal_hwa_release.py'
            python tools/nominal_hwa_hada_audit.py --verify --comparison docs/nominal-hwa-hada-diagnostics.json.gz
            python -m unittest discover -s tools -p 'test_nominal_hwa_hada_audit.py'
            python tools/nominal_hwa_hada_runtime.py --verify
            python -m unittest discover -s tools -p 'test_nominal_hwa_hada_runtime.py'
            python tools/nominal_hwa_hada_broad.py --verify
            python tools/nominal_hwa_hada_corpora.py --verify
            python -m unittest discover -s tools -p 'test_nominal_hwa_hada_corpora.py'
            python tools/nominal_hwa_hada_release.py --verify
            python tools/nominal_hwa_hada_broad.py --verify --report docs/nominal-hwa-hada-packaged-observations.json.gz
            python tools/nominal_hwa_hada_corpora.py --verify --report docs/nominal-hwa-hada-packaged-corpora.json.gz
            python tools/nominal_hwa_hada_performance.py --verify
            python -m unittest discover -s tools -p 'test_nominal_hwa_hada_release.py'
            python tools/nominal_si_hada_audit.py --verify --comparison docs/nominal-si-hada-diagnostics.json.gz
            python tools/hada_nominal_audit.py --verify
            python -m unittest discover -s tools -p 'test_hada_nominal_audit.py'
            python tools/hada_remaining_audit.py --verify
            python -m unittest discover -s tools -p 'test_hada_remaining_audit.py'
            python tools/hada_remaining_context.py --verify
            python tools/hada_remaining_runtime.py --verify
            python tools/hada_remaining_scoped_runtime.py --verify
            python -m unittest discover -s tools -p 'test_hada_remaining_scoped_runtime.py'
            python -m unittest discover -s tools -p 'test_hada_remaining_runtime.py'
            python tools/hada_remaining_broad.py --verify
            python tools/hada_remaining_corpora.py --verify
            python -m unittest discover -s tools -p 'test_hada_remaining_release_audits.py'
            python tools/hada_remaining_release.py --verify
            python tools/hada_remaining_broad.py --verify --report docs/hada-remaining-packaged-observations.json.gz
            python tools/hada_remaining_corpora.py --verify --report docs/hada-remaining-packaged-corpora.json.gz
            python tools/hada_remaining_performance.py --verify
            python -m unittest discover -s tools -p 'test_hada_remaining_release.py'
            python tools/hada_nominal_runtime.py --verify
            python -m unittest discover -s tools -p 'test_hada_nominal_runtime.py'
            python tools/hada_nominal_broad.py --verify
            python tools/hada_nominal_corpora.py --verify
            python -m unittest discover -s tools -p 'test_hada_nominal_release_audits.py'
            python tools/hada_nominal_release.py --verify
            python tools/hada_nominal_broad.py --verify --report docs/hada-nominal-packaged-observations.json.gz
            python tools/hada_nominal_corpora.py --verify --report docs/hada-nominal-packaged-corpora.json.gz
            python tools/hada_nominal_performance.py --verify
            python -m unittest discover -s tools -p 'test_hada_nominal_release.py'
            python -m unittest discover -s tools -p 'test_nominal_si_hada_audit.py'
            python tools/nominal_si_hada_runtime.py --verify
            python -m unittest discover -s tools -p 'test_nominal_si_hada_runtime.py'
            python tools/nominal_si_hada_broad.py --verify
            python tools/nominal_si_hada_corpora.py --verify
            python -m unittest discover -s tools -p 'test_nominal_si_hada_corpora.py'
            python tools/nominal_si_hada_release.py --verify
            python tools/nominal_si_hada_broad.py --verify --report docs/nominal-si-hada-packaged-observations.json.gz
            python tools/nominal_si_hada_corpora.py --verify --report docs/nominal-si-hada-packaged-corpora.json.gz
            python tools/nominal_si_hada_performance.py --verify
            python -m unittest discover -s tools -p 'test_nominal_si_hada_release.py'
            python tools/future_question_additional.py --verify
            python tools/future_question_queue.py --verify
            python tools/caution_ending_queue.py --verify
            python tools/ssik_audit.py
            python tools/ssik_comparison.py
            python tools/ssik_runtime.py
            python tools/ssik_corpora.py --verify
            python tools/ssik_broad.py --verify
            python tools/ssik_morphology.py
            python tools/ssik_broad.py --verify --report docs/ssik-packaged-observations.json.gz
            python tools/ssik_corpora.py --verify --report docs/ssik-packaged-corpora.json.gz
            python tools/ssik_release.py --verify
            python tools/ssik_performance.py --verify
            python tools/fresh_passage_audit.py
            python tools/ssik_adverb_audit.py
            python tools/ssik_adverb_comparison.py
            python tools/ssik_adverb_morphology.py
            python tools/ssik_adverb_runtime.py
            python tools/ssik_adverb_outer_tails.py
            python tools/friendly_command_preparation.py
            python tools/friendly_command_audit.py
            python tools/degree_expectation_audit.py
            python tools/degree_expectation_runtime.py
            python tools/degree_expectation_corpora.py
            python tools/degree_expectation_broad.py --verify
            python tools/degree_expectation_release.py --verify
            python -m unittest discover -s tools -p 'test_degree_expectation_release.py'
            python tools/degree_expectation_performance.py --verify
            python tools/degree_expectation_individual.py
            python tools/copula_expectation_audit.py
            python -m unittest discover -s tools -p 'test_copula_expectation_audit.py'
            python tools/copula_expectation_release.py --verify
            python -m unittest discover -s tools -p 'test_copula_expectation_release.py'
            python tools/copula_expectation_performance.py --verify
            python tools/reported_deoni_audit.py
            python tools/reported_deoni_corpora.py
            python tools/reported_deoni_broad.py
            python -m unittest discover -s tools -p 'test_reported_deoni.py'
            python tools/reported_deoni_release.py --verify
            python -m unittest discover -s tools -p 'test_reported_deoni_release.py'
            python -m unittest discover -s tools -p 'test_reported_deoni_complete_sources.py'
            python tools/reported_dana_audit.py
            python tools/present_prefinal_audit.py
            python -m unittest discover -s tools -p 'test_present_prefinal_audit.py'
            python tools/past_prefinal_audit.py
            python -m unittest discover -s tools -p 'test_past_prefinal_audit.py'
            python tools/double_past_prefinal_audit.py
            python -m unittest discover -s tools -p 'test_double_past_prefinal_audit.py'
            python tools/literary_ri_prefinal_audit.py
            python -m unittest discover -s tools -p 'test_literary_ri_prefinal_audit.py'
            python tools/literary_ri_prefinal_preservation.py
            python -m unittest discover -s tools -p 'test_literary_ri_prefinal_preservation.py'
            python tools/literary_ri_prefinal_sources.py --proof docs/literary-ri-prefinal-historical-sources.json.gz
            python -m unittest discover -s tools -p 'test_literary_ri_prefinal_sources.py'
            python tools/literary_ri_prefinal_runtime.py
            python -m unittest discover -s tools -p 'test_literary_ri_prefinal_runtime.py'
            python tools/declarative_contrast_audit.py
            python -m unittest discover -s tools -p 'test_declarative_contrast_audit.py'
            python tools/declarative_contrast_preservation.py
            python -m unittest discover -s tools -p 'test_declarative_contrast_preservation.py'
            python tools/declarative_contrast_sources.py --proof docs/declarative-contrast-historical-sources.json.gz
            python -m unittest discover -s tools -p 'test_declarative_contrast_sources.py'
            python tools/declarative_contrast_runtime.py
            python -m unittest discover -s tools -p 'test_declarative_contrast_runtime.py'
            python -m unittest discover -s tools -p 'test_declarative_contrast_performance.py'
            python tools/declarative_contrast_performance.py --verify
            python tools/literary_question_go_browser_audit.py
            python -m unittest discover -s tools -p 'test_literary_question_go_browser_audit.py'
            python tools/literary_question_go_preservation.py
            python -m unittest discover -s tools -p 'test_literary_question_go_preservation.py'
            python tools/literary_question_go_package.py
            python -m unittest discover -s tools -p 'test_literary_question_go_package*.py'
            python tools/literary_question_go_performance.py --verify
            python -m unittest discover -s tools -p 'test_literary_question_go_performance.py'
            python tools/literary_question_go_sources.py --proof docs/literary-question-go-historical-sources.json.gz
            python -m unittest discover -s tools -p 'test_literary_question_go_sources.py'
            python tools/literary_future_kko_audit.py
            python -m unittest discover -s tools -p 'test_literary_future_kko_audit.py'
            python tools/literary_future_kko_preservation.py
            python -m unittest discover -s tools -p 'test_literary_future_kko_preservation.py'
            python tools/literary_future_kko_runtime.py --report docs/literary-future-kko-packaged-cli-replay.json
            python -m unittest discover -s tools -p 'test_literary_future_kko_runtime.py'
            python tools/literary_future_kko_adapter_audit.py --report docs/literary-future-kko-packaged-adapter.json.gz
            python -m unittest discover -s tools -p 'test_literary_future_kko_adapter_audit.py'
            python tools/literary_future_kko_browser_audit.py --runtime docs/literary-future-kko-packaged-browser-runtime.json --browser docs/literary-future-kko-packaged-browser.json.gz
            python -m unittest discover -s tools -p 'test_literary_future_kko_browser_audit.py'
            python tools/literary_future_kko_sources.py --proof docs/literary-future-kko-historical-sources.json.gz
            python -m unittest discover -s tools -p 'test_literary_future_kko_sources.py'
            python tools/literary_future_kko_performance.py --verify
            python -m unittest discover -s tools -p 'test_literary_future_kko_performance.py'
            python tools/literary_future_kko_package.py
            python -m unittest discover -s tools -p 'test_literary_future_kko_package.py'
            python tools/literary_question_geona_runtime.py --report docs/literary-question-geona-packaged-cli-replay.json
            python -m unittest discover -s tools -p 'test_literary_question_geona_runtime.py'
            KLEM_GEONA_RUNTIME=docs/literary-question-geona-packaged-cli-replay.json python -m unittest discover -s tools -p 'test_literary_question_geona_runtime.py'
            python tools/literary_question_geona_adapter_audit.py --report docs/literary-question-geona-packaged-adapter.json.gz
            python -m unittest discover -s tools -p 'test_literary_question_geona_adapter_audit.py'
            KLEM_GEONA_ADAPTER=docs/literary-question-geona-packaged-adapter.json.gz python -m unittest discover -s tools -p 'test_literary_question_geona_adapter_audit.py'
            python tools/literary_question_geona_browser_audit.py --runtime docs/literary-question-geona-packaged-browser-runtime.json --browser docs/literary-question-geona-packaged-browser.json.gz
            python -m unittest discover -s tools -p 'test_literary_question_geona_browser_audit.py'
            KLEM_GEONA_BROWSER_RUNTIME=docs/literary-question-geona-packaged-browser-runtime.json KLEM_GEONA_BROWSER=docs/literary-question-geona-packaged-browser.json.gz python -m unittest discover -s tools -p 'test_literary_question_geona_browser_audit.py'
            python tools/literary_question_geona_sources.py --proof docs/literary-question-geona-historical-sources.json.gz
            python -m unittest discover -s tools -p 'test_literary_question_geona_sources.py'
            python tools/literary_question_geona_package.py
            python -m unittest discover -s tools -p 'test_literary_question_geona_package.py'
            python tools/literary_question_geona_performance.py --verify
            python -m unittest discover -s tools -p 'test_literary_question_geona_performance.py'
            python tools/additive_ppundeoreo_audit.py
            python tools/additive_ppundeoreo_adapter_audit.py --report docs/additive-ppundeoreo-adapter.json.gz
            python tools/additive_ppundeoreo_adapter_audit.py --phase main --report docs/additive-ppundeoreo-main-adapter.json.gz
            python tools/additive_ppundeoreo_browser_audit.py
            python tools/additive_ppundeoreo_browser_audit.py --phase main
            python tools/additive_ppundeoreo_main.py --verify
            python tools/additive_ppundeoreo_sources.py --proof docs/additive-ppundeoreo-historical-sources.json.gz
            python tools/additive_ppundeoreo_package.py
            python tools/additive_ppundeoreo_performance.py --verify
            python tools/additive_ppundeoreo_preservation_audit.py
            python tools/additive_ppundeoreo_preservation_audit.py --phase main
            python -m unittest discover -s tools -p 'test_additive_ppundeoreo_*.py'
            KLEM_PPUN_PHASE=main python -m unittest discover -s tools -p 'test_additive_ppundeoreo_browser_audit.py'
            KLEM_PPUN_PHASE=main python -m unittest discover -s tools -p 'test_additive_ppundeoreo_adapter_audit.py'
            KLEM_PPUN_PHASE=main python -m unittest discover -s tools -p 'test_additive_ppundeoreo_preservation.py'
            python tools/predicate_auxiliary_spacing_runtime.py --verify docs/predicate-auxiliary-spacing-main-portable-runtime.json.gz
            python tools/predicate_auxiliary_spacing_runtime.py --verify docs/predicate-auxiliary-spacing-packaged-portable-runtime.json.gz
            python -m unittest discover -s tools -p 'test_predicate_auxiliary_spacing_runtime.py'
            KLEM_AUX_SPACING_RUNTIME=docs/predicate-auxiliary-spacing-packaged-portable-runtime.json.gz python -m unittest discover -s tools -p 'test_predicate_auxiliary_spacing_runtime.py'
            python tools/predicate_auxiliary_spacing_package.py
            python tools/predicate_auxiliary_spacing_performance.py --verify
            python -m unittest discover -s tools -p 'test_predicate_auxiliary_spacing_performance.py'
            python tools/possessive_bound_noun_runtime.py --fixture tests/fixtures/possessive-bound-noun-cases.json --closure docs/possessive-bound-noun-native-closure.json.gz --verify docs/possessive-bound-noun-installed-runtime.json.gz
            python tools/possessive_bound_noun_package_audit.py --package docs/possessive-bound-noun-nix.json.gz --sources docs/possessive-bound-noun-installed-sources.json.gz --adapter docs/possessive-bound-noun-installed-adapter.json.gz
            python tools/possessive_bound_noun_performance.py
            python tools/declarative_dao_audit.py
            python tools/declarative_dao_preservation.py
            python tools/declarative_dao_performance.py
            python tools/proper_name_source_audit.py
            python -m unittest discover -s tools -p 'test_proper_name_source_audit.py'
            python tools/self_question_source_audit.py
            python -m unittest discover -s tools -p 'test_self_question_source_audit.py'
            python tools/self_question_cohort_audit.py
            python -m unittest discover -s tools -p 'test_self_question_cohort_audit.py'
            python tools/dapnikka_source_audit.py
            python -m unittest discover -s tools -p 'test_dapnikka_source_audit.py'
            python tools/dapnikka_cohort_audit.py
            python -m unittest discover -s tools -p 'test_dapnikka_cohort_audit.py'
            python tools/dapnikka_broad_audit.py
            python -m unittest discover -s tools -p 'test_dapnikka_broad_audit.py'
            python tools/formal_b_source_audit.py
            python -m unittest discover -s tools -p 'test_formal_b_source_audit.py'
            python tools/formal_b_cohort_audit.py
            python -m unittest discover -s tools -p 'test_formal_b_cohort_audit.py'
            python tools/formal_b_broad_audit.py
            python -m unittest discover -s tools -p 'test_formal_b_broad_audit.py'
            python tools/formal_b_installed_audit.py
            python -m unittest discover -s tools -p 'test_formal_b_installed_audit.py'
            python tools/reported_experience_source_audit.py
            python -m unittest discover -s tools -p 'test_reported_experience_source_audit.py'
            python tools/reported_experience_cohort_audit.py
            python -m unittest discover -s tools -p 'test_reported_experience_cohort_audit.py'
            python tools/reported_experience_broad_audit.py
            python -m unittest discover -s tools -p 'test_reported_experience_broad_audit.py'
            python tools/reported_experience_corpora_audit.py
            python -m unittest discover -s tools -p 'test_reported_experience_corpora_audit.py'
            python tools/reported_experience_installed_audit.py
            python -m unittest discover -s tools -p 'test_reported_experience_installed_audit.py'
            python tools/reported_experience_performance.py
            python -m unittest discover -s tools -p 'test_reported_experience_performance.py'
            python tools/formal_volitional_expression_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_expression_audit.py'
            python tools/formal_volitional_expression_streams_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_expression_streams_audit.py'
            python tools/conjectural_additive_source_audit.py
            python -m unittest discover -s tools -p 'test_conjectural_additive_source_audit.py'
            python tools/conjectural_additive_prototype_audit.py
            python -m unittest discover -s tools -p 'test_conjectural_additive_prototype_audit.py'
            python tools/conjectural_additive_distribution_audit.py
            python -m unittest discover -s tools -p 'test_conjectural_additive_distribution_audit.py'
            python tools/conjectural_additive_ledger_audit.py
            python -m unittest discover -s tools -p 'test_conjectural_additive_ledger_audit.py'
            python tools/conjectural_additive_novel_audit.py
            python -m unittest discover -s tools -p 'test_conjectural_additive_novel_audit.py'
            python tools/conjectural_additive_installed_audit.py
            python -m unittest discover -s tools -p 'test_conjectural_additive_installed_audit.py'
            python tools/expression_conjectural_ledger_audit.py
            python -m unittest discover -s tools -p 'test_expression_conjectural_ledger_audit.py'
            python tools/expression_conjectural_installed_audit.py
            python -m unittest discover -s tools -p 'test_expression_conjectural_installed_audit.py'
            python tools/willingness_question_source_audit.py
            python -m unittest discover -s tools -p 'test_willingness_question_source_audit.py'
            python tools/willingness_question_distribution_audit.py
            python -m unittest discover -s tools -p 'test_willingness_question_distribution_audit.py'
            python tools/willingness_question_browser_audit.py
            python -m unittest discover -s tools -p 'test_willingness_question_browser_audit.py'
            python tools/willingness_question_installed_audit.py
            python -m unittest discover -s tools -p 'test_willingness_question_installed_audit.py'
            python tools/willingness_question_interaction_browser_audit.py
            python -m unittest discover -s tools -p 'test_willingness_question_interaction_browser_audit.py'
            python tools/gentle_command_source_audit.py
            python -m unittest discover -s tools -p 'test_gentle_command_source_audit.py'
            python tools/gentle_command_history_audit.py
            python -m unittest discover -s tools -p 'test_gentle_command_history_audit.py'
            python tools/gentle_command_runtime_audit.py
            python -m unittest discover -s tools -p 'test_gentle_command_runtime_audit.py'
            python tools/gentle_command_installed_audit.py
            python -m unittest discover -s tools -p 'test_gentle_command_installed_audit.py'
            python tools/gentle_command_ledger_audit.py
            python -m unittest discover -s tools -p 'test_gentle_command_ledger_audit.py'
            python tools/gentle_command_long_source_audit.py
            python -m unittest discover -s tools -p 'test_gentle_command_long_source_audit.py'
            python tools/gentle_command_long_runtime_audit.py
            python -m unittest discover -s tools -p 'test_gentle_command_long_runtime_audit.py'
            python tools/giroseo_source_audit.py
            python -m unittest discover -s tools -p 'test_giroseo_source_audit.py'
            python tools/giroseo_streams_audit.py
            python -m unittest discover -s tools -p 'test_giroseo_streams_audit.py'
            python tools/giroseo_cohort_audit.py
            python -m unittest discover -s tools -p 'test_giroseo_cohort_audit.py'
            python tools/giroseo_broad_audit.py
            python -m unittest discover -s tools -p 'test_giroseo_broad_audit.py'
            python tools/giroseo_corpora_audit.py
            python -m unittest discover -s tools -p 'test_giroseo_corpora_audit.py'
            python tools/giroseo_installed_audit.py
            python -m unittest discover -s tools -p 'test_giroseo_installed_audit.py'
            python tools/explanatory_se_source_audit.py
            python -m unittest discover -s tools -p 'test_explanatory_se_source_audit.py'
            python tools/explanatory_se_streams_audit.py
            python -m unittest discover -s tools -p 'test_explanatory_se_streams_audit.py'
            python tools/explanatory_se_cohort_audit.py
            python -m unittest discover -s tools -p 'test_explanatory_se_cohort_audit.py'
            python tools/explanatory_se_broad_audit.py
            python -m unittest discover -s tools -p 'test_explanatory_se_broad_audit.py'
            python tools/explanatory_se_corpora_audit.py
            python -m unittest discover -s tools -p 'test_explanatory_se_corpora_audit.py'
            python tools/explanatory_se_browser_audit.py
            python -m unittest discover -s tools -p 'test_explanatory_se_browser_audit.py'
            python tools/explanatory_se_installed_audit.py
            python -m unittest discover -s tools -p 'test_explanatory_se_installed_audit.py'
            python tools/familiar_geurae_source_audit.py
            python -m unittest discover -s tools -p 'test_familiar_geurae_source_audit.py'
            python tools/familiar_geurae_streams_audit.py
            python -m unittest discover -s tools -p 'test_familiar_geurae_streams_audit.py'
            python tools/familiar_geurae_cohort_audit.py
            python -m unittest discover -s tools -p 'test_familiar_geurae_cohort_audit.py'
            python tools/familiar_geurae_broad_audit.py
            python -m unittest discover -s tools -p 'test_familiar_geurae_broad_audit.py'
            python tools/familiar_geurae_corpora_audit.py
            python -m unittest discover -s tools -p 'test_familiar_geurae_corpora_audit.py'
            python tools/familiar_geurae_browser_audit.py
            python -m unittest discover -s tools -p 'test_familiar_geurae_browser_audit.py'
            python tools/familiar_geurae_installed_audit.py
            python -m unittest discover -s tools -p 'test_familiar_geurae_installed_audit.py'
            python tools/fear_lsera_source_audit.py
            python -m unittest discover -s tools -p 'test_fear_lsera_source_audit.py'
            python tools/fear_lsera_streams_audit.py
            python -m unittest discover -s tools -p 'test_fear_lsera_streams_audit.py'
            python tools/fear_lsera_cohort_audit.py
            python -m unittest discover -s tools -p 'test_fear_lsera_cohort_audit.py'
            python tools/fear_lsera_corpora_audit.py
            python -m unittest discover -s tools -p 'test_fear_lsera_corpora_audit.py'
            python tools/fear_lsera_browser_audit.py
            python -m unittest discover -s tools -p 'test_fear_lsera_browser_audit.py'
            python tools/fear_lsera_broad_audit.py
            python -m unittest discover -s tools -p 'test_fear_lsera_broad_audit.py'
            python tools/fear_lsera_installed_audit.py
            python -m unittest discover -s tools -p 'test_fear_lsera_installed_audit.py'
            python tools/formal_volitional_source_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_source_audit.py'
            python tools/formal_volitional_streams_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_streams_audit.py'
            python tools/formal_volitional_cohort_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_cohort_audit.py'
            python tools/formal_volitional_corpora_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_corpora_audit.py'
            python tools/formal_volitional_broad_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_broad_audit.py'
            python tools/formal_volitional_browser_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_browser_audit.py'
            python tools/formal_volitional_ledger_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_ledger_audit.py'
            python tools/formal_volitional_installed_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_installed_audit.py'
            python tools/formal_volitional_expression_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_expression_audit.py'
            python tools/formal_volitional_expression_streams_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_expression_streams_audit.py'
            python tools/formal_volitional_expression_ledger_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_expression_ledger_audit.py'
            python tools/formal_volitional_expression_browser_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_expression_browser_audit.py'
            python tools/formal_volitional_expression_installed_audit.py
            python -m unittest discover -s tools -p 'test_formal_volitional_expression_installed_audit.py'
            python -m unittest discover -s tools -p 'test_declarative_dao_*.py'
            python -m unittest discover -s tools -p 'test_possessive_bound_noun_*.py'
            python tools/bound_noun_spacing_runtime.py --fixture tests/fixtures/bound-noun-spacing-cases.json --closure docs/bound-noun-spacing-native-closure.json.gz --verify docs/bound-noun-spacing-installed-runtime.json.gz
            python tools/bound_noun_spacing_package_audit.py --package docs/bound-noun-spacing-nix.json.gz --sources docs/bound-noun-spacing-installed-sources.json.gz --adapter docs/bound-noun-spacing-installed-adapter.json.gz
            python tools/bound_noun_spacing_performance.py
            python -m unittest discover -s tools -p 'test_bound_noun_spacing_*.py'
            python tools/literary_question_go_runtime.py --cli-report docs/literary-question-go-main-cli-replay.json
            python -m unittest discover -s tools -p 'test_literary_question_go_runtime.py'
            python tools/literary_question_go_adapter_audit.py --report docs/literary-question-go-main-adapter.json.gz
            python -m unittest discover -s tools -p 'test_literary_question_go_adapter_audit.py'
            python tools/literary_question_go_audit.py --output "$TMPDIR/literary-question-go-source-audit.json.gz"
            python -m unittest discover -s tools -p 'test_literary_question_go_audit.py'
            python tools/ostensible_reason_audit.py --preparation docs/ostensible-reason-source-owner-preparation.json.gz --replay docs/ostensible-reason-prototype-source-replay.json.gz --output "$TMPDIR/ostensible-source-audit.json.gz"
            python -m unittest discover -s tools -p 'test_ostensible_reason_audit.py'
            python tools/ostensible_reason_preservation.py --output "$TMPDIR/ostensible-preservation-audit.json"
            python -m unittest discover -s tools -p 'test_ostensible_reason_preservation.py'
            python tools/ostensible_reason_sources.py --proof docs/ostensible-reason-historical-sources.json.gz
            python -m unittest discover -s tools -p 'test_ostensible_reason_sources.py'
            python tools/ostensible_reason_runtime.py --package
            python -m unittest discover -s tools -p 'test_ostensible_reason_runtime.py'
            python -m unittest discover -s tools -p 'test_ostensible_reason_performance.py'
            python tools/ostensible_reason_performance.py --verify
            python -m unittest discover -s tools -p 'test_reported_dana_inputs.py'
            python tools/reported_dana_native.py
            python tools/reported_dana_corpora.py
            python tools/reported_dana_broad.py
            python tools/reported_dana_legacy_audit.py
            python tools/reported_dana_sources.py --verify
            python -m unittest discover -s tools -p 'test_reported_dana_sources.py'
            python tools/reported_dana_release.py --verify
            python -m unittest discover -s tools -p 'test_reported_dana_release.py'
            python tools/reported_dana_performance.py --verify
            python -m unittest discover -s tools -p 'test_reported_dana_performance.py'
            python tools/reported_deoni_performance.py --verify
            python tools/friendly_command_runtime.py
            python tools/friendly_command_corpora.py --verify
            python tools/friendly_command_broad.py --verify
            python tools/friendly_command_corpora.py --verify --report docs/friendly-command-packaged-corpora.json.gz
            python tools/friendly_command_broad.py --verify --report docs/friendly-command-packaged-observations.json.gz
            python tools/friendly_command_release.py --verify
            python tools/friendly_command_performance.py --verify
            python tools/ssik_adverb_corpora.py --verify
            python tools/ssik_adverb_broad.py --verify
            python tools/ssik_adverb_broad.py --verify --report docs/ssik-adverb-packaged-observations.json.gz
            python tools/ssik_adverb_corpora.py --verify --report docs/ssik-adverb-packaged-corpora.json.gz
            python tools/ssik_adverb_release.py --verify
            python tools/ssik_adverb_performance.py --verify
            touch "$out"
          '';
        });

      devShells = forAllSystems (system:
        let
          pkgs = nixpkgs.legacyPackages.${system};
        in
        {
          default = pkgs.mkShell {
            packages = with pkgs; [
              cargo
              rustc
              rustfmt
              clippy
              rust-analyzer
              nodejs
              python3 # Offline grammar/corpus inventory audit.
            ];

            RUST_SRC_PATH = "${pkgs.rustPlatform.rustLibSrc}";
          };
        });
    };
}
