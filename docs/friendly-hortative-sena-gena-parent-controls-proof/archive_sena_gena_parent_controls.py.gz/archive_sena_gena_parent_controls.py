"""Preserve every terminal combined-parent control and the preinit failure."""
import gzip
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
OUT = W / 'docs/friendly-hortative-sena-gena-parent-controls-proof-archive.json'
assert not OUT.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
name = 'friendly-hortative-sena-gena-parent-controls-retry1.json'
r = json.loads((P / name).read_bytes())
assert r['state'] == 'passed' and r['controls'] == r['expected_controls'] == 351
assert r['head'] == 'a7628093badbe8be62cc8ffe33327b15acf18646'
assert all(r[key] for key in ('source_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged'))
assert len(r['results']) == 12 and all(row['exit_code'] == 0 for row in r['results'])
assert all(sha((W / path).read_bytes()) == digest for path, digest in r['source_inputs'].items())
assert all(sha(Path(path).read_bytes()) == digest for path, digest in r['protected_binaries'].items())
producer = P / 'validate_sena_gena_parent_controls_retry1.py'
assert r['producer'] == dict(text=producer.read_text(), sha256=sha(producer.read_bytes()))
log = P / 'friendly-hortative-sena-gena-parent-controls-retry1.log'
assert r['log_sha256'] == sha(log.read_bytes())
names = [producer.name, name, log.name,
         'sena-gena-parent-controls-retry1-preinit-failure.json',
         'sena-gena-parent-controls-retry1-preinit-producer.py.gz',
         'archive_sena_gena_parent_controls.py']
paths = {name: P / name for name in names}
for row in r['results'][:10]:
    path = W / 'tools' / row['command'][-1]
    assert sha(path.read_bytes()) == r['source_inputs'][str(path.relative_to(W))]
    paths['actual-control-' + path.name] = path
for name in ('friendly_hortative_sena_revision.py', 'friendly_hortative_sena_gena_parent_audit.py'):
    path = W / 'tools' / name
    assert sha(path.read_bytes()) == r['source_inputs']['tools/' + name]
    paths['actual-installed-' + name] = path
destination = W / 'docs/friendly-hortative-sena-gena-parent-controls-proof'
destination.mkdir()
files = {}
for name, path in sorted(paths.items()):
    raw = path.read_bytes(); packed = gzip.compress(raw, mtime=0)
    target = destination / (name + '.gz'); target.write_bytes(packed)
    assert gzip.decompress(target.read_bytes()) == raw
    files[name] = dict(path=str(target.relative_to(W / 'docs')), source_sha256=sha(raw),
                       archive_sha256=sha(packed), bytes=len(raw))
OUT.write_text(json.dumps(dict(state='actual351-combined-parent-controls-passed', files=files,
                              head=r['head'], controls=351, inventory_entries=715,
                              all_source_head_index_and_six_binaries_unchanged=True,
                              original31_control_file_unchanged=True,
                              original25_Sena_cases_remain_private=True,
                              preinitialization_failure_retained=True,
                              producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
                              scope='Complete actual named parent controls, queue and diff. Shared25 promotion, selected Nix, main, quiet and contextual review remain separate.'),
                          indent=2) + '\n')
print(json.dumps(dict(files=len(files), manifest_sha256=sha(OUT.read_bytes()))), flush=True)
