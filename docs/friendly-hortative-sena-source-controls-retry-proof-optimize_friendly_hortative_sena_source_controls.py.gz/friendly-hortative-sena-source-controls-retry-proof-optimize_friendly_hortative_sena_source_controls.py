"""Clone only the field each negative control mutates; retain all 42 assertions."""
import ast
from pathlib import Path
W=Path('/home/josh/projects/klem/.direnv/friendly-hortative-sena')
p=W/'tools/test_friendly_hortative_sena_source_audit.py'
s=p.read_text();tree=ast.parse(s)
replacements=[]
for method in (n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')):
 for call in (n for n in ast.walk(method) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='rejects'):
  target=call.args[0]
  if isinstance(target,ast.Name):target=next(n for n in method.body if isinstance(n,ast.FunctionDef) and n.name==target.id)
  roots={n.slice.value for n in ast.walk(target) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id in ['v','value'] and isinstance(n.slice,ast.Constant)}
  if not roots and isinstance(target,ast.Lambda) and isinstance(target.body,ast.Call) and isinstance(target.body.func,ast.Attribute) and target.body.func.attr=='update':
   roots={k.arg for k in target.body.keywords}
  if roots=={'ending_native','native'}:
   assert method.name=='test_catalog_cannot_borrow_related_ending'
   roots={'ending_native'}
  assert len(roots)==1,roots
  field=roots.pop();old=ast.get_source_segment(s,call);assert old.endswith(')')
  replacements.append((old,old[:-1]+', field='+repr(field)+')'))
assert len(replacements)==41
for old,new in replacements:assert s.count(old)==1;s=s.replace(old,new,1)
old="    def rejects(self, change):\n        value = copy.deepcopy(self.original)"
new="    def rejects(self, change, field):\n        value = dict(self.original)\n        value[field] = copy.deepcopy(self.original[field])"
assert s.count(old)==1;s=s.replace(old,new,1)
newtree=ast.parse(s)
assert [n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]==[n.name for n in ast.walk(newtree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
p.write_text(s)
print('Retained all42 original test methods/assertions; negative controls clone only their own mutated root field.',flush=True)
