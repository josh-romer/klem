"""Run new strict closure controls and unchanged historical tests on the draft source."""
import datetime,hashlib,json,os,re,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent/'friendly-hortative-sena'
O=P/'friendly-hortative-sena-revision-validation-retry1.json';L=P/'friendly-hortative-sena-revision-validation-retry1.log'
assert not O.exists() and not L.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest();git=lambda *args:subprocess.check_output(['git',*args],cwd=W)
frozen={n:sha((W/n).read_bytes()) for n in git('ls-files','-z').decode().split('\0')[:-1]}
head,index=git('rev-parse','HEAD').decode().strip(),sha(git('ls-files','--stage','-z'))
status=git('status','--porcelain').decode()
external={str(p):sha(p.read_bytes()) for p in [Path(__file__),W/'tools/friendly_hortative_sena_revision.py',W/'tools/test_friendly_hortative_sena_revision.py']}
binding=json.loads((P/'friendly-hortative-sena-complete-runtime-binding.json').read_bytes())
external.update({b['path']:b['sha256'] for b in binding['binaries'].values()});external.update(binding['protected_parent_binaries'])
patterns=[('test_friendly_hortative_sena_revision.py',31),('test_friendly_command_gena_runtime_audit.py',48),('test_friendly_command_gena_browser_audit.py',18),('test_gentle_command_long_runtime_audit.py',34),('test_gentle_command_long_installed_audit.py',37)]
for name,count in patterns[1:]:
 backup=P/('friendly-hortative-sena-unchanged-'+name);assert backup.read_bytes()==(W/'tools'/name).read_bytes();external[str(backup)]=sha(backup.read_bytes())
assert all(sha(Path(p).read_bytes())==d for p,d in external.items())
r=dict(state='running',head=head,index_sha256=index,working_tree_status=status,frozen_inputs=frozen,external_inputs=external,results=[],
 producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 scope='Draft current source;31 new strict Sena captured-source controls plus all unchanged48GenaRuntime/18GenaBrowser/34LongRuntime/37LongInstalled controls. All current production44/frontend18/compile1158 bytes and6protectedbinaries pinned. Preserves old tests/rejection messages/original failed receipts. Does not claim full historical inventory/Nixpackages/installedSena/sharedpromotion/main/performance/context/register review passed.')
def save():O.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 with L.open('xb') as log:
  env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',KLEM_SENA_BINARY_EVIDENCE='captured')
  commands=[([sys.executable,'tools/friendly_hortative_sena_revision.py'],0)]
  commands.extend(([sys.executable,'-m','unittest','discover','-s','tools','-p',name],count) for name,count in patterns)
  for command,count in commands:
   log.write(('COMMAND '+json.dumps(command)+'\n').encode());log.flush()
   job=subprocess.run(command,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT)
   r['results'].append(dict(command=command,exit_code=job.returncode,expected_controls=count));save()
   assert job.returncode==0,'Actual strict closure/historical controls failed; full original source/producer/log/receipt retained.'
 r['state']='passed'
except BaseException as error:r.update(state='failed',error=repr(error));raise
finally:
 r.update(inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),external_inputs_unchanged=all(sha(Path(p).read_bytes())==d for p,d in external.items()),head_unchanged=git('rev-parse','HEAD').decode().strip()==head,index_unchanged=sha(git('ls-files','--stage','-z'))==index,working_tree_status_unchanged=git('status','--porcelain').decode()==status,controls=sum(map(int,re.findall(r'Ran (\d+) tests',L.read_text()))) if L.exists() else 0,log_sha256=sha(L.read_bytes()) if L.exists() else None,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 if not all(r[k] for k in ['inputs_unchanged','external_inputs_unchanged','head_unchanged','index_unchanged','working_tree_status_unchanged']):r['state']='failed'
 if r['state']=='passed' and r['controls']!=168:r['state']='failed'
 save()
assert r['state']=='passed'
print('Passed168strict/historical controls; oldtests/source/status/head/index/6binaries unchanged.',flush=True)
