"""Append source judgments while preserving every existing ledger case byte."""
import gzip
import hashlib
import json
from pathlib import Path

prep = Path(__file__).resolve().parent
work = Path('/tmp/klem-willingness-question-prototype')
out = prep / 'ledger-integration.json'
assert not out.exists()
path = work / 'tests/fixtures/validity.json'
raw = path.read_bytes()
parent = json.loads(raw)
assert len(parent['cases']) == 35651
(prep / 'parent-active-validity.json.gz').write_bytes(gzip.compress(raw, mtime=0))
source = json.loads((work / 'tests/fixtures/willingness-question-validity.json').read_bytes())
boundaries = json.loads((work / 'tests/fixtures/willingness-question-boundaries.json').read_bytes())
boundary_suite = {key: source[key] for key in ['schema_version', 'review_status', 'sources']}
boundary_suite['cases'] = []
for number, boundary in enumerate(boundaries, 1):
    boundary_suite['cases'].append({
        'id': 'willingness-question-stem-boundary-' + str(number),
        'surface': boundary['surface'],
        'judgments': [{
            'id': 'exact-verb-ending-path', 'verdict': 'required' if boundary['expected'] else 'forbidden',
            'lemmas': [boundary['lemma']], 'lemma_kinds': ['predicate'],
            'morphemes': [boundary['canonical']], 'morpheme_kinds': ['ending'],
            'required_rules': ['ending.willingness_question'],
            'source': 'original-willingness-ending-76564' if boundary['surface'].endswith('련') and not boundary['surface'].endswith('으련') else 'original-willingness-ending-76567',
            'reason': boundary['reason'],
        }],
    })
boundary_path = work / 'tests/fixtures/willingness-question-boundary-validity.json'
assert not boundary_path.exists()
boundary_path.write_text(json.dumps(boundary_suite, ensure_ascii=False, indent=2) + '\n')
additions = source['cases'] + boundary_suite['cases']
assert len(additions) == 22
current = json.loads(raw)
for key, value in source['sources'].items():
    assert key not in current['sources'] or current['sources'][key] == value
    current['sources'][key] = value
existing_ids = {case['id'] for case in current['cases']}
assert not existing_ids & {case['id'] for case in additions}
current['cases'].extend(additions)
updated = (json.dumps(current, ensure_ascii=False, indent=2) + '\n').encode()
prefix = raw.split(b'"cases": [', 1)[1].rsplit(b'\n  ]\n}', 1)[0]
assert updated.split(b'"cases": [', 1)[1].startswith(prefix)
assert current['cases'][:35651] == parent['cases']
path.write_bytes(updated)
sha = lambda value: hashlib.sha256(value).hexdigest()
receipt = {'state': 'twenty-two-preauthored-judgments-appended-with-every-parent-case-retained',
           'parent_sha256': sha(raw), 'current_sha256': sha(updated),
           'parent_case_prefix_sha256': sha(prefix), 'parent_case_prefix_bytes': len(prefix),
           'original_cases': 35651, 'added_cases': 22, 'added_required': 15, 'added_forbidden': 7,
           'original_metadata_retained': True, 'original_serialized_case_prefix_retained': True,
           'source_fixture_sha256': sha((work / 'tests/fixtures/willingness-question-validity.json').read_bytes()),
           'boundary_fixture_sha256': sha(boundary_path.read_bytes()),
           'inventory_dispositions_changed': False,
           'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__).read_bytes())}}
out.write_text(json.dumps(receipt, indent=2) + '\n')
print('Appended22 cases; parent prefix', receipt['parent_case_prefix_sha256'], len(prefix), 'bytes')
