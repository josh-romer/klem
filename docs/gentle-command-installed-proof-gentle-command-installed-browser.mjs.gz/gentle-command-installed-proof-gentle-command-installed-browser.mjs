import assert from 'node:assert/strict';
import {isDeepStrictEqual} from 'node:util';
import {gunzipSync} from 'node:zlib';
import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root='/home/josh/projects/klem',proto='/tmp/klem-gentle-command';
const url=process.env.KLEM_WEB_URL,cli=process.env.KLEM_BIN,db=root+'/data/dictionaries/krdict/krdict.db',prefix=process.env.KLEM_CAPTURE_PREFIX||'/home/josh/projects/klem/.direnv/willingness-question-prepared/gentle-command-installed';
assert.ok(url && cli,'Actual installed server URL and bound CLI required');
const suites=await Promise.all(['gentle-command-validity.json'].map(async name=>JSON.parse(await readFile(proto+'/tests/fixtures/'+name,'utf8'))));
const suite={cases:suites.flatMap(suite=>suite.cases)};
const grammarLabels=JSON.parse(await readFile(proto+'/web/src/grammar-labels.json','utf8'));
const cases=suite.cases.flatMap(c=>c.judgments.map(j=>({...c,id:c.id+'/'+(j.id||'path'),judgments:[j]})));
assert.equal(cases.length,23);
const {chromium}=createRequire(root+'/.direnv/dapnikka-integration/web/package.json')('playwright');
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH,args:['--no-sandbox']});
const errors=[],exports=[],responses=[],diagrams=[],spacingDiagrams=[],nativeEntries=[],policyDecisions=[];
try {
 const page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});
 page.on('pageerror',error=>errors.push(String(error)));await page.goto(url);
 const breakdown=page.getByRole('region',{name:'Sentence breakdown',exact:true});
 for(const encoding of ['NFC','NFD']) {
  const text=cases.map(c=>c.surface.normalize(encoding)).join(' ');
  await page.getByLabel('Your sentence',{exact:true}).fill(text);
  const pending=page.waitForResponse(r=>r.url().endsWith('/api/analyze')&&r.request().postDataJSON()?.text===text);
  await page.getByRole('button',{name:'Analyze sentence',exact:true}).click();
  const response=await pending;assert.equal(response.status(),200);const api=await response.json();responses.push({encoding,api});
  assert.ok(api.rules['ending.gentle_command']);
  await page.waitForFunction(t=>document.querySelector('.sentence')?.textContent===t,text);
  for(const [mode,flag]of[['raw',null],['headword','--dict-only'],['compatible','--dict-compatible']]) {
   if(flag){await page.getByLabel('Dictionary matches only').check();if(mode==='compatible')await page.getByLabel('Exclude known grammar conflicts').check();else await page.getByLabel('Exclude known grammar conflicts').uncheck();}
   else await page.getByLabel('Dictionary matches only').uncheck();
   const expected=execFileSync(cli,['text','-','--dictionary',db,...(flag?[flag]:[])],{input:text,encoding:'utf8',maxBuffer:32*1024*1024}).trim().split('\n').map(JSON.parse);
   const pending=page.waitForEvent('download');await page.getByRole('button',{name:'Export JSON',exact:true}).click();
   const exported=JSON.parse(await readFile(await(await pending).path(),'utf8'));assert.deepEqual(exported.records,expected);exports.push({encoding,mode,records:expected});
   for(const [ordinal,c]of cases.entries()) {
    const recordIndex=api.records.findIndex((r,i)=>r.kind==='word'&&api.records.slice(0,i).filter(t=>t.kind==='word').length===ordinal);
    const token=api.records[recordIndex];assert.equal(token.surface,c.surface.normalize(encoding));
    const judgment=c.judgments[0];
    const index=token.analysis.analyses.findIndex(a=>JSON.stringify(a.lemmas.map(l=>l.text))===JSON.stringify(judgment.lemmas)&&JSON.stringify(a.lemmas.map(l=>l.kind))===JSON.stringify(judgment.lemma_kinds)&&JSON.stringify(a.morphemes.map(m=>m.kind))===JSON.stringify(judgment.morpheme_kinds)&&(!judgment.morphemes||JSON.stringify(a.morphemes.map(m=>m.form))===JSON.stringify(judgment.morphemes))&&judgment.required_rules.every(rule=>a.rules.includes(rule)));
    assert.equal(index>=0,judgment.verdict==='required',c.id+'/original-judgment');
    const word=breakdown.locator('.breakdown-word').nth(ordinal),selector=word.getByRole('combobox');
    // Preserve the CLI policy for every originally authored path.
    const offered=await selector.locator('option').evaluateAll(os=>os.map(o=>o.value));
    const expectedOffered=token.analysis.analyses.flatMap((path,i)=>expected[recordIndex].analysis?.analyses?.some(p=>isDeepStrictEqual(p,path))?[String(i)]:[]);
    assert.deepEqual(offered.filter(i=>/^\d+$/.test(i)),expectedOffered,c.id+'/'+mode+'/all-original-options');
    if(judgment.verdict==='forbidden') {
     policyDecisions.push({case_id:c.id,encoding,mode,record_index:recordIndex,verdict:'forbidden',judgment,raw_analysis_index:index,allowed:false,offered_indices:offered});
     continue;
    }
    const selectedPath=token.analysis.analyses[index];
    const allowed=expected[recordIndex].analysis?.analyses?.some(path=>isDeepStrictEqual(path,selectedPath))||false;
    assert.equal(offered.includes(String(index)),allowed,c.id+'/'+mode+'/policy');
    const decision={case_id:c.id,encoding,mode,record_index:recordIndex,raw_analysis_index:index,analysis:selectedPath,allowed,offered_indices:offered};
    if(!allowed){
     if(!expected[recordIndex].analysis?.analyses?.length){assert.ok(await selector.isDisabled());assert.equal(await word.locator('.breakdown-unavailable').textContent(),'No matching reading');decision.empty_message='No matching reading';}
     policyDecisions.push(decision);continue;
    }
    policyDecisions.push(decision);
    await selector.selectOption(String(index));
    const order=api.breakdowns[recordIndex][index];assert.ok(order);
    assert.equal(await word.locator('.part-form').count(),order.length,c.id);
    const stems=judgment.lemmas.map((head,i)=>["predicate","auxiliary","copula"].includes(judgment.lemma_kinds[i])?head.replace(/다$/,""):head);
    const expectedForms=stems.length===1?[stems[0],...judgment.morphemes]:judgment.lemma_kinds[1]==='auxiliary'?[stems[0],judgment.morphemes[0],stems[1],...judgment.morphemes.slice(1)]:[...stems,...judgment.morphemes];
    if(judgment.lemmas.length===1&&judgment.lemmas[0].endsWith('하다'))expectedForms[1]=expectedForms[1].replace(/^어/,'여').replace(/^었/,'였');
    assert.deepEqual(await word.locator('.part-form').allTextContents(),expectedForms,c.id+'/independent-order');
    const ending=word.locator('.breakdown-component').last();
    const form=token.analysis.analyses[index].morphemes.at(-1).form;
    const last = token.analysis.analyses[index].morphemes.at(-1);
    const label = grammarLabels[last.kind==='particle'?form:'-'+form];
    const details = label ? {label:label.label,ids:label.sources.map(s=>s.id)} : null;
    assert.ok(details,c.id+'/'+form);
    assert.equal(await ending.locator('.part-gloss').textContent(),details.label,c.id);
    const refs=await ending.locator('.grammar-references a').evaluateAll(as=>as.map(a=>a.href));
    const ids=details.ids;
    const hint=await ending.locator('.breakdown-part').getAttribute('title');
    for(const id of ids)assert.ok(hint.includes(String(id)),c.id+'/'+id);
    assert.equal(refs.length,0,'KRDict label sources use the entry button and hint');
    diagrams.push({case_id:c.id,encoding,mode,analysis:token.analysis.analyses[index],forms:await word.locator('.part-form').allTextContents(),references:refs,source_hint:hint});
   }
  }
 }
 await page.getByLabel('Dictionary matches only').uncheck();
 await page.getByLabel('Your sentence',{exact:true}).fill('오렴 살렴 먹으렴 들으렴 도우렴 지으렴 학생이렴 학생답렴 주렴');
 await page.getByRole('button',{name:'Analyze sentence',exact:true}).click();
 await page.waitForFunction(()=>document.querySelector('.sentence')?.textContent==='오렴 살렴 먹으렴 들으렴 도우렴 지으렴 학생이렴 학생답렴 주렴');
 await breakdown.scrollIntoViewIfNeeded();assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 await page.screenshot({path:prefix+'-browser-desktop.png'});
 await page.setViewportSize({width:390,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:prefix+'-browser-mobile.png'});
 const native=Object.assign({},...await Promise.all(['gentle-command-native-entries.json','gentle-command-boundary-native-entries.json'].map(async name=>JSON.parse(await readFile(proto+'/tests/fixtures/'+name,'utf8')))));
 for(const[id,value]of Object.entries(native)) {
  const response=await page.request.post(url+'/api/entry',{data:{id}});assert.equal(response.status(),200);const data=await response.json();assert.deepEqual(data.entry,value);nativeEntries.push({id,entry:data.entry});
 }
 assert.deepEqual(errors,[]);assert.equal(exports.length,6);assert.equal(policyDecisions.length,cases.length*6);assert.equal(diagrams.length,policyDecisions.filter(decision=>decision.allowed).length);
 await writeFile(prefix+'-browser.json',JSON.stringify({state:'source-bound-gentle-command-installed-browser-passed',producer_sha256:createHash('sha256').update(await readFile(new URL(import.meta.url))).digest('hex'),responses,exports,diagrams,spacingDiagrams,nativeEntries,policyDecisions,errors,scope:'Actual bound installed Nix SolidJS application, CLI/server and launcher; all23 independently authored Source/boundary cases with15required and8forbidden paths, six Unicode/filter policies, six exact exports and all47 complete original ending/lexical/boundary Native owners. Both original gentle ending owners are retained; dropdown policy never replaces every raw alternative with a contextual judgment. Full inventory Nix, current-main/performance/contextual and independent review remain separate.'},null,2)+'\n');
 console.log('Passed',diagrams.length,'individual diagrams and six exact exports.');
} finally {await browser.close();}
