"""Preserve actual committed Git-selected32 browser controls in the Nix sandbox."""
import gzip,hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent/'friendly-hortative-sena';D=W/'docs';sha=lambda raw:hashlib.sha256(raw).hexdigest()
r=json.loads((P/'friendly-hortative-sena-browser-sandbox-controls.json').read_bytes())
assert r['state']=='passed' and r['exit_code']==0 and r['controls']==32 and r['actual_sandbox_host_executables_absent']
assert all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged'])
assert all(sha((W/n).read_bytes())==d for n,d in r['frozen_inputs'].items())
assert r['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
assert r['index_sha256']==sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=W))
assert r['log_sha256']==sha((P/'friendly-hortative-sena-browser-sandbox-controls.log').read_bytes())
assert {k:len(v['files']) for k,v in r['profiles'].items()}=={'klem':1158,'corpus-adapter':1158,'web-assets':18}
prior=json.loads((P/'friendly-hortative-sena-sandbox-controls-retry2.json').read_bytes())
assert prior['state']=='passed' and prior['controls']==146
assert all(r['selected_files'][n]==d for n,d in prior['selected_files'].items() if n.startswith('tools/'))
names=['run_friendly_hortative_sena_browser_sandbox_controls.py','friendly-hortative-sena-browser-sandbox-controls.nix',
 'friendly-hortative-sena-browser-sandbox-controls.json','friendly-hortative-sena-browser-sandbox-controls.log',
 'friendly-hortative-sena-browser-integration-queue-validation.json',Path(__file__).name]
files={}
for name in names:
 raw=(P/name).read_bytes();path='friendly-hortative-sena-browser-sandbox-proof-'+name+'.gz';assert not (D/path).exists()
 packed=gzip.compress(raw,mtime=0);(D/path).write_bytes(packed);files[name]=dict(path=path,source_sha256=sha(raw),archive_sha256=sha(packed))
o=D/'friendly-hortative-sena-browser-sandbox-proof-archive.json';assert not o.exists()
o.write_text(json.dumps(dict(state='actual-committed-Git-selected-Sena-browser-Nix32-passed',files=files,source_head=r['head'],source_files=len(r['frozen_inputs']),selected_files=len(r['selected_files']),controls=32,all_prior146_tool_bytes_unchanged=True,compiled_profile_counts={'klem':1158,'corpus-adapter':1158,'web-assets':18},all_six_host_executables_actually_absent=True,binary_evidence_mode='captured',live_executable_files_verified=False,all715queue_rows_and519reviews_unchanged=True,full_coverage_complete=False,remaining='Strict historical Source adapters and complete historical inventory/fourpackages/installed/sharedpromotion/main/quiettiming/context/register/Korean review.'),indent=2)+'\n')
print('Archived',len(files),'actual current Git-selected browser sandbox originals;',sha(o.read_bytes()),flush=True)
