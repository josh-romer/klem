"""Retain the sole observed corpus hypothesis alongside unchanged original gold."""
import gzip
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = P.parents[1]
O = P / 'friendly-hortative-sena-corpus-observations.json'
assert not O.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
cohort_path = P / 'friendly-hortative-sena-cohorts.json.gz'
gold_path = P / 'friendly-hortative-sena-corpora.json.gz'
cohort = json.loads(gzip.decompress(cohort_path.read_bytes()))
gold = json.loads(gzip.decompress(gold_path.read_bytes()))
assert cohort['inputs_unchanged'] and gold['inputs_unchanged']
assert [r['surface'] for r in cohort['individual_changed_words']] == ['중세나']
assert next(r for r in cohort['runs'] if r['family'] == 'history')['changed_words'] == []
run = next(r for r in gold['runs'] if r['corpus'] == 'kaist' and r['partition'] == 'test')
row = next(r for r in map(json.loads, run['jsonl'].splitlines()) if r.get('surface') == '중세나')
assert row == dict(id='id:MH2_0180-s63/5', surface='중세나', expected=['중세'],
                   matched=True, recovered=1, recovered_sets=[[0]])
path = ROOT / run['source']
raw = path.read_bytes()
assert sha(raw) == run['source_sha256']
block = next(b for b in raw.split(b'\n\n') if b'# sent_id = MH2_0180-s63\n' in b)
start = raw.index(block)
fields = next(line.decode().split('\t') for line in block.splitlines() if line.startswith(b'5\t'))
assert fields[1:5] == ['중세나', '중세+나', 'CCONJ', 'ncn+jcj']
change = cohort['individual_changed_words'][0]
assert len(change['new_paths']) == 1
new = change['new_paths'][0]
assert [l['text'] for l in new['lemmas']] == ['중다']
assert new['morphemes'] == [dict(form='세나', kind='ending')]
assert 'ending.friendly_hortative.sena' in new['rules']
assert [p for p in change['after']['analyses'] if p in change['before']['analyses']] == change['before']['analyses']
record = dict(
    state='single-unjudged-Sena-corpus-hypothesis-original-annotation-preserved',
    producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
    source=str(path.relative_to(ROOT)), source_sha256=sha(raw),
    cohort_sha256=sha(cohort_path.read_bytes()), gold_sha256=sha(gold_path.read_bytes()),
    observations_precede_runtime=False, historical_fixture_words_changed=0,
    historical_allowances_assigned=False,
    items=[dict(id='friendly-hortative-sena-kaist-MH2_0180-s63-5',
                complete_original_conllu_block=block.decode(), sentence_byte_start=start,
                complete_original_token_fields=fields, original_gold_row=row,
                complete_original_word_analysis=change['before'], current_word_analysis=change['after'],
                new_unjudged_paths=change['new_paths'], contextual_verdict='unjudged',
                independent_korean_review='pending')],
    shared_cases_reviews_changed=False, full_coverage_complete=False)
O.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
assert sha(path.read_bytes()) == run['source_sha256']
print('Recorded exact original KAIST sentence/token/gold and one unjudged 중다+세나 hypothesis; no historical allowance or gold changes.', flush=True)
