"""Audit every original Rust command after terminal completion; never rerun tests."""
import datetime
import gzip
import hashlib
import json
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-command-gena'
NAME = 'friendly-command-gena-promotion-full-rust'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def inspect_commands(report, log):
    """Require the entire Cargo inventory and every trailing gate, in order."""
    assert report['state'] in ('passed', 'failed'), 'original job must be terminal'
    metadata = report['cargo_metadata']
    package = next(p for p in metadata['packages'] if p['manifest_path'] == str(W / 'Cargo.toml'))
    targets = package['targets']
    assert report['all_targets'] == targets and targets
    assert all(t['kind'] in [['lib'], ['bin'], ['test'], ['example']] for t in targets)
    expected = [(['cargo', 'fmt', '--all', '--', '--check'], None)]
    for target in targets:
        flag = {'lib': '--lib', 'bin': '--bin', 'test': '--test', 'example': '--example'}[target['kind'][0]]
        selector = [flag] if flag == '--lib' else [flag, target['name']]
        expected.append((['cargo', 'test', '--locked', '--offline', '--features', 'web', '--message-format', 'json', *selector], target))
    expected.extend((command, None) for command in [
        ['cargo', 'clippy', '--locked', '--offline', '--all-targets', '--features', 'web', '--', '-D', 'warnings'],
        ['python3', 'tools/review_inventory.py', '--verify'],
        ['git', 'diff', '--check'],
    ])
    results = report['results']
    assert len(results) == len(expected), 'no missing target or trailing check'
    chunks = re.split(rb'^COMMAND (.+)\n', log, flags=re.M)
    assert chunks[0] == b'' and len(chunks) == 1 + 2 * len(expected), 'entire command log accounted for'
    summaries = []
    for row, (command, target), logged_command, output in zip(results, expected, chunks[1::2], chunks[2::2], strict=True):
        assert row['command'] == command == json.loads(logged_command)
        assert row['target'] == target and row['exit_code'] == 0
        batches = re.findall(rb'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', output, flags=re.M)
        if target is None:
            assert not batches, 'test output cannot be borrowed from another command'
        else:
            assert len(batches) == 1, 'each metadata target has its own terminal test summary'
            status, passed, failed, ignored = batches[0]
            assert status == b'ok' and int(failed) == 0
            build_events = []
            for line in output.splitlines():
                if line.startswith(b'{'):
                    try:
                        value = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if value.get('reason') == 'build-finished':
                        build_events.append(value)
            assert len(build_events) == 1 and build_events[0]['success'] is True
            summaries.append(dict(target=target['name'], kind=target['kind'], passed=int(passed), failed=int(failed), ignored=int(ignored)))
    totals = {key: sum(row[key] for row in summaries) for key in ['passed', 'failed', 'ignored']}
    assert report['rust_totals'] == totals and report['rust_batches'] == len(summaries)
    assert report['log_sha256'] == sha(log)
    return dict(targets=len(targets), commands=len(expected), batches=len(summaries), totals=totals, summaries=summaries)


def main():
    out = P / (NAME + '-results-audit.json')
    archive_manifest = P / (NAME + '-terminal-originals.json')
    assert not out.exists() and not archive_manifest.exists()
    original_names = [NAME + '.json', NAME + '.log', 'run_friendly_command_gena_promotion_full_rust.py']
    payloads = {name: (P / name).read_bytes() for name in original_names}
    report = json.loads(payloads[NAME + '.json'])
    assert report['state'] in ('passed', 'failed'), 'do not archive or audit an active job'
    originals = {}
    for name, raw in payloads.items():
        path = P / (name + '.terminal-original.gz')
        assert not path.exists()
        packed = gzip.compress(raw, mtime=0)
        path.write_bytes(packed)
        assert gzip.decompress(path.read_bytes()) == raw
        originals[name] = dict(path=str(path), source_sha256=sha(raw), archive_sha256=sha(packed))
    archive_manifest.write_text(json.dumps(dict(actual_session_id=10415, original_state=report['state'], originals=originals), indent=2) + '\n')
    r = dict(state='running', actual_original_execution_session_id=10415,
             original_state=report['state'], original_receipt_retained=True,
             originals_manifest_sha256=sha(archive_manifest.read_bytes()),
             producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
             scope='Independent complete original Cargo inventory/command/log audit. No rerun, release/Nix/package/browser/main/performance/context/register/independent Korean review claim.')
    def save():
        out.write_text(json.dumps(r, indent=2) + '\n')
    save()
    try:
        producer = payloads[original_names[2]]
        assert report['producer'] == dict(text=producer.decode(), sha256=sha(producer))
        assert b"assert len(targets)==255 and len(r['results'])==259" in producer
        if report['state'] == 'failed':
            assert report['error'] == "AssertionError('complete actual255target inventory andfourrequiredcommands')", 'only the documented final count failure can be corrected'
        result = inspect_commands(report, payloads[NAME + '.log'])
        assert result['targets'] == 260 and result['commands'] == 264
        assert result['totals']['failed'] == 0 and result['totals']['ignored'] == 1
        git = lambda *args: subprocess.check_output(['git', *args], cwd=W)
        current_names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').decode().split('\0')[:-1]
        assert set(current_names) == set(report['frozen_inputs'])
        assert all(sha((W / n).read_bytes()) == digest for n, digest in report['frozen_inputs'].items())
        assert git('rev-parse', 'HEAD').decode().strip() == report['head']
        assert sha(git('ls-files', '--stage', '-z')) == report['index_sha256']
        assert len(report['protected_binaries']) == 6
        assert all(sha(Path(name).read_bytes()) == digest for name, digest in report['protected_binaries'].items())
        assert all(report[key] for key in ['inputs_unchanged', 'head_unchanged', 'index_unchanged', 'protected_binaries_unchanged'])
        assert all((P / name).read_bytes() == raw for name, raw in payloads.items())
        r.update(state='passed', **result, source_unchanged=True, head_unchanged=True,
                 index_unchanged=True, protected_binaries_unchanged=True,
                 original_receipt_sha256=sha(payloads[NAME + '.json']), original_log_sha256=sha(payloads[NAME + '.log']))
    except BaseException as error:
        r.update(state='failed', error=repr(error))
        raise
    finally:
        r['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()
    print('Entire original Rust inventory verified:', result['totals'], result['targets'], 'targets;', result['commands'], 'commands.', flush=True)


if __name__ == '__main__':
    main()
