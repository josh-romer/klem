"""Reconcile complete installed formal evidence and the newer apprehensive parent."""
import gzip
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

BASE = Path('/home/josh/projects/klem')
PREP = BASE / '.direnv/formal-volitional-prepared'
WORK = BASE / '.direnv/formal-volitional-integration'
PARENT = BASE / '.direnv/fear-lsera-integration'
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
assert subprocess.check_output(['git', 'rev-parse', '--short', 'HEAD'], cwd=WORK, text=True).strip() == '44553b8'
assert not (PREP / 'installed-finalization.json').exists()
assert 'Ran 24 tests' in (PREP / 'installed-controls.log').read_text()
assert (PREP / 'installed-controls.log').read_text().rstrip().endswith('OK')
binding = json.loads((PREP / 'installed-source-binding.json').read_bytes())
assert binding['state'] == 'passed' and binding['exit_code'] == 0
assert {name: len(profile['files']) for name, profile in binding['profiles'].items()} == {'klem': 1079, 'web-assets': 18, 'corpus-adapter': 1079}
protected = {str(WORK / field['snapshot_path']): sha(WORK / field['snapshot_path'])
             for profile in binding['profiles'].values() for field in profile['files'].values()}
parent_reviews = json.loads((PARENT / 'docs/inventory-reviews.json').read_bytes())
reviews = json.loads((WORK / 'docs/inventory-reviews.json').read_bytes())
original_formal_reviews = {row['id']: row for row in reviews['entries'] if 'COV-017cw' in row['checklist']}
assert len(original_formal_reviews) == 4
for name in ['installed-audit.log', 'installed-controls.log']:
    source = PREP / name
    out = BASE / 'docs' / ('formal-volitional-' + name + '.gz')
    assert not out.exists()
    out.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
for name in ['formal_volitional_installed_audit.py', 'test_formal_volitional_installed_audit.py']:
    source = WORK / 'tools' / name
    out = BASE / 'docs' / ('formal-volitional-' + name + '.gz')
    assert not out.exists()
    out.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
proof = {'state': 'complete-installed-validation-passed', 'head': binding['head'],
         'source_profiles': {'klem': 1079, 'web-assets': 18, 'corpus-adapter': 1079},
         'controls': 24, 'cohort_words': 53502, 'annotated_rows': 66570,
         'broad_frames': 1128312, 'finite_streams': 24, 'finite_frames': 4764,
         'policy_decisions': 222, 'diagrams': 222, 'exports': 6, 'native_entries': 69,
         'owned_server_stopped': True,
         'scope': 'Actual four-package build, exact evaluated-source/derivation binding, complete finite/cache/Unicode/filter, original cohort/gold/broad and actual Nix-launcher browser captures independently rederived;24controls pass. Original offline dependency failure retained alongside the identical-source cache-enabled retry. Fullinventory/main/familytiming/wider/contextual/independent review remain open.'}
out = BASE / 'docs/formal-volitional-installed-validation.json.gz'
assert not out.exists()
out.write_bytes(gzip.compress((json.dumps(proof, indent=2) + '\n').encode(), mtime=0))
copied = []
for family in ['fear-lsera', 'formal-volitional']:
    for source in sorted((BASE / 'docs').glob(family + '-*')):
        if source.name.startswith('formal-volitional-expression-'):
            continue
        target = WORK / 'docs' / source.name
        assert not target.exists() or target.read_bytes() == source.read_bytes(), source
        if not target.exists():
            shutil.copyfile(source, target)
            copied.append(str(target.relative_to(WORK)))
for name in ['fear_lsera_installed_audit.py', 'test_fear_lsera_installed_audit.py']:
    source = PARENT / 'tools' / name
    target = WORK / 'tools' / name
    assert not target.exists()
    shutil.copyfile(source, target)
    copied.append(str(target.relative_to(WORK)))
flake = WORK / 'flake.nix'
text = flake.read_text()
for family, last in [('fear_lsera', 'broad'), ('formal_volitional', 'ledger')]:
    marker = '                ./tools/test_' + family + '_' + last + '_audit.py\n'
    command = "            python -m unittest discover -s tools -p 'test_" + family + '_' + last + "_audit.py'\n"
    assert text.count(marker) == text.count(command) == 1
    text = text.replace(marker, marker + '                ./tools/' + family + '_installed_audit.py\n                ./tools/test_' + family + '_installed_audit.py\n')
    text = text.replace(command, command + '            python tools/' + family + "_installed_audit.py\n            python -m unittest discover -s tools -p 'test_" + family + "_installed_audit.py'\n")
flake.write_text(text)
path = WORK / 'docs/coverage-checklist.md'
text = path.read_text()
parent_text = (PARENT / 'docs/coverage-checklist.md').read_text()
start, end = text.index('- [ ] **COV-017cv —'), text.index('- [ ] **COV-017cw —')
parent_start, parent_end = parent_text.index('- [ ] **COV-017cv —'), parent_text.index('- [ ] **COV-018 —')
text = text[:start] + parent_text[parent_start:parent_end] + text[end:]
start, end = text.index('- [ ] **COV-017cw —'), text.index('- [ ] **COV-018 —')
block = text[start:end]
block = block.replace('Nix/main integration pending', 'full Nix inventory/main integration pending')
block += ('  [Actual installed validation](formal-volitional-installed-validation.json.gz)\n'
          '  passes all four Nix packages and exact 1,079/18/1,079 source binding.\n'
          '  Complete replays retain 53,502 cohort words, 66,570 original gold rows,\n'
          '  1,128,312 broad frames and 4,764 finite frames across 24 streams. The\n'
          '  actual launcher passes 222 decisions and diagrams, six CLI exports\n'
          '  and 69 full Native endpoints; its server stops. The combined audit\n'
          '  passes 24 corruption controls and is wired into Nix, alongside the\n'
          '  completed apprehensive installed audit. Both original offline\n'
          '  dependency failure and successful identical-source retry are retained.\n'
          '  Full inventory/main, family timing and wider/contextual/independent\n'
          '  review remain pending.\n\n')
path.write_text(text[:start] + block + text[end:])
path = WORK / 'docs/formal-volitional-draft.md'
text = path.read_text().replace('Nix/installed/main integration pending', 'Full Nix inventory/main integration pending')
text += '\nActual installed package/source/derivation, complete finite/cohort/gold/broad/browser evidence and24controls pass. Full Nixinventory/main/familytiming/contextualreview remain open.\n'
path.write_text(text)
shutil.copyfile(PARENT / 'docs/fear-lsera-draft.md', WORK / 'docs/fear-lsera-draft.md')
by_id = {row['id']: row for row in parent_reviews['entries']}
for i, review in enumerate(reviews['entries']):
    if review['id'] in ['krdict:86497', 'krdict:86619']:
        reviews['entries'][i] = by_id[review['id']]
    elif review['id'] in original_formal_reviews:
        review['evidence'].append({'path': 'docs/formal-volitional-installed-validation.json.gz'})
        review['scope'] += ' Actual installed packages and1079/18/1079sourcebinding reproduce all finite/cohort/gold/broad/browser captures;24combinedcorruptioncontrols pass.'
        review['remaining'] = review['remaining'].replace('Actual Nix/installed/main integration', 'Full Nix inventory/main integration').replace('Nix/installed/main integration', 'Full Nix inventory/main integration')
path = WORK / 'docs/inventory-reviews.json'
path.write_text(json.dumps(reviews, ensure_ascii=False, indent=2) + '\n')
sys.path.insert(0, str(WORK / 'tools'))
import review_inventory as audit
path = WORK / 'docs/inventory-review-queue.json'
queue = json.loads(path.read_bytes())
queue = audit.build_queue(WORK, queue['dictionary_metadata'], [row['source'] for row in queue['entries']])
assert queue['counts']['by_review'] == {'scoped': 511, 'unreviewed': 204}
path.write_text(json.dumps(queue, ensure_ascii=False, indent=2) + '\n')
audit.verify_queue(WORK, queue)
assert all(sha(path) == digest for path, digest in protected.items()), 'installed runtime source inputs changed'
result = {'state': 'installed-finalization-and-parent-reconciliation-passed',
          'copied': copied, 'queue_counts': queue['counts'], 'protected_runtime_sources_unchanged': True,
          'parent': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=PARENT, text=True).strip(),
          'scope': 'All installed Rust/frontend/adapter source bytes unchanged while newer apprehensive installed evidence/two reviews and formal installed evidence/four reviews are reconciled. Source judgments and complete ledger remain unchanged. Fullinventory/main/timing/wider review remain pending.',
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)}}
(PREP / 'installed-finalization.json').write_text(json.dumps(result, indent=2) + '\n')
print('Finalized complete formal installed proof and newer apprehensive parent with511/204queue; package sources unchanged')
