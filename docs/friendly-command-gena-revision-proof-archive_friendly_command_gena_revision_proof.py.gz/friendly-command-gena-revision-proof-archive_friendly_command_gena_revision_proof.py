import gzip,hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;W=Path('/home/josh/projects/klem/.direnv/friendly-command-gena');D=W/'docs'
sha=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((P/'friendly-command-gena-revision-adapters.json').read_bytes());assert r['state']=='passed' and all(r[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged']) and len(r['results'])==9 and all(x['exit_code']==0 for x in r['results'])
assert [x['controls'] for x in r['results'][:3]]==[22,48,18];assert sha((P/'friendly-command-gena-revision-adapters.log').read_bytes())==r['log_sha256']
files={}
def add(name,raw):
 path=D/('friendly-command-gena-revision-proof-'+name+'.gz');assert not path.exists();packed=gzip.compress(raw,mtime=0);path.write_bytes(packed);files[name]=dict(path=path.name,source_sha256=sha(raw),archive_sha256=sha(packed))
for name in ['validate_friendly_command_gena_revision_adapters.py','friendly-command-gena-revision-adapters.json','friendly-command-gena-revision-adapters.log','archive_friendly_command_gena_revision_proof.py']:
 add(name,(P/name).read_bytes())
changed=['tools/friendly_command_gena_revision.py','tools/test_friendly_command_gena_runtime_audit.py','tools/gentle_command_long_revision.py','tools/gentle_command_long_installed_audit.py','flake.nix']
for name in changed:
 current=(W/name).read_bytes();assert r['frozen_inputs'][str(W/name)]==sha(current);add('current-'+Path(name).name,current);add('original-'+Path(name).name,subprocess.check_output(['git','show','ee3b49f:'+name],cwd=W))
path=D/'friendly-command-gena-revision-proof-archive.json';assert not path.exists();path.write_text(json.dumps(dict(state='current-Gena-named-revision-adapters-and-Nix-wiring-verified',files=files,controls=r['controls'],individual_control_suites=[dict(module=x['command'][-1],controls=x['controls']) for x in r['results'][:7]],all_source_head_index_unchanged=True,production_changed=False,all_original_historical_captures_assertions_and_judgments_retained=True,current_source_runtime_browser_controls=88,complete_named_production_inputs=44,individual_production_changes=5,complete_named_frontend_inputs=18,declared_frontend_build_inputs=14,current_gena_modules_selected_in_flake=5,current_gena_runtime_browser_controls_executed_by_inventory=True,actual_git_selected_current_package_full_nix_installed_main='pending',quiet_performance_context_register_independent_review_and_shared24promotion='pending',full_coverage_complete=False),indent=2)+'\n');print('Archived',len(files),'fulloriginalartifacts;',r['controls'],'actualcontrols',flush=True)
