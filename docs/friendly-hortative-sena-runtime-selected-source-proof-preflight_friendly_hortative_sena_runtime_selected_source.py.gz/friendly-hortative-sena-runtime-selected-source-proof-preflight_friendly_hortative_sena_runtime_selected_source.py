"""Check the actual Nix-selected Sena source and source-evidence controls."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = Path('/home/josh/projects/klem')
W = ROOT / '.direnv/friendly-hortative-sena'
B = Path('/var/tmp/klem-friendly-hortative-sena-nix-build')
O = P / 'friendly-hortative-sena-runtime-selected-source.json'
L = P / 'friendly-hortative-sena-runtime-selected-source.log'
assert not O.exists() and not L.exists()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=W)
B.mkdir(exist_ok=True)
B.chmod(0o1777)
sha = lambda b: hashlib.sha256(b).hexdigest()
names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=W).decode().split('\0')[:-1]
frozen = {n: sha((W / n).read_bytes()) for n in names}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
index = sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=W))
flake = 'git+file://' + str(W)
env = dict(os.environ, TMPDIR=str(B), PYTHONDONTWRITEBYTECODE='1')

def source(attr):
    return Path(subprocess.check_output(['nix', 'eval', '--offline', '--raw', flake + '#' + attr],
                                       cwd=W, env=env, text=True).strip())

def files(src, prefix=''):
    values = {}
    for path in src.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            name = str(path.relative_to(src))
            digest = sha(path.read_bytes())
            assert digest == frozen[prefix + name], 'actual selected input bytes'
            values[name] = digest
    return values

src = source('checks.x86_64-linux.inventory-review.src')
selected = files(src)
assert all(name in selected for name in [
    'tools/friendly_hortative_sena_source_audit.py',
    'tools/test_friendly_hortative_sena_source_audit.py',
    'tools/friendly_hortative_sena_runtime_audit.py',
    'tools/test_friendly_hortative_sena_runtime_audit.py',
    'docs/friendly-hortative-sena-source-baseline-proof-archive.json'])
profiles = {}
for attr, prefix in [('klem', ''), ('corpus-adapter', ''), ('web-assets', 'web/')]:
    s = source('packages.x86_64-linux.' + attr + '.src')
    profiles[attr] = dict(source=str(s), files=files(s, prefix))
parent_path = ROOT / '.direnv/willingness-question-prepared/friendly-command-gena-complete-runtime-binding.json'
parent_raw = parent_path.read_bytes()
parent = json.loads(parent_raw)['production_inputs']
assert len(parent) == 44
changes = {'src/grammar.rs', 'src/engine.rs', 'src/dictionary/attachment.rs',
           'src/bin/klem-web/grammar_labels.rs', 'web/src/grammar-labels.json'}
current = {name: frozen[name] for name in parent}
assert {name for name in parent if parent[name] != current[name]} == changes
parent_catalog_path = ROOT / '.direnv/friendly-command-gena/web/src/grammar-labels.json'
assert sha(parent_catalog_path.read_bytes()) == parent['web/src/grammar-labels.json']
parent_catalog = json.loads(parent_catalog_path.read_bytes())
current_catalog = json.loads((W / 'web/src/grammar-labels.json').read_bytes())
assert list(current_catalog) == list(parent_catalog) + ['-세나'], 'all old catalog ordering'
assert {k: v for k, v in current_catalog.items() if k != '-세나'} == parent_catalog, 'all old catalog fields'
for attr in ['klem', 'corpus-adapter']:
    assert all(profiles[attr]['files'][name] == digest for name, digest in current.items())
assert len(profiles['web-assets']['files']) == 18
commands = [
    ['python3', 'tools/friendly_hortative_sena_source_audit.py'],
    ['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_friendly_hortative_sena_source_audit.py'],
    ['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_friendly_command_gena_source_audit.py'],
    ['python3', 'tools/friendly_hortative_sena_runtime_audit.py'],
    ['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_friendly_hortative_sena_runtime_audit.py'],
    ['python3', 'tools/review_inventory.py', '--verify']]
r = dict(state='running', head=head, index_sha256=index, frozen_inputs=frozen,
         selected_source=str(src), selected_files=selected, profiles=profiles,
         production_inputs=current, parent_production_inputs=parent,
         declared_production_changes=sorted(changes), parent_binding_sha256=sha(parent_raw),
         producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), results=[],
         scope='Actual Git-backed Nix-selected Sena source/current-runtime controls and preserved parent Gena source controls; every selected byte,44compiled production inputs/five exact declared changes and18frontend inputs. No claim that wider historical runtime audits, full inventory, packages, installed browser, main, timing or contextual review pass for this new source.')

def save():
    O.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')

save()
with L.open('xb') as log:
    for command in commands:
        log.write(('COMMAND ' + json.dumps(command) + '\n').encode())
        log.flush()
        job = subprocess.run(command, cwd=src, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        log.write(job.stdout)
        log.flush()
        match = re.search(rb'Ran (\d+) tests', job.stdout)
        r['results'].append(dict(command=command, exit_code=job.returncode,
                                 controls=int(match[1]) if match else 0))
        save()
        print(command[-1], job.returncode, r['results'][-1]['controls'], flush=True)
        if job.returncode:
            break
r.update(inputs_unchanged=all(sha((W / name).read_bytes()) == digest for name, digest in frozen.items()),
         head_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip() == head,
         index_unchanged=sha(subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=W)) == index,
         parent_binding_unchanged=sha(parent_path.read_bytes()) == sha(parent_raw),
         log_sha256=sha(L.read_bytes()), controls=sum(x['controls'] for x in r['results']),
         finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
r['state'] = 'passed' if len(r['results']) == len(commands) and all(x['exit_code'] == 0 for x in r['results']) and all(
    r[k] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged', 'parent_binding_unchanged']) else 'failed'
save()
print(r['state'], r['controls'], 'actual Nix-selected source controls', flush=True)
raise SystemExit(0 if r['state'] == 'passed' else 1)
