"""Retain each observed history addition and exact unmodified fixture witness."""
import datetime,gzip,hashlib,json,subprocess
from pathlib import Path
PREP=Path(__file__).resolve().parent;WORK=Path('/home/josh/projects/klem/.direnv/friendly-command-gena')
OUT=PREP/'friendly-command-gena-history.json';LOG=PREP/'friendly-command-gena-history.log';assert not OUT.exists() and not LOG.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
cohort_path=PREP/'friendly-command-gena-cohorts.json.gz';cohort=json.loads(gzip.decompress(cohort_path.read_bytes()));assert cohort['state']=='complete-original-corpus-history-comparison-passed' and cohort['inputs_unchanged']
changed={}
for row in cohort['individual_changed_words']:
 surface=row['surface']
 if surface in changed:assert changed[surface]['before']==row['before'] and changed[surface]['after']==row['after']
 else:changed[surface]=dict(before=row['before'],after=row['after'])
words=set(changed);paths=subprocess.check_output(['git','ls-tree','-r','--name-only','3ad5839','tests/fixtures'],cwd=WORK,text=True).splitlines();source_files={};witnesses={word:[] for word in words}
def escaped(s):return s.replace('~','~0').replace('/','~1')
def walk(value,pointer,name,digest):
 if isinstance(value,dict):
  if value.get('normalized') in words and isinstance(value.get('analyses'),list):
   word=value['normalized'];witnesses[word].append(dict(source=name,source_sha256=digest,pointer=pointer,complete_original_record=value,kind='original-word-analysis'))
  for key,item in value.items():
   child=pointer+'/'+escaped(key)
   if key in words and not (isinstance(item,dict) and item.get('normalized')==key and isinstance(item.get('analyses'),list)):
    witnesses[key].append(dict(source=name,source_sha256=digest,pointer=child,complete_original_record=item,kind='original-surface-key'))
   walk(item,child,name,digest)
 elif isinstance(value,list):
  for i,item in enumerate(value):walk(item,pointer+'/'+str(i),name,digest)
with LOG.open('x') as log:
 for name in paths:
  if not name.endswith('.json'):continue
  raw=(WORK/name).read_bytes();old=subprocess.check_output(['git','show','3ad5839:'+name],cwd=WORK);assert raw==old,'do not refresh any parent fixture'
  if not any(word.encode() in raw for word in words):continue
  digest=sha(raw);source_files[name]=digest;walk(json.loads(raw),'',name,digest);log.write(name+' '+digest+'\n');log.flush()
items=[]
for surface in sorted(changed):
 before=changed[surface]['before'];after=changed[surface]['after'];assert [a for a in after['analyses'] if a in before['analyses']]==before['analyses']
 for a in after['analyses']:
  if a in before['analyses']:continue
  assert 'ending.friendly_command.gena' in a['rules'];items.append(dict(id='friendly-command-gena-history-'+str(len(items)+1),surface=surface,analysis=a,original_occurrences=witnesses[surface],contextual_verdict='unjudged',independent_review='pending'))
assert words=={'누구에게나','머슴에게나','보게나','알려주시게나','아무에게나'} and len(items)==11
assert any(w['source']=='tests/fixtures/deoniman-sources.json' for w in witnesses['아무에게나'])
record=dict(state='complete-gena-history-and-unchanged-parent-fixture-capture-passed',captured_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_files_sha256=source_files,changed_words=changed,individual_additions=items,cohort_sha256=sha(cohort_path.read_bytes()),cohort_scope=dict(words=53502,corpus_words=32096,history_words=21406),producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),inputs_unchanged=True,observations_precede_runtime=False,scope='Exactly11observedrawhypotheses across5changed53502cohortwords, matched to complete unmodified parent3ad5839fixtures and original JSON pointers. AlloriginalSourcefiles/candidates/order retained; Nativeclasses/contextual/lexicalsenses unjudged. This permits only finite original historical observations, not every future path carrying a rule ID; no gold or linguistic judgments refreshed/promoted.')
OUT.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');fixture=WORK/'tests/fixtures/friendly-command-gena-history.json';assert not fixture.exists();fixture.write_bytes(OUT.read_bytes());print('Captured',len(items),'exact unjudged additions /',len(changed),'words /',len(source_files),'original fixture files; SHA',sha(OUT.read_bytes()),flush=True)
