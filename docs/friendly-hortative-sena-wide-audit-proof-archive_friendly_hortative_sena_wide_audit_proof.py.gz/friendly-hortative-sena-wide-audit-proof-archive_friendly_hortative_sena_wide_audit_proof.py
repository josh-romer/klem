"""Retain the complete actual independent34-controls evidence."""
import gzip
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
D = W / 'docs'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
R = P / 'friendly-hortative-sena-wide-audit-validation.json'
r = json.loads(R.read_bytes())
assert r['state'] == 'passed' and r['controls'] == 34 and len(r['results']) == 2
assert all(row['exit_code'] == 0 for row in r['results'])
assert all(r[k] for k in ['inputs_unchanged','external_inputs_unchanged','head_unchanged','index_unchanged'])
assert all(sha((W / p).read_bytes()) == d for p, d in r['frozen_inputs'].items())
assert all(sha(Path(p).read_bytes()) == d for p, d in r['external_inputs'].items())
assert sha((P / 'friendly-hortative-sena-wide-audit-validation.log').read_bytes()) == r['log_sha256']
files = {}
for path in [P/'friendly_hortative_sena_wide_audit.py',P/'test_friendly_hortative_sena_wide_audit.py',
             P/'validate_friendly_hortative_sena_wide_audit.py',R,
             P/'friendly-hortative-sena-wide-audit-validation.log',Path(__file__)]:
    raw=path.read_bytes();name='friendly-hortative-sena-wide-audit-proof-'+path.name+'.gz'
    output=D/name;assert not output.exists();packed=gzip.compress(raw,mtime=0);output.write_bytes(packed)
    files[path.name]=dict(path=name,source_sha256=sha(raw),archive_sha256=sha(packed))
output=D/'friendly-hortative-sena-wide-audit-proof-archive.json';assert not output.exists()
output.write_text(json.dumps(dict(state='actual-independent-Sena-wide34controls-passed',files=files,
    immutable_wide_manifest_sha256='bb4cb1f2cfa778ba8eab65d02d398e26c89809b578e3c3ff268d74be9a5e4621',
    independent_controls=34,cohort_words=53502,annotated_rows=66570,broad_frames=1128312,
    changed_corpus_words=1,changed_historical_words=0,changed_full_gold_rows=0,changed_broad_frames=0,
    Native_heads=71,complete_Native_owners=41,additional_Native_owners=9,unmatched_heads=48,
    Source_and_binaries_unchanged=True,original_stopped_attempt_not_relabelled=True,
    contextual_hypotheses='unjudged',independent_korean_review='pending',
    full_coverage_complete=False),indent=2)+'\n')
print('Archived all six original wide-audit artifacts;actual34controls passed.',flush=True)
