"""Archive current-main validation only after the exact live Nix gate is terminal and green."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
PREP = Path(__file__).resolve().parent
GATE = ROOT / '.direnv/coverage-gates/formal-volitional-main-installed.json'
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
gate = json.loads(GATE.read_text())
rust = json.loads((PREP / 'main-full-rust.json').read_text())
binding = json.loads((PREP / 'main-installed-source-binding-retry1.json').read_text())
assert all(r['state'] == 'passed' and r['exit_code'] == 0 for r in [gate, rust, binding]), 'all three actual terminal proofs required'
assert all(r[k] for r in [gate, rust, binding] for k in ['inputs_unchanged', 'head_unchanged', 'index_unchanged'])
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == gate['head'] == rust['head'] == binding['head'] == '162e82689b382747bc969ac6933a4848008406f8'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
assert all(sha(ROOT / name) == record['sha256'] for name, record in gate['snapshot_files'].items())
assert all(sha(ROOT / name) == digest for name, digest in rust['frozen_files'].items())
assert rust['totals'] == {'passed': 1150, 'failed': 0, 'ignored': 1} and rust['batches'] == 247
assert {name: len(profile['files']) for name, profile in binding['profiles'].items()} == {'klem': 1080, 'web-assets': 18, 'corpus-adapter': 1080}
assert len(gate['outputs']) == 4
files = [PREP / name for name in ['main-full-rust.json', 'main-full-rust.log', 'run_main_full_rust.py',
          'main-installed-source-binding-retry1.json', 'main-installed-source-binding-retry1.log', 'bind-main-installed-source-retry1.py',
          'main-installed-source-binding-failure.json', 'main-installed-source-binding.log', 'bind-main-installed-source.py',
          'run_main_complete_inventory_gate.py', Path(__file__).name]]
files.extend([GATE, GATE.with_suffix('.log')])
archived = []
for source in files:
    destination = ROOT / 'docs' / ('formal-volitional-current-main-' + source.name + '.gz')
    assert not destination.exists(), destination
    destination.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
    archived.append({'path': str(destination.relative_to(ROOT)), 'original_sha256': sha(source), 'archive_sha256': sha(destination)})
result = {'state': 'actual-current-main-validation-preserved', 'validated_head': head, 'rust': rust['totals'],
          'rust_batches': 247, 'nix_gate_outputs': gate['outputs'], 'archives': archived,
          'full_coverage_complete': False,
          'scope': 'Exact current-main formal implementation at162e826; full1150Rust, actual4Nixpackage/sourcebindings1080/18/1080 andterminal complete4checkNix gate. Every tracked file/HEAD/index remained unchanged. Initial missingTMPDIRfailure andcorrectedproducer preserved. Expression andconjectural promotion, currentfullinstalledworkloads, quiettiming andwidercontextual/independent review remain separate. New proof archives do not alter tested compiled sources.'}
out = PREP / 'main-validation-archive.json'; assert not out.exists()
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(ROOT / 'docs/formal-volitional-current-main-validation-archive.json.gz').write_bytes(gzip.compress(out.read_bytes(), mtime=0))
print(result['state'], rust['totals'], 'actual complete Nix checks', len(gate['outputs']), flush=True)
