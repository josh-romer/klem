"""Record focused draft evidence without changing the current repository or queue."""
from pathlib import Path
import json, gzip, hashlib

ROOT = Path('/home/josh/projects/klem')
PROTO = Path('/tmp/klem-declarative-dao-prototype')
BASE = Path('/tmp/klem-possessive-bound-noun-final-prototype')
read = lambda p: json.loads(gzip.decompress(Path(p).read_bytes()))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
native = read('/tmp/klem-declarative-dao-native-revision2.json.gz')
runtime = read('/tmp/klem-declarative-dao-runtime.json.gz')
prior = read('/tmp/klem-declarative-dao-native.json.gz')
assert all(native['complete_native_entries'][i] == v for i, v in prior['complete_native_entries'].items())
assert all(native['original_lmf'][i] == v for i, v in prior['original_lmf'].items())
matched = {e['id'] for run in runtime['runs'] for record in run['records']
           for m in (record.get('dictionary') or {}).get('lemmas', []) for e in m['entries']}
assert matched <= set(native['complete_native_entries'])
proof = read('/tmp/klem-possessive-bound-noun-installed-sources.json.gz')
snapshot, updates = {}, []
for name, old in proof['snapshot_files'].items():
    p = next(root / name for root in [PROTO, BASE, ROOT] if (root / name).is_file())
    raw = p.read_bytes()
    snapshot[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    if snapshot[name] != old:
        updates.append(name)
new = ['tests/declarative_dao.rs', 'tests/fixtures/declarative-dao-proposals.json',
       'tests/fixtures/declarative-dao-native.json', 'tests/fixtures/krdict-declarative-dao-english.json',
       'tests/fixtures/declarative-dao-validity.json']
for name in new:
    p = PROTO / name
    snapshot[name] = {'bytes': p.stat().st_size, 'sha256': sha(p)}
assert len(snapshot) == 982 and len(updates) == 4
assert '6 passed; 0 failed' in Path('/tmp/klem-declarative-dao-tests-retry4.log').read_text()
assert 'Finished' in Path('/tmp/klem-declarative-dao-clippy.log').read_text()
report = {
    'state': 'isolated-dao-draft-focused-validation-passed', 'prototype': str(PROTO),
    'snapshot_files': snapshot, 'updated_files': updates, 'new_files': new,
    'complete_native_entries': len(native['complete_native_entries']), 'matched_native_owners': len(matched),
    'complete_original_groups': 26, 'source_occurrences': 26, 'individual_cases': 34,
    'required_judgments': 31, 'forbidden_judgments': 3, 'focused_rust_tests': 6,
    'clippy_passed': True, 'actual_cli_streams': 6, 'frames_per_stream': 417,
    'all_prior_candidates_and_dictionary_assessments_preserved': True,
    'additional_raw_candidates': 84, 'additional_headword_candidates': 32,
    'additional_compatible_candidates': 31, 'root_integration_complete': False,
    'wider_corpus_complete': False, 'nix_complete': False, 'independent_review_complete': False,
    'inventory_dispositions_changed': False, 'full_coverage_complete': False,
    'evidence': {str(p): sha(p) for p in map(Path, [
        '/tmp/klem-declarative-dao-native-revision2.json.gz', '/tmp/klem-declarative-dao-runtime.json.gz',
        '/tmp/klem-declarative-dao-tests-retry4.log', '/tmp/klem-declarative-dao-clippy.log'])},
    'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)},
    'remaining': [
        'Preserve and assess every added path individually against its complete original context and exact Native owner.',
        'Review wider owner/prefinal combinations; the six source identities do not license a general polite 오 prefinal.',
        'Run full regression, corpus/novel, adapter, installed Nix, API/browser, performance and integration checks.',
        'Retain the prior possession/cause implementation and its proper-name gap; do not mix unvalidated source deltas.',
    ],
}
Path('/tmp/klem-declarative-dao-checkpoint.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print({k: v for k, v in report.items() if k not in ['snapshot_files', 'evidence', 'producer']})
