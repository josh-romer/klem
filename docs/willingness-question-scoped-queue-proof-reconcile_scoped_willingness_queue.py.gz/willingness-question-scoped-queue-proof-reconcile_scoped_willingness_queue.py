"""Regenerate only derived evidence/citations and two explicit bounded review dispositions."""
import datetime, gzip, hashlib, json, sys
from pathlib import Path
work=Path('/tmp/klem-willingness-interactions');prep=Path(__file__).resolve().parent
out=prep/'willingness-scoped-queue-reconciliation.json'; assert not out.exists()
sys.path.insert(0,str(work/'tools'));import review_inventory as inventory
sha=lambda raw:hashlib.sha256(raw).hexdigest()
path=work/inventory.QUEUE;raw=path.read_bytes();parent=json.loads(raw)
assert sha(raw)=='7dd6e284b03d1a7b7ee2ad9e1e2e417850cd6a316bbb8552f9751f58d8a0c0a3'
archive=work/'docs/willingness-question-scoped-parent-inventory-queue.json.gz';assert not archive.exists()
old_reviews=gzip.decompress((work/'docs/willingness-question-parent-inventory-reviews.json.gz').read_bytes())
assert sha(old_reviews)=='5809cc3e8a9dabd2c81a1f6f1d4f2bf48c19cc7615dcc0b699e0957459f65e48'
reviews=json.loads((work/inventory.REVIEWS).read_bytes());authored_raw=(work/'docs/willingness-question-scoped-reviews.json').read_bytes()
assert sha(authored_raw)=='0d5ba30af82b1342609dc8f7e2ce9d72212325598f92483d52dd3809ff58c2f7'
authored=json.loads(authored_raw)['entries'];assert reviews['entries']==json.loads(old_reviews)['entries']+authored
metadata,entries=inventory.dictionary_entries(Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db'))
updated=inventory.build_queue(work,metadata,entries);inventory.verify_queue(work,updated)
before={r['source']['id']:r for r in parent['entries']};after={r['source']['id']:r for r in updated['entries']}
assert set(before)==set(after) and len(after)==715
assert parent['dictionary_metadata']==updated['dictionary_metadata']
new_review={r['id']:r for r in authored};assert set(new_review)=={'krdict:76564','krdict:76567'}
fixture=json.loads((work/'tests/fixtures/willingness-question-interaction-validity.json').read_bytes())
new_refs=sorted([{'case':c['id'],'judgment':j['id'],'verdict':j['verdict']} for c in fixture['cases'] for j in c['judgments']],key=lambda r:(r['case'],r['judgment']))
assert len(new_refs)==8
for ident,old in before.items():
 new=after[ident]
 for field in ['source','source_sha256','catalog','inventory_evidence']:assert old[field]==new[field],(ident,field)
 if ident in new_review:
  assert old['review']=={'status':'unreviewed'} and new['review']==new_review[ident]
 else:assert old['review']==new['review'],ident
 expected=sorted(old['cited_judgments']+(new_refs if ident=='krdict:76567' else []),key=lambda r:(r['case'],r['judgment']))
 assert new['cited_judgments']==expected,ident
assert updated['counts']['by_review']=={'scoped':515,'unreviewed':200}
new=(json.dumps(updated,ensure_ascii=False,indent=2)+'\n').encode()
archive.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(archive.read_bytes())==raw
path.write_bytes(new)
r=dict(state='passed',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent_queue_sha256=sha(raw),queue_sha256=sha(new),all_original_source_rows_retained=715,all_original_catalog_and_inventory_links_retained=715,unchanged_review_rows=713,previous_complete_manual_reviews_retained=513,only_added_reviews=['krdict:76564','krdict:76567'],only_added_citations={'krdict:76567':new_refs},counts=updated['counts'],source_review_metadata_retained=True,producer={'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},scope='Source-based bounded structural dispositions only. All independent Korean-language, contextual precision, original source register/pragmatics and stated remaining review restrictions remain open.')
out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print('Retained all715source rows and513manual reviews; only2scoped dispositions/8citations appended; 515scoped/200unreviewed')
