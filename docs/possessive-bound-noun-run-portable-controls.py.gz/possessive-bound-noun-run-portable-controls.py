import json,os,subprocess
from pathlib import Path
report=Path('/tmp/klem-possessive-bound-noun-performance.json')
assert json.loads(report.read_text())['state']=='passed'
env=os.environ.copy()
env.update(KLEM_ROOT='/home/josh/projects/klem',KLEM_POSSESSIVE_CLOSURE='/tmp/klem-possessive-bound-noun-native-revision2.json.gz',KLEM_POSSESSIVE_FIXTURE='/tmp/klem-possessive-bound-noun-final-prototype/tests/fixtures/possessive-bound-noun-cases.json',KLEM_POSSESSIVE_RUNTIME='/tmp/klem-possessive-bound-noun-installed-runtime.json.gz',KLEM_POSSESSIVE_PACKAGE='/tmp/klem-possessive-bound-noun-nix-retry1.json',KLEM_POSSESSIVE_SOURCES='/tmp/klem-possessive-bound-noun-installed-sources.json.gz',KLEM_POSSESSIVE_ADAPTER='/tmp/klem-possessive-bound-noun-installed-adapter.json.gz',KLEM_POSSESSIVE_PERFORMANCE=str(report),KLEM_POSSESSIVE_BROAD='/tmp/klem-possessive-bound-noun-broad-final.json.gz',KLEM_POSSESSIVE_CLI='/tmp/klem-possessive-bound-noun-installed-cli.json')
command=['python3','-m','unittest','discover','-s','/tmp/klem-possessive-bound-noun-integration/tools','-p','test_possessive_bound_noun_*.py']
log=Path('/tmp/klem-possessive-bound-noun-portable-controls-final.log');assert not log.exists()
with log.open('xb') as stream:
 job=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
print('Portable controls exit:',job.returncode)
raise SystemExit(job.returncode)
