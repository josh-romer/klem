"""Build source-bound willingness server and SolidJS assets offline."""
import hashlib,json,os,subprocess
from pathlib import Path
prep=Path(__file__).resolve().parent
work=Path('/tmp/klem-willingness-question-prototype')
target=Path('/tmp/klem-expression-conjectural-main-target')
out=prep/'browser-prototype-build.json';assert not out.exists()
modules=Path('/home/josh/projects/klem/.direnv/dapnikka-integration/web/node_modules')
assert modules.is_dir() and (modules.parent/'package-lock.json').read_bytes()==(work/'web/package-lock.json').read_bytes()
link=work/'web/node_modules';assert not link.exists();link.symlink_to(modules,target_is_directory=True)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
files=[p for folder in ['src','web/src'] for p in (work/folder).rglob('*') if p.is_file()]
files += [work/'Cargo.toml',work/'Cargo.lock',work/'web/package.json',work/'web/package-lock.json',Path(__file__)]
frozen={str(p):sha(p) for p in files}
protected={str(p):sha(p) for p in [target/'debug/klem',target/'debug/examples/evaluate']}
r={'state':'running','frozen_inputs':frozen,'protected_prior_binaries':protected,'commands':[],'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__))}}
def save():out.write_text(json.dumps(r,indent=2)+'\n')
save()
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4')
commands=[(['cargo','build','--locked','--offline','--features','web','--bin','klem-web'],work),(['npm','run','build'],work/'web')]
try:
 for i,(command,cwd) in enumerate(commands):
  log=prep/('browser-prototype-build-'+str(i)+'.log')
  with log.open('xb') as f:job=subprocess.run(command,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
  r['commands'].append({'command':command,'exit_code':job.returncode,'log':str(log),'log_sha256':sha(log)});save();print(i,job.returncode,flush=True);assert job.returncode==0,log
 r.update(state='passed',exit_code=0,inputs_unchanged=all(sha(p)==d for p,d in frozen.items()),prior_binaries_unchanged=all(sha(p)==d for p,d in protected.items()),server={'path':str(target/'debug/klem-web'),'sha256':sha(target/'debug/klem-web')},assets={str(p.relative_to(work/'web/dist')):sha(p) for p in (work/'web/dist').rglob('*') if p.is_file()})
 assert r['inputs_unchanged'] and r['prior_binaries_unchanged']
except Exception as error:r.update(state='failed',error=str(error));raise
finally:save()
