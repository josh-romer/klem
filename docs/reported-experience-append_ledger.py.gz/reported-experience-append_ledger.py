"""Append the independently authored raw cases without changing earlier judgments."""
import json,gzip,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];PROTO=ROOT/'.direnv/reported-experience-prototype';PREP=Path(__file__).resolve().parent
path=PROTO/'tests/fixtures/validity.json';raw=path.read_bytes();before=json.loads(raw)
suite_path=PROTO/'tests/fixtures/reported-experience-validity.json';suite=json.loads(suite_path.read_bytes())
conditional=json.loads((PROTO/'tests/fixtures/reported-experience-native-conditional-cases.json').read_bytes())
assert len(before['cases'])==35250 and len(suite['cases'])==97
assert not set(before['sources'])&set(suite['sources'])
assert not {c['id'] for c in before['cases']}&{c['id'] for c in suite['cases']}
after={**before,'sources':{**before['sources'],**suite['sources']},'cases':before['cases']+suite['cases']}
counts={v:sum(j['verdict']==v for c in after['cases'] for j in c['judgments']) for v in ['required','forbidden']}
assert counts=={'required':31157,'forbidden':4206}
assert not {c['id'] for c in conditional['cases']}&{c['id'] for c in after['cases']}
path.write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n')
(PREP/'ledger-before-reported-experience.json.gz').write_bytes(gzip.compress(raw,mtime=0))
receipt={'state':'exact-raw-append-preserved','before_sha256':hashlib.sha256(raw).hexdigest(),'after_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'fixture_sha256':hashlib.sha256(suite_path.read_bytes()).hexdigest(),'before_case_count':35250,'after_case_count':35347,'new_cases':suite['cases'],'new_sources':suite['sources'],'counts':counts,'excluded_conditional_cases':conditional['cases'],'producer':{'text':Path(__file__).read_text(),'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
(PREP/'ledger-append.json.gz').write_bytes(gzip.compress((json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print('Exact35250prefix preserved;35347cases31157required4206forbidden;2conditionalexcluded;fixtureSHA',receipt['fixture_sha256'])
