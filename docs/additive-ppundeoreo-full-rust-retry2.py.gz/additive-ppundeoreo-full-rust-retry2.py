"""Run the complete isolated Rust suite on the restored baseline and finite new source scope."""
import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
ROOT=Path('/tmp/klem-additive-ppundeoreo-prototype')
OUT=Path('/tmp/klem-additive-ppundeoreo-full-rust-retry2.json');LOG=OUT.with_suffix('.log')
assert not OUT.exists() and not LOG.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
baseline=json.loads(Path('/home/josh/projects/klem/docs/literary-question-geona-package-nix.json').read_bytes())['snapshot']['files']
names=set(baseline)
names.update(str(p.relative_to(ROOT)) for p in (ROOT/'tests').rglob('*') if p.is_file())
snapshot={n:{'sha256':sha((ROOT/n).read_bytes()),'bytes':(ROOT/n).stat().st_size} for n in sorted(names)}
assert len(snapshot)==964,len(snapshot)
command=['cargo','test','--offline','--all-targets','--features','web','--target-dir','/tmp/klem-additive-ppundeoreo-prototype-target-no-debug']
producer=Path(__file__);report={'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'command':command,'cwd':str(ROOT),'snapshot_files':snapshot,'environment':{'CARGO_BUILD_JOBS':'4','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_INCREMENTAL':'0'},
    'producer':{'text':producer.read_text(),'sha256':sha(producer.read_bytes())},
    'scope':'Storage-adjusted retry of complete isolated Rust suite: all957previous compile/frontend inputs plus7new fixture/test files. All prior tests and33new append-only raw cases run without modifying Root or its active Nix gate. Initial ENOSPC compilation failure and the subsequent ledger namespace-collision test failure remain retained. New global case IDs are namespaced to the ending family; linguistic shapes, judgments and all previous cases are unchanged. Debug symbols and incremental caching are disabled; assertions and the exact964 test/source inputs are unchanged. Downloaded-corpus ignored test, browser, Clippy, source/broad/Native controls and main/package/context review remain separate.'}
def save():OUT.write_text(json.dumps(report,indent=2)+'\n')
save();env=dict(os.environ,CARGO_BUILD_JOBS='4',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_INCREMENTAL='0')
with LOG.open('xb') as stream:job=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
raw=LOG.read_bytes();rows=re.findall(rb'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw,re.MULTILINE)
counts={k:sum(int(row[i]) for row in rows) for i,k in enumerate(['passed','failed','ignored'])};counts['batches']=len(rows)
report.update(state='passed' if job.returncode==0 else 'failed',exit_code=job.returncode,tests=counts,
    inputs_unchanged=all(sha((ROOT/n).read_bytes())==v['sha256'] for n,v in snapshot.items()),log_sha256=sha(raw),
    finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
print('Full isolated Rust:',report['state'],counts,'unchanged964inputs:',report['inputs_unchanged'],flush=True)
assert report['inputs_unchanged']
raise SystemExit(job.returncode)
