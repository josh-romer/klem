"""Replay all saved word cohorts; retain each new path and its original witnesses."""
import gzip
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/josh/projects/klem')
INTEGRATION = ROOT / '.direnv/dapnikka-integration'
SOURCE = ROOT / '.direnv/formal-b-prepared/formal-b-cohorts.json.gz'
CORPORA = ROOT / 'docs/literary-question-geona-prototype-corpora.json.gz'
HISTORY = ROOT / 'docs/literary-question-geona-prototype-legacy-history.json.gz'
BEFORE = ROOT / '.direnv/formal-b-target/debug/klem'
AFTER = ROOT / '.direnv/reported-experience-target/debug/klem'
DB = ROOT / 'data/dictionaries/krdict/krdict.db'
OUT = ROOT / '.direnv/reported-experience-prepared/cohorts.json.gz'
assert not OUT.exists()
sys.path.insert(0, str(INTEGRATION / 'tools'))
from doeda_native_corpora import contexts_text, words_from_cli

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)

def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()

def enriched(binary, surface):
    command = [str(binary), 'word', surface, '--dictionary', str(DB)]
    job = subprocess.run(command, capture_output=True, check=True)
    assert not job.stderr
    return json.loads(job.stdout)

frozen = {str(p): sha(p) for p in [SOURCE, CORPORA, HISTORY, BEFORE, AFTER, DB, Path(__file__), INTEGRATION / 'tools/doeda_native_corpora.py']}
report = read(SOURCE)
runs = []
observations = []
native_entries = {}
changed_surfaces = set()
for cohort in report['runs']:
    expected = cohort['captures'][1]['words']
    captures = []
    for binary in [BEFORE, AFTER]:
        words = words_from_cli(binary, sorted(expected))
        if binary == BEFORE:
            assert words == expected, 'actual prior binary must reproduce complete saved cohort'
        captures.append({'binary': str(binary), 'words': words, 'word_sha256': digest(words)})
    old, new = [capture['words'] for capture in captures]
    assert old.keys() == new.keys()
    changes = {}
    for surface, previous in old.items():
        current = new[surface]
        assert {k: v for k, v in previous.items() if k != 'analyses'} == {k: v for k, v in current.items() if k != 'analyses'}
        assert [p for p in current['analyses'] if p in previous['analyses']] == previous['analyses'], (surface, 'old candidate lost/reordered')
        additions = [p for p in current['analyses'] if p not in previous['analyses']]
        if not additions:
            assert current == previous
            continue
        changed_surfaces.add(surface)
        before_dict, after_dict = enriched(BEFORE, surface), enriched(AFTER, surface)
        assert {k: v for k, v in before_dict.items() if k != 'dictionary'} == previous
        assert {k: v for k, v in after_dict.items() if k != 'dictionary'} == current
        bd, ad = before_dict['dictionary'], after_dict['dictionary']
        assert {k: v for k, v in bd.items() if k not in ['lemmas', 'readings']} == {k: v for k, v in ad.items() if k not in ['lemmas', 'readings']}
        assert all(owner in ad['lemmas'] for owner in bd['lemmas'])
        for i, path in enumerate(previous['analyses']):
            assert bd['readings'][i] == ad['readings'][current['analyses'].index(path)]
        changes[surface] = {'before': previous, 'after': current, 'before_dictionary': bd, 'after_dictionary': ad}
        for path in additions:
            assert 'ending.reported_experience' in path['rules'], (surface, path)
            index = current['analyses'].index(path)
            owners = [next(m for m in ad['lemmas'] if m['lemma'] == lemma) for lemma in path['lemmas']]
            for owner in owners:
                for entry in owner['entries']:
                    if entry['id'] not in native_entries:
                        job = subprocess.run([str(AFTER), 'dict', 'entry', str(DB), entry['id']], capture_output=True, check=True)
                        assert not job.stderr
                        native_entries[entry['id']] = json.loads(job.stdout)['entry']
            observations.append({'id': 'reported-experience-' + cohort['family'] + '-' + digest([surface, path])[:24], 'family': cohort['family'], 'surface': surface, 'analysis': path, 'dictionary_assessment': ad['readings'][index], 'dictionary_owners': owners, 'contextual_verdict': 'unjudged', 'independent_review': 'pending'})
    runs.append({'family': cohort['family'], 'surfaces': len(expected), 'captures': captures, 'changed_words': changes})
    print(cohort['family'], len(expected), 'complete words;', len(changes), 'changed; old paths, fields and dictionary assessments preserved', flush=True)

occurrences = {surface: [] for surface in changed_surfaces}
corpora = read(CORPORA)
for partition in corpora['corpora']:
    text = partition['original_source_text']
    assert hashlib.sha256(text.encode()).hexdigest() == partition['source_sha256']
    contexts = contexts_text(text)
    for row in partition['original_converted_rows']:
        if row['surface'] in occurrences:
            occurrences[row['surface']].append({'kind': 'corpus', 'corpus': partition['corpus'], 'partition': partition['partition'], 'source': partition['source'], 'source_sha256': partition['source_sha256'], 'original_gold_row': row, **contexts[row['id']]})
historical = {surface: [] for surface in changed_surfaces}
history = read(HISTORY)
for surface in changed_surfaces:
    for origin in history['origins'].get(surface, []):
        path = ROOT / origin['source']
        assert sha(path) == origin['source_sha256']
        frozen[str(path)] = sha(path)
        original = read(path)
        witness = original
        for key in origin['pointer'].split('/')[1:]:
            witness = witness[int(key)] if isinstance(witness, list) else witness[key]
        historical[surface].append({**origin, 'complete_original_record': witness})
for observation in observations:
    witnesses = occurrences[observation['surface']] if observation['family'] == 'corpus' else historical[observation['surface']]
    assert witnesses, (observation['family'], observation['surface'], 'missing original witnesses')
    observation['original_occurrences'] = witnesses
assert len(observations) == len({o['id'] for o in observations})
assert [(r['family'], r['surfaces']) for r in runs] == [('corpus', 32096), ('history', 21406)]
assert all(sha(p) == digest_ for p, digest_ in frozen.items())
result = {'state': 'complete-corpus-history-preservation-passed', 'runs': runs, 'individual_additions': observations, 'complete_native_entries': native_entries, 'frozen_inputs': frozen, 'inputs_unchanged': True, 'producer': {'text': Path(__file__).read_text(), 'sha256': sha(__file__)}, 'scope': 'Every saved corpus/history surface replayed against actual before/after binaries; earlier ordered candidates and dictionary assessments retained. Each added dapnikka path has a stable identity, original complete corpus/ledger witnesses and complete Native owners. Prototype execution only; integrated package binding, contextual and independent review remain pending.', 'full_coverage_complete': False}
OUT.write_bytes(gzip.compress((json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
print('Passed', sum(r['surfaces'] for r in runs), 'surfaces;', len(observations), 'individual additions;', len(native_entries), 'complete Native owners', flush=True)
