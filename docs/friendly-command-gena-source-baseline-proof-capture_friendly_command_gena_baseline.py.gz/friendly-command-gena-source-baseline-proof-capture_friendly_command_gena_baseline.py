"""Capture complete pre-implementation -게나 output against immutable installed CLI."""
import datetime,gzip,hashlib,itertools,json,subprocess,unicodedata
from pathlib import Path
PREP=Path(__file__).resolve().parent
CLI=Path('/nix/store/nwg63yj2522dpi0dhgw7rrp286z82bbi-klem-0.1.0/bin/klem')
DB=Path('/home/josh/projects/klem/.direnv/dictionary-restoration/krdict.db')
OUT=PREP/'friendly-command-gena-baseline.json'
CAP=PREP/'friendly-command-gena-baseline-records.json.gz'
LOG=PREP/'friendly-command-gena-baseline.log'
assert not OUT.exists() and not CAP.exists() and not LOG.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
author_path=PREP/'friendly-command-gena-source-authoring.json'
suite_path=PREP/'friendly-command-gena-validity.json'
closure_path=PREP/'friendly-command-gena-original-native-closure.json.gz'
author=json.loads(author_path.read_bytes());suite=json.loads(suite_path.read_bytes());closure=json.loads(gzip.decompress(closure_path.read_bytes()))
assert author['candidate_runtime_observed'] is False
assert sha(suite_path.read_bytes())==author['suite_sha256'] and sha(closure_path.read_bytes())==author['native_closure_sha256']
assert sha(DB.read_bytes())=='23d993696c55d0e54660e4a2b23dac7d68525fecb1fdc44341e1f2b3f75dead5'
frozen={str(p):sha(p.read_bytes()) for p in [CLI,DB,author_path,suite_path,closure_path]}
families={
 'complete-original-groups':'\n\n'.join('\n'.join(i['complete_original_group']) for i in author['items'])+'\n',
 'preauthored-24-proposals':'\n'.join(c['surface'] for c in suite['cases'])+'\n',
 'unjudged-lexical-prefinal-boundaries':'\n'.join(['예쁘게나','예쁘시게나','학생이시게나','학생답시게나','먹었게나','먹겠게나'])+'\n',
}
def typed_match(a,j):
 return [l['text'] for l in a['lemmas']]==j['lemmas'] and [l['kind'] for l in a['lemmas']]==j['lemma_kinds'] and [m['form'] for m in a['morphemes']]==j['morphemes'] and [m['kind'] for m in a['morphemes']]==j['morpheme_kinds']
record=dict(state='running',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),frozen_inputs=frozen,source_authoring_sha256=sha(author_path.read_bytes()),producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),scope='Complete actual installed pre-implementation baseline after independent finite target authoring. A prior single-word 앉게나 probe occurred after authoring in this turn; this is the first complete capture. Presence checked by canonical typed lemma/morpheme paths, independently of future new rule ID. All other analyses/order, own Native homonyms, filter readings and original UTF-8/NFD spans retained. Not a contextual/register or gold annotation.')
OUT.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
captures=[];native={}
with LOG.open('x') as log:
 for name,norm,mode,cache in itertools.product(families,['NFC','NFD'],['all','headwords','compatible'],[0,4096]):
  text=unicodedata.normalize(norm,families[name]);command=[str(CLI),'text','-','--dictionary',str(DB),'--cache-bytes',str(cache)]
  if mode=='headwords':command+=['--dict-only']
  if mode=='compatible':command+=['--dict-compatible']
  run=subprocess.run(command,input=text.encode(),capture_output=True);assert run.returncode==0,(command,run.stderr.decode())
  frames=[json.loads(line) for line in run.stdout.splitlines()];cursor=0
  for frame in frames:
   span=frame['span'];assert span['start']==cursor and text.encode()[span['start']:span['end']].decode()==frame['surface'];cursor=span['end']
  assert cursor==len(text.encode())
  observed=[]
  for case in suite['cases']:
   j=case['judgments'][0];matches=[f for f in frames if unicodedata.normalize('NFC',f['surface'])==case['surface']]
   for frame in matches:
    analyses=frame['analysis']['analyses']
    observed.append(dict(case_id=case['id'],span=frame['span'],verdict=j['verdict'],typed_path_present=any(typed_match(a,j) for a in analyses),future_rule_path_present=any(typed_match(a,j) and all(r in a['rules'] for r in j['required_rules']) for a in analyses)))
  captures.append(dict(family=name,normalization=norm,mode=mode,cache_bytes=cache,input=text,command=command,exit_code=run.returncode,stdout=run.stdout.decode(),stderr=run.stderr.decode(),frames=frames,observations=observed))
  log.write(json.dumps(dict(family=name,normalization=norm,mode=mode,cache_bytes=cache,frames=len(frames),typed_paths=sum(o['typed_path_present'] for o in observed)),ensure_ascii=False)+'\n');log.flush()
  print('Captured',name,norm,mode,cache,flush=True)
 for ident,expected in sorted(closure['complete_native_entries'].items()):
  command=[str(CLI),'dict','entry',str(DB),ident];run=subprocess.run(command,capture_output=True);assert run.returncode==0
  value=json.loads(run.stdout);assert value['entry']==expected,ident
  native[ident]=dict(command=command,stdout=run.stdout.decode(),stderr=run.stderr.decode(),exit_code=run.returncode,response=value)
# Cache policies must yield identical complete output, including assessments and spans.
for a in captures:
 b=next(x for x in captures if all(a[k]==x[k] for k in ['family','normalization','mode']) and x['cache_bytes']!=a['cache_bytes']);assert a['stdout']==b['stdout']
assert all(sha(Path(p).read_bytes())==v for p,v in frozen.items())
packed=gzip.compress((json.dumps(dict(captures=captures,native_entries=native),ensure_ascii=False)+'\n').encode(),mtime=0);CAP.write_bytes(packed)
record.update(state='passed',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),capture_path=CAP.name,capture_sha256=sha(packed),log_sha256=sha(LOG.read_bytes()),runs=len(captures),complete_native_owners=len(native),inputs_unchanged=True,frame_count=sum(len(c['frames']) for c in captures),preauthored_cases=len(suite['cases']),typed_path_matches=sum(o['typed_path_present'] for c in captures for o in c['observations']),future_rule_path_matches=sum(o['future_rule_path_present'] for c in captures for o in c['observations']),production_changed=False,shared_judgments_reviews_changed=False)
OUT.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print('Complete baseline passed:',record['runs'],'runs;',len(native),'full Native owners;',record['typed_path_matches'],'canonical typed matches',flush=True)
