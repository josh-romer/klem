"""Author source readings before implementation, independently of emitted candidates."""
import gzip,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
prepared=json.loads(gzip.decompress((OUT/'source-preparation.json.gz').read_bytes()))
# Each tuple is read from the full original example group; never selected from engine output.
readings={
(86336,'1'):[('참으랍디까',['참다'],['으랍디까']),('있으랍디까',['있다'],['으랍디까']),('먹으랍디까',['먹다'],['으랍디까'])],
(86337,'1'):[('뭐랍디까',['뭐','이다'],['랍디까']),('언제랍디까',['언제','이다'],['랍디까']),('둘이랍디까',['둘','이다'],['랍디까']),('여자랍디까',['여자','이다'],['랍디까'])],
(86337,'2'):[('별거랍디까',['별거','이다'],['랍디까']),('날벼락이랍디까',['날벼락','이다'],['랍디까']),('상관이랍디까',['상관','이다'],['랍디까']),('인간이랍디까',['인간','이다'],['랍디까'])],
(86337,'3'):[('어떡하랍디까',['어떡하다'],['으랍디까']),('말랍디까',['말다'],['으랍디까']),('버리랍디까',['버리다'],['으랍디까']),('오랍디까',['오다'],['으랍디까'])],
(86338,'1'):[('놓으랍디다',['놓다'],['으랍디다']),('앉으랍디다',['앉다'],['으랍디다']),('있으랍디다',['있다'],['으랍디다']),('먹으랍디다',['먹다'],['으랍디다'])],
(86339,'2'):[('양식이랍디다',['양식','이다'],['랍디다']),('내일까지랍디다',['내일','이다'],['까지','랍디다']),('입춘이랍디다',['입춘','이다'],['랍디다']),('아니랍디다',['아니다'],['랍디다'])],
(86339,'1'):[('포기하랍디다',['포기하다'],['으랍디다']),('오랍디다',['오다'],['으랍디다']),('드시랍디다',['들다'],['시','으랍디다']),('가랍디다',['가다'],['으랍디다'])],
(86674,'1'):[('괜찮았답디다',['괜찮다'],['었','답디다']),('없답디다',['없다'],['답디다']),('튼튼하답디다',['튼튼하다'],['답디다']),('바쁘답디다',['바쁘다'],['답디다'])],
(86678,'1'):[('있답디까',['있다'],['답디까']),('않답디까',['않다'],['답디까']),('행복하답디까',['행복하다'],['답디까']),('필요하답디까',['필요하다'],['답디까'])],
(86680,'1'):[('지낸답디까',['지내다'],['는답디까']),('산답디까',['살다'],['는답디까']),('꾼답디까',['꾸다'],['는답디까']),('온답디까',['오다'],['는답디까'])],
(86683,'1'):[('산답디다',['살다'],['는답디다']),('준답디다',['주다'],['는답디다']),('한답디다',['하다'],['는답디다']),('온답디다',['오다'],['는답디다'])],
(86687,'1'):[('받는답디까',['받다'],['는답디까']),('읽는답디까',['읽다'],['는답디까']),('했답디까',['하다'],['었','답디까']),('먹는답디까',['먹다'],['는답디까'])],
(86692,'1'):[('먹는답디다',['먹다'],['는답디다']),('입는답디다',['입다'],['는답디다']),('찾는답디다',['찾다'],['는답디다']),('잡는답디다',['잡다'],['는답디다'])],
}
cli=ROOT/'.direnv/formal-b-target/debug/klem';db=(ROOT/'data/dictionaries/krdict/krdict.db').resolve()
frozen={str(p):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in [cli,db,Path(__file__),OUT/'source-preparation.json.gz']}
proposals=[]
for group in prepared['complete_groups']:
 key=(int(group['entry_id'].split(':')[1]),group['sense_id'])
 surface,lemmas,morphs=readings[key][group['group']-1]
 block='\n'.join(group['complete_original_examples']);offset=block.encode().find(surface.encode());assert offset>=0
 records={}
 for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
  v=json.loads(subprocess.check_output([str(cli),'word',surface,'--dictionary',str(db),*flags],text=True))
  records[mode]={'analysis':{k:v[k] for k in ['normalized','analyses']},'dictionary':v['dictionary']}
 proposals.append({'id':group['id']+'-'+str(offset),'source_group_id':group['id'],'entry_id':group['entry_id'],'sense_id':group['sense_id'],'surface':surface,'proposed_lemmas':lemmas,'proposed_morphemes':morphs,'complete_original_group':group['complete_original_examples'],'baseline_records':records,'review_status':'Agent-authored structural reading; contextual and independent Korean review pending.','source_tension':'Original -는답디까 group contains a plain past 했답디까 form; preserve this classification and read the surface as 하다+었+답디까, supported separately by the plain-report past license.' if surface=='했답디까' else None})
assert len(proposals)==51 and len({p['id'] for p in proposals})==51
assert {p['source_group_id'] for p in proposals}=={g['id'] for g in prepared['complete_groups']}
assert all(hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()==digest for p,digest in frozen.items())
value={'state':'authored-proposals-and-exact-baseline-preserved','proposals':proposals,'frozen_inputs':frozen,'inputs_unchanged':True,'producer':{'text':Path(__file__).read_text(),'sha256':frozen[str(Path(__file__))]},'scope':'All 51 complete original groups have independent authored structural targets and exact pre-implementation raw/headword/compatible records. No positive candidate certification or implementation inferred from those records.'}
(OUT/'proposals.json.gz').write_bytes(gzip.compress((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
proto=ROOT/'.direnv/reported-experience-prototype'
(proto/'tests/fixtures/reported-experience-proposals.json').write_text(json.dumps(proposals,ensure_ascii=False,indent=2)+'\n')
print('Authored',len(proposals),'complete source targets with exact three-mode baseline records',flush=True)
