"""Retain complete modifier homonyms and explicit finite profile/correction scope."""
import copy,gzip,hashlib,json,sqlite3,sys
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');sys.path.insert(0,str(ROOT/'tools'))
from native_lmf import array,entry,feature,verify_native_lmf
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
closure_path=Path('/tmp/klem-bound-noun-spacing-native-closure.json.gz');closure=json.load(gzip.open(closure_path,'rt'));fixture_path=Path('/tmp/klem-bound-noun-spacing-prototype/tests/fixtures/bound-noun-spacing-cases.json');fixture=json.loads(fixture_path.read_bytes())
db=ROOT/'data/dictionaries/krdict/krdict.db';con=sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True)
heads=['-던','-ㄴ','-은','-는','-ㄹ','-을','-기'];native={}
for head in heads:
 for ident,raw in con.execute('select id,data from entries where headword=?',(head,)):native[ident]=json.loads(raw)
original={};exports={};ids={i.split(':')[1] for i in native}
for p in sorted((ROOT/'data/dictionaries/krdict/json').glob('*.json')):
 exports[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
 for value in array(json.loads(p.read_bytes())['LexicalResource']['Lexicon'].get('LexicalEntry')):
  if value.get('val') not in ids:continue
  projected=entry(value);ident=projected['id'];assert projected==native[ident] and ident not in original;original[ident]=value
assert set(original)==set(native)
projection=copy.deepcopy(list(original.values()))
for value in projection:
 for sense in array(value.get('Sense')):sense['Equivalent']=[v for v in array(sense.get('Equivalent')) if feature(v,'language')=='영어']
lmf={'LexicalResource':{'Lexicon':{'LexicalEntry':projection}}};verify_native_lmf(lmf,native)
profiles=[('것','62835',['은','는','을','던']),('수','15615',['은','는','을']),('줄','91870',['은','는','을']),('바','56324',['은','는','을']),('적','71232',['은','을']),('지','91881',['은']),('듯','49981',['은','는','을']),('뿐','66641',['을']),('대로','48415',['은','는','을']),('만큼','53008',['은','는','을']),('때문','64555',['기']),('따름','49675',['을'])]
rows=[]
for head,n,forms in profiles:
 ident='krdict:'+n;e=closure['complete_native_entries'][ident];assert e['headword']==head and e['pos']=='의존 명사'
 rows.append({'headword':head,'id':ident,'canonical_modifier_forms':forms,'complete_native_entry':e,'original_lmf':closure['original_lmf'][ident],'evidence_class':'Finite implementer structural inference from complete noun senses/attachment notes/examples plus the independently sourced modifier or nominalizer class. Required case combinations are authored tests, not verbatim dictionary examples or contextual gold.','excluded_scope':'Unlisted modifier classes and noun identities are outside this template. Notes saying usually are not universal bans; noun senses and contextual acceptability are unjudged.'})
runtime=json.load(gzip.open('/tmp/klem-bound-noun-spacing-runtime.json.gz','rt'));run=next(r for r in runtime['runs'] if r['encoding']=='NFC' and r['mode']=='compatible' and r['cache_bytes']==4096);target=next(r for r in run['after'] if (r.get('analysis') or {}).get('normalized')==fixture['original_proposal']['surface'])
report={'schema_version':1,'state':'finite-structural-source-review-retained','profiles':rows,'modifier_heads':heads,'complete_modifier_native_entries':native,'original_modifier_lmf':original,'english_modifier_projection':lmf,'source_exports':exports,'dictionary_sha256':sha(db),'bound_noun_closure_sha256':sha(closure_path),'fixture_sha256':sha(fixture_path),'original_proposal':fixture['original_proposal'],'correction':{'original_status':'Unmet original two-word target is retained unchanged; no Compatible reading of 준것은. This is a recorded proposal correction, not a new global forbidden judgment.','proper_targets':['먹어준 것은','먹어 준 것은'],'actual_compatible_record':target,'source_ids':['krdict:62835','krdict:77245'],'spacing_rule_reference':{'url':'https://www.korean.go.kr/kornorms/m/m_regltn.do','article':42,'short_title':'의존 명사는 띄어 쓴다.','retrieval':'Primary search result available; direct web open returned403. No complete norm-text capture is claimed.'},'status':'Separately source-supported and finite-runtime verified; original proposal remains explicit, contextual sense and independent language review pending.'},'producer':{'text':Path(__file__).read_text(),'sha256':sha(__file__)},'scope':'Twelve bounded source profiles and complete same-head modifier/suffix homonyms. All examples/turns/Korean fields remain intact. Final-question 던 and suffix 기 homonyms are retained separately from the adnominal86038/nominalizer72222 sources; raw engine analyses do not select a source sense. No global source/corpus gold promotion or independent review claim.'}
out=Path('/tmp/klem-bound-noun-spacing-source-review.json.gz');assert not out.exists();out.write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Retained12 source profiles,',len(native),'complete modifier/suffix homonyms and the explicit original/corrected proposal distinction.')
