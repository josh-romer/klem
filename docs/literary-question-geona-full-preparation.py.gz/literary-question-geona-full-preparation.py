import copy,gzip,hashlib,json,tarfile
from pathlib import Path
ROOT=Path('/home/josh/projects/klem'); PROTO=Path('/tmp/klem-literary-question-geona-prototype'); OUT=Path('/tmp/klem-literary-question-geona-full-preparation.json')
assert not OUT.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
checkpoint=json.loads(gzip.decompress(Path('/tmp/klem-literary-question-geona-expanded-prototype-checkpoint.json.gz').read_bytes()))
parent=json.loads(Path('/tmp/klem-literary-question-geona-build-preparation.json').read_text())['parent_snapshot_files']
for name,expected in parent.items(): assert sha((ROOT/name).read_bytes())==expected['sha256'],name
for name,expected in checkpoint['snapshot_files'].items(): assert sha((PROTO/name).read_bytes())==expected['sha256'],name
saved=Path('/tmp/klem-literary-question-geona-expanded-inputs.tar.gz');assert not saved.exists()
with tarfile.open(saved,'w:gz') as archive:
 for name in sorted(checkpoint['snapshot_files']):archive.add(PROTO/name,arcname=name)
restored=[]
for name,expected in parent.items():
 target=PROTO/name
 if target.exists():continue
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/name).read_bytes());assert sha(target.read_bytes())==expected['sha256'];restored.append(name)
changes={}
p=PROTO/'src/grammar.rs';before=p.read_bytes(); text=before.decode();old='Recover source-listed literary -(으)ㄹ거나 self/opinion questions';new='Recover source-listed informal -(으)ㄹ거나 self/opinion questions';assert text.count(old)==1;p.write_text(text.replace(old,new));changes[str(p.relative_to(PROTO))]={'before_sha256':sha(before),'after_sha256':sha(p.read_bytes())}
p=PROTO/'web/src/grammar-labels.json';before=p.read_bytes();text=before.decode();assert text.count('Literary self/opinion question')==1;p.write_text(text.replace('Literary self/opinion question','Self / opinion question'));changes[str(p.relative_to(PROTO))]={'before_sha256':sha(before),'after_sha256':sha(p.read_bytes())}
complete=json.loads(gzip.decompress(Path('/tmp/klem-literary-question-geona-complete-owner-preparation.json.gz').read_bytes()))
projection=copy.deepcopy(complete['english_projection']);entries=projection['LexicalResource']['Lexicon']['LexicalEntry'];projection['LexicalResource']['Lexicon']['LexicalEntry']=[entry for entry in entries if str(entry['val']) in {'80970','80972'}];assert len(projection['LexicalResource']['Lexicon']['LexicalEntry'])==2
p=PROTO/'tests/fixtures/krdict-literary-question-geona-labels.json';assert not p.exists();p.write_text(json.dumps(projection,ensure_ascii=False,indent=2)+'\n')
p=PROTO/'src/bin/klem-web/grammar_labels.rs';before=p.read_bytes();text=before.decode();old='                PathBuf::from("tests/fixtures/krdict-literary-future-kko-labels.json"),';assert text.count(old)==1;p.write_text(text.replace(old,old+'\n                PathBuf::from("tests/fixtures/krdict-literary-question-geona-labels.json"),'));changes[str(p.relative_to(PROTO))]={'before_sha256':sha(before),'after_sha256':sha(p.read_bytes())}
for name,expected in parent.items():assert sha((ROOT/name).read_bytes())==expected['sha256'],name
snapshot={str(p.relative_to(PROTO)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in PROTO.rglob('*') if p.is_file()}
OUT.write_text(json.dumps({'state':'prepared','parent_inputs_unchanged':True,'parent_snapshot_files':parent,'preserved_prior_inputs':{'path':str(saved),'sha256':sha(saved.read_bytes())},'restored_files':restored,'changes':changes,'snapshot_files':snapshot,'source_entry_ids':[80970,80972],'scope':'Restore every parent regression input; correct unsupported literary register wording; add exact complete original English LMF grammar label source fixture. Prior source/broad/corpus/history captures remain bound to the preserved earlier binary and bytes.'},ensure_ascii=False,indent=2)+'\n')
print('Restored',len(restored),'parent inputs; prepared',len(snapshot),'prototype inputs. Root947 input hashes unchanged.')
