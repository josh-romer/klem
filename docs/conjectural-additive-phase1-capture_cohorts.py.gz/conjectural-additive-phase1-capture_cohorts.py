"""Compare every frozen annotated/history word, retaining individual changes."""
import gzip
import hashlib
import json
import subprocess
import sys
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = PREP.parents[1]
SOURCE = ROOT / '.direnv/formal-volitional-expression-integration/docs/formal-volitional-cohorts.json.gz'
OUT = PREP / 'cohorts.json.gz'
AFTER = Path('/tmp/klem-conjectural-additive-target/debug/klem')
REFERENCE = ROOT / '.direnv/formal-volitional-expression-prepared/installed-source-binding.json'
assert not OUT.exists()
sys.path.insert(0, str(ROOT / 'tools'))
from doeda_native_corpora import words_from_cli

sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
binding = json.loads(REFERENCE.read_bytes())
assert binding['state'] == 'passed'
BEFORE = Path(next(p for p in binding['outputs'] if p.endswith('-klem-0.1.0'))) / 'bin/klem'
frozen = {str(p): sha(p) for p in [SOURCE, REFERENCE, BEFORE, AFTER, Path(__file__), ROOT / 'tools/doeda_native_corpora.py']}
runs = []
individual = []
for cohort in json.loads(gzip.decompress(SOURCE.read_bytes()))['runs']:
    expected = cohort['captures'][1]['words']
    assert words_from_cli(BEFORE, sorted(expected)) == expected
    words = words_from_cli(AFTER, sorted(expected))
    assert set(words) == set(expected)
    changed = []
    for surface, old in expected.items():
        new = words[surface]
        assert old['normalized'] == new['normalized']
        assert all(path in new['analyses'] for path in old['analyses']), ('lost original path', surface)
        additions = [path for path in new['analyses'] if path not in old['analyses']]
        assert all('ending.conjectural_additive' in path['rules'] for path in additions), ('unrelated addition', surface)
        if old != new:
            changed.append(surface)
            individual.append({'id': f"conjectural-additive-cohort-{cohort['family']}-{len(changed)}",
                               'family': cohort['family'], 'surface': surface,
                               'before': old, 'after': new, 'new_paths': additions,
                               'contextual_verdict': 'unjudged'})
    runs.append({'family': cohort['family'], 'surfaces': len(expected),
                 'captures': [{'binary': str(BEFORE), 'words': expected}, {'binary': str(AFTER), 'words': words}],
                 'changed_words': changed})
    print(cohort['family'], len(expected), 'complete words;', len(changed), 'changed surfaces', flush=True)
assert sum(run['surfaces'] for run in runs) == 53502
assert all(sha(p) == digest for p, digest in frozen.items())
report = {'state': 'complete-corpus-history-cohorts-passed', 'runs': runs,
          'individual_changed_words': individual, 'frozen_inputs': frozen, 'inputs_unchanged': True,
          'producer': {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))},
          'scope': 'Every original53502corpus/history word compared against the actual bound parent Nix CLI and isolated new-rule CLI. Original source words and every old candidate are retained. All changes carry individual IDs/full before/after/new paths and remain contextually unjudged. Full annotated rows, broader Native/spacing streams, novel-context review, installed/newNix/main/performance remain separate.'}
OUT.write_bytes(gzip.compress((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
