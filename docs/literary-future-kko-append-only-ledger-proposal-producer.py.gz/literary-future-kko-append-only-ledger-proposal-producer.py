"""Author exact finite ledger paths; leave Native-only and conditional policies separate."""
import collections,gzip,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');PROTO=Path('/tmp/klem-literary-future-kko-prototype');OUT=Path('/tmp/klem-literary-future-kko-append-only-ledger-proposal.json.gz');assert not OUT.exists()
read=lambda p:json.loads(gzip.decompress(Path(p).read_bytes()) if str(p).endswith('.gz') else Path(p).read_bytes())
sha=lambda raw:hashlib.sha256(raw).hexdigest()
before=(ROOT/'tests/fixtures/validity.json').read_bytes();ledger=json.loads(before)
assert len(ledger['cases'])==34843
original=read(ROOT/'docs/literary-future-kko-original-preparation.json.gz')['original_cases']
boundaries=read(PROTO/'tests/fixtures/literary-future-kko-authored-boundaries.json')['cases']
extension=read(ROOT/'docs/literary-future-kko-owner-extension-preflight.json.gz')
conditional={'literary-future-kko-authored-omitted-copula','literary-future-kko-authored-modal-unknown','literary-future-kko-authored-retrospective-unknown'}
sources={'literary-future-kko-'+i:'https://krdict.korean.go.kr/kor/dicSearch/SearchView?ParaWordNo='+i for i in ['81026','81032']}
added=[];excluded=[]
def add(ident,word,expected,verdict,source,reason):
 added.append({'id':ident,'surface':word,'judgments':[{'id':'exact-finite-path','source':source,'verdict':verdict,**{k:expected[k] for k in ['lemmas','lemma_kinds','morphemes','morpheme_kinds','required_rules']},'reason':reason}]})
for c in original:
 add(c['id'],c['surface'],c['expected'],'required','literary-future-kko-'+c['source_occurrence']['source'].split(':')[1],'Complete original source occurrence; exact normalized structural hypothesis, without contextual sense/register or independent Korean certification.')
for c in boundaries:
 if c['id'] in conditional or c['proposal']=='dictionary-policy-only':excluded.append({'id':c['id'],'reason':'Conditional Unknown or Native spelling policy, not a raw required/forbidden source judgment.'});continue
 add(c['id'],c['surface'],c,'required' if c['proposal']=='required' else 'forbidden','literary-future-kko-81026','Authored finite allomorph, established spelling, own honorific/past marker or auxiliary/copula structure. The exact roles and ordered morphemes define this hypothesis; contextual sense and precision remain unreviewed.')
for c in extension['cases']:
 if 'unknown' in c['id']:excluded.append({'id':c['id'],'reason':'Unlisted own modal marker remains a conditional Unknown hypothesis.'});continue
 kind='nominal' if c['id'].split('extension-')[1].startswith('derived-') else 'predicate'
 kinds=[kind]+['auxiliary']*(len(c['lemmas'])-1)
 if c['id'].endswith('aux-result'):kinds[-1]='predicate'
 expected={**c,'lemma_kinds':kinds,'morpheme_kinds':['suffix' if m in ['답다','하다'] else 'prefinal' if m in ['시','었','겠'] else 'ending' for m in c['morphemes']],'required_rules':['ending.literary_future_question_kko']}
 add(c['id'],c['surface'],expected,'required' if c['proposal']=='required' else 'forbidden','literary-future-kko-81032','Authored finite derivation spelling or immediate auxiliary/lexical owner. 답다 retains its fixed ㅂ class, and later auxiliaries own their markers. The lexical 되다 hypothesis is distinct from the auxiliary-role hypothesis. Context and independent review remain unjudged.')
assert len(added)==77 and len({c['id'] for c in added})==77
assert not {c['id'] for c in added}&{c['id'] for c in ledger['cases']}
counts=collections.Counter(j['verdict'] for c in added for j in c['judgments']);assert counts=={'required':66,'forbidden':11}
text=' '.join(dict.fromkeys(c['surface'] for c in added))
command=['/tmp/klem-literary-future-kko-catalog-cli','text','-']
p=subprocess.run(command,input=text.encode(),capture_output=True,check=True)
rows={r['analysis']['normalized']:r for r in map(json.loads,p.stdout.splitlines()) if r.get('analysis')}
observations=[]
for c in added:
 j=c['judgments'][0];matches=[a for a in rows[c['surface']]['analysis']['analyses'] if [l['text'] for l in a['lemmas']]==j['lemmas'] and [l['kind'] for l in a['lemmas']]==j['lemma_kinds'] and [m['form'] for m in a['morphemes']]==j['morphemes'] and [m['kind'] for m in a['morphemes']]==j['morpheme_kinds'] and set(j['required_rules'])<=set(a['rules'])]
 assert bool(matches)==(j['verdict']=='required'),c['id']
 observations.append({'id':c['id'],'verdict':j['verdict'],'matches':matches})
suite={'schema_version':ledger['schema_version'],'review_status':'Finite structural hypotheses from complete original ending entries and authored allomorph/owner derivations. Not contextual gold or independent review. Conditional Unknown and Native spelling policies remain outside this raw ledger.','sources':sources,'cases':added}
r={'schema_version':1,'preparation_only':True,'state':'actual-candidate-proposal-passed','before_case_count':len(ledger['cases']),'after_case_count':len(ledger['cases'])+len(added),'before_sha256':sha(before),'before_text':before.decode(),'added_cases':added,'added_sources':sources,'finite_suite':suite,'raw_verdict_counts':counts,'excluded_conditional_or_native_cases':excluded,'actual_raw_capture':{'command':command,'input':text,'input_sha256':sha(text.encode()),'jsonl':p.stdout.decode(),'sha256':sha(p.stdout),'exit_code':0,'cli_sha256':sha(Path(command[0]).read_bytes())},'observations':observations,'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},'scope':'Append-only proposal for77finite structures:19complete original occurrences,35required/five-forbidden authored allomorph cases,12required/six-forbidden derived/auxiliary owner cases. Nine conditional/Native policy cases stay outside raw global judgments. Every actual proposed required path is present and every proposed forbidden path absent; all other candidate hypotheses remain unjudged. Main integration and Rust global-ledger validation remain pending.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Actual append-only77case proposal:',dict(counts),'; excluded',len(excluded),flush=True)
