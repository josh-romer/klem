"""Run every Rust target with bounded disk use and a complete immutable input receipt."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = P.parents[1]
W = P.parent / 'friendly-command-gena'
O = P / 'friendly-command-gena-promotion-full-rust.json'
L = P / 'friendly-command-gena-promotion-full-rust.log'
TARGET = ROOT / '.direnv/friendly-command-gena-promotion-full-serial-target'
assert not O.exists() and not L.exists() and TARGET.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=W)
names = git('ls-files','--cached','--others','--exclude-standard','-z').decode().split('\0')[:-1]
frozen = {n:sha((W/n).read_bytes()) for n in names}
head, index = git('rev-parse','HEAD').decode().strip(), sha(git('ls-files','--stage','-z'))
binding_path = P / 'friendly-command-gena-complete-runtime-binding.json'
binding = json.loads(binding_path.read_bytes())
assert binding['state']=='passed' and all(frozen[n]==d for n,d in binding['production_inputs'].items())
sena_binding = json.loads((P.parent/'friendly-hortative-sena-prepared/friendly-hortative-sena-complete-runtime-binding.json').read_bytes())
protected = {b['path']:b['sha256'] for b in sena_binding['binaries'].values()} | sena_binding['protected_parent_binaries']
assert len(protected)==6
assert all(sha(Path(p).read_bytes())==d for p,d in protected.items())
temp=P/'rust-serial-temp';temp.mkdir(exist_ok=True)
overrides=dict(CARGO_TARGET_DIR=str(TARGET),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',
               CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',TMPDIR=str(temp),PYTHONDONTWRITEBYTECODE='1')
env=dict(os.environ,**overrides)
metadata_command=['cargo','metadata','--locked','--offline','--no-deps','--format-version','1']
metadata_raw=subprocess.check_output(metadata_command,cwd=W,env=env)
metadata=json.loads(metadata_raw)
package=next(p for p in metadata['packages'] if p['manifest_path']==str(W/'Cargo.toml'))
targets=package['targets']
assert targets and all(t['kind'] in [['lib'],['bin'],['test'],['example']] for t in targets), 'every original cargo target accounted for'
r=dict(state='running',head=head,index_sha256=index,frozen_inputs=frozen,protected_binaries=protected,
       production_inputs=binding['production_inputs'],runtime_binding_sha256=sha(binding_path.read_bytes()),
       environment_overrides=overrides,fresh_disposable_target=True,actual_shared_cases=35764,actual_scoped_reviews=520,cargo_metadata_command=metadata_command,cargo_metadata=json.loads(metadata_raw),
       cargo_metadata_sha256=sha(metadata_raw),all_targets=targets,results=[],removed_disposable_test_executables=[],
       producer=dict(text=Path(__file__).read_text(),sha256=sha(Path(__file__).read_bytes())),
       started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
       scope='Actual Gena35764-case/520-review promotion. Every Cargo metadata target tested once, preserving complete lib/bin/integration/example scope of --all-targets. Only disposable own test harness executables removed after successful test execution to bound disk use; original/fresh CLI and every protected parent binary retained. Full warning-denied all-targets Clippy, formatting,715-source queue and diff follow. No fullNix/browser/installed/quiet/contextual-review claim.')
def save():
    O.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
    with L.open('xb') as log:
        commands=[(['cargo','fmt','--all','--','--check'],None)]
        for target in targets:
            flag={'lib':'--lib','bin':'--bin','test':'--test','example':'--example'}[target['kind'][0]]
            selector=[flag] if flag=='--lib' else [flag,target['name']]
            commands.append((['cargo','test','--locked','--offline','--features','web','--message-format','json',*selector],target))
        commands.extend([(c,None) for c in [
            ['cargo','clippy','--locked','--offline','--all-targets','--features','web','--','-D','warnings'],
            ['python3','tools/review_inventory.py','--verify'],['git','diff','--check']]])
        for command,target in commands:
            log.write(('COMMAND '+json.dumps(command)+'\n').encode());log.flush()
            artifacts=[]
            process=subprocess.Popen(command,cwd=W,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            try:
                for line in process.stdout:
                    log.write(line);log.flush()
                    if line.startswith(b'{'):
                        try:value=json.loads(line)
                        except json.JSONDecodeError:continue
                        if target is not None and value.get('reason')=='compiler-artifact' and value.get('executable') and value['profile']['test'] and value['target']['name']==target['name'] and value['target']['kind']==target['kind']:
                            artifacts.append(value['executable'])
                code=process.wait()
            finally:
                if process.poll() is None:process.terminate();process.wait()
            r['results'].append(dict(command=command,exit_code=code,target=target))
            assert code==0,'Actual complete serial Rust gate failed; full original log and partial target records retained.'
            for name in sorted(set(artifacts)):
                path=Path(name)
                assert (path.is_relative_to(TARGET/'debug/deps') or target['kind']==['example'] and path.is_relative_to(TARGET/'debug/examples')) and not path.is_symlink(), 'only this run disposable test harnesses'
                r['removed_disposable_test_executables'].append(dict(path=name,sha256=sha(path.read_bytes()),bytes=path.stat().st_size,target=target['name']))
                path.unlink()
            save()
            print(target['name'] if target is not None else command[0:2],'exit',code,flush=True)
    assert [x['target'] for x in r['results'] if x['target'] is not None]==targets, 'entire unchanged Cargo target inventory executed'
    assert len(targets)==255 and len(r['results'])==259, 'complete actual255target inventory andfourrequiredcommands'
    r['state']='passed'
except BaseException as error:
    r.update(state='failed',error=repr(error));raise
finally:
    text=L.read_text() if L.exists() else ''
    totals=dict(passed=0,failed=0,ignored=0)
    batches=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    for batch in batches:
        for key,n in zip(totals,batch,strict=True):totals[key]+=int(n)
    r.update(rust_totals=totals,rust_batches=len(batches),
             inputs_unchanged=all(sha((W/n).read_bytes())==d for n,d in frozen.items()),
             protected_binaries_unchanged=all(sha(Path(p).read_bytes())==d for p,d in protected.items()),
             head_unchanged=git('rev-parse','HEAD').decode().strip()==head,
             index_unchanged=sha(git('ls-files','--stage','-z'))==index,
             log_sha256=sha(L.read_bytes()) if L.exists() else None,
             finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ['inputs_unchanged','protected_binaries_unchanged','head_unchanged','index_unchanged']):r['state']='failed'
    save()
assert r['state']=='passed' and r['rust_totals']==dict(passed=1200,failed=0,ignored=1) and r['rust_batches']==255
print('Actual entire Rust target inventory passed:',r['rust_totals'],'batches',r['rust_batches'],'allSource/HEAD/index/protected binaries unchanged.',flush=True)
