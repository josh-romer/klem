"""Record complete controls without changing the frozen Sena worktree."""
import datetime
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
W = P.parent / 'friendly-hortative-sena'
OUT = P / 'sena-ledger-prepared-guard-controls.json'
LOG = P / 'sena-ledger-prepared-guard-controls.log'
assert not OUT.exists() and not LOG.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=W)
source = {name: sha((W / name).read_bytes())
          for name in git('ls-files', '-z').decode().split('\0')[:-1]}
head = git('rev-parse', 'HEAD').decode().strip()
index = sha(git('ls-files', '--stage', '-z'))
prepared = {name: sha((P / name).read_bytes()) for name in (
    'friendly_hortative_sena_ledger_audit.py', 'test_friendly_hortative_sena_ledger_audit.py',
    'friendly_hortative_sena_ledger_draft_audit.py', 'test_friendly_hortative_sena_ledger_draft_audit.py')}
r = dict(state='running', head=head, index_sha256=index, source_inputs=source,
         prepared_inputs=prepared, results=[],
         producer=dict(text=Path(__file__).read_text(), sha256=sha(Path(__file__).read_bytes())),
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         scope='Only prepared append guard: original12 draft controls plus18 actual-tail corruption controls. No shared promotion or runtime/Nix claim.')
def save():
    OUT.write_text(json.dumps(r, indent=2) + '\n')
save()
try:
    with LOG.open('xb') as log:
        for pattern, count in [('test_friendly_hortative_sena_ledger_draft_audit.py', 12),
                               ('test_friendly_hortative_sena_ledger_audit.py', 18)]:
            command = ['python3', '-m', 'unittest', 'discover', '-s', str(P), '-p', pattern]
            log.write(('COMMAND ' + json.dumps(command) + '\n').encode()); log.flush()
            job = subprocess.run(command, cwd=W, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            log.write(job.stdout); log.flush()
            r['results'].append(dict(command=command, exit_code=job.returncode, stdout=job.stdout.decode())); save()
            assert job.returncode == 0
            assert re.search(rb'Ran ' + str(count).encode() + rb' tests in ', job.stdout)
            assert job.stdout.rstrip().endswith(b'OK')
    r.update(state='passed', controls=30, actual_shared_promotion=False)
except BaseException as error:
    r.update(state='failed', error=repr(error)); raise
finally:
    r.update(source_unchanged=all(sha((W / name).read_bytes()) == digest for name, digest in source.items()),
             head_unchanged=git('rev-parse', 'HEAD').decode().strip() == head,
             index_unchanged=sha(git('ls-files', '--stage', '-z')) == index,
             prepared_inputs_unchanged=all(sha((P / name).read_bytes()) == digest for name, digest in prepared.items()),
             log_sha256=sha(LOG.read_bytes()), completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if not all(r[k] for k in ('source_unchanged', 'head_unchanged', 'index_unchanged', 'prepared_inputs_unchanged')):
        r['state'] = 'failed'
    save()
assert r['state'] == 'passed'
print('Prepared Sena guard:12 original draft plus18 complete-tail controls passed; Source/HEAD/index unchanged.', flush=True)
