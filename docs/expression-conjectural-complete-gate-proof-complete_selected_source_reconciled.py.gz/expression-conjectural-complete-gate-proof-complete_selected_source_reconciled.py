"""Complete the unchanged actual selected-source precheck after an invocation error."""
import datetime,hashlib,json,os,subprocess
from pathlib import Path
prep=Path(__file__).resolve().parent;work=Path('/tmp/klem-expression-conjectural-main')
parent_path=prep/'combined-selected-inventory-source-reconciled-retry1.json';parent=json.loads(parent_path.read_text())
assert parent['state']=='failed' and len(parent['runs'])==19 and all(r['exit_code']==0 for r in parent['runs'][:18]) and parent['runs'][18]['exit_code']==2
assert all(parent[k] for k in ['inputs_unchanged','head_unchanged','index_unchanged'])
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
assert hashlib.sha256(parent['producer']['text'].encode()).hexdigest()==parent['producer']['sha256']
source=Path(parent['actual_inventory_source']);head=parent['head'];index=parent['index_sha256'];frozen=parent['all_tracked_files'];selected=parent['actual_selected_files']
def unchanged():
 return all(sha(work/n)==d for n,d in frozen.items()) and all(sha(source/n)==d['sha256'] and (source/n).stat().st_size==d['bytes'] for n,d in selected.items()) and subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==head and hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=work)).hexdigest()==index
assert unchanged() and not subprocess.check_output(['git','status','--porcelain'],cwd=work)
inherited=[]
for i,run in enumerate(parent['runs'][:18]):
 log=prep/('combined-selected-inventory-reconciled-retry1-audit-'+str(i)+'.log');assert sha(log)==run['log_sha256']
 if run['controls']:assert 'Ran '+str(run['controls'])+' tests' in log.read_text() and log.read_text().rstrip().endswith('OK')
 inherited.append(dict(run,log=str(log)))
assert sum(r['controls'] or 0 for r in inherited)==173
commands=[(['python3','tools/literary_question_geona_runtime.py','--report','docs/literary-question-geona-packaged-cli-replay.json'],None),(['python3','-m','unittest','discover','-s','tools','-p','test_literary_question_geona_runtime.py'],94),(['python3','tools/review_inventory.py','--verify'],None),(['python3','-m','unittest','discover','-s','tools','-p','test_review_inventory.py'],10)]
out=prep/'combined-selected-inventory-source-reconciled-complete.json';assert not out.exists()
r={'state':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'index_sha256':index,'all_tracked_files':frozen,'actual_inventory_source':str(source),'actual_selected_files':selected,'parent_receipt':str(parent_path),'parent_receipt_sha256':sha(parent_path),'inherited_successes':inherited,'runs':[],'producer':{'text':Path(__file__).read_text(),'sha256':sha(Path(__file__))},'scope':'Reuse only the eighteen successful commands/173controls whose complete actual immutable selected Source, tracked inputs, HEAD/index and logs remain byte-identical. Preserve the failed missing-report invocation separately. Run exactly the four remaining source-selected commands with the actual flake report argument. Full corrected Nix and main/timing/wider contextual review remain pending.'}
def save():out.write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 for i,(command,controls) in enumerate(commands):
  log=prep/('combined-selected-inventory-reconciled-complete-'+str(i)+'.log')
  with log.open('xb') as f:job=subprocess.run(command,cwd=source,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=f,stderr=subprocess.STDOUT)
  r['runs'].append({'command':command,'controls':controls,'exit_code':job.returncode,'log':str(log),'log_sha256':sha(log)})
  r['inputs_head_index_source_unchanged']=unchanged();save();print(i,job.returncode,'complete frozen source',r['inputs_head_index_source_unchanged'],flush=True)
  assert job.returncode==0 and r['inputs_head_index_source_unchanged'],log
  if controls:assert 'Ran '+str(controls)+' tests' in log.read_text() and log.read_text().rstrip().endswith('OK')
 r.update(state='passed',exit_code=0,controls=173+sum(c for _,c in commands if c),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());assert r['controls']==277
except Exception as error:r.update(state='failed',error=str(error));raise
finally:save()
