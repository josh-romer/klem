"""Retain full original sentence/filter outputs and every new geona path in isolation."""
import datetime,gzip,hashlib,json,subprocess,unicodedata
from pathlib import Path
ROOT=Path('/home/josh/projects/klem');PROTO=Path('/tmp/klem-literary-question-geona-prototype');CLI=Path('/tmp/klem-literary-question-geona-cli');DB=ROOT/'data/dictionaries/krdict/krdict.db';OUT=Path('/tmp/klem-literary-question-geona-prototype-source-replay.json.gz');assert not OUT.exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest();read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if str(p).endswith('.gz') else p.read_bytes())
source_path=ROOT/'docs/literary-question-geona-source-discovery.json.gz';prepared_path=ROOT/'docs/literary-question-geona-original-preparation.json.gz';source=read(source_path);prepared=read(prepared_path);build=read(Path('/tmp/klem-literary-question-geona-build-preparation.json'))
snapshot={n:{'bytes':(PROTO/n).stat().st_size,'sha256':sha((PROTO/n).read_bytes())} for n in build['initial_copied_files']}
changes={n:{'before_sha256':row['sha256'],'after_sha256':snapshot[n]['sha256'],'before_text':(ROOT/n).read_text(),'after_text':(PROTO/n).read_text()} for n,row in build['initial_copied_files'].items() if row!=snapshot[n]};assert set(changes)=={'src/grammar.rs','src/engine.rs','src/dictionary/attachment.rs','web/src/grammar-labels.json'}
frozen={str(p):sha(p.read_bytes()) for p in [CLI,DB,source_path,prepared_path,Path(__file__)]}
def match(a,c):
 e=c['expected'];return [l['text'] for l in a['lemmas']]==e['lemmas'] and [l['kind'] for l in a['lemmas']]==e['lemma_kinds'] and [m['form'] for m in a['morphemes']]==e['morphemes'] and [m['kind'] for m in a['morphemes']]==e['morpheme_kinds'] and set(e['required_rules'])<=set(a['rules'])
runs=[];observations=[];deltas=[];ids=set()
for encoding in ['NFC','NFD']:
 for mode,flags in [('raw',[]),('headword',['--dict-only']),('compatible',['--dict-compatible'])]:
  text=unicodedata.normalize(encoding,source['input']);command=[str(CLI),'text','-','--dictionary',str(DB),*flags];job=subprocess.run(command,input=text.encode(),capture_output=True,check=True);after=list(map(json.loads,job.stdout.splitlines()));old=next(r for r in source['runs'] if r['encoding']==encoding and r['mode']==mode);before=list(map(json.loads,old['jsonl'].splitlines()));assert len(after)==len(before)
  cursor=0
  for oldrow,newrow in zip(before,after,strict=True):
   for key in ['surface','span','kind']:assert oldrow[key]==newrow[key]
   assert newrow['span']['start']==cursor and text.encode()[cursor:newrow['span']['end']].decode()==newrow['surface'];cursor=newrow['span']['end']
   if not oldrow.get('analysis'):assert oldrow==newrow;continue
   a=oldrow['analysis']['analyses'];b=newrow['analysis']['analyses'];assert [path for path in b if path in a]==a
   for path,assessment in zip(a,oldrow['dictionary']['readings'],strict=True):assert newrow['dictionary']['readings'][b.index(path)]==assessment
   new=[(i,path) for i,path in enumerate(b) if path not in a]
   if new:
    deltas.append({'encoding':encoding,'mode':mode,'surface':newrow['surface'],'span':newrow['span'],'before':oldrow,'after':newrow,'new_paths':[{'analysis':p,'assessment':newrow['dictionary']['readings'][i]} for i,p in new],'contextual_verdict':'unjudged','independent_review':'pending'})
    owners={(v['lemma']['text'],v['lemma']['kind']):v['entries'] for v in newrow['dictionary']['lemmas']}
    for _,path in new:
     for lemma in path['lemmas']:ids.update(v['id'] for v in owners[(lemma['text'],lemma['kind'])])
  assert cursor==len(text.encode())
  for case in prepared['original_cases']:
   row=next(v for v in after if v.get('analysis') and v['analysis']['normalized']==case['surface']);targets=[(i,a) for i,a in enumerate(row['analysis']['analyses']) if match(a,case)];assert len(targets)==1,case['id'];i,path=targets[0];assessment=row['dictionary']['readings'][i];assert assessment['status']!='incompatible';assert assessment['status']==('unknown' if case['surface']=='좋을거나' else 'compatible'),(case['id'],assessment)
   observations.append({'encoding':encoding,'mode':mode,'case_id':case['id'],'surface':case['surface'],'analysis':path,'assessment':assessment,'source_occurrence':case['source_occurrence'],'contextual_verdict':'unjudged'})
  runs.append({'encoding':encoding,'mode':mode,'command':command,'exit_code':0,'jsonl':job.stdout.decode(),'sha256':sha(job.stdout),'records':len(after),'all_prior_candidate_paths_and_assessments_preserved':True});print(encoding,mode,len(after),'source frames and8required structures retained',flush=True)
assert len(observations)==48 and all(sha(Path(p).read_bytes())==h for p,h in frozen.items()) and all(sha((PROTO/n).read_bytes())==row['sha256'] for n,row in snapshot.items()) and all(sha((ROOT/n).read_bytes())==row['sha256'] for n,row in build['parent_snapshot_files'].items())
producer=Path(__file__);r={'schema_version':1,'state':'passed','exit_code':0,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cli':str(CLI),'cli_sha256':frozen[str(CLI)],'snapshot_files':snapshot,'parent_snapshot_files':build['parent_snapshot_files'],'changes':changes,'input':source['input'],'runs':runs,'original_observations':observations,'candidate_deltas':deltas,'matched_new_owner_ids':sorted(ids),'source_capture_sha256':frozen[str(source_path)],'preparation_sha256':frozen[str(prepared_path)],'frozen_inputs':frozen,'inputs_unchanged':True,'root_parent_inputs_unchanged':True,'producer':{'text':producer.read_text(),'sha256':sha(producer.read_bytes())},'scope':'Actual independent CLI-only geona prototype. All eight original groups/48Unicode-filter paths pass, full original sentence records and native assessments are retained, every prior path/assessment is conserved and every new path is individually unjudged. Bare adjective/copy-owner tension remains Unknown; listed verb paths remain Compatible. Initial65non-test build inputs are frozen; this is not full Rust, main integration, broad/corpus/history, package or browser validation.'}
OUT.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Saved full original source replay and',len(deltas),'mode-specific changed source frames; owners',len(ids),flush=True)
