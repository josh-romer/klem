"""Preserve the suffix owner separately from the original word-only Native closure."""
import gzip,hashlib,json,sqlite3,sys
from pathlib import Path
prep=Path(__file__).resolve().parent;root=Path('/home/josh/projects/klem');out=prep/'gentle-command-suffix-native-closure.json.gz';assert not out.exists()
sys.path.insert(0,str(root/'tools'));from native_lmf import entry
with sqlite3.connect((root/'.direnv/dictionary-restoration/krdict.db').resolve().as_uri()+'?mode=ro',uri=True) as db:
 rows=list(db.execute('SELECT data FROM entries WHERE headword=?',('-답다',)));assert len(rows)==1;expected=json.loads(rows[0][0])
assert expected['id']=='krdict:92145' and expected['pos']=='접사'
originals=[];exports={};sha=lambda raw:hashlib.sha256(raw).hexdigest()
for source in sorted((root/'.direnv/dictionary-restoration/2026-09').glob('*.json')):
 raw=source.read_bytes();exports[source.name]={'bytes':len(raw),'sha256':sha(raw)}
 originals.extend(v for v in json.loads(raw)['LexicalResource']['Lexicon']['LexicalEntry'] if v['val']=='92145')
assert len(exports)==11 and len(originals)==1 and entry(originals[0])==expected
for name,value in [('gentle-command-suffix-native.json',{'LexicalResource':{'Lexicon':{'LexicalEntry':originals}}}),('gentle-command-suffix-native-entries.json',{expected['id']:expected})]:
 p=prep/name;assert not p.exists();p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
prior=gzip.decompress((prep/'gentle-command-original-native-closure.json.gz').read_bytes());assert expected['id'] not in json.loads(prior)['complete_imported_entries']
r=dict(state='complete-original-suffix-owner-preserved-separately',original_native_entries={expected['id']:originals[0]},complete_imported_entries={expected['id']:expected},original_exports=exports,prior_word_only_closure_sha256=sha(prior),prior_word_only_owners=40,total_word_and_suffix_owners=41,producer={'text':Path(__file__).read_text(),'sha256':sha(Path(__file__).read_bytes())},scope='The previous word-only closure excludes non-word lexical units. Preserve suffix-답다 as a separate original owner; no 학생답다 dictionary headword is invented. Original40owners and every source/group/proposal/baseline remain unchanged. No runtime or semantic gold judgment added.')
out.write_bytes(gzip.compress((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0));print('Preserved suffix owner92145 separately; all40word owners unchanged; 41total originalNative owners')
