"""Verify promoted source/copula/global-ledger cases without touching frozen main."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

PREP = Path(__file__).resolve().parent
WORK = Path('/tmp/klem-conjectural-additive-integration')
OUT = PREP / 'conjectural-integration-novel-focused.json'
assert not OUT.exists()
sha = lambda p: hashlib.file_digest(Path(p).open('rb'), 'sha256').hexdigest()
files = [WORK / 'Cargo.toml', WORK / 'Cargo.lock']
for folder in ['src', 'tests', 'tools', 'web/src']:
    files.extend(path for path in (WORK / folder).rglob('*') if path.is_file())
files.append(Path(__file__))
frozen = {str(path): sha(path) for path in sorted(set(files))}
commands = [['cargo', 'fmt', '--all', '--', '--check'],
            ['cargo', 'test', '--locked', '--offline', '--features', 'web', '--test', 'conjectural_additive', '--test', 'conjectural_additive_copula', '--test', 'conjectural_additive_novel', '--test', 'validity'],
            ['cargo', 'clippy', '--locked', '--offline', '--all-targets', '--features', 'web', '--', '-D', 'warnings']]
env = dict(os.environ, CARGO_TARGET_DIR='/tmp/klem-conjectural-additive-integration-target',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='4')
r = {'state': 'running', 'pid': os.getpid(), 'frozen_inputs': frozen, 'runs': [],
     'scope': 'Whole format, eleven Source/copula/novel tests and four complete global ledger tests plus all-target web-feature Clippy with warnings denied. Exact35628previous serialized cases retained; only15 original-context cases/16 independently authored targets appended. Native29 exactfields, complete original context/Unicode/filter/cache/CLI-library parity. Production unchanged since the complete1158pass checkpoint. Full updatedRust/Nix/installed/main and wider contextual/independent review remain separate.'}
OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
for ordinal, command in enumerate(commands):
    log = PREP / f'conjectural-integration-novel-focused-{ordinal}.log'
    assert not log.exists()
    with log.open('wb') as handle:
        code = subprocess.run(command, cwd=WORK, env=env, stdout=handle, stderr=subprocess.STDOUT).returncode
    r['runs'].append({'command': command, 'exit_code': code, 'log_sha256': sha(log)})
    r['inputs_unchanged'] = all(sha(path) == digest for path, digest in frozen.items())
    OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
    print(command, code, 'inputs unchanged', r['inputs_unchanged'], flush=True)
    if code or not r['inputs_unchanged']:
        r['state'] = 'failed'
        OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
        raise SystemExit(code or 1)
r['state'] = 'passed'
r['producer'] = {'text': Path(__file__).read_text(), 'sha256': sha(Path(__file__))}
OUT.write_text(json.dumps(r, ensure_ascii=False, indent=2) + '\n')
